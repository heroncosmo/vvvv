#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const conversationId = "0b98d398-3162-4e98-9200-33c7dfd5623e";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

(async () => {
  const client = await pool.connect();
  try {
    const conversation = await client.query(
      `SELECT c.id, c.connection_id, c.contact_number, c.remote_jid, c.contact_name,
              c.last_message_text, c.last_message_time, c.last_message_from_me,
              c.unread_count, c.needs_human_attention, c.followup_active,
              wc.user_id, wc.phone_number AS connection_phone, wc.name AS connection_name,
              u.email AS owner_email, u.name AS owner_name
         FROM conversations c
         LEFT JOIN whatsapp_connections wc ON wc.id = c.connection_id
         LEFT JOIN users u ON u.id = wc.user_id
        WHERE c.id = $1`,
      [conversationId],
    );
    const messages = await client.query(
      `SELECT id, timestamp, from_me, is_from_agent, media_type, status, text
         FROM messages
        WHERE conversation_id = $1
        ORDER BY timestamp ASC
        LIMIT 140`,
      [conversationId],
    );
    console.log(JSON.stringify({
      ok: true,
      conversation: conversation.rows[0] || null,
      messages: messages.rows,
    }, null, 2));
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
