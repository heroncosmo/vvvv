#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const email = "tititidabeleza@gmail.com";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

function cleanRow(row) {
  return Object.fromEntries(
    Object.entries(row).map(([key, value]) => {
      if (value instanceof Date) return [key, value.toISOString()];
      return [key, value];
    }),
  );
}

(async () => {
  const client = await pool.connect();
  try {
    const users = await client.query(
      `SELECT id, email, name, phone, whatsapp_number, role, onboarding_completed, created_at, updated_at
         FROM users
        WHERE lower(email) = lower($1)
        LIMIT 5`,
      [email],
    );

    const result = { ok: true, email, users: [] };
    for (const user of users.rows) {
      const userId = user.id;
      const subscriptions = await client.query(
        `SELECT to_jsonb(s) - 'metadata' AS subscription,
                p.nome AS plan_catalog_name, p.valor AS plan_catalog_value
           FROM subscriptions s
           LEFT JOIN plans p ON p.id = s.plan_id
          WHERE s.user_id = $1
          ORDER BY s.created_at DESC
          LIMIT 10`,
        [userId],
      );

      const connections = await client.query(
        `SELECT to_jsonb(whatsapp_connections) AS connection
           FROM whatsapp_connections
          WHERE user_id = $1
          ORDER BY created_at ASC`,
        [userId],
      );

      const connectionIds = connections.rows.map((row) => row.connection.id);
      let tenantConversations = { rows: [] };
      let disabledConversations = { rows: [] };
      let recentMessages = { rows: [] };

      if (connectionIds.length > 0) {
        tenantConversations = await client.query(
          `SELECT to_jsonb(conversations) AS conversation
             FROM conversations
            WHERE connection_id = ANY($1::uuid[])
            ORDER BY last_message_time DESC NULLS LAST
            LIMIT 50`,
          [connectionIds],
        );

        disabledConversations = await client.query(
          `SELECT to_jsonb(adc) AS disabled,
                  to_jsonb(c) - 'share_token' AS conversation
             FROM agent_disabled_conversations adc
             JOIN conversations c ON c.id = adc.conversation_id
            WHERE c.connection_id = ANY($1::uuid[])
            ORDER BY adc.updated_at DESC
            LIMIT 100`,
          [connectionIds],
        );

        recentMessages = await client.query(
          `SELECT to_jsonb(m) - 'media_data' AS message,
                  c.contact_number, c.contact_name
             FROM messages m
             JOIN conversations c ON c.id = m.conversation_id
            WHERE c.connection_id = ANY($1::uuid[])
              AND m.timestamp >= NOW() - INTERVAL '7 days'
            ORDER BY m.timestamp DESC
            LIMIT 80`,
          [connectionIds],
        );
      }

      result.users.push({
        user: cleanRow(user),
        subscriptions: subscriptions.rows.map(cleanRow),
        connections: connections.rows.map(cleanRow),
        tenantConversations: tenantConversations.rows.map(cleanRow),
        disabledConversations: disabledConversations.rows.map(cleanRow),
        recentMessages: recentMessages.rows.map(cleanRow),
      });
    }

    console.log(JSON.stringify(result, null, 2));
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
