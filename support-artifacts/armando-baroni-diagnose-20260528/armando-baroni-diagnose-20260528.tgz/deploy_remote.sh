#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const email = "tititidabeleza@gmail.com";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

function cleanRow(row) {
  return Object.fromEntries(
    Object.entries(row).map(([key, value]) => {
      if (value instanceof Date) return [key, value.toISOString()];
      return [key, value];
    }),
  );
}

(async () => {
  const client = await pool.connect();
  try {
    const users = await client.query(
      `SELECT id, email, name, phone, whatsapp_number, role, onboarding_completed, created_at, updated_at
         FROM users
        WHERE lower(email) = lower($1)
        LIMIT 5`,
      [email],
    );

    const result = { ok: true, email, users: [] };
    for (const user of users.rows) {
      const userId = user.id;
      const subscriptions = await client.query(
        `SELECT s.id, s.status, s.amount, s.coupon_price, s.data_inicio, s.data_fim,
                s.next_payment_date, s.pending_receipt, s.created_at, s.updated_at,
                p.nome AS plan_catalog_name, p.valor AS plan_catalog_value
           FROM subscriptions s
           LEFT JOIN plans p ON p.id = s.plan_id
          WHERE s.user_id = $1
          ORDER BY s.created_at DESC
          LIMIT 10`,
        [userId],
      );

      const connections = await client.query(
        `SELECT id, user_id, phone_number, name, is_connected, status, provider, provider_status,
                connection_method, is_primary, last_qr_reconnect_cutoff, created_at, updated_at
           FROM whatsapp_connections
          WHERE user_id = $1
          ORDER BY created_at ASC`,
        [userId],
      );

      const connectionIds = connections.rows.map((row) => row.id);
      let tenantConversations = { rows: [] };
      let disabledConversations = { rows: [] };
      let recentMessages = { rows: [] };

      if (connectionIds.length > 0) {
        tenantConversations = await client.query(
          `SELECT id, connection_id, contact_number, remote_jid, contact_name, last_message_text,
                  last_message_time, last_message_from_me, unread_count, needs_human_attention,
                  followup_active, orchestration_mode, updated_at
             FROM conversations
            WHERE connection_id = ANY($1::uuid[])
            ORDER BY last_message_time DESC NULLS LAST
            LIMIT 50`,
          [connectionIds],
        );

        disabledConversations = await client.query(
          `SELECT adc.conversation_id, c.connection_id, c.contact_number, c.contact_name,
                  c.last_message_text, c.last_message_time, c.last_message_from_me,
                  adc.owner_last_reply_at, adc.auto_reactivate_after_minutes,
                  adc.client_has_pending_message, adc.client_last_message_at,
                  adc.created_at, adc.updated_at
             FROM agent_disabled_conversations adc
             JOIN conversations c ON c.id = adc.conversation_id
            WHERE c.connection_id = ANY($1::uuid[])
            ORDER BY adc.updated_at DESC
            LIMIT 100`,
          [connectionIds],
        );

        recentMessages = await client.query(
          `SELECT m.id, m.conversation_id, c.contact_number, c.contact_name, m.from_me,
                  m.is_from_agent, m.text, m.timestamp, m.status
             FROM messages m
             JOIN conversations c ON c.id = m.conversation_id
            WHERE c.connection_id = ANY($1::uuid[])
              AND m.timestamp >= NOW() - INTERVAL '7 days'
            ORDER BY m.timestamp DESC
            LIMIT 80`,
          [connectionIds],
        );
      }

      result.users.push({
        user: cleanRow(user),
        subscriptions: subscriptions.rows.map(cleanRow),
        connections: connections.rows.map(cleanRow),
        tenantConversations: tenantConversations.rows.map(cleanRow),
        disabledConversations: disabledConversations.rows.map(cleanRow),
        recentMessages: recentMessages.rows.map(cleanRow),
      });
    }

    console.log(JSON.stringify(result, null, 2));
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
