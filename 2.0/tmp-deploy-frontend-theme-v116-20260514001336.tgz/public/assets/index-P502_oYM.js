import{r as i}from"./main-DPMm__h1.js";import"./index-CFiobzNL.js";const r=i("PushNotifications",{});export{r as PushNotifications};
