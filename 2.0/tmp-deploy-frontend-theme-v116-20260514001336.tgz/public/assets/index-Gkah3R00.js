import{r as i}from"./main-CSpmhfE4.js";import"./index-BMbSZjhq.js";const r=i("PushNotifications",{});export{r as PushNotifications};
