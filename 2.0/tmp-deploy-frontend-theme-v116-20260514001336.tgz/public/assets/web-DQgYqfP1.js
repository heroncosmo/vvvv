import{W as n}from"./main-DPMm__h1.js";import"./index-CFiobzNL.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
