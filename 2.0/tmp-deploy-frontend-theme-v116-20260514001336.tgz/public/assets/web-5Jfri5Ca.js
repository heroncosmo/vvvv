import{W as n}from"./main-CSpmhfE4.js";import"./index-BMbSZjhq.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
