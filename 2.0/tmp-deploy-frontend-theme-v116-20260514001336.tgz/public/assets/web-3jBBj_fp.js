import{W as n}from"./main-BEiQ6R89.js";import"./index-KahnIpuo.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
