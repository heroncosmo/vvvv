import{r as i}from"./main-BEiQ6R89.js";import"./index-KahnIpuo.js";const r=i("PushNotifications",{});export{r as PushNotifications};
