﻿#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:frontend-theme-v114-20260513235954"
EXPECTED_BASE="agentezap-app:frontend-theme-v113-20260513235054"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-frontend-theme-v114-20260513235954"
SESSIONS_DIR="/data/agentezap/sessions"

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_restart=${current_restart}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 1
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi

cd "$DEPLOY_DIR"

check_file() {
  local file="$1"
  echo "[deploy] checking artifact file: ${file}"
  test -f "$file"
}
check_grep() {
  local pattern="$1"
  local file="$2"
  echo "[deploy] checking artifact grep: ${pattern} in ${file}"
  grep -aR -m 1 -- "$pattern" "$file" >/dev/null
}

check_file public/index.html
check_file public/sw.js
check_file public/assets/main-CUpfqkUu.css
check_file public/assets/main-CSpmhfE4.js
check_file public/assets/index-BMbSZjhq.js
check_grep '--background: 210 20% 97%' public/assets/main-CUpfqkUu.css
check_grep 'az-chat-surface' public/assets/main-CUpfqkUu.css
check_grep '#DCF8C6' public/assets/main-CUpfqkUu.css
check_grep '.pl-12' public/assets/main-CUpfqkUu.css
check_grep 'index-BMbSZjhq.js' public/index.html
check_grep 'main-CSpmhfE4.js' public/assets/index-BMbSZjhq.js
check_grep 'main-CUpfqkUu.css' public/assets/index-BMbSZjhq.js
check_grep 'paddingLeft:"3rem"' public/assets/main-CSpmhfE4.js

cat > Dockerfile <<EOF
FROM ${current_image}
COPY public /app/dist/public
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-frontend-theme-v114-20260513235954"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path(".env.runtime")
desired = {
    "AGENTEZAP_APP_IMAGE": tag,
    "NODE_OPTIONS": "--max-old-space-size=4096",
    "WA_PENDING_TIMERS_START_DURING_RESTORE": "false",
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in desired:
        out.append(f"{key}={desired[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_restart=${running_restart}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during app-only deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi

docker exec agentezap-app sh -lc "grep -aR -m 1 -- '--background: 210 20% 97%' /app/dist/public/assets/main-CUpfqkUu.css >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'az-chat-surface' /app/dist/public/assets/main-CUpfqkUu.css >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- '#DCF8C6' /app/dist/public/assets/main-CUpfqkUu.css >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- '.pl-12' /app/dist/public/assets/main-CUpfqkUu.css >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'index-BMbSZjhq.js' /app/dist/public/index.html >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'main-CSpmhfE4.js' /app/dist/public/assets/index-BMbSZjhq.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'main-CUpfqkUu.css' /app/dist/public/assets/index-BMbSZjhq.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'paddingLeft:\"3rem\"' /app/dist/public/assets/main-CSpmhfE4.js >/dev/null"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"

echo "[deploy] done"


