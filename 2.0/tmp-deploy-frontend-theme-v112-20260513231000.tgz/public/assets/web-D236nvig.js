import{W as n}from"./main-CxSvVP57.js";import"./index-DDQbuOnA.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
