import{r as i}from"./main-CxSvVP57.js";import"./index-DDQbuOnA.js";const r=i("PushNotifications",{});export{r as PushNotifications};
