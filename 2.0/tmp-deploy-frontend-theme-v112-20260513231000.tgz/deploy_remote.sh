#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:frontend-theme-v112-20260513231000"
EXPECTED_BASE="agentezap-app:agendamento3-agent-test-v111-20260513230011"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-frontend-theme-v112-20260513231000"
SESSIONS_DIR="/data/agentezap/sessions"

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_restart=${current_restart}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 1
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi

require_marker() {
  local marker="$1"
  echo "[deploy] checking marker: ${marker}"
  docker exec agentezap-app sh -lc "grep -aR -m 1 '$marker' /app/dist >/dev/null"
}

require_marker "enforcePromptCriticalRentalPaymentRule"
require_marker "resolveBrazilTemporalContext"
require_marker "enforceBrazilTemporalConsistency"
require_marker "evaluateSaaSSubscriptionAccess"
require_marker "applyRotoplastRuntimeMediaGuard"
require_marker "agendamento3-v1-agentic-extractor"
require_marker "temporalToolContract"
require_marker "hasConcreteFirstOpeningRequest"
require_marker "concreteRequest"
require_marker "sync_token"
require_marker "syncMode"

cd "$DEPLOY_DIR"
test -f public/index.html
test -f public/sw.js
test -f public/assets/main-B3ug0T3Y.css
test -f public/assets/main-CxSvVP57.js
grep -aR -m 1 -- '--background: 210 20% 97%' public/assets/main-B3ug0T3Y.css >/dev/null
grep -aR -m 1 -- 'az-chat-surface' public/assets/main-B3ug0T3Y.css >/dev/null
grep -aR -m 1 -- '#DCF8C6' public/assets/main-B3ug0T3Y.css >/dev/null
grep -aR -m 1 -- 'main-B3ug0T3Y.css' public/index.html >/dev/null
grep -aR -m 1 -- 'main-CxSvVP57.js' public/index.html >/dev/null

cat > Dockerfile <<EOF
FROM ${current_image}
COPY public /app/dist/public
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-frontend-theme-v112-20260513231000"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path(".env.runtime")
desired = {
    "AGENTEZAP_APP_IMAGE": tag,
    "NODE_OPTIONS": "--max-old-space-size=4096",
    "WA_PENDING_TIMERS_START_DURING_RESTORE": "false",
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in desired:
        out.append(f"{key}={desired[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_restart=${running_restart}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during app-only deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi

docker exec agentezap-app sh -lc "grep -aR -m 1 'enforcePromptCriticalRentalPaymentRule' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'resolveBrazilTemporalContext' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'enforceBrazilTemporalConsistency' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'hasConcreteFirstOpeningRequest' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'concreteRequest' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'sync_token' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'syncMode' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- '--background: 210 20% 97%' /app/dist/public/assets/main-B3ug0T3Y.css >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'az-chat-surface' /app/dist/public/assets/main-B3ug0T3Y.css >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- '#DCF8C6' /app/dist/public/assets/main-B3ug0T3Y.css >/dev/null"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"

echo "[deploy] done"
