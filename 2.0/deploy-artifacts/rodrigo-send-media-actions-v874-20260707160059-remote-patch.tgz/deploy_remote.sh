#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="${NEW_IMAGE:-agentezap-app:rodrigo-send-media-actions-v874-20260707160059}"
EXPECTED_ACTIVE_IMAGE="${EXPECTED_ACTIVE_IMAGE:-agentezap-app:plus-gate-ready-v873d-20260707150500}"
TMP_CONTAINER="${TMP_CONTAINER:-agentezap-rodrigo-send-media-actions-v874-tmp}"
COMPOSE_DIR="${COMPOSE_DIR:-/opt/agentezap-single/compose}"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

retry_internal_health() {
  local out="/tmp/agentezap-health-rodrigo-send-media-v874.json"
  local attempt
  for attempt in $(seq 1 12); do
    if curl -fsS http://127.0.0.1:5000/api/health > "$out" && grep -F 'monolith' "$out" >/dev/null && grep -F 'full' "$out" >/dev/null; then
      cat "$out"
      return 0
    fi
    sleep 5
  done
  echo "[deploy] api health did not report monolith/full" >&2
  cat "$out" >&2 || true
  return 1
}

patch_runtime_bundles() {
  local container="$1"
  docker exec -i "$container" node <<'NODE'
const fs = require("fs");
const path = require("path");

const distDir = "/app/dist";
const targetArrays = ["RODRIGO_CREATOR_ACTIONS", "RODRIGO_EXISTING_ACCOUNT_ACTIONS"];

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...walk(full));
    } else if (entry.isFile() && full.endsWith(".js")) {
      files.push(full);
    }
  }
  return files;
}

function findMatchingBracket(text, openIndex) {
  let depth = 0;
  let quote = "";
  let escaped = false;
  for (let index = openIndex; index < text.length; index += 1) {
    const char = text[index];
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (char === "\\") {
        escaped = true;
      } else if (char === quote) {
        quote = "";
      }
      continue;
    }
    if (char === "'" || char === '"' || char === "`") {
      quote = char;
      continue;
    }
    if (char === "[") {
      depth += 1;
      continue;
    }
    if (char === "]") {
      depth -= 1;
      if (depth === 0) {
        return index;
      }
    }
  }
  return -1;
}

function findAssignment(text, arrayName) {
  const regex = new RegExp(`\\b${arrayName}\\s*=\\s*\\[`, "g");
  const match = regex.exec(text);
  if (!match) {
    return null;
  }
  const open = text.indexOf("[", match.index);
  const close = findMatchingBracket(text, open);
  if (open < 0 || close < 0) {
    throw new Error(`array_bracket_not_found:${arrayName}`);
  }
  return {
    matchStart: match.index,
    open,
    close,
    body: text.slice(open + 1, close),
  };
}

function hasSendMedia(body) {
  return /['"]send_media['"]/.test(body);
}

function patchArray(text, arrayName) {
  const assignment = findAssignment(text, arrayName);
  if (!assignment) {
    return { text, found: false, patched: false, already: false };
  }
  if (hasSendMedia(assignment.body)) {
    return { text, found: true, patched: false, already: true };
  }
  const baseActions = /(\.\.\.BASE_ACTIONS\s*,)(\s*)/.exec(assignment.body);
  if (!baseActions) {
    throw new Error(`base_actions_anchor_not_found:${arrayName}`);
  }
  const insert = `${baseActions[1]}${baseActions[2]}"send_media",${baseActions[2]}`;
  const newBody =
    assignment.body.slice(0, baseActions.index) +
    insert +
    assignment.body.slice(baseActions.index + baseActions[0].length);
  const patchedText = text.slice(0, assignment.open + 1) + newBody + text.slice(assignment.close);
  return { text: patchedText, found: true, patched: true, already: false };
}

const files = walk(distDir);
const results = [];
let patchedFiles = 0;

for (const file of files) {
  let text = fs.readFileSync(file, "utf8");
  const original = text;
  for (const arrayName of targetArrays) {
    const result = patchArray(text, arrayName);
    text = result.text;
    if (result.found) {
      results.push({
        file,
        arrayName,
        patched: result.patched,
        already: result.already,
      });
    }
  }
  if (text !== original) {
    fs.writeFileSync(file, text);
    patchedFiles += 1;
  }
}

const foundByArray = Object.fromEntries(
  targetArrays.map((arrayName) => [arrayName, results.filter((result) => result.arrayName === arrayName).length]),
);
const patchedCount = results.filter((result) => result.patched).length;
const alreadyCount = results.filter((result) => result.already).length;

console.log(JSON.stringify({
  filesScanned: files.length,
  patchedFiles,
  patchedCount,
  alreadyCount,
  foundByArray,
  results,
}, null, 2));

if (targetArrays.some((arrayName) => foundByArray[arrayName] < 1)) {
  console.error("[deploy] Rodrigo action arrays not found in dist");
  process.exit(60);
}
if (patchedCount < 1 && alreadyCount < targetArrays.length) {
  console.error("[deploy] send_media was not patched or already present");
  process.exit(61);
}
NODE
}

check_runtime_markers() {
  local container="$1"
  docker exec -i "$container" node <<'NODE'
const fs = require("fs");
const path = require("path");

const distDir = "/app/dist";
const targetArrays = ["RODRIGO_CREATOR_ACTIONS", "RODRIGO_EXISTING_ACCOUNT_ACTIONS"];

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...walk(full));
    } else if (entry.isFile() && full.endsWith(".js")) {
      files.push(full);
    }
  }
  return files;
}

function findMatchingBracket(text, openIndex) {
  let depth = 0;
  let quote = "";
  let escaped = false;
  for (let index = openIndex; index < text.length; index += 1) {
    const char = text[index];
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (char === "\\") {
        escaped = true;
      } else if (char === quote) {
        quote = "";
      }
      continue;
    }
    if (char === "'" || char === '"' || char === "`") {
      quote = char;
      continue;
    }
    if (char === "[") {
      depth += 1;
      continue;
    }
    if (char === "]") {
      depth -= 1;
      if (depth === 0) {
        return index;
      }
    }
  }
  return -1;
}

function getArrayBody(text, arrayName) {
  const regex = new RegExp(`\\b${arrayName}\\s*=\\s*\\[`, "g");
  const match = regex.exec(text);
  if (!match) {
    return null;
  }
  const open = text.indexOf("[", match.index);
  const close = findMatchingBracket(text, open);
  if (open < 0 || close < 0) {
    return null;
  }
  return text.slice(open + 1, close);
}

const files = walk(distDir);
const arrays = [];

for (const file of files) {
  const text = fs.readFileSync(file, "utf8");
  for (const arrayName of targetArrays) {
    const body = getArrayBody(text, arrayName);
    if (!body) {
      continue;
    }
    const sendMediaIndex = body.search(/['"]send_media['"]/);
    const askBusinessIndex = body.search(/['"]ask_business_context['"]/);
    arrays.push({
      file,
      arrayName,
      hasSendMedia: sendMediaIndex >= 0,
      sendMediaBeforeAskBusiness: sendMediaIndex >= 0 && askBusinessIndex >= 0 && sendMediaIndex < askBusinessIndex,
    });
  }
}

const httpText = fs.existsSync("/app/dist/api/http.js") ? fs.readFileSync("/app/dist/api/http.js", "utf8") : "";
const publicAssetsDir = "/app/dist/public/assets";
const publicText = fs.existsSync(publicAssetsDir)
  ? fs.readdirSync(publicAssetsDir)
      .filter((name) => name.endsWith(".js"))
      .map((name) => fs.readFileSync(path.join(publicAssetsDir, name), "utf8"))
      .join("\n")
  : "";

const checks = {
  creatorHasSendMedia: arrays.some((entry) => entry.arrayName === "RODRIGO_CREATOR_ACTIONS" && entry.hasSendMedia),
  existingAccountHasSendMedia: arrays.some((entry) => entry.arrayName === "RODRIGO_EXISTING_ACCOUNT_ACTIONS" && entry.hasSendMedia),
  allFoundArraysHaveSendMediaBeforeAskBusiness: arrays.length >= 2 && arrays.every((entry) => entry.hasSendMedia && entry.sendMediaBeforeAskBusiness),
  v872BridgePreserved: httpText.includes("bridgeDueLegacyPendingAIResponsesToVercelQueue") && httpText.includes("cancelled:bridged_to_vercel_agent_queue"),
  backendPro300Preserved: httpText.includes("CHECKOUT_PUBLIC_PRO_MONTHLY_PRICE = 300") && httpText.includes("normalizeCheckoutRenewalMonthlyPrice"),
  plusGateReadyPreserved: publicText.includes("h=!!o&&c!==void 0&&!m&&(c==null?void 0:c.shouldBlock)!==!0"),
};

console.log(JSON.stringify({
  arrays,
  checks,
}, null, 2));

if (Object.values(checks).some((ok) => ok !== true)) {
  process.exit(62);
}
NODE
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
  '
}

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] patching Rodrigo live CLI send_media action contract"
patch_runtime_bundles "$TMP_CONTAINER"
check_runtime_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
if ! docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null; then
  echo "[deploy] docker commit failed; trying export/import fallback"
  docker image rm "$NEW_IMAGE" >/dev/null 2>&1 || true
  docker export "$TMP_CONTAINER" | docker import \
    --change='WORKDIR /app' \
    --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
    --change='CMD ["node","dist/index.js"]' \
    - "$NEW_IMAGE" >/dev/null
fi

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
retry_internal_health >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|ReferenceError|Range out of order|UnhandledPromiseRejection|MODULE_NOT_FOUND'; then
  echo "[deploy] boot errors detected" >&2
  exit 63
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_runtime_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
