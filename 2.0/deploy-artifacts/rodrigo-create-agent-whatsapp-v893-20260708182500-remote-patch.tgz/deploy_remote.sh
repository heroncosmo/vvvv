#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="agentezap-app:rodrigo-create-agent-whatsapp-v893-20260708182500"
EXPECTED_ACTIVE_IMAGE="agentezap-app:rodrigo-create-agent-whatsapp-v892-20260708171204"
TMP_CONTAINER="agentezap-rodrigo-create-agent-whatsapp-v893-tmp"
COMPOSE_DIR="/opt/agentezap-single/compose"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

patch_http_bundle() {
  local container="$1"
  test -s "${SCRIPT_DIR}/http.js"
  docker cp "${SCRIPT_DIR}/http.js" "${container}:/app/dist/api/http.js"
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
  '
}

check_markers() {
  local container="$1"
  docker exec -i "$container" node - <<'NODE'
const fs = require("node:fs");
const source = fs.readFileSync("/app/dist/api/http.js", "utf8");
const checks = {
  createActionSet: source.includes("WEB_ONLY_CREATE_AGENT_ACTION_TYPES"),
  actionExecutor: source.includes("maybeExecuteWebOnlyRodrigoCreateAgentAction"),
  deliveryRenderer: source.includes("renderWebOnlyCodexCreateAgentDeliveryMessage"),
  contractExecutor: source.includes("executeCodexCreateAgentContract"),
  rodrigoOwnerGuard: source.includes("RODRIGO_AGENT_CREATOR_EMAIL") && source.includes("ownerEmail !== RODRIGO_AGENT_CREATOR_EMAIL"),
  explicitWhatsappOptIn: source.includes("allowRodrigoCreateAgentContract: true"),
  bodyFlagRequired: source.includes("body.allowRodrigoCreateAgentContract === true"),
  abortSignalPassed: source.includes("abortSignal: generationAbort.signal") && source.includes("web_only_codex_request_aborted_after_generation"),
  failClosedMissingPayload: source.includes("return \"\"") && source.includes("companyName") && source.includes("nomeEmpresa"),
  filtersCreateActionsAfterExecution: source.includes("!WEB_ONLY_CREATE_AGENT_ACTION_TYPES.has(action.type)"),
  normalizePhoneForAccount: source.includes("function normalizePhoneForAccount") && source.includes("normalizePhoneForAccount(session") && source.includes("replace(/\\D/g, \"\")"),
  noLocalDeliveryAuthor: !source.includes("Seu agente foi criado com sucesso!"),
};
for (const [name, ok] of Object.entries(checks)) {
  if (!ok) throw new Error(`marker failed: ${name}`);
}
console.log(JSON.stringify(checks));
NODE
}

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] replacing /app/dist/api/http.js"
patch_http_bundle "$TMP_CONTAINER"
check_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|Range out of order|ReferenceError|UnhandledPromiseRejection|MODULE_NOT_FOUND|AbortError'; then
  echo "[deploy] boot errors detected" >&2
  exit 62
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
