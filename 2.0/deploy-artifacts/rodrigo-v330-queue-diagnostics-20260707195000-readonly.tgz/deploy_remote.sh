#!/usr/bin/env bash
set -euo pipefail

echo "[diagnostics] active app image"
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app

echo "[diagnostics] public health"
curl -fsS http://127.0.0.1:5000/api/health

echo "[diagnostics] queue/db status"
docker exec -i agentezap-app node <<'NODE'
const { Client } = require("pg");

async function querySafe(client, name, sql, params = []) {
  try {
    const result = await client.query(sql, params);
    return { name, ok: true, rows: result.rows };
  } catch (error) {
    return { name, ok: false, error: String(error?.message || error) };
  }
}

async function main() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error("DATABASE_URL missing inside app container");
  }

  const client = new Client({
    connectionString,
    ssl: connectionString.includes("sslmode=require") ? { rejectUnauthorized: false } : undefined,
  });
  await client.connect();

  const queries = [];
  queries.push(await querySafe(client, "pending_ai_responses_status_24h", `
    SELECT status, count(*)::int AS total, min(created_at) AS oldest, max(updated_at) AS newest_update
    FROM pending_ai_responses
    WHERE created_at >= now() - interval '24 hours'
    GROUP BY status
    ORDER BY status
  `));
  queries.push(await querySafe(client, "pending_ai_responses_stale_active", `
    SELECT id, user_id, conversation_id, status, created_at, updated_at
    FROM pending_ai_responses
    WHERE status IN ('pending', 'processing', 'queued')
      AND created_at < now() - interval '10 minutes'
    ORDER BY created_at ASC
    LIMIT 20
  `));
  queries.push(await querySafe(client, "vercel_agent_response_jobs_status_24h", `
    SELECT status, count(*)::int AS total, min(created_at) AS oldest, max(updated_at) AS newest_update
    FROM vercel_agent_response_jobs
    WHERE created_at >= now() - interval '24 hours'
    GROUP BY status
    ORDER BY status
  `));
  queries.push(await querySafe(client, "vercel_agent_response_jobs_stale_active", `
    SELECT id, user_id, conversation_id, status, created_at, updated_at, attempts
    FROM vercel_agent_response_jobs
    WHERE status IN ('pending', 'processing', 'queued', 'running')
      AND created_at < now() - interval '10 minutes'
    ORDER BY created_at ASC
    LIMIT 20
  `));
  queries.push(await querySafe(client, "vercel_agent_response_jobs_recent_failures", `
    SELECT id, user_id, conversation_id, status, attempts, created_at, updated_at, left(coalesce(error_message, ''), 240) AS error_preview
    FROM vercel_agent_response_jobs
    WHERE status IN ('failed', 'error')
      AND updated_at >= now() - interval '2 hours'
    ORDER BY updated_at DESC
    LIMIT 20
  `));
  queries.push(await querySafe(client, "rodrigo_jobs_24h", `
    WITH owner AS (
      SELECT id FROM users WHERE lower(email) = lower('rodrigo4@gmail.com') LIMIT 1
    )
    SELECT 'pending_ai_responses' AS table_name, status, count(*)::int AS total
    FROM pending_ai_responses
    WHERE user_id = (SELECT id FROM owner)
      AND created_at >= now() - interval '24 hours'
    GROUP BY status
    UNION ALL
    SELECT 'vercel_agent_response_jobs' AS table_name, status, count(*)::int AS total
    FROM vercel_agent_response_jobs
    WHERE user_id = (SELECT id FROM owner)
      AND created_at >= now() - interval '24 hours'
    GROUP BY status
    ORDER BY table_name, status
  `));

  await client.end();

  const byName = Object.fromEntries(queries.map((item) => [item.name, item]));
  const checks = {
    pendingQueriesOk: queries.every((item) => item.ok),
    noPendingAiStaleActive: (byName.pending_ai_responses_stale_active?.rows || []).length === 0,
    noVercelJobStaleActive: (byName.vercel_agent_response_jobs_stale_active?.rows || []).length === 0,
    noRecentVercelFailures: (byName.vercel_agent_response_jobs_recent_failures?.rows || []).length === 0,
  };

  console.log(JSON.stringify({
    createdAt: new Date().toISOString(),
    queries,
    checks,
  }, null, 2));

  if (Object.values(checks).some((value) => value !== true)) {
    process.exit(20);
  }
}

main().catch((error) => {
  console.error("[diagnostics] failed", error);
  process.exit(1);
});
NODE

echo "[diagnostics] app logs recent errors"
if docker logs --since 10m agentezap-app 2>&1 | grep -a -E 'SyntaxError|ReferenceError|Range out of order|UnhandledPromiseRejection|MODULE_NOT_FOUND|FATAL|panic'; then
  echo "[diagnostics] recent boot/runtime errors detected" >&2
  exit 30
fi

echo "[diagnostics] READONLY_OK"
