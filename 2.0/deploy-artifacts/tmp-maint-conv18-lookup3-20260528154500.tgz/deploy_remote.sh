#!/usr/bin/env bash
set -euo pipefail

echo "CONV18_LOOKUP3_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");
const url = process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL;
const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
const targetPhone = "553131931983";
const marcosEmail = "marcos@mpalhares.com.br";

function isSafeColumn(name) {
  return !/(qr|auth|session|token|secret|credential|cookie|password|key|state_data|creds)/i.test(name);
}

async function q(name, sql, params = []) {
  const result = await client.query(sql, params);
  console.log(`## ${name}`);
  console.log(JSON.stringify(result.rows, null, 2));
}

(async () => {
  await client.connect();
  const columns = await client.query(`
    SELECT column_name
    FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'whatsapp_connections'
    ORDER BY ordinal_position
  `);
  const safeColumns = columns.rows.map((r) => r.column_name).filter(isSafeColumn);
  console.log("## whatsapp_connections_safe_columns");
  console.log(JSON.stringify(safeColumns, null, 2));

  const selectedColumns = safeColumns.map((c) => `wc.${JSON.stringify(c)} AS ${JSON.stringify(c)}`).join(", ");
  await q("connections_same_target_phone", `
    SELECT ${selectedColumns}, u.email AS owner_email, u.name AS owner_name
    FROM whatsapp_connections wc
    LEFT JOIN users u ON u.id = wc.user_id
    WHERE regexp_replace(coalesce(wc.phone_number, ''), '\\D', '', 'g') = $1
       OR u.email = $2
    ORDER BY wc.updated_at DESC NULLS LAST
    LIMIT 30
  `, [targetPhone, marcosEmail]);

  await q("marcos_subscription", `
    SELECT s.id, s.user_id, u.email, s.plan_name, s.status, s.price, s.coupon_price,
           s.pending_receipt, s.data_inicio, s.data_fim, s.next_payment_date,
           s.created_at, s.updated_at
    FROM subscriptions s
    JOIN users u ON u.id = s.user_id
    WHERE u.email = $1
    ORDER BY s.updated_at DESC NULLS LAST
    LIMIT 10
  `, [marcosEmail]);

  await q("marcos_recent_conversations", `
    SELECT c.id, c.contact_name, c.contact_number, c.last_message_text,
           c.last_message_from_me, c.needs_human_attention, c.followup_active, c.updated_at
    FROM conversations c
    JOIN whatsapp_connections wc ON wc.id = c.connection_id
    JOIN users u ON u.id = wc.user_id
    WHERE u.email = $1
    ORDER BY c.updated_at DESC
    LIMIT 10
  `, [marcosEmail]);
  await client.end();
})().catch(async (error) => {
  console.error("CONV18_LOOKUP3_FATAL", error);
  try { await client.end(); } catch {}
  process.exit(1);
});
NODE
echo "CONV18_LOOKUP3_END"
