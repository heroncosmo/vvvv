﻿#!/usr/bin/env bash
set -euo pipefail
echo "ANDERSON_RECEIPT_COLUMNS_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");
const client = new pg.Client({ connectionString: process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
(async()=>{ await client.connect();
for (const sql of [
`SELECT column_name,data_type FROM information_schema.columns WHERE table_name='payment_receipts' ORDER BY ordinal_position`,
`SELECT * FROM payment_receipts WHERE id='4a75a4e9-9fc4-487a-af5f-52fe81919c18'`,
`SELECT id,status,pending_receipt,data_inicio,data_fim,next_payment_date,metadata FROM subscriptions WHERE id='2e08234b-49da-45a1-b5db-4ceaa3ab1442'`
]) { const r=await client.query(sql); console.log(JSON.stringify(r.rows,null,2)); }
await client.end(); })().catch(async e=>{ console.error(e); try{await client.end()}catch{}; process.exit(1); });
NODE
echo "ANDERSON_RECEIPT_COLUMNS_END"
