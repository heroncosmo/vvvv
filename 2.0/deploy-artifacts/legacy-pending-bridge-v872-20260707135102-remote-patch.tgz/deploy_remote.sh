#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="${NEW_IMAGE:-agentezap-app:legacy-pending-bridge-v872-20260707135102}"
EXPECTED_ACTIVE_IMAGE="${EXPECTED_ACTIVE_IMAGE:-agentezap-app:plano-pro-300-v871-20260707121500}"
TMP_CONTAINER="${TMP_CONTAINER:-agentezap-legacy-pending-bridge-v872-tmp}"
COMPOSE_DIR="${COMPOSE_DIR:-/opt/agentezap-single/compose}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_HTTP="${PATCH_HTTP:-${SCRIPT_DIR}/api/http.js}"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

check_http_markers() {
  local container="$1"
  docker exec -i "$container" node <<'NODE'
const fs = require("fs");
const file = "/app/dist/api/http.js";
const text = fs.readFileSync(file, "utf8");

const required = [
  "bridgeDueLegacyPendingAIResponsesToVercelQueue",
  "VERCEL_AGENT_LEGACY_PENDING_BRIDGE_GRACE_SECONDS",
  "FOR UPDATE OF p SKIP LOCKED",
  "cancelled:bridged_to_vercel_agent_queue",
  "queued:vercel_gateway_agent:legacy_pending_bridge",
  "m.user_id::text",
  "CHECKOUT_PUBLIC_PRO_MONTHLY_PRICE = 300",
  "normalizeCheckoutRenewalMonthlyPrice",
];

const missing = required.filter((marker) => !text.includes(marker));
if (missing.length) {
  console.error("[deploy] missing http markers", JSON.stringify(missing));
  process.exit(60);
}

const start = text.indexOf("async function bridgeDueLegacyPendingAIResponsesToVercelQueue");
const end = text.indexOf("async function enqueueVercelAgentResponseJob", start);
if (start < 0 || end <= start) {
  console.error("[deploy] bridge block not found");
  process.exit(61);
}

const bridgeBlock = text.slice(start, end);
const forbiddenInBridge = [
  "customerFacingMessages",
  "runWebOnlyAgentTestForUser",
  "sendWebOnlyAgentActionsViaGateway",
  "sendJson(",
];
const forbiddenFound = forbiddenInBridge.filter((marker) => bridgeBlock.includes(marker));
if (forbiddenFound.length) {
  console.error("[deploy] bridge block contains public-authoring marker", JSON.stringify(forbiddenFound));
  process.exit(62);
}

console.log(JSON.stringify({
  ok: true,
  file,
  bridgeMarkers: required.length,
  bridgeBlockBytes: Buffer.byteLength(bridgeBlock),
}));
NODE
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
  '
}

echo "[deploy] checking patch file"
test -f "$PATCH_HTTP"
TMP_CHECK_FILE="$(mktemp /tmp/legacy-pending-bridge-http-check.XXXXXX.mjs)"
cp "$PATCH_HTTP" "$TMP_CHECK_FILE"
node --check "$TMP_CHECK_FILE"
rm -f "$TMP_CHECK_FILE"

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] replacing /app/dist/api/http.js"
docker cp "$PATCH_HTTP" "$TMP_CONTAINER:/app/dist/api/http.js"
check_http_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|ReferenceError|Range out of order|UnhandledPromiseRejection|MODULE_NOT_FOUND'; then
  echo "[deploy] boot errors detected" >&2
  exit 63
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_http_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
