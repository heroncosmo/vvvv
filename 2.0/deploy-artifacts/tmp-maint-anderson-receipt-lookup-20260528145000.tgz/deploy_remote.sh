#!/usr/bin/env bash
set -euo pipefail

echo "ANDERSON_RECEIPT_LOOKUP_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");

const url = process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL;
if (!url) throw new Error("DATABASE_URL missing");

const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
const conversationId = "7a7076cc-4206-437d-aebe-56a8c3374e33";
const receiptIdent = "43C6F49DCF3544F395E664C47";
const pixCode = "00020101021126360014br.gov.bcb.pix0114+5517981465183520400005303986540549.995802BR5914RODRIGO MACEDO6009COSMORAMA6229052543C6F49DCF3544F395E664C476304CCED";

async function q(name, sql, params = []) {
  try {
    const result = await client.query(sql, params);
    console.log(`## ${name}`);
    console.log(JSON.stringify(result.rows, null, 2));
  } catch (error) {
    console.log(`## ${name}_ERROR`);
    console.log(error.message);
  }
}

(async () => {
  await client.connect();
  await q("conversation", `
    SELECT c.id, c.user_id, owner.email AS owner_email, c.contact_name, c.contact_phone, c.connection_id,
           c.last_message_from_me, c.unread_count, c.needs_human_attention, c.followup_active
    FROM conversations c
    LEFT JOIN users owner ON owner.id = c.user_id
    WHERE c.id = $1
  `, [conversationId]);

  await q("messages_context", `
    SELECT id, from_me, content, media_type, media_url, created_at
    FROM messages
    WHERE conversation_id = $1
    ORDER BY created_at DESC
    LIMIT 8
  `, [conversationId]);

  await q("users_anderson", `
    SELECT id, email, name, whatsapp_number, created_at
    FROM users
    WHERE lower(coalesce(name,'')) LIKE '%anderson%'
       OR lower(coalesce(email,'')) LIKE '%anderson%'
       OR coalesce(whatsapp_number,'') LIKE '%249046%'
    ORDER BY created_at DESC
    LIMIT 20
  `);

  await q("subscriptions_recent_49", `
    SELECT s.id, s.user_id, u.email, u.name, p.name AS plan_name, p.price AS plan_price,
           s.status, s.coupon_price, s.data_inicio, s.data_fim, s.next_payment_date,
           s.pending_receipt, s.approved_receipt_at, s.created_at, s.metadata
    FROM subscriptions s
    JOIN users u ON u.id = s.user_id
    JOIN plans p ON p.id = s.plan_id
    WHERE s.created_at >= now() - interval '3 days'
      AND (u.name ILIKE '%Anderson%' OR u.email ILIKE '%anderson%' OR s.metadata::text ILIKE '%' || $1 || '%' OR s.metadata::text ILIKE '%' || $2 || '%')
    ORDER BY s.created_at DESC
    LIMIT 30
  `, [receiptIdent, pixCode]);

  await q("payments_match", `
    SELECT ph.id, ph.subscription_id, ph.user_id, u.email, ph.amount, ph.status, ph.payment_type,
           ph.payment_method, ph.mp_payment_id, ph.created_at, ph.raw_response
    FROM payment_history ph
    LEFT JOIN users u ON u.id = ph.user_id
    WHERE ph.created_at >= now() - interval '3 days'
      AND (ph.raw_response::text ILIKE '%' || $1 || '%' OR ph.raw_response::text ILIKE '%' || $2 || '%' OR ph.mp_payment_id ILIKE '%' || $1 || '%')
    ORDER BY ph.created_at DESC
    LIMIT 20
  `, [receiptIdent, pixCode]);

  await q("receipts_match", `
    SELECT pr.id, pr.subscription_id, pr.user_id, u.email, pr.plan_id, pr.amount, pr.status,
           pr.receipt_url, pr.receipt_filename, pr.created_at, pr.reviewed_at, pr.admin_notes
    FROM payment_receipts pr
    LEFT JOIN users u ON u.id = pr.user_id
    WHERE pr.created_at >= now() - interval '3 days'
      AND (pr.receipt_url ILIKE '%1779909075620%' OR pr.receipt_filename ILIKE '%1779909053953%' OR pr.admin_notes ILIKE '%' || $1 || '%')
    ORDER BY pr.created_at DESC
    LIMIT 20
  `, [receiptIdent]);

  await client.end();
})().catch(async (error) => {
  console.error("LOOKUP_ERROR", error);
  try { await client.end(); } catch {}
  process.exit(1);
});
NODE
echo "ANDERSON_RECEIPT_LOOKUP_END"
