#!/usr/bin/env bash
set -euo pipefail

NAME="tmp-deploy-wl-vidracaria-quote-guard-v63-20260512172358"
NEW_IMAGE="agentezap-app:wl-vidracaria-quote-guard-v63-20260512172358"
EXPECTED_ACTIVE="agentezap-app:meta-form-google-oauth-v62-20260512170913"
COMPOSE_DIR="/opt/agentezap-single/compose"
RUNTIME_ENV="${COMPOSE_DIR}/.env.runtime"
PAYLOAD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMP_CONTAINER="${NAME}-image"

cd "${COMPOSE_DIR}"
test -f compose.yml
test -f "${RUNTIME_ENV}"

APP_CONTAINER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app)"
test -n "${APP_CONTAINER}"
ACTIVE_IMAGE="$(docker inspect -f '{{.Config.Image}}' "${APP_CONTAINER}")"
echo "active_image=${ACTIVE_IMAGE}"
if [[ "${ACTIVE_IMAGE}" != "${EXPECTED_ACTIVE}" ]]; then
  echo "Abort: active image changed. Expected ${EXPECTED_ACTIVE}, got ${ACTIVE_IMAGE}" >&2
  exit 42
fi

BEFORE_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
BEFORE_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_before=${BEFORE_AUTH_DIRS}/${BEFORE_CREDS}"

docker rm -f "${TMP_CONTAINER}" >/dev/null 2>&1 || true
docker create --name "${TMP_CONTAINER}" "${ACTIVE_IMAGE}" /bin/true >/dev/null
docker cp "${PAYLOAD_DIR}/dist/." "${TMP_CONTAINER}:/app/dist/"
docker commit "${TMP_CONTAINER}" "${NEW_IMAGE}" >/dev/null
docker rm -f "${TMP_CONTAINER}" >/dev/null

printf '%s\n' "${ACTIVE_IMAGE}" > .previous-app.image
if grep -q '^AGENTEZAP_APP_IMAGE=' "${RUNTIME_ENV}"; then
  sed -i "s|^AGENTEZAP_APP_IMAGE=.*|AGENTEZAP_APP_IMAGE=${NEW_IMAGE}|" "${RUNTIME_ENV}"
else
  printf '\nAGENTEZAP_APP_IMAGE=%s\n' "${NEW_IMAGE}" >> "${RUNTIME_ENV}"
fi

docker compose --env-file "${RUNTIME_ENV}" -f compose.yml up -d --no-deps --wait app
docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps app

APP_CONTAINER_AFTER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app)"
docker exec "${APP_CONTAINER_AFTER}" grep -q "missing_measurement_before_quote" /app/dist/api/http.js
docker exec "${APP_CONTAINER_AFTER}" grep -q "isWebOnlyCustomerMediaUploadRequest" /app/dist/api/http.js
docker exec "${APP_CONTAINER_AFTER}" grep -q "META_FORM_GOOGLE_CLIENT_ID" /app/dist/api/http.js
docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('healthz', r.status, await r.text()); if(!r.ok) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"
docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{const text=await r.text(); console.log('api_health', r.status, text); if(!r.ok || !text.includes('monolith')) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"

AFTER_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
AFTER_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_after=${AFTER_AUTH_DIRS}/${AFTER_CREDS}"
echo "deploy_finished=${NEW_IMAGE}"
