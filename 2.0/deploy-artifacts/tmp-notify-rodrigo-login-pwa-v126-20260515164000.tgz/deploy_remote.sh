#!/usr/bin/env bash
set -euo pipefail

docker exec -i agentezap-app node - <<'NODE'
const payload = {
  conversationId: "0dc11f1d-6c1c-4b4a-b5b8-fd44368f52f8",
  text: "Rodrigo, terminei o ajuste do app. O login foi validado e ja pode testar novamente.",
  source: "owner",
};

const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 120000);

try {
  const res = await fetch("http://127.0.0.1:5000/api/integration/instances/8eb70fe1-f689-47ca-989f-c00b9cd4ae7c/messages/send", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-wa-gateway-token": "agentezap-internal-wa-gateway",
    },
    body: JSON.stringify(payload),
    signal: controller.signal,
  });
  const text = await res.text();
  console.log("status=" + res.status);
  console.log(text.slice(0, 1200));
  process.exit(res.ok || res.status === 202 ? 0 : 1);
} finally {
  clearTimeout(timeout);
}
NODE
