#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="agentezap-app:followup-toolname-v888b-20260708143520"
EXPECTED_ACTIVE_IMAGE="agentezap-app:followup-timeout-v887b-20260708141411"
TMP_CONTAINER="agentezap-followup-toolname-v888b-tmp"
COMPOSE_DIR="/opt/agentezap-single/compose"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

patch_http_bundle() {
  local container="$1"
  docker exec -i "$container" node - <<'NODE'
const fs = require("node:fs");
const file = "/app/dist/api/http.js";
let source = fs.readFileSync(file, "utf8");

if (!source.includes("function sanitizeWebOnlyAgenticToolName(")) {
  const anchors = [
    "function buildWebOnlyTemporalReferenceText(params) {\n",
    "async function runWebOnlyCodexCliText(params) {\n",
    "async function runWebOnlyAgenticTask(params) {\n",
  ];
  const anchor = anchors.find((candidate) => source.includes(candidate));
  if (!anchor) {
    throw new Error("safe sanitizeWebOnlyAgenticToolName insertion anchor not found");
  }
  const helper = `function sanitizeWebOnlyAgenticToolName(value, index2 = 0) {
  const fallback = \`tool_\${Math.max(1, index2 + 1)}\`;
  const normalized = String(value || "").trim().replace(/[^a-zA-Z0-9_-]+/g, "_").replace(/_+/g, "_").replace(/^_+|_+$/g, "").slice(0, 80);
  return normalized || fallback;
}
`;
  source = source.replace(anchor, helper + anchor);
  fs.writeFileSync(file, source);
}

const updated = fs.readFileSync(file, "utf8");
const helperIndex = updated.indexOf("function sanitizeWebOnlyAgenticToolName(");
const runtimeIndex = updated.indexOf("async function runWebOnlyAgenticTask");
if (helperIndex < 0) throw new Error("sanitizeWebOnlyAgenticToolName missing after patch");
if (runtimeIndex < 0 || helperIndex > runtimeIndex) throw new Error("sanitize helper is not before agentic runtime");

const recoveryStart = updated.indexOf("async function recoverWebOnlyFollowupsWaitingForCompanyReply");
const recoveryEnd = updated.indexOf("async function hasWebOnlyCustomerReplyInFollowupConversation", recoveryStart);
if (recoveryStart < 0 || recoveryEnd <= recoveryStart) throw new Error("recovery function block not found");
const recoveryBlock = updated.slice(recoveryStart, recoveryEnd);
if (!recoveryBlock.includes("WITH candidate_conversations AS")) throw new Error("missing candidate_conversations");
if (!recoveryBlock.includes("CROSS JOIN LATERAL")) throw new Error("missing lateral query");
if (recoveryBlock.includes("SELECT DISTINCT ON (m.conversation_id)")) throw new Error("global DISTINCT ON still present");

console.log(JSON.stringify({
  patched: true,
  toolDefined: helperIndex >= 0,
  toolBeforeRuntime: helperIndex < runtimeIndex,
  hasCandidateConversations: true,
  hasLateral: true,
  hasDistinctOnGlobal: false,
}));
NODE
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
  '
}

check_markers() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    grep -F "function sanitizeWebOnlyAgenticToolName" /app/dist/api/http.js >/dev/null
    grep -F "app.all(\"/api/followup/conversation/:id/trigger\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
    ! grep -F "app.all(\"/api/followup/*\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
    grep -F "WITH candidate_conversations AS" /app/dist/api/http.js >/dev/null
    grep -F "CROSS JOIN LATERAL (" /app/dist/api/http.js >/dev/null
    grep -F "runWebOnlyUserFollowupJob({ conversationId })" /app/dist/api/http.js >/dev/null
    grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_TENANT_MODEL" /app/dist >/dev/null
    grep -R -a -F -l -- "gpt-5.4-mini" /app/dist >/dev/null
    grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_RODRIGO_MODEL" /app/dist >/dev/null
    grep -R -a -F -l -- "gpt-5.5" /app/dist >/dev/null
    grep -R -a -F -l -- "x-stateful-job-async" /app/dist >/dev/null
    grep -R -a -F -l -- "webOnlyUserFollowupCronInFlight" /app/dist >/dev/null
    grep -R -a -F -l -- "pdf_rendered_image_vision" /app/dist >/dev/null
    command -v pdftoppm >/dev/null
  '
}

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] patching /app/dist/api/http.js"
patch_http_bundle "$TMP_CONTAINER"
check_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|Range out of order|ReferenceError|UnhandledPromiseRejection|MODULE_NOT_FOUND|AbortError'; then
  echo "[deploy] boot errors detected" >&2
  exit 62
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
