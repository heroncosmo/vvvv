#!/usr/bin/env bash
set -euo pipefail

echo "CONV18_LOOKUP_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");
const url = process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL;
const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
const conversationId = "5e5a71cb-e7f8-420e-8d12-205183fbe544";
async function q(name, sql, params = []) {
  const result = await client.query(sql, params);
  console.log(`## ${name}`);
  console.log(JSON.stringify(result.rows, null, 2));
}
(async () => {
  await client.connect();
  await q("conversation", `
    SELECT c.id, wc.user_id AS owner_user_id, owner.email AS owner_email, c.contact_name, c.contact_number,
           c.connection_id, c.last_message_text, c.last_message_from_me, c.unread_count,
           c.needs_human_attention, c.followup_active, c.created_at, c.updated_at
    FROM conversations c
    JOIN whatsapp_connections wc ON wc.id = c.connection_id
    LEFT JOIN users owner ON owner.id = wc.user_id
    WHERE c.id = $1
  `, [conversationId]);
  await q("messages", `
    SELECT id, from_me, text, media_type, media_url, timestamp, created_at
    FROM messages
    WHERE conversation_id = $1
    ORDER BY timestamp ASC
  `, [conversationId]);
  await q("connections_same_number", `
    SELECT wc.id, wc.user_id, u.email, wc.name, wc.phone_number, wc.status, wc.is_active, wc.created_at, wc.updated_at
    FROM whatsapp_connections wc
    LEFT JOIN users u ON u.id = wc.user_id
    WHERE wc.phone_number IN (
      SELECT c.contact_number FROM conversations c WHERE c.id = $1
    )
    ORDER BY wc.updated_at DESC
    LIMIT 10
  `, [conversationId]);
  await client.end();
})().catch(async (error) => {
  console.error("CONV18_LOOKUP_ERROR", error);
  try { await client.end(); } catch {}
  process.exit(1);
});
NODE
echo "CONV18_LOOKUP_END"
