#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="agentezap-app:followup-codex-parity-v886-20260708134241"
EXPECTED_ACTIVE_IMAGE="agentezap-app:pdf-followup-realtime-v885-20260708151000"
TMP_CONTAINER="agentezap-followup-codex-parity-v886-tmp"
COMPOSE_DIR="/opt/agentezap-single/compose"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

patch_container() {
  local container="$1"
  docker exec "$container" node - <<'NODE'
const fs = require("node:fs");
const path = require("node:path");

const distDir = "/app/dist";
const fullAppFiles = fs.readdirSync(distDir).filter((name) => /^full-app-.*\.js$/.test(name));
if (fullAppFiles.length !== 1) {
  throw new Error(`expected exactly one full-app bundle, got ${fullAppFiles.length}`);
}

const file = path.join(distDir, fullAppFiles[0]);
let source = fs.readFileSync(file, "utf8");
const original = source;

source = source
  .replace(/\n\s*app\.all\("\/api\/followup", delegateToVercelHttpHandler\);/g, "")
  .replace(/\n\s*app\.all\("\/api\/followup\/\*", delegateToVercelHttpHandler\);/g, "");

const anchor = '  app.all("/api/agent/edit-prompt-stream", delegateToVercelHttpHandler);\n';
const routes = [
  '  app.all("/api/followup/config", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/reorganize", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/stats", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/analytics", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/logs", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/pending", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/conversation/:id/status", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/conversation/:id/toggle", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/conversation/:id/schedule", delegateToVercelHttpHandler);',
  '  app.all("/api/followup/conversation/:id/trigger", delegateToVercelHttpHandler);',
].join("\n") + "\n";

if (!source.includes('app.all("/api/followup/conversation/:id/trigger", delegateToVercelHttpHandler);')) {
  if (!source.includes(anchor)) {
    throw new Error("parity route anchor not found");
  }
  source = source.replace(anchor, anchor + routes);
}

for (const route of routes.trim().split("\n")) {
  if (!source.includes(route.trim())) {
    throw new Error(`missing route after patch: ${route.trim()}`);
  }
}
if (source.includes('app.all("/api/followup/*", delegateToVercelHttpHandler);')) {
  throw new Error("broad /api/followup/* delegation is not allowed");
}

if (source !== original) {
  fs.writeFileSync(file, source);
}

console.log(JSON.stringify({
  fullAppFile: file,
  changed: source !== original,
  hasTriggerParity: source.includes('app.all("/api/followup/conversation/:id/trigger", delegateToVercelHttpHandler);'),
  broadFollowupDelegationAbsent: !source.includes('app.all("/api/followup/*", delegateToVercelHttpHandler);'),
}));
NODE
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
  '
}

check_markers() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    grep -F "app.all(\"/api/followup/config\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
    grep -F "app.all(\"/api/followup/conversation/:id/trigger\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
    ! grep -F "app.all(\"/api/followup/*\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
    grep -F "matchFollowupConversationTrigger" /app/dist/api/http.js >/dev/null
    grep -F "runWebOnlyUserFollowupJob({ conversationId })" /app/dist/api/http.js >/dev/null
    grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_TENANT_MODEL" /app/dist >/dev/null
    grep -R -a -F -l -- "gpt-5.4-mini" /app/dist >/dev/null
    grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_RODRIGO_MODEL" /app/dist >/dev/null
    grep -R -a -F -l -- "gpt-5.5" /app/dist >/dev/null
    grep -R -a -F -l -- "x-stateful-job-async" /app/dist >/dev/null
    grep -R -a -F -l -- "webOnlyUserFollowupCronInFlight" /app/dist >/dev/null
    grep -R -a -F -l -- "pdf_rendered_image_vision" /app/dist >/dev/null
    command -v pdftoppm >/dev/null
  '
}

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] patching follow-up parity routes"
patch_container "$TMP_CONTAINER"
check_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|Range out of order|ReferenceError|UnhandledPromiseRejection|MODULE_NOT_FOUND|AbortError'; then
  echo "[deploy] boot errors detected" >&2
  exit 62
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
