#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE="agentezap-app:wl-vidracaria-v62-http-turn-context-v65-20260512190500"
NEW_IMAGE="agentezap-app:wl-vidracaria-rotoplast-scope-v66-20260512193000"
COMPOSE_DIR="/opt/agentezap-single/compose"
RUNTIME_ENV="${COMPOSE_DIR}/.env.runtime"
PATCH_CONTAINER="wl_rotoplast_scope_patch_20260512193000"

cd "${COMPOSE_DIR}"
test -f compose.yml
test -f "${RUNTIME_ENV}"

rollback() {
  echo "rollback_to=${EXPECTED_ACTIVE}"
  if grep -q '^AGENTEZAP_APP_IMAGE=' "${RUNTIME_ENV}"; then
    sed -i "s|^AGENTEZAP_APP_IMAGE=.*|AGENTEZAP_APP_IMAGE=${EXPECTED_ACTIVE}|" "${RUNTIME_ENV}"
  else
    printf '\nAGENTEZAP_APP_IMAGE=%s\n' "${EXPECTED_ACTIVE}" >> "${RUNTIME_ENV}"
  fi
  docker compose --env-file "${RUNTIME_ENV}" -f compose.yml up -d --no-deps --wait app || true
  docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps app || true
}

APP_CONTAINER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app || true)"
if [[ -z "${APP_CONTAINER}" ]]; then
  echo "app container not found" >&2
  exit 2
fi

ACTIVE_IMAGE="$(docker inspect -f '{{.Config.Image}}' "${APP_CONTAINER}" || true)"
echo "active_image=${ACTIVE_IMAGE}"
if [[ "${ACTIVE_IMAGE}" != "${EXPECTED_ACTIVE}" ]]; then
  echo "Abort deploy: active image is not ${EXPECTED_ACTIVE}; got ${ACTIVE_IMAGE}" >&2
  exit 42
fi

ORIGINAL_ENTRYPOINT="$(docker inspect -f '{{json .Config.Entrypoint}}' "${EXPECTED_ACTIVE}")"
ORIGINAL_CMD="$(docker inspect -f '{{json .Config.Cmd}}' "${EXPECTED_ACTIVE}")"
ORIGINAL_WORKDIR="$(docker inspect -f '{{.Config.WorkingDir}}' "${EXPECTED_ACTIVE}")"
echo "original_entrypoint=${ORIGINAL_ENTRYPOINT}"
echo "original_cmd=${ORIGINAL_CMD}"
echo "original_workdir=${ORIGINAL_WORKDIR}"

docker exec "${APP_CONTAINER}" node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('healthz_before', r.status, await r.text()); if(!r.ok) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"
docker exec "${APP_CONTAINER}" node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{const text=await r.text(); console.log('api_health_before', r.status, text); if(!r.ok || !text.includes('monolith')) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"

BEFORE_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
BEFORE_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_before=${BEFORE_AUTH_DIRS}/${BEFORE_CREDS}"

docker rm -f "${PATCH_CONTAINER}" >/dev/null 2>&1 || true
docker create --name "${PATCH_CONTAINER}" --entrypoint sh "${EXPECTED_ACTIVE}" -c "sleep 600" >/dev/null
docker start "${PATCH_CONTAINER}" >/dev/null

cat > /tmp/patch_rotoplast_scope.js <<'NODE'
const fs = require('fs');
const file = '/app/dist/api/http.js';
let src = fs.readFileSync(file, 'utf8');

function replaceOnce(label, oldText, newText) {
  if (!src.includes(oldText)) {
    throw new Error(`missing anchor: ${label}`);
  }
  src = src.replace(oldText, newText);
  console.log(`patched=${label}`);
}

const oldText = String.raw`  const hasCommercialWall = /\b(comercial|comerciais|industrial|industriais|industria|parede|galpao|galpoes|empresa|empresas|loja|lojas|fabrica|fabricas)\b/i.test(normalized);
  const hasSupportIntent = /\b(peca|pecas|assistencia|manutencao|garantia|defeito|instalacao|visita|orcamento tecnico)\b/i.test(normalized);
  if (hasStandardCatalog && hasTouchCatalog && hasCommercialWall) {`;

const newText = String.raw`  const hasCommercialWall = /\b(comercial|comerciais|industrial|industriais|industria|parede|galpao|galpoes|empresa|empresas|loja|lojas|fabrica|fabricas)\b/i.test(normalized);
  const hasSupportIntent = /\b(peca|pecas|assistencia|manutencao|garantia|defeito|instalacao|visita|orcamento tecnico)\b/i.test(normalized);
  const hasRotoplastContext = hasPortableCatalog || hasPortablePrices || hasStandardCatalog || hasTouchCatalog || /\b(?:rotoplast|fernando|98118[-\s]?3718|catalogo\s+(?:standard|touch)|linha\s+portatil)\b/i.test([normalized, text].join(" "));
  if (!hasRotoplastContext) {
    return text;
  }
  if (hasStandardCatalog && hasTouchCatalog && hasCommercialWall) {`;

replaceOnce('rotoplast-fernando-scope', oldText, newText);
fs.writeFileSync(file, src);
console.log('patch_complete=true');
NODE

docker cp /tmp/patch_rotoplast_scope.js "${PATCH_CONTAINER}:/tmp/patch_rotoplast_scope.js"
docker exec "${PATCH_CONTAINER}" node /tmp/patch_rotoplast_scope.js
docker exec "${PATCH_CONTAINER}" node --check /app/dist/api/http.js

COMMIT_CHANGES=(--change "ENTRYPOINT ${ORIGINAL_ENTRYPOINT}" --change "CMD ${ORIGINAL_CMD}")
if [[ -n "${ORIGINAL_WORKDIR}" ]]; then
  COMMIT_CHANGES+=(--change "WORKDIR ${ORIGINAL_WORKDIR}")
fi
docker commit "${COMMIT_CHANGES[@]}" "${PATCH_CONTAINER}" "${NEW_IMAGE}" >/dev/null
docker rm -f "${PATCH_CONTAINER}" >/dev/null

if grep -q '^AGENTEZAP_APP_IMAGE=' "${RUNTIME_ENV}"; then
  sed -i "s|^AGENTEZAP_APP_IMAGE=.*|AGENTEZAP_APP_IMAGE=${NEW_IMAGE}|" "${RUNTIME_ENV}"
else
  printf '\nAGENTEZAP_APP_IMAGE=%s\n' "${NEW_IMAGE}" >> "${RUNTIME_ENV}"
fi

if ! docker compose --env-file "${RUNTIME_ENV}" -f compose.yml up -d --no-deps --wait app; then
  echo "deploy_failed_during_compose_wait" >&2
  rollback
  exit 1
fi

APP_CONTAINER_AFTER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app)"
if ! docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('healthz_after', r.status, await r.text()); if(!r.ok) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"; then
  rollback
  exit 1
fi
if ! docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{const text=await r.text(); console.log('api_health_after', r.status, text); if(!r.ok || !text.includes('monolith')) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"; then
  rollback
  exit 1
fi

AFTER_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
AFTER_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_after=${AFTER_AUTH_DIRS}/${AFTER_CREDS}"
echo "deploy_finished=${NEW_IMAGE}"
