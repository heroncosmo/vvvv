#!/usr/bin/env bash
set -euo pipefail

EXPECTED_IMAGE="agentezap-app:followup-codex-parity-v886b-20260708134904"

echo "[validate] active image"
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$EXPECTED_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"

echo "[validate] health"
curl -fsS http://127.0.0.1:5000/healthz
echo
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

echo "[validate] selected env"
docker exec agentezap-app sh -lc '
  set -eu
  printf "DISABLE_STATEFUL_INTERVAL_JOBS=%s\n" "${DISABLE_STATEFUL_INTERVAL_JOBS:-}"
  printf "ENABLE_STATEFUL_INTERVAL_JOBS=%s\n" "${ENABLE_STATEFUL_INTERVAL_JOBS:-}"
  printf "AGENTEZAP_CODEX_CLI_TENANT_MODEL=%s\n" "${AGENTEZAP_CODEX_CLI_TENANT_MODEL:-}"
  printf "AGENTEZAP_CODEX_CLI_RODRIGO_MODEL=%s\n" "${AGENTEZAP_CODEX_CLI_RODRIGO_MODEL:-}"
  printf "AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT=%s\n" "${AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT:-}"
'

echo "[validate] parity/model markers"
docker exec agentezap-app sh -lc '
  set -eu
  full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
  test -n "$full_app"
  grep -F "app.all(\"/api/followup/conversation/:id/trigger\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
  ! grep -F "app.all(\"/api/followup/*\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
  grep -F "matchFollowupConversationTrigger" /app/dist/api/http.js >/dev/null
  grep -F "runWebOnlyUserFollowupJob({ conversationId })" /app/dist/api/http.js >/dev/null
  grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_TENANT_MODEL" /app/dist >/dev/null
  grep -R -a -F -l -- "gpt-5.4-mini" /app/dist >/dev/null
  grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_RODRIGO_MODEL" /app/dist >/dev/null
  grep -R -a -F -l -- "gpt-5.5" /app/dist >/dev/null
  grep -R -a -F -l -- "x-stateful-job-async" /app/dist >/dev/null
  grep -R -a -F -l -- "webOnlyUserFollowupCronInFlight" /app/dist >/dev/null
'

echo "[validate] recent followup logs"
docker logs --since 15m agentezap-app 2>&1 | grep -a -E 'vercel-followup-cron|user-followup|USER-FOLLOW-UP|STATEFUL JOBS|Legacy scheduler|AbortError|ReferenceError|MODULE_NOT_FOUND|UnhandledPromiseRejection' | tail -n 180 || true

if docker logs --since 15m agentezap-app 2>&1 | grep -a -E 'AbortError|ReferenceError|MODULE_NOT_FOUND|UnhandledPromiseRejection|SyntaxError|Range out of order'; then
  echo "[validate] runtime errors detected" >&2
  exit 62
fi

echo "[validate] READ_ONLY_OK"
