import{r as i}from"./main-vWx1EeAW.js";import"./index-i__6lkAp.js";const r=i("PushNotifications",{});export{r as PushNotifications};
