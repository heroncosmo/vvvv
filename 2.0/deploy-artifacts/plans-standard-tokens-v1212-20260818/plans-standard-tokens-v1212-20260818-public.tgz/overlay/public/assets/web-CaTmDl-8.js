import{W as n}from"./main-vWx1EeAW.js";import"./index-i__6lkAp.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
