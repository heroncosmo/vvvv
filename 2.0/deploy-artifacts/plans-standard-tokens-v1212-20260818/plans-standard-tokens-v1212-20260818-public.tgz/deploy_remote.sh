#!/usr/bin/env bash
set -Eeuo pipefail

STACK_DIR="/opt/agentezap-single/compose"
EXPECTED_IMAGE="agentezap-app:ai-usage-customer-admin-parity-v1211-20260818"
EXPECTED_IMAGE_ID="sha256:9431ad3b8ae105819b7d4673b88bfd1d733f8c9ad6b77e97ed3e7066c200e939"
EXPECTED_PUBLIC_VERSION="ai-usage-customer-admin-parity-20260818"
EXPECTED_PUBLIC_INDEX_HASH="6171f8e54b9076eae2810a107cd8dcc6abf0f6f24bd13acef9f01a6f2f062d38"
EXPECTED_HTTP_HASH="cca5405865c17021ce8b5e5225aaa711f17ac62a6d92e2adb936eb4fbbd3920c"
EXPECTED_INDEX_HASH="e88aafccb9151f021718ada89dfa2d0ad8e586e2c1d3da167a658e711bca1c14"
EXPECTED_FULL_HASH="7eeac82fe3930854e8bc6898fc52eaa52e9fe261e8d1fb42be9a4560ebbcb41b"
TARGET_IMAGE="agentezap-app:plans-standard-tokens-v1212-20260818"
TARGET_PUBLIC_VERSION="plans-standard-tokens-v1212-20260818"
ENTRY_JS="assets/index-i__6lkAp.js"
MAIN_JS="assets/main-vWx1EeAW.js"
MAIN_CSS="assets/main-Dakg-KXu.css"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/overlay"
BACKUP_ENV="${STACK_DIR}/.env.runtime.plans-standard-tokens-v1212-backup"
DOCKERFILE="/tmp/Dockerfile.plans-standard-tokens-v1212"
MANIFEST="/tmp/plans-standard-tokens-v1212.sha256"
ENV_CHANGED=0

count_creds() {
  find "$1" -type f -name creds.json 2>/dev/null | wc -l
}

hash_full_app() {
  docker exec agentezap-app sh -lc 'sha256sum /app/dist/full-app-*.js | sort | sha256sum' | awk '{print $1}'
}

wait_for_healthy() {
  for _ in $(seq 1 120); do
    local state health
    state="$(docker inspect agentezap-app --format '{{.State.Status}}' 2>/dev/null || true)"
    health="$(docker inspect agentezap-app --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}' 2>/dev/null || true)"
    if [[ "$state" == "running" && "$health" == "healthy" ]]; then
      return 0
    fi
    sleep 2
  done
  return 1
}

cleanup_temp() {
  rm -f "$DOCKERFILE" "$MANIFEST"
}

rollback() {
  local exit_code=$?
  set +e
  echo "[deploy] validation failed; restoring ${EXPECTED_IMAGE}" >&2
  if [[ "$ENV_CHANGED" == "1" && -f "$BACKUP_ENV" ]]; then
    cp "$BACKUP_ENV" "${STACK_DIR}/.env.runtime"
    cd "$STACK_DIR"
    docker compose --env-file .env.runtime -f compose.yml -f compose.host-nginx.yml up -d --no-deps --wait app
    wait_for_healthy
  fi
  cleanup_temp
  exit "$exit_code"
}
trap rollback ERR

[[ -d "$BUILD_DIR/public/assets" ]]
[[ "$(find "$BUILD_DIR/public" -type f | wc -l)" == "11" ]]
[[ -f "$BUILD_DIR/public/index.html" ]]
[[ -f "$BUILD_DIR/public/pwa-version.json" ]]
[[ -f "$BUILD_DIR/public/site.webmanifest" ]]
[[ -f "$BUILD_DIR/public/sw.js" ]]
[[ -f "$BUILD_DIR/public/$ENTRY_JS" ]]
[[ -f "$BUILD_DIR/public/$MAIN_JS" ]]
[[ -f "$BUILD_DIR/public/$MAIN_CSS" ]]

[[ "$(docker inspect agentezap-app --format '{{.Config.Image}}')" == "$EXPECTED_IMAGE" ]]
[[ "$(docker inspect agentezap-app --format '{{.Image}}')" == "$EXPECTED_IMAGE_ID" ]]
[[ "$(docker inspect agentezap-app --format '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')" == "running/healthy/0/false" ]]
[[ "$(docker exec agentezap-app sha256sum /app/dist/public/index.html | awk '{print $1}')" == "$EXPECTED_PUBLIC_INDEX_HASH" ]]
docker exec agentezap-app grep -Fq "$EXPECTED_PUBLIC_VERSION" /app/dist/public/pwa-version.json
[[ "$(docker exec agentezap-app sha256sum /app/dist/api/http.js | awk '{print $1}')" == "$EXPECTED_HTTP_HASH" ]]
[[ "$(docker exec agentezap-app sha256sum /app/dist/index.js | awk '{print $1}')" == "$EXPECTED_INDEX_HASH" ]]
[[ "$(hash_full_app)" == "$EXPECTED_FULL_HASH" ]]
! pgrep -af 'docker (build|compose)|deploy-service|fast-deploy|deploy_safe_release' | grep -v "$$" | grep -v 'pgrep -af' >/dev/null

BEFORE_CREDS_HOST="$(count_creds /data/whatsapp-sessions)"
BEFORE_CREDS_MOUNT="$(docker exec agentezap-app sh -lc 'find /data/whatsapp-sessions -type f -name creds.json 2>/dev/null | wc -l')"
BEFORE_CMD="$(docker image inspect "$EXPECTED_IMAGE" --format '{{json .Config.Cmd}}')"
BEFORE_ENTRYPOINT="$(docker image inspect "$EXPECTED_IMAGE" --format '{{json .Config.Entrypoint}}')"
BEFORE_WORKER="$(docker inspect agentezap-audio-worker --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
BEFORE_PROXY="$(docker inspect agentezap-agnes-codex-proxy --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
BEFORE_PORTS="$(docker inspect agentezap-app --format '{{json .HostConfig.PortBindings}}')"

[[ "$BEFORE_CREDS_HOST" == "429" ]]
[[ "$BEFORE_CREDS_MOUNT" == "$BEFORE_CREDS_HOST" ]]
grep -q '127.0.0.1' <<<"$BEFORE_PORTS"
[[ -f "${STACK_DIR}/compose.host-nginx.yml" ]]

(
  cd "$BUILD_DIR"
  find . -type f -print0 | sort -z | xargs -0 sha256sum > "$MANIFEST"
)
SOURCE_OVERLAY_HASH="$(sha256sum "$MANIFEST" | cut -d ' ' -f1)"

grep -Fq "$TARGET_PUBLIC_VERSION" "$BUILD_DIR/public/pwa-version.json"
grep -Fq "$ENTRY_JS" "$BUILD_DIR/public/index.html"
grep -Fq "$MAIN_JS" "$BUILD_DIR/public/$ENTRY_JS"
grep -Fq "$MAIN_CSS" "$BUILD_DIR/public/$ENTRY_JS"
grep -Fq 'Aproximadamente' "$BUILD_DIR/public/$MAIN_JS"
grep -Fq 'tokens de IA por 30 dias' "$BUILD_DIR/public/$MAIN_JS"
grep -Fq 'rounded-[28px]' "$BUILD_DIR/public/$MAIN_JS"
! grep -Fq 'Plano Teste' "$BUILD_DIR/public/$MAIN_JS"
! grep -Fq 'Credito de IA' "$BUILD_DIR/public/$MAIN_JS"
! grep -Fq 'Crédito de IA' "$BUILD_DIR/public/$MAIN_JS"
! grep -Fq 'Tokens aproximados' "$BUILD_DIR/public/$MAIN_JS"
! grep -Fq 'Migrar para este plano' "$BUILD_DIR/public/$MAIN_JS"

docker image inspect "$TARGET_IMAGE" >/dev/null 2>&1 && {
  echo "[deploy] target image already exists" >&2
  exit 1
}

cat > "$DOCKERFILE" <<EOF
FROM ${EXPECTED_IMAGE}
COPY public/index.html /app/dist/public/index.html
COPY public/pwa-version.json /app/dist/public/pwa-version.json
COPY public/site.webmanifest /app/dist/public/site.webmanifest
COPY public/sw.js /app/dist/public/sw.js
COPY public/assets/ /app/dist/public/assets/
EOF

docker build --pull=false --no-cache -t "$TARGET_IMAGE" -f "$DOCKERFILE" "$BUILD_DIR"

[[ "$(docker image inspect "$TARGET_IMAGE" --format '{{json .Config.Cmd}}')" == "$BEFORE_CMD" ]]
[[ "$(docker image inspect "$TARGET_IMAGE" --format '{{json .Config.Entrypoint}}')" == "$BEFORE_ENTRYPOINT" ]]
docker run --rm -i --network none --entrypoint sh "$TARGET_IMAGE" -ec 'cd /app/dist; sha256sum -c >/dev/null' < "$MANIFEST"
docker run --rm --network none --entrypoint sh "$TARGET_IMAGE" -ec "
  node --check /app/dist/index.js >/dev/null
  node --check /app/dist/api/http.js >/dev/null
  test \"\$(sha256sum /app/dist/api/http.js | awk '{print \$1}')\" = '$EXPECTED_HTTP_HASH'
  test \"\$(sha256sum /app/dist/index.js | awk '{print \$1}')\" = '$EXPECTED_INDEX_HASH'
  grep -Fq '$TARGET_PUBLIC_VERSION' /app/dist/public/pwa-version.json
  grep -Fq '$ENTRY_JS' /app/dist/public/index.html
  grep -Fq '$MAIN_JS' /app/dist/public/$ENTRY_JS
  grep -Fq 'Aproximadamente' /app/dist/public/$MAIN_JS
  grep -Fq 'tokens de IA por 30 dias' /app/dist/public/$MAIN_JS
  ! grep -Fq 'Plano Teste' /app/dist/public/$MAIN_JS
  ! grep -Fq 'Tokens aproximados' /app/dist/public/$MAIN_JS
"

[[ "$(docker inspect agentezap-app --format '{{.Config.Image}}')" == "$EXPECTED_IMAGE" ]]
[[ "$(docker inspect agentezap-app --format '{{.Image}}')" == "$EXPECTED_IMAGE_ID" ]]
[[ "$(docker exec agentezap-app sha256sum /app/dist/public/index.html | awk '{print $1}')" == "$EXPECTED_PUBLIC_INDEX_HASH" ]]

cd "$STACK_DIR"
cp .env.runtime "$BACKUP_ENV"
ENV_CHANGED=1
sed -i "s#^AGENTEZAP_APP_IMAGE=.*#AGENTEZAP_APP_IMAGE=${TARGET_IMAGE}#" .env.runtime
grep -qxF "AGENTEZAP_APP_IMAGE=${TARGET_IMAGE}" .env.runtime
docker compose --env-file .env.runtime -f compose.yml -f compose.host-nginx.yml config >/dev/null
docker compose --env-file .env.runtime -f compose.yml -f compose.host-nginx.yml up -d --no-deps --wait app
wait_for_healthy

POST_IMAGE="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
POST_IMAGE_ID="$(docker inspect agentezap-app --format '{{.Image}}')"
POST_STATE="$(docker inspect agentezap-app --format '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
POST_PORTS="$(docker inspect agentezap-app --format '{{json .HostConfig.PortBindings}}')"
POST_CREDS_HOST="$(count_creds /data/whatsapp-sessions)"
POST_CREDS_MOUNT="$(docker exec agentezap-app sh -lc 'find /data/whatsapp-sessions -type f -name creds.json 2>/dev/null | wc -l')"
POST_WORKER="$(docker inspect agentezap-audio-worker --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
POST_PROXY="$(docker inspect agentezap-agnes-codex-proxy --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
POST_HTTP_HASH="$(docker exec agentezap-app sha256sum /app/dist/api/http.js | awk '{print $1}')"
POST_INDEX_HASH="$(docker exec agentezap-app sha256sum /app/dist/index.js | awk '{print $1}')"
POST_FULL_HASH="$(hash_full_app)"
POST_PUBLIC_INDEX_HASH="$(docker exec agentezap-app sha256sum /app/dist/public/index.html | awk '{print $1}')"
LOCAL_HEALTH="$(curl -fsS http://127.0.0.1:5000/healthz)"
PUBLIC_HEALTH="$(curl -fsS https://agentezap.online/healthz)"
API_HEALTH="$(curl -fsS http://127.0.0.1:5000/api/health)"

[[ "$POST_IMAGE" == "$TARGET_IMAGE" ]]
[[ "$POST_STATE" == "running/healthy/0/false" ]]
[[ "$POST_HTTP_HASH" == "$EXPECTED_HTTP_HASH" ]]
[[ "$POST_INDEX_HASH" == "$EXPECTED_INDEX_HASH" ]]
[[ "$POST_FULL_HASH" == "$EXPECTED_FULL_HASH" ]]
[[ "$POST_CREDS_HOST" == "$BEFORE_CREDS_HOST" ]]
[[ "$POST_CREDS_MOUNT" == "$BEFORE_CREDS_MOUNT" ]]
[[ "$POST_WORKER" == "$BEFORE_WORKER" ]]
[[ "$POST_PROXY" == "$BEFORE_PROXY" ]]
[[ "$POST_PORTS" == "$BEFORE_PORTS" ]]
grep -q '127.0.0.1' <<<"$POST_PORTS"
docker exec agentezap-app grep -Fq "$TARGET_PUBLIC_VERSION" /app/dist/public/pwa-version.json
docker exec -i agentezap-app sh -ec 'cd /app/dist; sha256sum -c >/dev/null' < "$MANIFEST"
[[ "$LOCAL_HEALTH" == "ok" && "$PUBLIC_HEALTH" == "ok" ]]
grep -q '"mode":"monolith"' <<<"$API_HEALTH"
grep -q '"runtimeProfile":"full"' <<<"$API_HEALTH"

ENV_CHANGED=0
cleanup_temp
trap - ERR

echo "pre_image=$EXPECTED_IMAGE"
echo "post_image=$POST_IMAGE"
echo "post_image_id=$POST_IMAGE_ID"
echo "post_state=$POST_STATE"
echo "ports=$POST_PORTS"
echo "creds_host=$POST_CREDS_HOST creds_mount=$POST_CREDS_MOUNT"
echo "worker=$POST_WORKER"
echo "proxy=$POST_PROXY"
echo "http_hash=$POST_HTTP_HASH"
echo "index_hash=$POST_INDEX_HASH"
echo "full_hash=$POST_FULL_HASH"
echo "public_index_hash=$POST_PUBLIC_INDEX_HASH"
echo "overlay_hash=$SOURCE_OVERLAY_HASH"
echo "health=$LOCAL_HEALTH/$PUBLIC_HEALTH"
echo "api_health=$API_HEALTH"
