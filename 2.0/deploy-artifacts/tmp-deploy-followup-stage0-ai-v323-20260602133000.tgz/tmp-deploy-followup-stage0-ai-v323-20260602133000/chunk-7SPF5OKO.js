import {
  buildBrazilWhatsAppPhoneVariants,
  buildMauricioMfcCatalogCaptionPriceLine,
  buildWhatsAppJidFromPhone,
  containsMauricioMfcReady50x50PromoText,
  isMauricioMfcCatalogTenant,
  mauricioMfcCatalogEntryMatchesLineKind,
  normalizePhoneForComparison,
  normalizePhoneToDigits,
  phoneNumbersMatch,
  resolveMauricioMfcRequestedLineKind,
  sendMetaPaidWhatsappConversion
} from "./chunk-YB77ZB3P.js";
import {
  getAdminFollowupGlobalConfig,
  isAdminConversationFollowupManuallyPaused,
  isLegacyAdminFollowupConfig,
  normalizeAdminFollowupConfig,
  sanitizeAdminNotificationConfig,
  sanitizeAdminWhatsappConnection
} from "./chunk-XZFDVJYL.js";
import {
  repairMojibakeDeep
} from "./chunk-K6J2PMOD.js";
import {
  chatComplete,
  detectMediaSendingIntent
} from "./chunk-M7TXNZTC.js";
import {
  analyzeImageWithMistral,
  transcribeAudioWithMistral
} from "./chunk-UKCWWGWI.js";
import {
  db,
  ensureAudioResponseModeConstraint,
  pool,
  withRetry
} from "./chunk-R6CXRQMB.js";
import {
  adminAgentMedia,
  adminConversations,
  adminMessages,
  adminWhatsappConnection,
  admins,
  agentDisabledConversations,
  agentMediaLibrary,
  agents,
  aiAgentConfig,
  audioConfig,
  audioMessageCounter,
  businessAgentConfigs,
  connectionAgents,
  connectionMembers,
  contactLists,
  conversationLeadIntelligence,
  conversationTags,
  conversations,
  coupons,
  mediaFlowItems,
  mediaFlows,
  messages,
  paymentHistory,
  paymentReceipts,
  payments,
  plans,
  resellerClients,
  resellerInvoiceItems,
  resellerInvoices,
  resellerPayments,
  resellers,
  subscriptions,
  systemConfig,
  tags,
  teamMemberSessions,
  teamMembers,
  users,
  whatsappConnections,
  whatsappContacts
} from "./chunk-JC6URYU5.js";

// server/supabaseAuth.ts
import { eq as eq2 } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";

// server/internalSimulatorConnection.ts
var INTERNAL_SIMULATOR_CONNECTION_NAME = "Simulador Estamparia";
var INTERNAL_SIMULATOR_SOURCE = "estamparia-simulator";
var USER_REMOVED_CONNECTION_TYPE = "removed";
var USER_REMOVED_CONNECTION_STATUS = "removed";
var USER_REMOVED_CONNECTION_FLAG = "removedFromApp";
function normalizeText(value) {
  return String(value || "").trim();
}
function normalizeLower(value) {
  return normalizeText(value).toLowerCase();
}
function normalizeProviderConfigSource(providerConfig) {
  if (!providerConfig || typeof providerConfig !== "object" || Array.isArray(providerConfig)) {
    return "";
  }
  return normalizeLower(
    typeof providerConfig.source === "string" ? providerConfig.source : null
  );
}
function readConnectionString(connection, camelKey, snakeKey) {
  if (!connection) {
    return "";
  }
  const camelValue = connection[camelKey];
  if (typeof camelValue === "string") {
    return camelValue;
  }
  const snakeValue = connection[snakeKey];
  return typeof snakeValue === "string" ? snakeValue : "";
}
function readConnectionProviderConfig(connection) {
  if (!connection) {
    return null;
  }
  const value = connection.providerConfig || connection.provider_config;
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function getProviderConfigFlag(providerConfig, key) {
  if (!providerConfig || typeof providerConfig !== "object" || Array.isArray(providerConfig)) {
    return false;
  }
  return providerConfig[key] === true;
}
function isSimulatorPhoneNumber(phoneNumber) {
  return normalizeLower(phoneNumber).startsWith("sim-");
}
function hasInternalSimulatorIdentity(connection) {
  if (!connection) {
    return false;
  }
  return normalizeLower(connection.provider) === "simulator" || normalizeLower(connection.connectionMethod) === "simulator" || normalizeLower(connection.connectionType) === "simulator" || normalizeLower(connection.connectionName) === INTERNAL_SIMULATOR_CONNECTION_NAME.toLowerCase() || normalizeProviderConfigSource(
    connection.providerConfig || null
  ) === INTERNAL_SIMULATOR_SOURCE;
}
function isInternalOnlySimulatorConnection(connection) {
  if (!hasInternalSimulatorIdentity(connection)) {
    return false;
  }
  const phoneNumber = normalizeText(connection?.phoneNumber);
  if (!phoneNumber) {
    return true;
  }
  if (isSimulatorPhoneNumber(phoneNumber)) {
    return true;
  }
  const hasOperationalSignal = connection?.isConnected === true || normalizeLower(connection?.providerStatus) === "connected";
  return !hasOperationalSignal;
}
function isUserRemovedConnection(connection) {
  if (!connection) {
    return false;
  }
  const looseConnection = connection;
  const providerConfig = readConnectionProviderConfig(looseConnection);
  return normalizeLower(readConnectionString(looseConnection, "connectionType", "connection_type")) === USER_REMOVED_CONNECTION_TYPE || normalizeLower(readConnectionString(looseConnection, "providerStatus", "provider_status")) === USER_REMOVED_CONNECTION_STATUS || getProviderConfigFlag(providerConfig, USER_REMOVED_CONNECTION_FLAG) || getProviderConfigFlag(providerConfig, "removedByUser");
}
function isAppVisibleWhatsappConnection(connection) {
  return !isInternalOnlySimulatorConnection(connection) && !isUserRemovedConnection(connection);
}
function buildInternalSimulatorConnectionInsert(userId) {
  return {
    userId,
    phoneNumber: `sim-${userId.split("-")[0] || "user"}`,
    isConnected: false,
    provider: "simulator",
    connectionMethod: "simulator",
    providerStatus: "inactive",
    providerConfig: { source: INTERNAL_SIMULATOR_SOURCE },
    connectionName: INTERNAL_SIMULATOR_CONNECTION_NAME,
    connectionType: "simulator",
    isPrimary: false,
    aiEnabled: true
  };
}

// server/storage.ts
import { eq, desc, and, gte, sql, inArray, lte, lt, gt, isNotNull, isNull, asc, or } from "drizzle-orm";

// server/adminBusinessDashboard.ts
var MONTH_LABEL_FORMATTER = new Intl.DateTimeFormat("pt-BR", {
  month: "short",
  year: "2-digit"
});
function asDate(value) {
  if (!value) return null;
  const parsed = value instanceof Date ? value : new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}
function toNumber(value) {
  if (value === null || value === void 0) return 0;
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : 0;
}
function startOfMonth(value) {
  return new Date(value.getFullYear(), value.getMonth(), 1, 0, 0, 0, 0);
}
function addMonths(value, months) {
  return new Date(
    value.getFullYear(),
    value.getMonth() + months,
    1,
    0,
    0,
    0,
    0
  );
}
function addDays(value, days) {
  const result = new Date(value);
  result.setDate(result.getDate() + days);
  return result;
}
function isWithinRange(value, startInclusive, endExclusive) {
  if (!value) return false;
  return value >= startInclusive && value < endExclusive;
}
function getCycleDays(subscription) {
  const configuredFrequency = Number(subscription.plan?.frequenciaDias);
  if (Number.isFinite(configuredFrequency) && configuredFrequency > 0) {
    return configuredFrequency;
  }
  return subscription.plan?.periodicidade === "anual" ? 365 : 30;
}
function getRecurringAmount(subscription) {
  const discounted = toNumber(subscription.couponPrice);
  if (discounted > 0) return discounted;
  return toNumber(subscription.plan?.valor);
}
function getChargeDate(subscription) {
  return asDate(subscription.nextPaymentDate) || asDate(subscription.dataFim) || null;
}
function roundTo(value, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}
function buildConnectionSummary(users2, connections) {
  const summary = /* @__PURE__ */ new Map();
  for (const user of users2) {
    summary.set(user.id, { isConnected: false });
  }
  for (const connection of connections) {
    const current = summary.get(connection.userId) || { isConnected: false };
    current.isConnected = current.isConnected || Boolean(connection.isConnected);
    summary.set(connection.userId, current);
  }
  return summary;
}
function smoothRate(sample, fallbackRate, priorWeight) {
  if (sample.eligible <= 0) return fallbackRate;
  return (sample.renewed + fallbackRate * priorWeight) / (sample.eligible + priorWeight);
}
function buildRenewalSamples(subscriptions2, approvedPayments, connectionSummary, now) {
  const paymentsBySubscription = /* @__PURE__ */ new Map();
  for (const payment of approvedPayments) {
    const bucket = paymentsBySubscription.get(payment.subscriptionId) || [];
    bucket.push(payment);
    paymentsBySubscription.set(payment.subscriptionId, bucket);
  }
  const overall = { eligible: 0, renewed: 0 };
  const connected = { eligible: 0, renewed: 0 };
  const disconnected = { eligible: 0, renewed: 0 };
  for (const subscription of subscriptions2) {
    if (subscription.user?.role === "admin" || subscription.user?.role === "owner") {
      continue;
    }
    const approvedForSubscription = (paymentsBySubscription.get(subscription.id) || []).map((payment) => ({
      ...payment,
      effectiveDate: asDate(payment.paymentDate) || asDate(payment.createdAt)
    })).filter((payment) => payment.effectiveDate).sort(
      (left, right) => left.effectiveDate.getTime() - right.effectiveDate.getTime()
    );
    if (approvedForSubscription.length === 0) continue;
    const firstChargeDate = approvedForSubscription[0].effectiveDate;
    const cycleDays = getCycleDays(subscription);
    if (firstChargeDate > addDays(now, -cycleDays)) continue;
    const renewalThreshold = addDays(firstChargeDate, Math.max(7, cycleDays - 5));
    const renewed = approvedForSubscription.some(
      (payment, index) => index > 0 && payment.effectiveDate >= renewalThreshold
    );
    overall.eligible += 1;
    overall.renewed += renewed ? 1 : 0;
    const target = connectionSummary.get(subscription.userId)?.isConnected ? connected : disconnected;
    target.eligible += 1;
    target.renewed += renewed ? 1 : 0;
  }
  return { overall, connected, disconnected };
}
function buildAdminBusinessDashboardReport({
  users: users2,
  connections,
  subscriptions: subscriptions2,
  paymentHistory: paymentHistory2,
  pendingReceiptsCount,
  activePlansCount,
  now = /* @__PURE__ */ new Date()
}) {
  const monthStart = startOfMonth(now);
  const previousMonthStart = addMonths(monthStart, -1);
  const nextMonthStart = addMonths(monthStart, 1);
  const monthAfterNextStart = addMonths(monthStart, 2);
  const sixMonthStart = addMonths(monthStart, -5);
  const connectionSummary = buildConnectionSummary(users2, connections);
  const approvedPayments = paymentHistory2.filter(
    (payment) => payment.status === "approved"
  );
  const activeSubscriptions = subscriptions2.filter(
    (subscription) => subscription.status === "active" && subscription.user?.role !== "admin" && subscription.user?.role !== "owner"
  );
  const latestSubscriptionByUser = /* @__PURE__ */ new Map();
  for (const subscription of subscriptions2) {
    const existing = latestSubscriptionByUser.get(subscription.userId);
    const currentDate = asDate(subscription.updatedAt) || asDate(subscription.createdAt) || asDate(subscription.dataFim) || /* @__PURE__ */ new Date(0);
    const existingDate = asDate(existing?.updatedAt) || asDate(existing?.createdAt) || asDate(existing?.dataFim) || /* @__PURE__ */ new Date(0);
    if (!existing || currentDate >= existingDate) {
      latestSubscriptionByUser.set(subscription.userId, subscription);
    }
  }
  const inactiveConnectedFormerSubscribers = Array.from(
    latestSubscriptionByUser.values()
  ).filter((subscription) => {
    const isFormer = subscription.status === "cancelled" || subscription.status === "expired";
    return isFormer && Boolean(connectionSummary.get(subscription.userId)?.isConnected);
  }).length;
  const currentMonthPayments = approvedPayments.filter(
    (payment) => isWithinRange(
      asDate(payment.paymentDate) || asDate(payment.createdAt),
      monthStart,
      nextMonthStart
    )
  );
  const previousMonthPayments = approvedPayments.filter(
    (payment) => isWithinRange(
      asDate(payment.paymentDate) || asDate(payment.createdAt),
      previousMonthStart,
      monthStart
    )
  );
  const lifetimeGross = approvedPayments.reduce(
    (sum, payment) => sum + toNumber(payment.amount),
    0
  );
  const lifetimeNet = approvedPayments.reduce(
    (sum, payment) => sum + (toNumber(payment.netAmount) || toNumber(payment.amount)),
    0
  );
  const currentMonthGross = currentMonthPayments.reduce(
    (sum, payment) => sum + toNumber(payment.amount),
    0
  );
  const currentMonthNet = currentMonthPayments.reduce(
    (sum, payment) => sum + (toNumber(payment.netAmount) || toNumber(payment.amount)),
    0
  );
  const previousMonthGross = previousMonthPayments.reduce(
    (sum, payment) => sum + toNumber(payment.amount),
    0
  );
  const previousMonthNet = previousMonthPayments.reduce(
    (sum, payment) => sum + (toNumber(payment.netAmount) || toNumber(payment.amount)),
    0
  );
  const monthlySeries = Array.from({ length: 6 }, (_, index) => {
    const month = addMonths(sixMonthStart, index);
    const monthEnd = addMonths(month, 1);
    const paymentsForMonth = approvedPayments.filter(
      (payment) => isWithinRange(
        asDate(payment.paymentDate) || asDate(payment.createdAt),
        month,
        monthEnd
      )
    );
    const subscriptionsForMonth = subscriptions2.filter(
      (subscription) => isWithinRange(asDate(subscription.createdAt), month, monthEnd)
    );
    return {
      monthKey: `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}`,
      label: MONTH_LABEL_FORMATTER.format(month).replace(".", ""),
      grossRevenue: roundTo(
        paymentsForMonth.reduce((sum, payment) => sum + toNumber(payment.amount), 0)
      ),
      netRevenue: roundTo(
        paymentsForMonth.reduce(
          (sum, payment) => sum + (toNumber(payment.netAmount) || toNumber(payment.amount)),
          0
        )
      ),
      approvedPayments: paymentsForMonth.length,
      recurringPayments: paymentsForMonth.filter(
        (payment) => payment.paymentType === "recurring"
      ).length,
      newSubscribers: subscriptionsForMonth.length
    };
  });
  const sixMonthGross = monthlySeries.reduce(
    (sum, point) => sum + point.grossRevenue,
    0
  );
  const sixMonthNet = monthlySeries.reduce(
    (sum, point) => sum + point.netRevenue,
    0
  );
  const renewalSamples = buildRenewalSamples(
    subscriptions2,
    approvedPayments,
    connectionSummary,
    now
  );
  const rawOverallRate = renewalSamples.overall.eligible > 0 ? renewalSamples.overall.renewed / renewalSamples.overall.eligible : 0.68;
  const connectedFallback = Math.min(0.95, Math.max(rawOverallRate + 0.08, 0.72));
  const disconnectedFallback = Math.max(0.25, Math.min(rawOverallRate - 0.12, 0.58));
  const overallRate = smoothRate(renewalSamples.overall, 0.68, 2);
  const connectedRate = smoothRate(renewalSamples.connected, connectedFallback, 2);
  const disconnectedRate = smoothRate(
    renewalSamples.disconnected,
    disconnectedFallback,
    2
  );
  const nextMonthSubscriptions = activeSubscriptions.map((subscription) => ({
    subscription,
    chargeDate: getChargeDate(subscription),
    isConnected: Boolean(connectionSummary.get(subscription.userId)?.isConnected),
    amount: getRecurringAmount(subscription)
  })).filter(({ chargeDate }) => isWithinRange(chargeDate, nextMonthStart, monthAfterNextStart)).sort((left, right) => left.chargeDate.getTime() - right.chargeDate.getTime());
  const expiringThisMonthSubscribers = activeSubscriptions.filter(
    (subscription) => isWithinRange(getChargeDate(subscription), monthStart, nextMonthStart)
  ).length;
  const nextMonthBaseRevenue = nextMonthSubscriptions.reduce(
    (sum, item) => sum + item.amount,
    0
  );
  const nextMonthConnectedBaseRevenue = nextMonthSubscriptions.filter((item) => item.isConnected).reduce((sum, item) => sum + item.amount, 0);
  const nextMonthDisconnectedBaseRevenue = nextMonthSubscriptions.filter((item) => !item.isConnected).reduce((sum, item) => sum + item.amount, 0);
  const nextMonthWeightedRevenue = nextMonthSubscriptions.reduce((sum, item) => {
    const probability = item.isConnected ? connectedRate : disconnectedRate;
    return sum + item.amount * probability;
  }, 0);
  const nextMonthConnectedWeightedRevenue = nextMonthSubscriptions.filter((item) => item.isConnected).reduce((sum, item) => sum + item.amount * connectedRate, 0);
  const nextMonthDisconnectedWeightedRevenue = nextMonthSubscriptions.filter((item) => !item.isConnected).reduce((sum, item) => sum + item.amount * disconnectedRate, 0);
  const activeConnectedSubscribers = activeSubscriptions.filter(
    (subscription) => Boolean(connectionSummary.get(subscription.userId)?.isConnected)
  ).length;
  const activeDisconnectedSubscribers = activeSubscriptions.length - activeConnectedSubscribers;
  const atRiskDisconnectedSubscribers = nextMonthSubscriptions.filter(
    (item) => !item.isConnected
  ).length;
  const planMixMap = /* @__PURE__ */ new Map();
  for (const subscription of activeSubscriptions) {
    const existing = planMixMap.get(subscription.planId) || {
      planId: subscription.planId,
      planName: subscription.plan?.nome || "Plano",
      activeSubscribers: 0,
      connectedSubscribers: 0,
      scheduledRevenueNextMonth: 0
    };
    existing.activeSubscribers += 1;
    if (connectionSummary.get(subscription.userId)?.isConnected) {
      existing.connectedSubscribers += 1;
    }
    if (isWithinRange(
      getChargeDate(subscription),
      nextMonthStart,
      monthAfterNextStart
    )) {
      existing.scheduledRevenueNextMonth += getRecurringAmount(subscription);
    }
    planMixMap.set(subscription.planId, existing);
  }
  const upcomingRenewals = nextMonthSubscriptions.slice(0, 8).map((item) => ({
    subscriptionId: item.subscription.id,
    userId: item.subscription.userId,
    userName: item.subscription.user?.name || "Cliente",
    userEmail: item.subscription.user?.email || null,
    planName: item.subscription.plan?.nome || "Plano",
    amount: roundTo(item.amount),
    nextPaymentDate: item.chargeDate?.toISOString() || null,
    isConnected: item.isConnected,
    daysUntilCharge: item.chargeDate ? Math.max(
      0,
      Math.ceil(
        (item.chargeDate.getTime() - now.getTime()) / (1e3 * 60 * 60 * 24)
      )
    ) : null,
    renewalProbability: roundTo(
      item.isConnected ? connectedRate : disconnectedRate,
      4
    )
  }));
  return {
    generatedAt: now.toISOString(),
    overview: {
      totalUsers: users2.filter(
        (user) => user.role !== "admin" && user.role !== "owner"
      ).length,
      activeSubscribers: activeSubscriptions.length,
      activeConnectedSubscribers,
      activeDisconnectedSubscribers,
      inactiveConnectedFormerSubscribers,
      availablePlans: activePlansCount,
      pendingReceipts: pendingReceiptsCount
    },
    revenue: {
      lifetimeGross: roundTo(lifetimeGross),
      lifetimeNet: roundTo(lifetimeNet),
      currentMonthGross: roundTo(currentMonthGross),
      currentMonthNet: roundTo(currentMonthNet),
      previousMonthGross: roundTo(previousMonthGross),
      previousMonthNet: roundTo(previousMonthNet),
      averageMonthlyGrossLast6: roundTo(sixMonthGross / monthlySeries.length),
      averageMonthlyNetLast6: roundTo(sixMonthNet / monthlySeries.length),
      monthOverMonthGrowth: previousMonthGross > 0 ? roundTo((currentMonthGross - previousMonthGross) / previousMonthGross * 100, 2) : currentMonthGross > 0 ? 100 : null,
      averageTicket: approvedPayments.length > 0 ? roundTo(lifetimeGross / approvedPayments.length) : 0
    },
    forecast: {
      nextMonthBaseRevenue: roundTo(nextMonthBaseRevenue),
      nextMonthWeightedRevenue: roundTo(nextMonthWeightedRevenue),
      nextMonthBaseSubscribers: nextMonthSubscriptions.length,
      nextMonthWeightedSubscribers: roundTo(
        nextMonthSubscriptions.reduce(
          (sum, item) => sum + (item.isConnected ? connectedRate : disconnectedRate),
          0
        ),
        2
      ),
      nextMonthConnectedBaseRevenue: roundTo(nextMonthConnectedBaseRevenue),
      nextMonthConnectedWeightedRevenue: roundTo(nextMonthConnectedWeightedRevenue),
      nextMonthConnectedSubscribers: nextMonthSubscriptions.filter(
        (item) => item.isConnected
      ).length,
      nextMonthDisconnectedBaseRevenue: roundTo(nextMonthDisconnectedBaseRevenue),
      nextMonthDisconnectedWeightedRevenue: roundTo(
        nextMonthDisconnectedWeightedRevenue
      ),
      nextMonthDisconnectedSubscribers: nextMonthSubscriptions.filter(
        (item) => !item.isConnected
      ).length,
      expiringThisMonthSubscribers,
      atRiskDisconnectedSubscribers
    },
    renewal: {
      overallRate: roundTo(overallRate * 100, 2),
      connectedRate: roundTo(connectedRate * 100, 2),
      disconnectedRate: roundTo(disconnectedRate * 100, 2),
      connectedEligible: renewalSamples.connected.eligible,
      disconnectedEligible: renewalSamples.disconnected.eligible,
      connectedRenewed: renewalSamples.connected.renewed,
      disconnectedRenewed: renewalSamples.disconnected.renewed
    },
    monthlySeries,
    upcomingRenewals,
    planMix: Array.from(planMixMap.values()).map((item) => ({
      ...item,
      scheduledRevenueNextMonth: roundTo(item.scheduledRevenueNextMonth)
    })).sort((left, right) => right.activeSubscribers - left.activeSubscribers)
  };
}

// server/pendingAiDeliveryState.ts
function isConfirmedOutgoingMessageStatus(status) {
  if (!status) return true;
  switch (status.trim().toLowerCase()) {
    case "sent":
    case "delivered":
    case "read":
      return true;
    case "queued":
    case "pending":
    case "pending_delivery":
    case "failed":
      return false;
    default:
      return true;
  }
}
function isUnconfirmedOutgoingMessageStatus(status) {
  if (!status) return false;
  switch (status.trim().toLowerCase()) {
    case "queued":
    case "pending":
    case "pending_delivery":
    case "failed":
      return true;
    default:
      return false;
  }
}
function shouldRecoverCompletedTimer(params) {
  const {
    lastCustomerAt,
    lastAgentAt,
    lastOwnerAt,
    now = /* @__PURE__ */ new Date(),
    maxCustomerSilenceHours = 24
  } = params;
  if (!lastCustomerAt) return false;
  const maxAgeMs = maxCustomerSilenceHours * 60 * 60 * 1e3;
  if (now.getTime() - lastCustomerAt.getTime() > maxAgeMs) return false;
  if (lastOwnerAt && lastOwnerAt.getTime() >= lastCustomerAt.getTime()) {
    return false;
  }
  if (!lastAgentAt) return true;
  return lastCustomerAt.getTime() > lastAgentAt.getTime();
}

// shared/planCatalog.ts
function isPlanVisibleInPublicCatalog(plan) {
  if (!plan || plan.ativo !== true) {
    return false;
  }
  if (plan.exibirNaPaginaPlanos !== true) {
    return false;
  }
  if (plan.isPersonalizado === true) {
    return false;
  }
  if (plan.tipo === "revenda") {
    return false;
  }
  if (plan.tipo === "implementacao" || plan.tipo === "implementacao_mensal") {
    return false;
  }
  return true;
}
function sortPlansForPublicCatalog(plans2) {
  return [...plans2].sort((left, right) => {
    const leftOrder = typeof left.ordem === "number" ? left.ordem : 0;
    const rightOrder = typeof right.ordem === "number" ? right.ordem : 0;
    if (leftOrder !== rightOrder) {
      return leftOrder - rightOrder;
    }
    return left.id.localeCompare(right.id);
  });
}
function getPublicCatalogPlans(plans2) {
  return sortPlansForPublicCatalog(plans2.filter((plan) => isPlanVisibleInPublicCatalog(plan)));
}

// server/productCatalogAssets.ts
function toInt(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const parsed = Number.parseInt(String(value ?? ""), 10);
  return Number.isFinite(parsed) ? parsed : 0;
}
function toOptionalInt(value) {
  if (value === null || value === void 0 || value === "") return null;
  if (typeof value === "number" && Number.isFinite(value)) return Math.trunc(value);
  const parsed = Number.parseInt(String(value ?? ""), 10);
  return Number.isFinite(parsed) ? parsed : null;
}
function toOptionalNumericString(value) {
  if (value === null || value === void 0) return null;
  const normalized = String(value).trim();
  return normalized ? normalized : null;
}
function normalizeProductMediaAsset(row) {
  return {
    id: String(row?.id ?? ""),
    product_id: String(row?.product_id ?? row?.productId ?? ""),
    user_id: row?.user_id ?? row?.userId ?? null,
    storage_url: String(row?.storage_url ?? row?.storageUrl ?? ""),
    storage_path: row?.storage_path ?? row?.storagePath ?? null,
    file_name: row?.file_name ?? row?.fileName ?? null,
    file_size: typeof row?.file_size === "number" ? row.file_size : typeof row?.fileSize === "number" ? row.fileSize : null,
    mime_type: row?.mime_type ?? row?.mimeType ?? null,
    caption: row?.caption ?? null,
    variation_code: toOptionalInt(row?.variation_code ?? row?.variationCode),
    variation_name: toOptionalNumericString(row?.variation_name ?? row?.variationName),
    variation_price: toOptionalNumericString(row?.variation_price ?? row?.variationPrice),
    variation_stock: toOptionalInt(row?.variation_stock ?? row?.variationStock),
    variation_is_active: row?.variation_is_active !== false && row?.variationIsActive !== false,
    display_order: toInt(row?.display_order ?? row?.displayOrder),
    created_at: row?.created_at ?? row?.createdAt ?? null,
    updated_at: row?.updated_at ?? row?.updatedAt ?? null
  };
}
function buildLegacyProductMediaAsset(product) {
  const imageUrl = typeof product.image_url === "string" ? product.image_url.trim() : "";
  if (!imageUrl) {
    return null;
  }
  return {
    id: `legacy:${product.id}`,
    product_id: product.id,
    user_id: null,
    storage_url: imageUrl,
    storage_path: null,
    file_name: null,
    file_size: null,
    mime_type: null,
    caption: null,
    variation_code: 1,
    variation_name: null,
    variation_price: null,
    variation_stock: null,
    variation_is_active: true,
    display_order: 0,
    created_at: null,
    updated_at: null
  };
}
function attachMediaToProducts(products, mediaRows) {
  const mediaByProduct = /* @__PURE__ */ new Map();
  for (const row of mediaRows || []) {
    const media = normalizeProductMediaAsset(row);
    if (!media.product_id || !media.storage_url) continue;
    const list = mediaByProduct.get(media.product_id) || [];
    list.push(media);
    mediaByProduct.set(media.product_id, list);
  }
  return products.map((product) => {
    const existingMedia = [...mediaByProduct.get(product.id) || []].sort((a, b) => {
      if (a.display_order !== b.display_order) {
        return a.display_order - b.display_order;
      }
      return a.id.localeCompare(b.id);
    });
    const legacyMedia = existingMedia.length === 0 ? buildLegacyProductMediaAsset(product) : null;
    const media_items = legacyMedia ? [legacyMedia] : existingMedia;
    return {
      ...product,
      media_items,
      image_count: media_items.length,
      primary_image_url: media_items[0]?.storage_url || (typeof product.image_url === "string" ? product.image_url : null) || null
    };
  });
}
async function fetchProductMediaRows(params) {
  const productIds = Array.from(new Set((params.productIds || []).filter(Boolean)));
  if (productIds.length === 0) {
    return [];
  }
  const { data, error } = await params.supabase.from("product_media").select("*").eq("user_id", params.userId).in("product_id", productIds).order("display_order", { ascending: true }).order("created_at", { ascending: true });
  if (error) {
    throw error;
  }
  return (data || []).map(normalizeProductMediaAsset);
}

// server/blogUtils.ts
function extractFirstJsonObject(raw) {
  let depth = 0;
  let start = -1;
  let inString = false;
  let escaped = false;
  for (let index = 0; index < raw.length; index += 1) {
    const char = raw[index];
    if (char === '"' && !escaped) {
      inString = !inString;
    }
    if (!inString) {
      if (char === "{") {
        if (depth === 0) start = index;
        depth += 1;
      } else if (char === "}") {
        depth -= 1;
        if (depth === 0 && start >= 0) {
          return JSON.parse(raw.slice(start, index + 1));
        }
      }
    }
    escaped = char === "\\" && !escaped;
  }
  throw new Error("Nenhum JSON valido encontrado");
}
function readObject(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return null;
  }
  return value;
}
function isBlogAiImageProvider(provider) {
  return provider === "nvidia" || provider === "mistral" || provider === "huggingface";
}
function isBlogDurableImageUrl(input) {
  if (!input.publicUrl) {
    return false;
  }
  const storage2 = readObject(readObject(input.sourceProvenance)?.storage);
  if (storage2?.provider === "supabase") {
    return true;
  }
  try {
    const parsed = new URL(input.publicUrl);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return false;
    }
    return parsed.pathname.includes("/storage/v1/object/public/");
  } catch {
    return false;
  }
}
function isBlogPublishableImageAsset(input) {
  return isBlogAiImageProvider(input.provider) && isBlogDurableImageUrl(input);
}
function resolveBlogPostStatusAfterEditorialUpdate(input) {
  if (input.isRefresh && input.currentStatus === "published") {
    return "published";
  }
  return input.approvalDecision === "blocked" ? "rejected" : "ready";
}
function buildBlogApprovalSummary(input) {
  const blockingReasons = [];
  if (!input.passed) {
    blockingReasons.push("A revisao semantica bloqueou a publicacao automatica.");
  }
  if (input.internalProofCount < 3) {
    blockingReasons.push("Faltam provas internas suficientes do produto.");
  }
  if (input.requiredInternalLinks < 5) {
    blockingReasons.push("O artigo ainda tem poucos links internos semanticos.");
  }
  if (input.duplicateSimilarity > 0.76) {
    blockingReasons.push("O texto ficou proximo demais de outro artigo ja publicado.");
  }
  if (input.unsupportedClaims > 0) {
    blockingReasons.push("Ainda existem claims sem sustentacao clara.");
  }
  const improvementActions = [
    ...input.notes || [],
    ...input.factualIssues || [],
    ...input.seoIssues || [],
    ...input.styleIssues || [],
    ...input.suggestedFixes || []
  ].filter(Boolean);
  if (blockingReasons.length > 0) {
    return {
      decision: "blocked",
      autoApproved: false,
      canAutoPublish: false,
      meetsQualityBar: false,
      meetsAutoPublishBar: false,
      blockingReasons,
      improvementActions
    };
  }
  const qualityReady = input.qualityScore >= 88 && input.peopleFirstScore >= 86 && input.originalityScore >= 82;
  const autoPublishReady = input.qualityScore >= 92 && input.peopleFirstScore >= 90 && input.originalityScore >= 86 && input.duplicateSimilarity <= 0.46 && input.internalProofCount >= 3 && input.requiredInternalLinks >= 5 && input.unsupportedClaims === 0 && (input.factualIssues?.length || 0) === 0 && (input.styleIssues?.length || 0) <= 1 && (input.seoIssues?.length || 0) <= 1;
  const autoApproved = input.autoApproveEnabled && qualityReady;
  return {
    decision: autoApproved ? "auto-approved" : "needs-review",
    autoApproved,
    canAutoPublish: autoApproved && autoPublishReady && input.autoPublishEnabled && input.publishEnabled,
    meetsQualityBar: qualityReady,
    meetsAutoPublishBar: autoPublishReady,
    blockingReasons: [],
    improvementActions
  };
}

// server/productCatalogMediaService.ts
var PRODUCT_IMAGE_MEDIA_PREFIX = "CATALOG_PRODUCT_IMAGE";
function buildCatalogProductImageMediaName(productId, mediaId) {
  const suffix = String(mediaId || "legacy").trim() || "legacy";
  return `${PRODUCT_IMAGE_MEDIA_PREFIX}:${productId}:${suffix}`;
}
function getCatalogContextTimestampMs(message) {
  const raw = message?.timestamp;
  if (!raw) return null;
  const parsed = raw instanceof Date ? raw.getTime() : new Date(raw).getTime();
  return Number.isFinite(parsed) ? parsed : null;
}
function buildCatalogMediaRequestContext(params) {
  const currentText = String(params.clientMessage || "").trim();
  const history = Array.isArray(params.conversationHistory) ? params.conversationHistory : [];
  const maxMessages = Math.max(1, Math.min(10, params.maxMessages ?? 6));
  const windowMs = Math.max(3e4, params.windowMs ?? 10 * 6e4);
  let latestInboundMs = null;
  for (let index = history.length - 1; index >= 0; index -= 1) {
    const message = history[index];
    if (!message || message.fromMe) continue;
    latestInboundMs = getCatalogContextTimestampMs(message);
    break;
  }
  const recentInbound = [];
  for (let index = history.length - 1; index >= 0; index -= 1) {
    const message = history[index];
    if (!message) continue;
    if (message.fromMe) break;
    const text = String(message.text || "").trim();
    if (!text) continue;
    if (latestInboundMs !== null) {
      const messageMs = getCatalogContextTimestampMs(message);
      if (messageMs !== null && latestInboundMs - messageMs > windowMs) {
        break;
      }
    }
    recentInbound.push(text);
    if (recentInbound.length >= maxMessages) break;
  }
  const orderedInbound = recentInbound.reverse();
  const normalizedCurrent = normalizeCatalogRequestText(currentText);
  const coveredByCurrent = orderedInbound.filter((text) => {
    const normalized = normalizeCatalogRequestText(text);
    return normalized && normalizedCurrent.includes(normalized);
  }).length;
  if (currentText && orderedInbound.length > 1 && coveredByCurrent >= Math.min(2, orderedInbound.length)) {
    return truncateText(currentText, 2e3);
  }
  const pieces = [];
  const seen = /* @__PURE__ */ new Set();
  const addPiece = (value) => {
    const text = String(value || "").trim();
    const key = normalizeCatalogRequestText(text);
    if (!text || !key || seen.has(key)) return;
    seen.add(key);
    pieces.push(text);
  };
  orderedInbound.forEach(addPiece);
  addPiece(currentText);
  return truncateText(pieces.join("\n\n"), 2e3);
}
function truncateText(value, maxLength) {
  const text = String(value || "").trim();
  if (!text) return "";
  if (text.length <= maxLength) return text;
  return `${text.slice(0, Math.max(0, maxLength - 3))}...`;
}
function normalizeCatalogConsistencyText(value) {
  return normalizeCatalogRequestText(value);
}
function normalizeCatalogRequestText(value) {
  return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
}
function includesAnyCatalogFragment(text, fragments) {
  return fragments.some((fragment) => text.includes(fragment));
}
function countNumericTokens(text) {
  let count = 0;
  let index = 0;
  while (index < text.length) {
    const char = text[index];
    if (char < "0" || char > "9") {
      index += 1;
      continue;
    }
    count += 1;
    while (index < text.length) {
      const digitChar = text[index];
      if (digitChar < "0" || digitChar > "9") {
        break;
      }
      index += 1;
    }
  }
  return count;
}
function looksLikeCompactCatalogCodeSelection(normalizedClientMessage) {
  if (!normalizedClientMessage) {
    return false;
  }
  const hasSelectionVerb = includesAnyCatalogFragment(normalizedClientMessage, [
    "quero ",
    "vou querer",
    "pode ser",
    "separa",
    "separe",
    "inclui",
    "inclua"
  ]);
  return hasSelectionVerb && countNumericTokens(normalizedClientMessage) >= 2;
}
function isDetailedCatalogChoiceMessage(normalizedClientMessage) {
  return includesAnyCatalogFragment(normalizedClientMessage, [
    "quero esse",
    "quero este",
    "quero o codigo",
    "quero os codigos",
    "quero o cod",
    "quero os cod",
    "codigo ",
    "codigos ",
    "codigos:",
    "cod ",
    "quantidade",
    "costurado",
    "sem costura",
    "orcamento",
    "pedido",
    "pix",
    "cartao",
    "dinheiro",
    "link de pagamento",
    "finalizar",
    "finalizacao"
  ]) || looksLikeCompactCatalogCodeSelection(normalizedClientMessage);
}
function isExplicitCatalogPhotoRequest(normalizedClientMessage) {
  return includesAnyCatalogFragment(normalizedClientMessage, [
    "manda foto",
    "manda a foto",
    "manda as fotos",
    "me manda foto",
    "me manda a foto",
    "me manda as fotos",
    "envia foto",
    "envia a foto",
    "envia as fotos",
    "me envia foto",
    "me envia a foto",
    "me envia as fotos",
    "mostra foto",
    "mostra a foto",
    "mostra as fotos",
    "me mostra foto",
    "me mostra a foto",
    "me mostra as fotos",
    "quero ver foto",
    "quero ver as fotos",
    "fotos do tema",
    "foto do tema",
    "foto do codigo",
    "foto do cod",
    "imagem do codigo",
    "imagem do cod"
  ]);
}
function isCatalogLocationOrVisitRequest(normalizedClientMessage) {
  if (!normalizedClientMessage) {
    return false;
  }
  return includesAnyCatalogFragment(normalizedClientMessage, [
    "endereco",
    "localizacao",
    "como chegar",
    "onde fica",
    "mapa",
    "horario presencial",
    "atendimento presencial",
    "visita",
    "visitar",
    "ir ver",
    "ver uma tenda",
    "ver a tenda",
    "ver no local",
    "ver pessoalmente",
    "ver na loja",
    "loja fisica"
  ]);
}
function isCatalogTechnicalInfoRequest(normalizedClientMessage) {
  if (!normalizedClientMessage) return false;
  if (isExplicitCatalogPhotoRequest(normalizedClientMessage)) return false;
  return includesAnyCatalogFragment(normalizedClientMessage, [
    "qual ",
    "quais ",
    "quanto ",
    "quantos ",
    "vazao",
    "vasao",
    "potencia",
    "consumo",
    "ruido",
    "barulho",
    " db",
    "decibeis",
    "medida",
    "medidas",
    "dimensao",
    "dimensoes",
    "altura",
    "largura",
    "profundidade",
    "alcance",
    "ficha",
    "tecnico",
    "tecnicos",
    "tecnica",
    "tecnicas",
    "dados",
    "especificacao",
    "especificacoes",
    "detalhe",
    "detalhes",
    "descricao",
    "descreve",
    "informacao",
    "informacoes",
    "caracteristica",
    "caracteristicas",
    "voltagem"
  ]);
}
function isCatalogTransactionalReply(normalizedAssistantResponse) {
  return includesAnyCatalogFragment(normalizedAssistantResponse, [
    "carrinho do pedido",
    "total geral",
    "subtotal",
    "forma de pagamento",
    "qual sera a forma de pagamento",
    "esta tudo certo com seu pedido",
    "posso seguir para a finalizacao",
    "vou organizar o seu pedido",
    "vou organizar o item no seu orcamento",
    "deseja orcamento de mais algum item"
  ]);
}
function looksLikeCatalogListingReply(normalizedAssistantResponse) {
  const hasCode = includesAnyCatalogFragment(normalizedAssistantResponse, [
    "codigo:",
    "codigo ",
    "cod:",
    "cod "
  ]);
  const hasPrice = includesAnyCatalogFragment(normalizedAssistantResponse, [
    "valor:",
    "valor ",
    "preco:",
    "preco ",
    "r$"
  ]);
  return hasCode && hasPrice;
}
function looksLikeImmediateCatalogPhotoReply(normalizedAssistantResponse) {
  if (!normalizedAssistantResponse) {
    return false;
  }
  if (normalizedAssistantResponse.includes("[foto")) {
    return true;
  }
  return includesAnyCatalogFragment(normalizedAssistantResponse, [
    "aqui estao as fotos",
    "aqui estao os produtos",
    "seguem as fotos",
    "segue as fotos",
    "estou enviando as fotos",
    "to enviando as fotos",
    "vou te mostrar as fotos",
    "vou mostrar as fotos",
    "fotos do tema",
    "fotos para voce conferir"
  ]);
}
function shouldAttachCatalogMediaForReply(params) {
  if (params.allowExplicitResend) {
    return true;
  }
  const assistantResponse = String(params.assistantResponse || "").trim();
  if (!assistantResponse) {
    return false;
  }
  const normalizedClientMessage = normalizeCatalogRequestText(params.clientMessage);
  const isDetailedChoice = isDetailedCatalogChoiceMessage(normalizedClientMessage);
  const explicitPhotoRequest = isExplicitCatalogPhotoRequest(normalizedClientMessage);
  if (isCatalogLocationOrVisitRequest(normalizedClientMessage) && !explicitPhotoRequest) {
    return false;
  }
  if (isDetailedChoice && !explicitPhotoRequest) {
    return false;
  }
  if (detectMediaSendingIntent(assistantResponse)) {
    return true;
  }
  const normalizedAssistantResponse = normalizeCatalogRequestText(assistantResponse);
  if (looksLikeImmediateCatalogPhotoReply(normalizedAssistantResponse)) {
    return true;
  }
  if (!looksLikeCatalogListingReply(normalizedAssistantResponse)) {
    return false;
  }
  if (isCatalogTransactionalReply(normalizedAssistantResponse)) {
    return false;
  }
  return true;
}
function shouldForceCatalogMediaForKnownSubject(params) {
  const normalizedClientMessage = normalizeCatalogRequestText(params.clientMessage);
  const products = params.products || [];
  if (!normalizedClientMessage || products.length === 0) {
    return false;
  }
  if (isOperationalCatalogFollowUp(params.clientMessage)) {
    return false;
  }
  if (isCatalogTechnicalInfoRequest(normalizedClientMessage)) {
    return false;
  }
  const explicitPhotoRequest = isExplicitCatalogPhotoRequest(normalizedClientMessage);
  const isDetailedChoice = isDetailedCatalogChoiceMessage(normalizedClientMessage);
  if (isCatalogLocationOrVisitRequest(normalizedClientMessage) && !explicitPhotoRequest) {
    return false;
  }
  if (isDetailedChoice && !explicitPhotoRequest) {
    return false;
  }
  if (isCatalogSwitchRequestWithoutKnownSubject(params.clientMessage, products)) {
    return false;
  }
  if (!messageReferencesKnownCatalogSubject(params.clientMessage, products)) {
    return false;
  }
  const catalogInquirySignals = [
    "tem ",
    "temos ",
    "voces tem",
    "voce tem",
    "trabalha",
    "faz ",
    "tema",
    "catalogo",
    "foto",
    "fotos",
    "imagem",
    "imagens",
    "painel",
    "cilindro",
    "cilindros",
    "capa",
    "me mostra",
    "mostra",
    "me manda",
    "manda",
    "me envia",
    "envia",
    "quero ver"
  ];
  return catalogInquirySignals.some((signal) => normalizedClientMessage.includes(signal));
}
function listCatalogAnchorTerms(product) {
  const stopTerms = /* @__PURE__ */ new Set([
    "de",
    "do",
    "da",
    "das",
    "dos",
    "e",
    "tema",
    "catalogo",
    "fotos",
    "foto",
    "painel",
    "paineis",
    "arte",
    "artes",
    "kit",
    "kits",
    "cilindro",
    "cilindros",
    "lateral",
    "laterais",
    "com",
    "sem",
    "para"
  ]);
  const rawTerms = [
    normalizeCatalogRequestText(product.name),
    normalizeCatalogRequestText(product.category)
  ].filter(Boolean).flatMap((value) => value.split(" "));
  const uniqueTerms = /* @__PURE__ */ new Set();
  for (const term of rawTerms) {
    const cleanTerm = String(term || "").trim();
    if (!cleanTerm || (cleanTerm.length < 4 && !/^\d{2,4}$/.test(cleanTerm) || stopTerms.has(cleanTerm))) {
      continue;
    }
    uniqueTerms.add(cleanTerm);
  }
  return Array.from(uniqueTerms);
}
function buildUniqueCatalogAnchorTerms(products) {
  const productTerms = /* @__PURE__ */ new Map();
  const ownership = /* @__PURE__ */ new Map();
  for (const product of products) {
    const terms = listCatalogAnchorTerms(product);
    productTerms.set(product.id, terms);
    for (const term of terms) {
      if (!ownership.has(term)) {
        ownership.set(term, /* @__PURE__ */ new Set());
      }
      ownership.get(term).add(product.id);
    }
  }
  const uniqueTermsByProduct = /* @__PURE__ */ new Map();
  for (const product of products) {
    uniqueTermsByProduct.set(
      product.id,
      (productTerms.get(product.id) || []).filter((term) => ownership.get(term)?.size === 1)
    );
  }
  return uniqueTermsByProduct;
}
function hasCatalogCodeLabelBefore(text, digitStart) {
  const before = text.slice(Math.max(0, digitStart - 24), digitStart).toLowerCase();
  const labels = ["codigo", "c\xF3digo", "cod", "c\xF3d"];
  return labels.some((label) => before.includes(label));
}
function extractKnownCatalogVariationCodes(value, knownCodes) {
  const text = String(value || "");
  if (!text || knownCodes.size === 0) {
    return [];
  }
  const codes = [];
  const seen = /* @__PURE__ */ new Set();
  let index = 0;
  let listContextBudget = 0;
  while (index < text.length) {
    const current = text[index];
    if (current === "\n" || current === "\r" || current === "." || current === ";" || current === ":") {
      listContextBudget = 0;
      index += 1;
      continue;
    }
    if ((current === "c" || current === "C") && text.slice(index, index + 7).toLowerCase().startsWith("codigo")) {
      listContextBudget = 16;
      index += 6;
      continue;
    }
    if ((current === "c" || current === "C") && text.slice(index, index + 3).toLowerCase().startsWith("cod")) {
      listContextBudget = 16;
      index += 3;
      continue;
    }
    if (current < "0" || current > "9") {
      if (listContextBudget > 0 && current !== "," && current !== " " && current !== "	" && current !== "e") {
        listContextBudget = Math.max(0, listContextBudget - 1);
      }
      index += 1;
      continue;
    }
    const digitStart = index;
    let digits = "";
    while (index < text.length) {
      const digit = text[index];
      if (digit < "0" || digit > "9") break;
      digits += digit;
      index += 1;
    }
    const parsed = Number(digits);
    const hasDirectLabel = hasCatalogCodeLabelBefore(text, digitStart);
    const inListContext = listContextBudget > 0;
    if (Number.isInteger(parsed) && knownCodes.has(parsed) && !seen.has(parsed) && (hasDirectLabel || inListContext)) {
      seen.add(parsed);
      codes.push(parsed);
    }
    if (inListContext) {
      listContextBudget = Math.max(0, listContextBudget - 1);
    }
  }
  return codes;
}
function collectReferencedProductIdsFromText(value, products) {
  const normalizedValue = normalizeCatalogRequestText(value);
  if (!normalizedValue) {
    return [];
  }
  const uniqueTermsByProduct = buildUniqueCatalogAnchorTerms(products);
  return products.filter((product) => {
    const fullName = normalizeCatalogRequestText(product.name);
    if (fullName && normalizedValue.includes(fullName)) {
      return true;
    }
    return (uniqueTermsByProduct.get(product.id) || []).some((term) => normalizedValue.includes(term));
  }).map((product) => product.id);
}
function inferCatalogProductIdsFromContext(input, products) {
  const codesByProductId = /* @__PURE__ */ new Map();
  for (const product of products) {
    for (const image of product.images || []) {
      if (typeof image.variationCode === "number" && Number.isFinite(image.variationCode)) {
        codesByProductId.set(image.variationCode, product.id);
      }
    }
  }
  const knownCodes = new Set(codesByProductId.keys());
  const currentMessageCodes = extractKnownCatalogVariationCodes(input.clientMessage, knownCodes);
  if (currentMessageCodes.length > 0) {
    return Array.from(
      new Set(
        currentMessageCodes.map((code) => codesByProductId.get(code)).filter((productId) => Boolean(productId))
      )
    );
  }
  const currentMessageProductIds = collectReferencedProductIdsFromText(input.clientMessage, products);
  if (currentMessageProductIds.length > 0) {
    return Array.from(new Set(currentMessageProductIds));
  }
  const assistantResponseCodes = extractKnownCatalogVariationCodes(input.assistantResponse, knownCodes);
  if (assistantResponseCodes.length > 0) {
    return Array.from(
      new Set(
        assistantResponseCodes.map((code) => codesByProductId.get(code)).filter((productId) => Boolean(productId))
      )
    );
  }
  if (detectMediaSendingIntent(input.assistantResponse) || looksLikeImmediateCatalogPhotoReply(normalizeCatalogRequestText(input.assistantResponse)) || looksLikeCatalogListingReply(normalizeCatalogRequestText(input.assistantResponse))) {
    const assistantResponseProductIds = collectReferencedProductIdsFromText(input.assistantResponse, products);
    if (assistantResponseProductIds.length > 0) {
      return Array.from(new Set(assistantResponseProductIds));
    }
  }
  const recentInboundHistory = (input.conversationHistory || []).slice(-20).filter((message) => !message.fromMe).map((message) => String(message.text || "").trim()).filter(Boolean);
  if (isExplicitCatalogMediaResendRequest(input.clientMessage)) {
    const historyCodes = extractKnownCatalogVariationCodes(recentInboundHistory.join("\n"), knownCodes);
    if (historyCodes.length > 0) {
      return Array.from(
        new Set(
          historyCodes.map((code) => codesByProductId.get(code)).filter((productId) => Boolean(productId))
        )
      );
    }
    const historyProductIds = recentInboundHistory.flatMap((text) => collectReferencedProductIdsFromText(text, products));
    if (historyProductIds.length > 0) {
      return Array.from(new Set(historyProductIds));
    }
  }
  return [];
}
function messageReferencesKnownCatalogSubject(value, products) {
  const normalizedValue = normalizeCatalogRequestText(value);
  if (!normalizedValue) {
    return false;
  }
  const uniqueTermsByProduct = buildUniqueCatalogAnchorTerms(products);
  return products.some((product) => {
    const fullName = normalizeCatalogRequestText(product.name);
    if (fullName && normalizedValue.includes(fullName)) {
      return true;
    }
    return (uniqueTermsByProduct.get(product.id) || []).some((term) => normalizedValue.includes(term));
  });
}
function isOperationalCatalogFollowUp(value) {
  const normalizedValue = normalizeCatalogRequestText(value);
  if (!normalizedValue) {
    return false;
  }
  const operationalSignals = [
    "pix",
    "qr code",
    "qrcode",
    "comprovante",
    "pagamento",
    "pagar",
    "endereco",
    "localizacao",
    "como chegar",
    "onde fica",
    "mapa",
    "horario",
    "funcionamento"
  ];
  return operationalSignals.some((signal) => normalizedValue.includes(signal));
}
function isCatalogSwitchRequestWithoutKnownSubject(value, products) {
  const normalizedValue = normalizeCatalogRequestText(value);
  if (!normalizedValue) {
    return false;
  }
  if (messageReferencesKnownCatalogSubject(normalizedValue, products)) {
    return false;
  }
  const switchSignals = [
    "outro tema",
    "outra tema",
    "tema do",
    "tema de",
    "tem outro tema",
    "tem outro item",
    "outro item",
    "outra arte",
    "quero outro tema"
  ];
  return switchSignals.some((signal) => normalizedValue.includes(signal));
}
function isExplicitCatalogMediaResendRequest(value) {
  const normalized = normalizeCatalogRequestText(value);
  if (!normalized) return false;
  const resendPhrases = [
    "manda de novo",
    "manda novamente",
    "me manda de novo",
    "me manda novamente",
    "envia de novo",
    "envia novamente",
    "me envia de novo",
    "me envia novamente",
    "reenvia",
    "reenvie",
    "quero ver de novo",
    "quero ver novamente",
    "me mostra de novo",
    "me mostra novamente",
    "mostra de novo",
    "mostra novamente",
    "nao abriu",
    "nao carregou"
  ];
  return resendPhrases.some((phrase) => normalized.includes(phrase));
}
function catalogResponseContradictsAttachedImages(value) {
  const text = normalizeCatalogConsistencyText(value);
  if (!text) return false;
  const contradictionPhrases = [
    "nao esta cadastrado",
    "nao est\xE1 cadastrado",
    "n\xE3o est\xE1 cadastrado",
    "ainda nao esta cadastrado",
    "ainda nao est\xE1 cadastrado",
    "ainda n\xE3o est\xE1 cadastrado",
    "nao encontrei esse produto",
    "n\xE3o encontrei esse produto",
    "nao achei esse produto",
    "n\xE3o achei esse produto",
    "nao temos esse produto",
    "n\xE3o temos esse produto",
    "nao tenho esse produto",
    "nao posso enviar imagens",
    "nao consigo enviar imagens",
    "nao posso enviar fotos",
    "nao consigo enviar fotos",
    "nao tenho acesso a um catalogo visual",
    "nao tenho acesso ao catalogo visual",
    "nao tenho capacidade de enviar arquivos",
    "nao tenho capacidade de enviar imagens",
    "sem acesso a um catalogo visual",
    "sou uma ia sem acesso",
    "como uma ia nao tenho acesso",
    "n\xE3o tenho esse produto",
    "vou encaminhar para um humano",
    "vou encaminhar para uma pessoa",
    "vou passar para um humano",
    "vou passar para uma pessoa",
    "assim que cadastrar",
    "quando cadastrar"
  ];
  return contradictionPhrases.some((phrase) => text.includes(phrase));
}
function buildAttachedImagesResponseFallback(productName, imageCount) {
  return `Separei ${imageCount} foto(s) de ${productName} e estou enviando agora logo abaixo para voc\xEA ver.`;
}
function getFirstMeaningfulLine(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) {
    return "";
  }
  const firstLineBreak = trimmed.indexOf("\n");
  if (firstLineBreak < 0) {
    return trimmed;
  }
  return trimmed.slice(0, firstLineBreak).trim();
}
function startsWithBrazilGreeting(line) {
  const rawLine = String(line || "").trim();
  if (!rawLine) {
    return false;
  }
  let startIndex = 0;
  while (startIndex < rawLine.length) {
    const current = rawLine[startIndex];
    if (current === "*" || current === "_" || current === "~" || current === "`" || current === " " || current === "	") {
      startIndex += 1;
      continue;
    }
    break;
  }
  const lowered = rawLine.slice(startIndex).toLocaleLowerCase("pt-BR");
  if (!lowered) {
    return false;
  }
  return lowered.startsWith("bom dia") || lowered.startsWith("boa tarde") || lowered.startsWith("boa noite") || lowered.startsWith("ol\xE1") || lowered.startsWith("ola") || lowered.startsWith("oi");
}
function preserveGreetingLineWhenMissing(originalResponse, rewrittenResponse) {
  const originalGreetingLine = getFirstMeaningfulLine(originalResponse);
  if (!startsWithBrazilGreeting(originalGreetingLine)) {
    return rewrittenResponse;
  }
  const rewrittenFirstLine = getFirstMeaningfulLine(rewrittenResponse);
  if (startsWithBrazilGreeting(rewrittenFirstLine)) {
    return rewrittenResponse;
  }
  return `${originalGreetingLine}
${rewrittenResponse}`.trim();
}
function getOrderedImages(product) {
  return [...product.images || []].filter((image) => String(image?.storageUrl || "").trim()).sort((a, b) => Number(a.displayOrder || 0) - Number(b.displayOrder || 0));
}
async function selectCatalogProductImage(input, deps = {}) {
  const visualProducts = input.products.map((product) => ({
    ...product,
    images: getOrderedImages(product)
  })).filter((product) => product.images.length > 0);
  if (visualProducts.length === 0) {
    return {
      shouldSend: false,
      productId: null,
      productIds: [],
      confidence: 0,
      reason: "Nenhum produto com imagem disponivel no catalogo."
    };
  }
  const normalizedClientMessage = normalizeCatalogRequestText(input.clientMessage);
  const explicitPhotoRequest = isExplicitCatalogPhotoRequest(normalizedClientMessage);
  if (isCatalogLocationOrVisitRequest(normalizedClientMessage) && !explicitPhotoRequest && !isExplicitCatalogMediaResendRequest(input.clientMessage)) {
    return {
      shouldSend: false,
      productId: null,
      productIds: [],
      confidence: 100,
      reason: "Mensagem atual pede endereco, localizacao ou visita presencial, nao fotos do catalogo."
    };
  }
  const currentTurnReferencesKnownProduct = messageReferencesKnownCatalogSubject(input.clientMessage, visualProducts) || messageReferencesKnownCatalogSubject(input.assistantResponse, visualProducts);
  if (isOperationalCatalogFollowUp(input.clientMessage) && !currentTurnReferencesKnownProduct && !isExplicitCatalogMediaResendRequest(input.clientMessage)) {
    return {
      shouldSend: false,
      productId: null,
      productIds: [],
      confidence: 100,
      reason: "Mensagem atual mudou para assunto operacional sem pedido de fotos do catalogo."
    };
  }
  if (isCatalogSwitchRequestWithoutKnownSubject(input.clientMessage, visualProducts) && !isExplicitCatalogMediaResendRequest(input.clientMessage)) {
    return {
      shouldSend: false,
      productId: null,
      productIds: [],
      confidence: 100,
      reason: "Mensagem atual pede outro tema/item sem ancoragem em produto existente do catalogo."
    };
  }
  if (isCatalogTechnicalInfoRequest(normalizedClientMessage)) {
    return {
      shouldSend: false,
      productId: null,
      productIds: [],
      confidence: 100,
      reason: "Mensagem atual pede dados tecnicos do produto, nao fotos do catalogo."
    };
  }
  if (!catalogResponseContradictsAttachedImages(input.assistantResponse) && !isDetailedCatalogChoiceMessage(normalizedClientMessage)) {
    const inferredProductIds = inferCatalogProductIdsFromContext(input, visualProducts);
    if (inferredProductIds.length > 0) {
      return {
        shouldSend: true,
        productId: inferredProductIds[0] || null,
        productIds: inferredProductIds,
        confidence: 100,
        reason: "Produtos do cat\xE1logo identificados por c\xF3digo exato ou assunto citado no turno atual."
      };
    }
  }
  const recentHistory = input.conversationHistory.slice(-20).map((message) => `${message.fromMe ? "Agente" : "Cliente"}: ${truncateText(message.text, 240) || "(sem texto)"}`).join("\n");
  const catalogText = visualProducts.slice(0, 120).map((product, index) => {
    const variationSummary = product.imageVariationsEnabled === true ? product.images.filter((image) => image.variationIsActive !== false).map((image) => {
      const parts2 = [];
      if (typeof image.variationCode === "number") {
        parts2.push(`COD=${image.variationCode}`);
      }
      if (image.variationName) {
        parts2.push(`NOME_VARIACAO=${image.variationName}`);
      }
      if (image.variationPrice) {
        parts2.push(`PRECO_VARIACAO=${image.variationPrice}`);
      }
      return parts2.join(" | ");
    }).filter(Boolean).join(" ; ") : "";
    const parts = [
      `ID=${product.id}`,
      `NOME=${product.name}`,
      product.category ? `CATEGORIA=${product.category}` : null,
      product.price ? `PRECO=${product.price}` : null,
      product.description ? `DESCRICAO=${truncateText(product.description, 160)}` : null,
      `FOTOS=${product.images.length}`,
      variationSummary ? `VARIACOES=${variationSummary}` : null
    ].filter(Boolean);
    return `${index + 1}. ${parts.join(" | ")}`;
  }).join("\n");
  const systemPrompt = `Voce decide se o agente deve enviar AS FOTOS de um ou mais produtos do catalogo.

Regras:
- Envie as fotos somente quando a conversa estiver claramente focada em um ou mais produtos especificos do catalogo.
- Se decidir enviar, o sistema mandara todas as fotos de cada produto escolhido na ordem cadastrada.
- So envie varios produtos quando a mensagem atual trouxer dois ou mais temas ou itens explicitos e identificaveis na lista recebida.
- Quando a mensagem ou o historico citar CODIGO/COD de variacao, escolha somente produto que contenha esse codigo exato.
- Nunca troque COD 40 por COD 39, COD 41 por COD 40, nem escolha codigo vizinho por sequencia, tema parecido ou aproximacao.
- Se varios codigos forem citados, preserve todos os codigos exatos na decisao e nao deixe nenhum de fora por inferencia.
- Nao envie fotos para pedidos genericos de catalogo, listas amplas ou saudacao sem pedido concreto.
- A MENSAGEM_ATUAL tem prioridade total sobre o historico antigo.
- Se a mensagem atual for sobre Pix, endereco, horario, funcionamento, pagamento, comprovante, localizacao ou mapa, responda NO_IMAGE mesmo que o historico anterior tenha fotos ou um tema em andamento.
- Se a mensagem atual pedir outro tema ou outro item e voce nao conseguir ancorar esse novo pedido a produtos reais da lista recebida, responda NO_IMAGE.
- Considere a mensagem do cliente, o historico recente e a resposta textual do agente.
- Nunca invente produto. So escolha IDs existentes na lista recebida.
- Se nao houver seguranca suficiente, responda NO_IMAGE.

Responda APENAS em JSON com este formato:
{"decision":"SEND"|"NO_IMAGE","productId":"id-ou-null","productIds":["id1","id2"],"confidence":0-100,"reason":"motivo curto"}`;
  const userPrompt = `MENSAGEM_ATUAL:
${truncateText(input.clientMessage, 500)}

RESPOSTA_DO_AGENTE:
${truncateText(input.assistantResponse, 500) || "(sem resposta textual)"}

HISTORICO_RECENTE:
${recentHistory || "(sem historico)"}

PRODUTOS_COM_FOTO:
${catalogText}
`;
  try {
    const completeChat = deps.completeChat ?? chatComplete;
    const response = await completeChat({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      maxTokens: 180,
      temperature: 0.1
    });
    const rawContent = response.choices?.[0]?.message?.content;
    const content = typeof rawContent === "string" ? rawContent : String(rawContent || "");
    const parsed = extractFirstJsonObject(content);
    const confidence = Number.isFinite(parsed.confidence) ? Number(parsed.confidence) : 0;
    const validProductIds = new Set(visualProducts.map((product) => String(product.id)));
    const parsedProductIds = Array.isArray(parsed.productIds) ? parsed.productIds.map((productId) => typeof productId === "string" ? productId.trim() : "").filter((productId) => productId && validProductIds.has(productId)) : [];
    const fallbackProductId = typeof parsed.productId === "string" && parsed.productId.trim() ? parsed.productId.trim() : null;
    const selectedProductIds = Array.from(
      /* @__PURE__ */ new Set([
        ...parsedProductIds,
        ...fallbackProductId && validProductIds.has(fallbackProductId) ? [fallbackProductId] : []
      ])
    );
    const shouldSend = parsed.decision === "SEND" && confidence >= 60 && selectedProductIds.length > 0;
    return {
      shouldSend,
      productId: shouldSend ? selectedProductIds[0] || null : null,
      productIds: shouldSend ? selectedProductIds : [],
      confidence,
      reason: parsed.reason || "Sem motivo informado."
    };
  } catch (error) {
    console.error("[ProductCatalogMedia] Falha ao selecionar imagens do catalogo:", error);
    return {
      shouldSend: false,
      productId: null,
      productIds: [],
      confidence: 0,
      reason: error?.message || "Erro ao interpretar imagens do catalogo."
    };
  }
}
async function harmonizeCatalogProductResponseForSentImages(input, deps = {}) {
  const originalResponse = String(input.assistantResponse || "").trim();
  const productName = String(input.productLabel || input.productName || "").trim() || "produto";
  const imageCount = Math.max(1, Number(input.imageCount || 0));
  if (!originalResponse) {
    return buildAttachedImagesResponseFallback(productName, imageCount);
  }
  const systemPrompt = `Voce reescreve uma mensagem de atendimento para ficar coerente com o fato de que as fotos do produto ou dos produtos JA serao enviadas nesta mesma resposta.

Regras:
- Preserve os fatos principais da mensagem original.
- Deixe claro que as fotos estao sendo enviadas agora ou que seguem logo abaixo.
- Nao pergunte se o cliente quer ver, quer receber ou se voce pode enviar as fotos depois.
- Se as fotos estao sendo enviadas agora, remova qualquer frase que diga que o produto nao existe, nao esta cadastrado, nao foi encontrado ou que sera preciso encaminhar para humano por falta de material.
- Nao invente preco, estoque ou detalhes novos.
- Mantenha o tom natural de WhatsApp e seja objetivo.
- Responda SOMENTE com o texto final reescrito.`;
  const userPrompt = `PRODUTO: ${productName}
QUANTIDADE_DE_FOTOS: ${imageCount}

MENSAGEM_ORIGINAL:
${truncateText(originalResponse, 800)}`;
  try {
    const completeChat = deps.completeChat ?? chatComplete;
    const response = await completeChat({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      maxTokens: 180,
      temperature: 0.1
    });
    const rawContent = response.choices?.[0]?.message?.content;
    const content = typeof rawContent === "string" ? rawContent.trim() : String(rawContent || "").trim();
    if (content) {
      const finalContent = preserveGreetingLineWhenMissing(originalResponse, content);
      if (catalogResponseContradictsAttachedImages(finalContent)) {
        return buildAttachedImagesResponseFallback(productName, imageCount);
      }
      return finalContent;
    }
  } catch (error) {
    console.error("[ProductCatalogMedia] Falha ao harmonizar texto com imagens anexadas:", error);
  }
  return buildAttachedImagesResponseFallback(productName, imageCount);
}

// server/productCatalogMessageActions.ts
function normalizeSentMediaNames(sentMedias) {
  return new Set(
    sentMedias.map((item) => String(item || "").trim().toUpperCase()).filter(Boolean)
  );
}
function normalizeCatalogProductStock(stock) {
  if (typeof stock === "number" && Number.isFinite(stock)) {
    return stock;
  }
  const parsed = Number(stock ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}
function formatVariationPrice(price) {
  const normalized = String(price || "").trim();
  if (!normalized) return null;
  const parsed = Number(normalized.replace(",", "."));
  if (!Number.isFinite(parsed)) return normalized;
  return parsed.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
function hasCatalogVariationMetadata(image) {
  if (!image) {
    return false;
  }
  if (typeof image.variation_code === "number" && Number.isFinite(image.variation_code)) {
    return true;
  }
  if (String(image.variation_name || "").trim()) {
    return true;
  }
  if (String(image.variation_price || "").trim()) {
    return true;
  }
  return typeof image.variation_stock === "number" && Number.isFinite(image.variation_stock);
}
function buildCatalogVariationCaption(product, image, index, options) {
  const lines = [];
  const treatAsVariation = product.imageVariationsEnabled === true || hasCatalogVariationMetadata(image);
  if (index === 0 || treatAsVariation) {
    lines.push(product.name);
  }
  if (treatAsVariation) {
    if (typeof image.variation_code === "number" && Number.isFinite(image.variation_code)) {
      lines.push(`C\xF3digo ${image.variation_code}`);
    }
    const variationName = String(image.variation_name || "").trim();
    if (variationName) {
      lines.push(`Nome ${variationName}`);
    }
    const mauricioMfcPriceLine = buildMauricioMfcCatalogCaptionPriceLine({
      userId: options?.userId,
      userEmail: options?.userEmail,
      productName: product.name,
      productCategory: product.category,
      productDescription: product.description,
      variationName: image.variation_name,
      variationCaption: image.caption,
      variationPrice: image.variation_price,
      contextText: options?.contextText,
      includeReady50x50Promo: options?.mauricioMfcIncludeReady50x50Promo === true
    });
    const priceLabel = mauricioMfcPriceLine || formatVariationPrice(image.variation_price) || formatVariationPrice(product.price);
    if (priceLabel) {
      lines.push(mauricioMfcPriceLine ? priceLabel : `Pre\xE7o ${priceLabel}`);
    }
    if (typeof image.variation_stock === "number" && Number.isFinite(image.variation_stock)) {
      lines.push(`Estoque ${image.variation_stock}`);
    }
  }
  const caption = lines.map((line) => String(line || "").trim()).filter(Boolean).join("\n").trim();
  return caption || void 0;
}
function isCatalogProductAvailable(product) {
  if (product.controlStock !== true) {
    return true;
  }
  return normalizeCatalogProductStock(product.stock) > 0;
}
function buildCatalogProductDeliveryActions(product, sentMedias = [], options) {
  if (!isCatalogProductAvailable(product)) {
    return [];
  }
  const actions = [];
  const sentMediaNames = normalizeSentMediaNames(sentMedias);
  let appendedImageCount = 0;
  let orderedImages = [...product.images || []].sort(
    (a, b) => Number(a.display_order || 0) - Number(b.display_order || 0)
  );
  const isMauricioMfcTenant = isMauricioMfcCatalogTenant(options || {});
  const mauricioMfcLineKind = isMauricioMfcTenant ? options?.mauricioMfcLineKind || resolveMauricioMfcRequestedLineKind(options?.contextText) : null;
  if (mauricioMfcLineKind) {
    const matchingImages = orderedImages.filter(
      (image) => mauricioMfcCatalogEntryMatchesLineKind({
        userId: options?.userId,
        userEmail: options?.userEmail,
        productName: product.name,
        productCategory: product.category,
        variationName: image.variation_name,
        variationCaption: image.caption
      }, mauricioMfcLineKind)
    );
    if (matchingImages.length > 0) {
      orderedImages = matchingImages;
    }
  }
  for (const [index, image] of orderedImages.entries()) {
    const treatAsVariation = product.imageVariationsEnabled === true || hasCatalogVariationMetadata(image);
    if (treatAsVariation && image.variation_is_active === false) {
      continue;
    }
    const mediaName = buildCatalogProductImageMediaName(product.id, image.id);
    if (sentMediaNames.has(mediaName.toUpperCase())) {
      continue;
    }
    actions.push({
      type: "send_media_url",
      media_name: mediaName,
      media_url: image.storage_url,
      media_type: "image",
      caption: buildCatalogVariationCaption(product, image, index, options),
      file_name: image.file_name || void 0
    });
    appendedImageCount += 1;
  }
  const description = String(product.description || "").trim();
  const canSendDescription = !isMauricioMfcTenant || options?.mauricioMfcIncludeReady50x50Promo === true || !containsMauricioMfcReady50x50PromoText(description);
  if (appendedImageCount > 0 && product.sendDescriptionWithImages && description && canSendDescription) {
    actions.push({
      type: "send_text",
      text: description
    });
  }
  return actions;
}

// server/productCatalogVariationMatcher.ts
var MAX_CATALOG_VARIATION_MATCHES = 10;
function hasCodeLabelBefore(text, digitStart) {
  const before = text.slice(Math.max(0, digitStart - 18), digitStart).toLowerCase();
  const labels = ["codigo", "c\xF3digo", "cod", "c\xF3d"];
  return labels.some((label) => before.includes(label));
}
function extractMentionedVariationCodes(text, knownCodes) {
  const codes = [];
  const seen = /* @__PURE__ */ new Set();
  let index = 0;
  let listContextBudget = 0;
  while (index < text.length) {
    const char = text[index];
    if (char === "\n" || char === "\r" || char === "." || char === ";" || char === ":") {
      listContextBudget = 0;
      index += 1;
      continue;
    }
    const lowerTail = text.slice(index).toLowerCase();
    if (lowerTail.startsWith("codigos") || lowerTail.startsWith("c\xF3digos")) {
      listContextBudget = 96;
      index += 7;
      continue;
    }
    if (lowerTail.startsWith("codigo") || lowerTail.startsWith("c\xF3digo")) {
      listContextBudget = 96;
      index += 6;
      continue;
    }
    if (lowerTail.startsWith("cod") || lowerTail.startsWith("c\xF3d")) {
      listContextBudget = 96;
      index += 3;
      continue;
    }
    if (char < "0" || char > "9") {
      if (listContextBudget > 0 && char !== "," && char !== " " && char !== "	" && char !== "e") {
        listContextBudget = Math.max(0, listContextBudget - 1);
      }
      index += 1;
      continue;
    }
    let digits = "";
    while (index < text.length) {
      const digit = text[index];
      if (digit < "0" || digit > "9") break;
      digits += digit;
      index += 1;
    }
    const code = Number(digits);
    const digitStart = index - digits.length;
    if (Number.isInteger(code) && knownCodes.has(code) && (hasCodeLabelBefore(text, digitStart) || listContextBudget > 0) && !seen.has(code)) {
      seen.add(code);
      codes.push(code);
    }
    if (listContextBudget > 0) {
      listContextBudget = Math.max(0, listContextBudget - 1);
    }
  }
  return codes;
}
function parseCatalogVariationMatchItems(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  const items = [];
  for (const item of value) {
    if (!item || typeof item !== "object") {
      continue;
    }
    const record = item;
    const productId = typeof record.productId === "string" ? record.productId.trim() : "";
    const mediaId = typeof record.mediaId === "string" ? record.mediaId.trim() : "";
    if (!productId || !mediaId) {
      continue;
    }
    items.push({
      productId,
      mediaId,
      confidence: Number.isFinite(Number(record.confidence)) ? Number(record.confidence) : void 0,
      reason: typeof record.reason === "string" ? record.reason.trim() : void 0
    });
    if (items.length >= MAX_CATALOG_VARIATION_MATCHES) {
      break;
    }
  }
  return items;
}
function parseCatalogVariationDecision(rawResponse) {
  const parsed = extractFirstJsonObject(String(rawResponse || "").trim());
  if (!parsed || typeof parsed !== "object") return null;
  try {
    return {
      decision: parsed?.decision === "MATCH" ? "MATCH" : "NO_MATCH",
      productId: typeof parsed?.productId === "string" && parsed.productId.trim() ? parsed.productId.trim() : null,
      mediaId: typeof parsed?.mediaId === "string" && parsed.mediaId.trim() ? parsed.mediaId.trim() : null,
      matches: parseCatalogVariationMatchItems(parsed?.matches),
      confidence: Number.isFinite(Number(parsed?.confidence)) ? Number(parsed.confidence) : 0,
      reason: typeof parsed?.reason === "string" ? parsed.reason.trim() : ""
    };
  } catch (error) {
    console.warn("[CatalogVariationMatcher] Falha ao parsear resposta:", error);
    return null;
  }
}
async function matchCatalogVariationFromCustomerImage(input, deps = {}) {
  const description = String(input.customerImageDescription || "").trim();
  const activeCandidates = (input.candidates || []).filter(
    (candidate) => String(candidate.mediaId || "").trim() && String(candidate.productId || "").trim() && String(candidate.productName || "").trim() && candidate.variationIsActive !== false
  );
  if (!description || activeCandidates.length === 0) {
    return null;
  }
  const candidatesByCode = /* @__PURE__ */ new Map();
  for (const candidate of activeCandidates) {
    if (typeof candidate.variationCode === "number" && !candidatesByCode.has(candidate.variationCode)) {
      candidatesByCode.set(candidate.variationCode, candidate);
    }
  }
  const mentionedCodes = extractMentionedVariationCodes(
    [
      input.customerMessage,
      description,
      ...(input.conversationHistory || []).map((message) => message.text)
    ].map((value) => String(value || "").trim()).filter(Boolean).join("\n"),
    new Set(candidatesByCode.keys())
  );
  if (mentionedCodes.length > 1) {
    const exactMatches = mentionedCodes.slice(0, MAX_CATALOG_VARIATION_MATCHES).map((code) => candidatesByCode.get(code)).filter((candidate) => Boolean(candidate)).map((candidate) => ({
      productId: candidate.productId,
      mediaId: candidate.mediaId,
      confidence: 100,
      reason: `Codigo ${candidate.variationCode} informado no contexto da imagem do cliente.`
    }));
    if (exactMatches.length > 0) {
      return {
        matched: true,
        productId: exactMatches[0].productId,
        mediaId: exactMatches[0].mediaId,
        matches: exactMatches,
        confidence: 100,
        reason: `${exactMatches.length} codigos informados no contexto da imagem do cliente.`
      };
    }
  }
  if (mentionedCodes.length === 1) {
    const candidate = candidatesByCode.get(mentionedCodes[0]);
    if (candidate) {
      return {
        matched: true,
        productId: candidate.productId,
        mediaId: candidate.mediaId,
        matches: [{ productId: candidate.productId, mediaId: candidate.mediaId, confidence: 100 }],
        confidence: 100,
        reason: `C\xF3digo ${mentionedCodes[0]} informado no contexto da imagem do cliente.`
      };
    }
  }
  const recentHistory = (input.conversationHistory || []).slice(-6).map((message) => `${message.fromMe ? "Atendente" : "Cliente"}: ${String(message.text || "").trim()}`).filter((line) => !line.endsWith(":")).join("\n");
  const candidateList = activeCandidates.slice(0, 80).map((candidate) => ({
    mediaId: candidate.mediaId,
    productId: candidate.productId,
    productName: candidate.productName,
    category: candidate.productCategory || "",
    productPrice: candidate.productPrice || "",
    fileName: candidate.fileName || "",
    caption: candidate.caption || "",
    variationCode: candidate.variationCode ?? null,
    variationName: candidate.variationName || "",
    variationPrice: candidate.variationPrice || "",
    variationStock: candidate.variationStock ?? null
  }));
  const systemPrompt = `Voce decide se a imagem enviada pelo cliente corresponde a uma ou mais variacoes ja cadastradas no catalogo.

Regras:
- Use a descricao visual da imagem enviada pelo cliente como fonte principal.
- Compare com os candidatos do catalogo e escolha somente se houver correspondencia realmente forte.
- Leve em conta nome do produto, nome do arquivo, caption, categoria, nome da variacao, preco da variacao e codigo da variacao.
- Se a imagem/legenda trouxer varios itens ou codigos, preserve ate ${MAX_CATALOG_VARIATION_MATCHES} correspondencias exatas em "matches", na mesma ordem.
- Se houver duvida real, responda NO_MATCH.
- Responda apenas JSON valido no formato:
{"decision":"MATCH|NO_MATCH","productId":"primeiro-produto-ou-null","mediaId":"primeira-midia-ou-null","matches":[{"productId":"...","mediaId":"...","confidence":0-100,"reason":"..."}],"confidence":0-100,"reason":"..."}
`;
  const userPrompt = `DESCRI\xC7\xC3O DA IMAGEM DO CLIENTE:
${description}

MENSAGEM ATUAL DO CLIENTE:
${String(input.customerMessage || "").trim() || "(sem texto adicional)"}

HIST\xD3RICO RECENTE:
${recentHistory || "(sem hist\xF3rico relevante)"}

CANDIDATOS DO CAT\xC1LOGO:
${JSON.stringify(candidateList, null, 2)}`;
  const chatCompleteFn = deps.chatCompleteFn || chatComplete;
  try {
    const response = await chatCompleteFn({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: 0,
      maxTokens: 220
    });
    const raw = String(response.choices?.[0]?.message?.content || "").trim();
    const parsed = parseCatalogVariationDecision(raw);
    if (!parsed) {
      return null;
    }
    const validMediaIds = new Set(activeCandidates.map((candidate) => candidate.mediaId));
    const validProductIds = new Set(activeCandidates.map((candidate) => candidate.productId));
    const parsedMatches = parsed.matches.filter(
      (match) => validMediaIds.has(match.mediaId) && validProductIds.has(match.productId)
    );
    const hasValidIds = parsed.mediaId && parsed.productId && validMediaIds.has(parsed.mediaId) && validProductIds.has(parsed.productId);
    const fallbackMatches = hasValidIds ? [{ productId: parsed.productId, mediaId: parsed.mediaId, confidence: parsed.confidence, reason: parsed.reason }] : [];
    const matches = Array.from(
      new Map(
        [...parsedMatches, ...fallbackMatches].slice(0, MAX_CATALOG_VARIATION_MATCHES).map((match) => [`${match.productId}:${match.mediaId}`, match])
      ).values()
    );
    const matched = parsed.decision === "MATCH" && parsed.confidence >= 70 && matches.length > 0;
    return {
      matched,
      productId: matched ? matches[0]?.productId || null : null,
      mediaId: matched ? matches[0]?.mediaId || null : null,
      matches: matched ? matches : [],
      confidence: parsed.confidence,
      reason: parsed.reason || ""
    };
  } catch (error) {
    console.warn("[CatalogVariationMatcher] Falha ao identificar varia\xE7\xE3o por imagem:", error);
    return null;
  }
}

// server/paymentReceiptPolicy.ts
function calculateManualReceiptActivationWindow(plan, now = /* @__PURE__ */ new Date()) {
  const dataInicio = new Date(now);
  const dataFim = new Date(now);
  const periodicidade = String(plan?.periodicidade || "").toLowerCase();
  const frequenciaDias = Number.parseInt(String(plan?.frequencia_dias ?? ""), 10);
  if (periodicidade === "anual") {
    dataFim.setFullYear(dataFim.getFullYear() + 1);
  } else if (periodicidade === "mensal") {
    dataFim.setDate(dataFim.getDate() + 30);
  } else if (Number.isFinite(frequenciaDias) && frequenciaDias > 0) {
    dataFim.setDate(dataFim.getDate() + frequenciaDias);
  } else {
    dataFim.setDate(dataFim.getDate() + 30);
  }
  return {
    dataInicio,
    dataFim,
    nextPaymentDate: new Date(dataFim)
  };
}

// server/subscriptionSelection.ts
function toValidDate(value) {
  if (!value) return null;
  const parsed = value instanceof Date ? value : new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}
function resolveCoverageEnd(candidate) {
  return toValidDate(candidate.nextPaymentDate) || toValidDate(candidate.dataFim);
}
function resolveApprovedReceiptActivationWindow(candidate, now = /* @__PURE__ */ new Date()) {
  const approvedReceiptAt = toValidDate(candidate.approvedReceiptAt) || now;
  const fallbackWindow = calculateManualReceiptActivationWindow(
    {
      periodicidade: candidate.planPeriodicity,
      frequencia_dias: candidate.planFrequencyDays
    },
    approvedReceiptAt
  );
  const dataInicio = toValidDate(candidate.dataInicio) || fallbackWindow.dataInicio;
  const dataFim = toValidDate(candidate.dataFim) || fallbackWindow.dataFim;
  const nextPaymentDate = toValidDate(candidate.nextPaymentDate) || toValidDate(candidate.dataFim) || fallbackWindow.nextPaymentDate;
  return {
    dataInicio,
    dataFim,
    nextPaymentDate
  };
}
function shouldAutoActivateSubscriptionFromApprovedReceipt(candidate, now = /* @__PURE__ */ new Date()) {
  const status = String(candidate.status || "").toLowerCase();
  if (!candidate.approvedReceiptAt) return false;
  if (status === "active" || status === "cancelled" || status === "canceled") {
    return false;
  }
  const activationWindow = resolveApprovedReceiptActivationWindow(candidate, now);
  return activationWindow.nextPaymentDate.getTime() > now.getTime();
}
function buildPriority(candidate, now) {
  const status = String(candidate.status || "").toLowerCase();
  const coverageEnd = resolveCoverageEnd(candidate);
  const hasFutureCoverage = Boolean(coverageEnd && coverageEnd.getTime() > now.getTime());
  if (status === "active") return 600;
  if (shouldAutoActivateSubscriptionFromApprovedReceipt(candidate, now)) return 550;
  if (status === "pending_payment" && candidate.pendingReceipt) return 500;
  if (status === "pending_pix" && hasFutureCoverage) return 450;
  if ((status === "pending" || status === "overdue") && hasFutureCoverage) return 400;
  if (hasFutureCoverage) return 350;
  if (status === "pending_pix") return 300;
  if (status === "pending_payment") return 250;
  if (status === "pending") return 200;
  return 0;
}
function pickPreferredSubscriptionCandidate(candidates, now = /* @__PURE__ */ new Date()) {
  if (!Array.isArray(candidates) || candidates.length === 0) {
    return void 0;
  }
  const ranked = [...candidates].sort((left, right) => {
    const priorityDiff = buildPriority(right, now) - buildPriority(left, now);
    if (priorityDiff !== 0) return priorityDiff;
    const coverageDiff = (resolveCoverageEnd(right)?.getTime() || 0) - (resolveCoverageEnd(left)?.getTime() || 0);
    if (coverageDiff !== 0) return coverageDiff;
    const approvedDiff = (toValidDate(right.approvedReceiptAt)?.getTime() || 0) - (toValidDate(left.approvedReceiptAt)?.getTime() || 0);
    if (approvedDiff !== 0) return approvedDiff;
    return (toValidDate(right.createdAt)?.getTime() || 0) - (toValidDate(left.createdAt)?.getTime() || 0);
  });
  return ranked[0];
}

// server/storage.ts
var RODRIGO_PAID_LEAD_OWNER_EMAIL = "rodrigo4@gmail.com";
var MemoryCache = class {
  constructor() {
    this.cache = /* @__PURE__ */ new Map();
    this.inflight = /* @__PURE__ */ new Map();
    this.maxSize = 2e3;
  }
  // Máximo de entradas no cache
  set(key, data, ttlMs = 3e4) {
    if (this.cache.size >= this.maxSize) {
      this.cleanup();
    }
    this.cache.set(key, { data, timestamp: Date.now(), ttl: ttlMs });
  }
  get(key) {
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return null;
    }
    return entry.data;
  }
  /** Check if key exists in cache (distinguishes cached null from cache miss) */
  has(key) {
    const entry = this.cache.get(key);
    if (!entry) return false;
    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return false;
    }
    return true;
  }
  /**
   * Get-or-compute with thundering herd protection.
   * Only ONE concurrent call per key actually runs computeFn;
   * all others await the same Promise.
   */
  async getOrCompute(key, computeFn, ttlMs = 3e4) {
    if (this.has(key)) {
      return this.get(key);
    }
    const existing = this.inflight.get(key);
    if (existing) return existing;
    const promise = computeFn().then((result) => {
      this.set(key, result, ttlMs);
      this.inflight.delete(key);
      return result;
    }).catch((err) => {
      this.inflight.delete(key);
      throw err;
    });
    this.inflight.set(key, promise);
    return promise;
  }
  invalidate(pattern) {
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
  cleanup() {
    const now = Date.now();
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key);
      }
    }
    if (this.cache.size >= this.maxSize) {
      const entries = Array.from(this.cache.entries()).sort((a, b) => a[1].timestamp - b[1].timestamp);
      const toRemove = entries.slice(0, Math.floor(this.maxSize / 2));
      toRemove.forEach(([key]) => this.cache.delete(key));
    }
  }
  getStats() {
    return {
      size: this.cache.size,
      maxSize: this.maxSize,
      hitRate: "n/a"
    };
  }
};
var memoryCache = new MemoryCache();
function buildAttentionPriorityScore(column = conversations.attentionPriority) {
  return sql`
    CASE ${column}
      WHEN 'critica' THEN 4
      WHEN 'alta' THEN 3
      WHEN 'media' THEN 2
      WHEN 'baixa' THEN 1
      ELSE 0
    END
  `;
}
function isAudioPlaceholderText(text) {
  const normalized = String(text || "").trim().toLowerCase();
  if (!normalized) {
    return true;
  }
  if (normalized === "audio" || normalized === "\xE1udio" || normalized === "[audio enviado]" || normalized === "[\xE1udio enviado]") {
    return true;
  }
  return normalized.startsWith("[audio") || normalized.startsWith("[\xE1udio") || normalized.startsWith("\u{1F3B5}") || normalized.startsWith("\u{1F3A4}") || normalized.startsWith("??");
}
async function resolveAudioTranscriptionForMessage(params) {
  if (params.mediaType !== "audio" || !params.mediaUrl) {
    return null;
  }
  let audioBuffer = null;
  if (params.mediaUrl.startsWith("data:")) {
    const base64Part = params.mediaUrl.split(",")[1];
    if (base64Part) {
      audioBuffer = Buffer.from(base64Part, "base64");
      console.log(`\u{1F3A4} [Storage] \xC1udio base64 detectado: ${audioBuffer.length} bytes`);
    }
  } else if (params.mediaUrl.startsWith("http://") || params.mediaUrl.startsWith("https://")) {
    console.log(`\u{1F3A4} [Storage] Baixando \xE1udio de URL externa para transcri\xE7\xE3o...`);
    try {
      const audioResponse = await fetch(params.mediaUrl);
      if (audioResponse.ok) {
        const arrayBuffer = await audioResponse.arrayBuffer();
        audioBuffer = Buffer.from(arrayBuffer);
        console.log(`\u{1F3A4} [Storage] \xC1udio baixado da URL: ${audioBuffer.length} bytes`);
      } else {
        console.error(`\u{1F3A4} [Storage] Erro ao baixar \xE1udio: HTTP ${audioResponse.status}`);
      }
    } catch (fetchError) {
      console.error(`\u{1F3A4} [Storage] Erro ao fazer fetch do \xE1udio:`, fetchError);
    }
  }
  if (!audioBuffer || audioBuffer.length === 0) {
    console.log(`\u{1F3A4} [Storage] \u26A0\uFE0F N\xE3o foi poss\xEDvel obter buffer do \xE1udio para transcri\xE7\xE3o`);
    return null;
  }
  let transcriptionModel;
  let llmUserId;
  const [conversation] = await db.select().from(conversations).where(eq(conversations.id, params.conversationId));
  if (conversation) {
    const [connection] = await db.select().from(whatsappConnections).where(eq(whatsappConnections.id, conversation.connectionId));
    if (connection?.userId) {
      llmUserId = connection.userId;
      transcriptionModel = process.env.MISTRAL_TRANSCRIPTION_MODEL || void 0;
    }
  }
  console.log(`\u{1F3A4} [Storage] Iniciando transcri\xE7\xE3o com Mistral...`);
  const transcription = await transcribeAudioWithMistral(audioBuffer, {
    fileName: "whatsapp-audio.ogg",
    model: transcriptionModel,
    userId: llmUserId
  });
  if (transcription && transcription.length > 0) {
    console.log(`\u{1F3A4} [Storage] \u2705 Transcri\xE7\xE3o bem-sucedida: "${transcription.substring(0, 100)}..."`);
    return transcription;
  }
  console.log(`\u{1F3A4} [Storage] \u26A0\uFE0F Transcri\xE7\xE3o vazia ou nula`);
  return null;
}
var CircuitBreaker = class {
  constructor() {
    this.failures = 0;
    this.lastFailure = 0;
    this.state = "closed";
    this.threshold = 5;
    // Número de falhas para abrir
    this.resetTimeout = 3e4;
  }
  // 30 segundos para tentar novamente
  async execute(operation, fallback) {
    if (this.state === "open") {
      if (Date.now() - this.lastFailure > this.resetTimeout) {
        this.state = "half-open";
      } else {
        console.warn("\u26A1 [Circuit Breaker] Circuito ABERTO - usando fallback");
        if (fallback !== void 0) return fallback;
        throw new Error("Database circuit breaker is open");
      }
    }
    try {
      const result = await operation();
      if (this.state === "half-open") {
        this.state = "closed";
        this.failures = 0;
        console.log("\u2705 [Circuit Breaker] Circuito FECHADO - DB recuperado");
      }
      return result;
    } catch (error) {
      this.failures++;
      this.lastFailure = Date.now();
      if (this.failures >= this.threshold) {
        this.state = "open";
        console.error(`\u{1F534} [Circuit Breaker] Circuito ABERTO ap\xF3s ${this.failures} falhas`);
      }
      if (fallback !== void 0) return fallback;
      throw error;
    }
  }
  isOpen() {
    return this.state === "open";
  }
  getState() {
    return this.state;
  }
};
var dbCircuitBreaker = new CircuitBreaker();
function adminConversationIsVisibleCondition() {
  return sql`coalesce(${adminConversations.contextState} -> 'followupMigration' ->> 'migratedBackAt', '') = ''`;
}
var campaignsStore = /* @__PURE__ */ new Map();
var syncedContactsStore = /* @__PURE__ */ new Map();
function unwrapDbError(error) {
  if (!error || typeof error !== "object") return error;
  return error.cause && typeof error.cause === "object" ? error.cause : error;
}
function getDbErrorCode(error) {
  const directCode = error?.code;
  if (typeof directCode === "string" && directCode.length > 0) return directCode;
  const wrappedCode = error?.cause?.code;
  if (typeof wrappedCode === "string" && wrappedCode.length > 0) return wrappedCode;
  return void 0;
}
function getDbConstraintName(error) {
  const directConstraint = error?.constraint;
  if (typeof directConstraint === "string" && directConstraint.length > 0) return directConstraint;
  const wrappedConstraint = error?.cause?.constraint;
  if (typeof wrappedConstraint === "string" && wrappedConstraint.length > 0) return wrappedConstraint;
  return void 0;
}
function getDbErrorMessage(error) {
  const raw = error?.message || error?.cause?.message || "";
  return typeof raw === "string" ? raw : "";
}
function isPendingAiSkippedConstraintError(error) {
  const normalized = unwrapDbError(error);
  const code = getDbErrorCode(normalized);
  const constraint = getDbConstraintName(normalized)?.toLowerCase() || "";
  const message = getDbErrorMessage(normalized).toLowerCase();
  if (code === "23514") return true;
  if (constraint.includes("pending_ai_responses_status_check")) return true;
  return message.includes("pending_ai_responses_status_check") || message.includes("violates check constraint") && message.includes("pending_ai_responses");
}
function buildPendingAIResponseMutationGuard(guard) {
  return sql`
    ${guard?.expectedMessages ? sql`AND messages = ${JSON.stringify(guard.expectedMessages)}::jsonb` : sql``}
    ${guard?.notUpdatedAfter ? sql`AND updated_at <= ${guard.notUpdatedAfter.toISOString()}::timestamptz` : sql``}
  `;
}
function confirmedOutgoingMessageStatusSql(statusColumn) {
  return sql`
    COALESCE(NULLIF(BTRIM(LOWER(${statusColumn})), ''), 'sent')
      NOT IN ('queued', 'pending', 'pending_delivery', 'failed')
  `;
}
var DatabaseStorage = class {
  constructor() {
    this.pendingAiSkippedUnsupported = false;
  }
  // User operations
  async getUser(id) {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  async getUserByPhone(phone) {
    const cleanPhone = phone.replace(/\D/g, "");
    const phoneWithPlus = "+" + cleanPhone;
    const [user] = await db.select().from(users).where(
      sql`${users.phone} = ${phoneWithPlus} OR ${users.phone} = ${cleanPhone} OR REPLACE(${users.phone}, '+', '') = ${cleanPhone}`
    );
    return user;
  }
  async getUserByEmail(email) {
    const [user] = await db.select().from(users).where(eq(users.email, email)).orderBy(
      desc(sql`CASE WHEN COALESCE(${users.phone}, '') <> '' OR COALESCE(${users.whatsappNumber}, '') <> '' THEN 1 ELSE 0 END`),
      desc(users.updatedAt),
      desc(users.createdAt)
    ).limit(1);
    return user;
  }
  async updateUser(id, data) {
    await db.update(users).set(data).where(eq(users.id, id));
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  async upsertUser(userData) {
    const [user] = await db.insert(users).values(userData).onConflictDoUpdate({
      target: users.id,
      set: {
        ...userData,
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    return user;
  }
  // Delete user and all related data (cascade)
  quotePgIdentifier(value) {
    return `"${value.replaceAll('"', '""')}"`;
  }
  buildQualifiedTableName(tableName, schemaName = "public") {
    return `${this.quotePgIdentifier(schemaName)}.${this.quotePgIdentifier(tableName)}`;
  }
  async getForeignKeyReferencesToTable(tx, tableName, schemaName = "public") {
    const result = await tx.execute(sql`
      select
        child_ns.nspname as schema_name,
        child.relname as table_name,
        child_col.attname as column_name
      from pg_constraint c
      join pg_class child on child.oid = c.conrelid
      join pg_namespace child_ns on child_ns.oid = child.relnamespace
      join unnest(c.conkey) with ordinality as cols(attnum, ord) on true
      join pg_attribute child_col on child_col.attrelid = c.conrelid and child_col.attnum = cols.attnum
      where c.contype = 'f'
        and child_ns.nspname = ${schemaName}
        and c.confrelid = to_regclass(${`${schemaName}.${tableName}`})
      order by child.relname, child_col.attname
    `);
    return (result?.rows || []).map((row) => ({
      schemaName: String(row?.schema_name || schemaName),
      tableName: String(row?.table_name || ""),
      columnName: String(row?.column_name || "")
    })).filter((row) => row.tableName && row.columnName);
  }
  async getSinglePrimaryKeyColumn(tx, tableName, schemaName = "public") {
    const result = await tx.execute(sql`
      select att.attname as column_name
      from pg_index idx
      join pg_class tbl on tbl.oid = idx.indrelid
      join pg_namespace ns on ns.oid = tbl.relnamespace
      join unnest(idx.indkey) with ordinality as cols(attnum, ord) on true
      join pg_attribute att on att.attrelid = idx.indrelid and att.attnum = cols.attnum
      where idx.indisprimary
        and ns.nspname = ${schemaName}
        and tbl.relname = ${tableName}
      order by cols.ord
    `);
    const rows = (result?.rows || []).map((row) => String(row?.column_name || "")).filter(Boolean);
    return rows.length === 1 ? rows[0] : null;
  }
  async deleteRowsByForeignKey(tx, reference, parentIds) {
    if (parentIds.length === 0) return;
    const uniqueParentIds = Array.from(new Set(parentIds.filter((value) => value !== null && value !== void 0)));
    if (uniqueParentIds.length === 0) return;
    const primaryKeyColumn = await this.getSinglePrimaryKeyColumn(tx, reference.tableName, reference.schemaName);
    if (primaryKeyColumn) {
      const childIdRows = await tx.execute(sql`
        select ${sql.raw(this.quotePgIdentifier(primaryKeyColumn))} as id
        from ${sql.raw(this.buildQualifiedTableName(reference.tableName, reference.schemaName))}
        where ${sql.raw(this.quotePgIdentifier(reference.columnName))} in (${sql.join(
        uniqueParentIds.map((value) => sql`${value}`),
        sql`, `
      )})
      `);
      const childIds = Array.from(
        new Set(
          (childIdRows?.rows || []).map((row) => row?.id).filter((value) => value !== null && value !== void 0)
        )
      );
      if (childIds.length > 0) {
        await this.deleteCascadeByIds(tx, reference.tableName, childIds, reference.schemaName);
      }
    }
    await tx.execute(sql`
      delete from ${sql.raw(this.buildQualifiedTableName(reference.tableName, reference.schemaName))}
      where ${sql.raw(this.quotePgIdentifier(reference.columnName))} in (${sql.join(
      uniqueParentIds.map((value) => sql`${value}`),
      sql`, `
    )})
    `);
  }
  async deleteCascadeByIds(tx, tableName, ids, schemaName = "public") {
    const uniqueIds = Array.from(new Set(ids.filter((value) => value !== null && value !== void 0)));
    if (uniqueIds.length === 0) return;
    const references = await this.getForeignKeyReferencesToTable(tx, tableName, schemaName);
    for (const reference of references) {
      await this.deleteRowsByForeignKey(tx, reference, uniqueIds);
    }
    await tx.execute(sql`
      delete from ${sql.raw(this.buildQualifiedTableName(tableName, schemaName))}
      where ${sql.raw(this.quotePgIdentifier("id"))} in (${sql.join(
      uniqueIds.map((value) => sql`${value}`),
      sql`, `
    )})
    `);
  }
  async cleanupSupabaseAuthUsers(userId, authEmails) {
    if (authEmails.size === 0) return;
    try {
      const attemptedAuthIds = /* @__PURE__ */ new Set();
      attemptedAuthIds.add(String(userId));
      const { error: deleteByIdError } = await supabase.auth.admin.deleteUser(String(userId));
      if (deleteByIdError) {
        console.warn(`[STORAGE] Falha ao excluir Auth por user.id ${userId}: ${deleteByIdError.message}`);
      } else {
        console.log(`[STORAGE] Usu\uFFFDrio Auth exclu\uFFFDdo por user.id: ${userId}`);
      }
      const { data, error } = await supabase.auth.admin.listUsers();
      if (error) {
        console.warn(`[STORAGE] Falha ao listar usu\uFFFDrios no Auth: ${error.message}`);
        return;
      }
      const authUsers = Array.isArray(data?.users) ? data.users : [];
      for (const authUser of authUsers) {
        if (attemptedAuthIds.has(String(authUser?.id || ""))) continue;
        const authEmail = String(authUser?.email || "").toLowerCase();
        if (!authEmail || !authEmails.has(authEmail)) continue;
        const { error: deleteError } = await supabase.auth.admin.deleteUser(authUser.id);
        if (deleteError) {
          console.warn(`[STORAGE] Falha ao excluir Auth ${authEmail}: ${deleteError.message}`);
        } else {
          console.log(`[STORAGE] Usu\uFFFDrio Auth exclu\uFFFDdo: ${authEmail}`);
        }
      }
    } catch (authCleanupError) {
      console.warn(`[STORAGE] Erro ao limpar Auth do Supabase:`, authCleanupError);
    }
  }
  async deleteUser(id) {
    console.log(`[STORAGE] Deleting user ${id} and all related data...`);
    const [user] = await db.select({
      id: users.id,
      email: users.email,
      phone: users.phone
    }).from(users).where(eq(users.id, id)).limit(1);
    if (!user) {
      console.log(`[STORAGE] User ${id} not found, nothing to delete`);
      return;
    }
    const authEmails = /* @__PURE__ */ new Set();
    if (user.email) {
      authEmails.add(String(user.email).toLowerCase());
    }
    await db.transaction(async (tx) => {
      const cleanPhone = normalizePhoneToDigits(user.phone || "");
      if (cleanPhone) {
        const adminConversationRows = await tx.select({ id: adminConversations.id }).from(adminConversations).where(and(
          eq(adminConversations.contactNumber, cleanPhone),
          adminConversationIsVisibleCondition()
        ));
        const adminConversationIds = Array.from(
          new Set(adminConversationRows.map((row) => row.id).filter(Boolean))
        );
        if (adminConversationIds.length > 0) {
          await this.deleteCascadeByIds(tx, "admin_conversations", adminConversationIds);
        }
      }
      await this.deleteCascadeByIds(tx, "users", [id]);
    });
    await this.cleanupSupabaseAuthUsers(id, authEmails);
    console.log(`[STORAGE] User ${id} and all related data deleted successfully`);
  }
  // Agent operations
  async getAgents() {
    const agentsList = await db.select().from(agents).orderBy(desc(agents.createdAt));
    return agentsList;
  }
  async getAgent(id) {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id)).limit(1);
    return agent;
  }
  async createAgent(data) {
    const [agent] = await db.insert(agents).values(data).returning();
    return agent;
  }
  async updateAgent(id, data) {
    const [agent] = await db.update(agents).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(agents.id, id)).returning();
    return agent;
  }
  async deleteAgent(id) {
    await db.delete(agents).where(eq(agents.id, id));
  }
  // WhatsApp connection operations
  // FIX: Priorizar conexão primária/conectada em vez de apenas a mais recente
  // Isso evita que conexões secundárias recém-criadas "roubem" a sessão principal
  async getConnectionByUserId(userId, connectionId) {
    const cacheKey = connectionId ? `connByUser:${userId}:${connectionId}` : `connByUser:${userId}`;
    return memoryCache.getOrCompute(cacheKey, async () => {
      if (connectionId) {
        const [specific] = await db.select().from(whatsappConnections).where(and(
          eq(whatsappConnections.id, connectionId),
          eq(whatsappConnections.userId, userId)
        )).limit(1);
        if (specific && !isUserRemovedConnection(specific)) return specific;
      }
      const allConnections = await db.select().from(whatsappConnections).where(eq(whatsappConnections.userId, userId)).orderBy(whatsappConnections.createdAt);
      const visibleConnections = allConnections.filter(isAppVisibleWhatsappConnection);
      const primaryConnected = visibleConnections.find(
        (connection) => connection.isConnected === true && connection.isPrimary === true
      );
      if (primaryConnected) return primaryConnected;
      const connectedConn = visibleConnections.find(
        (connection) => connection.isConnected === true
      );
      if (connectedConn) return connectedConn;
      const primaryConn = visibleConnections.find(
        (connection) => connection.isPrimary === true
      );
      if (primaryConn) return primaryConn;
      return visibleConnections[0];
    }, 3e4);
  }
  async getConnectionById(connectionId) {
    const [connection] = await db.select().from(whatsappConnections).where(eq(whatsappConnections.id, connectionId)).limit(1);
    return connection;
  }
  async getAdminConnection() {
    const [connection] = await db.select().from(adminWhatsappConnection).limit(1);
    return connection;
  }
  async getAllConnections() {
    const connections = await withRetry(
      () => db.select().from(whatsappConnections).orderBy(desc(whatsappConnections.createdAt))
    );
    return connections;
  }
  // Retorna UMA conexão por userId (a principal/conectada), para uso em
  // restoreExistingSessions e healthCheck — evita duplicatas e loops
  async getPrimaryConnectionPerUser() {
    const allConnections = await this.getAllConnections();
    const seen = /* @__PURE__ */ new Map();
    for (const conn of allConnections) {
      if (!conn.userId) continue;
      if (!isAppVisibleWhatsappConnection(conn)) continue;
      const existing = seen.get(conn.userId);
      if (!existing) {
        seen.set(conn.userId, conn);
      } else {
        if (conn.isConnected && !existing.isConnected) {
          seen.set(conn.userId, conn);
        } else if (!existing.isConnected && !conn.isConnected && conn.isPrimary && !existing.isPrimary) {
          seen.set(conn.userId, conn);
        }
      }
    }
    return Array.from(seen.values());
  }
  async createConnection(connectionData) {
    const [connection] = await db.insert(whatsappConnections).values(connectionData).returning();
    memoryCache.invalidate(`connByUser:${connection.userId}`);
    memoryCache.invalidate(`api:wa-conn:${connection.userId}`);
    memoryCache.invalidate(`api:wa-conn:${connection.userId}:default`);
    return connection;
  }
  async updateConnection(id, data) {
    const [connection] = await db.update(whatsappConnections).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(whatsappConnections.id, id)).returning();
    memoryCache.invalidate(`connByUser:${connection.userId}`);
    memoryCache.invalidate(`api:wa-conn:${connection.userId}`);
    memoryCache.invalidate(`api:wa-conn:${connection.userId}:default`);
    return connection;
  }
  async deleteConnection(id) {
    const [connection] = await db.select().from(whatsappConnections).where(eq(whatsappConnections.id, id)).limit(1);
    await db.delete(whatsappConnections).where(eq(whatsappConnections.id, id));
    if (connection?.userId) {
      memoryCache.invalidate(`connByUser:${connection.userId}`);
      memoryCache.invalidate(`api:wa-conn:${connection.userId}`);
      memoryCache.invalidate(`api:wa-conn:${connection.userId}:default`);
    }
  }
  // Multi-connection: get all connections for a user
  async getConnectionsByUserId(userId) {
    const connections = await db.select().from(whatsappConnections).where(eq(whatsappConnections.userId, userId)).orderBy(desc(whatsappConnections.createdAt));
    return connections.filter((connection) => !isUserRemovedConnection(connection));
  }
  // Connection Agents (many-to-many) CRUD
  async getConnectionAgents(connectionId) {
    return await db.select().from(connectionAgents).where(eq(connectionAgents.connectionId, connectionId)).orderBy(desc(connectionAgents.assignedAt));
  }
  async getAgentConnections(agentId) {
    return await db.select().from(connectionAgents).where(eq(connectionAgents.agentId, agentId)).orderBy(desc(connectionAgents.assignedAt));
  }
  async addConnectionAgent(data) {
    const [record] = await db.insert(connectionAgents).values(data).onConflictDoUpdate({
      target: [connectionAgents.connectionId, connectionAgents.agentId],
      set: { isActive: data.isActive ?? true, assignedBy: data.assignedBy }
    }).returning();
    return record;
  }
  async removeConnectionAgent(connectionId, agentId) {
    await db.delete(connectionAgents).where(
      and(
        eq(connectionAgents.connectionId, connectionId),
        eq(connectionAgents.agentId, agentId)
      )
    );
  }
  async updateConnectionAgent(connectionId, agentId, data) {
    const [record] = await db.update(connectionAgents).set(data).where(and(
      eq(connectionAgents.connectionId, connectionId),
      eq(connectionAgents.agentId, agentId)
    )).returning();
    return record;
  }
  // Connection Members CRUD
  async getConnectionMembers(connectionId) {
    return await db.select().from(connectionMembers).where(eq(connectionMembers.connectionId, connectionId)).orderBy(desc(connectionMembers.assignedAt));
  }
  async addConnectionMember(data) {
    const [record] = await db.insert(connectionMembers).values(data).onConflictDoUpdate({
      target: [connectionMembers.connectionId, connectionMembers.memberId],
      set: { canView: data.canView, canRespond: data.canRespond, canManage: data.canManage }
    }).returning();
    return record;
  }
  async removeConnectionMember(connectionId, memberId) {
    await db.delete(connectionMembers).where(
      and(
        eq(connectionMembers.connectionId, connectionId),
        eq(connectionMembers.memberId, memberId)
      )
    );
  }
  async updateConnectionMember(connectionId, memberId, data) {
    const [record] = await db.update(connectionMembers).set(data).where(and(
      eq(connectionMembers.connectionId, connectionId),
      eq(connectionMembers.memberId, memberId)
    )).returning();
    return record;
  }
  // Conversation operations
  async getConversationsByConnectionId(connectionId) {
    return await db.select().from(conversations).where(eq(conversations.connectionId, connectionId)).orderBy(sql`${conversations.lastMessageTime} DESC NULLS LAST`);
  }
  async getRecentConversationRecoveryState(connectionId, since) {
    const rows = await db.select({
      id: conversations.id,
      contactNumber: conversations.contactNumber,
      jidSuffix: conversations.jidSuffix,
      lastMessageText: conversations.lastMessageText,
      lastMessageTime: conversations.lastMessageTime,
      lastMessageFromMe: conversations.lastMessageFromMe
    }).from(conversations).where(
      and(
        eq(conversations.connectionId, connectionId),
        gte(conversations.lastMessageTime, since),
        or(eq(conversations.isClosed, false), isNull(conversations.isClosed))
      )
    ).orderBy(sql`${conversations.lastMessageTime} ASC NULLS LAST`);
    return rows;
  }
  // 🔥 OTIMIZADO: Retorna apenas COUNT e SUM ao invés de carregar 20k+ rows
  async getConversationStatsCount(connectionId) {
    const cacheKey = `convStats:${connectionId}`;
    const cached = memoryCache.get(cacheKey);
    if (cached !== null) return cached;
    const result = await db.select({
      total: sql`count(*)::int`,
      unread: sql`coalesce(sum("unread_count"), 0)::int`
    }).from(conversations).where(eq(conversations.connectionId, connectionId));
    const stats = { total: result[0]?.total || 0, unread: result[0]?.unread || 0 };
    memoryCache.set(cacheKey, stats, 3e4);
    return stats;
  }
  async getConversationByContactNumber(connectionId, contactNumber) {
    const [conversation] = await db.select().from(conversations).where(
      and(
        eq(conversations.connectionId, connectionId),
        eq(conversations.contactNumber, contactNumber)
      )
    );
    return conversation;
  }
  // FIX Encerramento: retorna apenas conversas ativas (nao fechadas) pelo numero do contato
  async getActiveConversationByContactNumber(connectionId, contactNumber) {
    const result = await db.select().from(conversations).where(
      and(
        eq(conversations.connectionId, connectionId),
        eq(conversations.contactNumber, contactNumber),
        or(eq(conversations.isClosed, false), isNull(conversations.isClosed))
      )
    ).orderBy(desc(conversations.updatedAt)).limit(1);
    return result[0];
  }
  async findConversationByIdentity(connectionId, params) {
    const numberCandidates = buildBrazilWhatsAppPhoneVariants(
      params.contactNumber || params.remoteJid || ""
    );
    const jidCandidates = /* @__PURE__ */ new Set();
    const normalizedRemoteJid = String(params.remoteJid || "").trim();
    if (normalizedRemoteJid) {
      jidCandidates.add(normalizedRemoteJid);
    }
    for (const candidate of numberCandidates) {
      const jid = buildWhatsAppJidFromPhone(candidate);
      if (jid) {
        jidCandidates.add(jid);
      }
    }
    const identityClauses = [];
    if (numberCandidates.length > 0) {
      identityClauses.push(inArray(conversations.contactNumber, numberCandidates));
    }
    if (jidCandidates.size > 0) {
      identityClauses.push(inArray(conversations.remoteJid, Array.from(jidCandidates)));
    }
    if (identityClauses.length === 0) {
      return void 0;
    }
    const filters = [
      eq(conversations.connectionId, connectionId),
      or(...identityClauses)
    ];
    if (params.activeOnly) {
      filters.push(or(eq(conversations.isClosed, false), isNull(conversations.isClosed)));
    }
    const rows = await db.select().from(conversations).where(and(...filters)).orderBy(
      desc(conversations.lastMessageTime),
      desc(conversations.updatedAt),
      desc(conversations.createdAt)
    ).limit(1);
    return rows[0];
  }
  async findAdminMirrorConversationForConnection(connectionId, contactNumber) {
    const [result] = await db.select({
      adminConversationId: adminConversations.id,
      adminId: adminConversations.adminId
    }).from(whatsappConnections).innerJoin(
      adminWhatsappConnection,
      eq(adminWhatsappConnection.phoneNumber, whatsappConnections.phoneNumber)
    ).innerJoin(
      adminConversations,
      and(
        eq(adminConversations.adminId, adminWhatsappConnection.adminId),
        eq(adminConversations.contactNumber, contactNumber),
        adminConversationIsVisibleCondition()
      )
    ).where(
      and(
        eq(whatsappConnections.id, connectionId),
        isNotNull(whatsappConnections.phoneNumber)
      )
    ).limit(1);
    return result ?? null;
  }
  async getConversation(id) {
    return memoryCache.getOrCompute(`conv:${id}`, async () => {
      const [conversation] = await db.select().from(conversations).where(eq(conversations.id, id));
      return conversation;
    }, 3e4);
  }
  invalidateConversationListCaches(connectionId) {
    if (!connectionId) return;
    memoryCache.invalidate(`convWithTags:${connectionId}`);
    memoryCache.invalidate(`convCount:${connectionId}`);
    memoryCache.invalidate(`convStats:${connectionId}`);
  }
  async createConversation(conversationData) {
    if (conversationData.connectionId && (conversationData.contactNumber || conversationData.remoteJid)) {
      const existing = await this.findConversationByIdentity(conversationData.connectionId, {
        contactNumber: conversationData.contactNumber,
        remoteJid: conversationData.remoteJid,
        activeOnly: true
      });
      if (existing) {
        console.log(`\u26A0\uFE0F [STORAGE] Conversa ativa j\xE1 existe para ${conversationData.contactNumber || conversationData.remoteJid} (${existing.id}), retornando existente em vez de duplicar`);
        const updated = await this.updateConversation(existing.id, {
          contactNumber: conversationData.contactNumber || existing.contactNumber,
          remoteJid: conversationData.remoteJid || existing.remoteJid,
          jidSuffix: conversationData.jidSuffix || existing.jidSuffix,
          contactName: conversationData.contactName || existing.contactName,
          contactAvatar: conversationData.contactAvatar || existing.contactAvatar,
          lastMessageText: conversationData.lastMessageText || existing.lastMessageText,
          lastMessageTime: conversationData.lastMessageTime || existing.lastMessageTime
        });
        return updated;
      }
    }
    const [conversation] = await db.insert(conversations).values(conversationData).returning();
    this.invalidateConversationListCaches(conversation.connectionId);
    return conversation;
  }
  async updateConversation(id, data) {
    memoryCache.invalidate(`conv:${id}`);
    const [conversation] = await db.update(conversations).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(conversations.id, id)).returning();
    this.invalidateConversationListCaches(conversation.connectionId);
    return conversation;
  }
  normalizeWhatsappAdsAttribution(input) {
    if (!input || typeof input !== "object") return null;
    const source = input;
    const clean = (value, maxLength = 512) => {
      const text = String(value ?? "").trim();
      if (!text) return null;
      return text.length > maxLength ? text.slice(0, maxLength) : text;
    };
    const attribution = {
      ctwaClid: clean(source.ctwaClid ?? source.ctwa_clid, 1024),
      sourceId: clean(source.sourceId ?? source.source_id, 128),
      sourceUrl: clean(source.sourceUrl ?? source.source_url, 1024),
      sourceType: clean(source.sourceType ?? source.source_type, 64),
      title: clean(source.title ?? source.headline, 256),
      body: clean(source.body, 512),
      mediaType: clean(source.mediaType ?? source.media_type, 64),
      thumbnailUrl: clean(source.thumbnailUrl ?? source.thumbnail_url, 1024),
      capturedAt: clean(source.capturedAt ?? source.captured_at, 64),
      messageId: clean(source.messageId ?? source.message_id, 128)
    };
    if (!attribution.ctwaClid && !attribution.sourceId && !attribution.sourceUrl && !attribution.sourceType) {
      return null;
    }
    return attribution;
  }
  pickBestWhatsappAdsAttribution(...candidates) {
    const normalized = candidates.map((candidate) => this.normalizeWhatsappAdsAttribution(candidate)).filter(Boolean);
    if (!normalized.length) return null;
    return normalized.find((candidate) => Boolean(candidate.ctwaClid)) || normalized.find((candidate) => Boolean(candidate.sourceId)) || normalized[0];
  }
  async recordConversationWhatsappAdsAttribution(data) {
    const nextAttribution = this.normalizeWhatsappAdsAttribution(data.attribution);
    if (!nextAttribution) return;
    const [existing] = await db.select({ rawAnalysis: conversationLeadIntelligence.rawAnalysis }).from(conversationLeadIntelligence).where(eq(conversationLeadIntelligence.conversationId, data.conversationId)).limit(1);
    const currentRawAnalysis = existing?.rawAnalysis || {};
    const currentAttribution = this.normalizeWhatsappAdsAttribution(currentRawAnalysis.whatsappAdsAttribution);
    const bestAttribution = this.pickBestWhatsappAdsAttribution(nextAttribution, currentAttribution);
    if (!bestAttribution) return;
    const nextRawAnalysis = {
      ...currentRawAnalysis,
      whatsappAdsAttribution: bestAttribution
    };
    await db.insert(conversationLeadIntelligence).values({
      conversationId: data.conversationId,
      connectionId: data.connectionId,
      userId: data.userId,
      contactNumber: data.contactNumber,
      contactName: data.contactName || null,
      rawAnalysis: nextRawAnalysis,
      analysisVersion: "whatsapp-ads-attribution-v1"
    }).onConflictDoUpdate({
      target: conversationLeadIntelligence.conversationId,
      set: {
        connectionId: data.connectionId,
        userId: data.userId,
        contactNumber: data.contactNumber,
        contactName: data.contactName || null,
        rawAnalysis: nextRawAnalysis,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
  async recordAdminConversationWhatsappAdsAttribution(conversationId, attribution) {
    const nextAttribution = this.normalizeWhatsappAdsAttribution(attribution);
    if (!nextAttribution) return;
    const conversation = await this.getAdminConversation(conversationId);
    if (!conversation) return;
    const currentContextState = conversation.contextState || {};
    const currentAttribution = this.normalizeWhatsappAdsAttribution(currentContextState.whatsappAdsAttribution);
    const bestAttribution = this.pickBestWhatsappAdsAttribution(nextAttribution, currentAttribution);
    if (!bestAttribution) return;
    await this.updateAdminConversation(conversationId, {
      contextState: {
        ...currentContextState,
        whatsappAdsAttribution: bestAttribution
      }
    });
  }
  async getConversationWhatsappAdsAttribution(conversationId) {
    if (!conversationId) return null;
    const [row] = await db.select({ rawAnalysis: conversationLeadIntelligence.rawAnalysis }).from(conversationLeadIntelligence).where(eq(conversationLeadIntelligence.conversationId, conversationId)).limit(1);
    return this.normalizeWhatsappAdsAttribution(row?.rawAnalysis?.whatsappAdsAttribution);
  }
  async getAdminConversationWhatsappAdsAttribution(conversationId) {
    if (!conversationId) return null;
    const [row] = await db.select({ contextState: adminConversations.contextState }).from(adminConversations).where(eq(adminConversations.id, conversationId)).limit(1);
    return this.normalizeWhatsappAdsAttribution(row?.contextState?.whatsappAdsAttribution);
  }
  async clearConversationOperationalHistory(conversationId) {
    const conversation = await this.getConversation(conversationId);
    if (!conversation) {
      throw new Error("Conversa n\xE3o encontrada.");
    }
    memoryCache.invalidate(`conv:${conversationId}`);
    memoryCache.invalidate(`messages:${conversationId}`);
    await db.transaction(async (tx) => {
      await tx.delete(messages).where(eq(messages.conversationId, conversationId));
      await tx.delete(agentDisabledConversations).where(eq(agentDisabledConversations.conversationId, conversationId));
      await tx.execute(sql`DELETE FROM message_deduplication WHERE conversation_id = ${conversationId}`);
      await tx.execute(sql`DELETE FROM pending_ai_responses WHERE conversation_id = ${conversationId}`);
      await tx.execute(sql`DELETE FROM vercel_agent_response_jobs WHERE conversation_id = ${conversationId}`);
      await tx.execute(sql`DELETE FROM conversation_lead_intelligence WHERE conversation_id = ${conversationId}`);
      await tx.execute(sql`DELETE FROM estamparia_requests WHERE conversation_id = ${conversationId}`);
      await tx.execute(sql`DELETE FROM chatbot_conversation_data WHERE conversation_id = ${conversationId}`);
      await tx.execute(sql`DELETE FROM conversation_flow_states WHERE conversation_id = ${conversationId}`);
      await tx.update(conversations).set({
        lastMessageText: null,
        lastMessageTime: null,
        lastMessageFromMe: null,
        unreadCount: 0,
        hasReplied: false,
        followupStage: 0,
        nextFollowupAt: null,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq(conversations.id, conversationId));
    });
    this.invalidateConversationListCaches(conversation.connectionId);
  }
  async getConversationByShareToken(shareToken) {
    const [conversation] = await db.select().from(conversations).where(eq(conversations.shareToken, shareToken));
    return conversation;
  }
  // Message operations - OTIMIZADO para reduzir egress do Supabase
  // ⚡ CRÍTICO: NÃO retorna media_url para economizar egress massivamente!
  // media_url pode ter 50KB-500KB de base64 por mensagem!
  async getMessagesByConversationId(conversationId) {
    const cacheKey = `messages:${conversationId}`;
    const cached = memoryCache.get(cacheKey);
    if (cached) return cached;
    const result = await db.select({
      id: messages.id,
      conversationId: messages.conversationId,
      messageId: messages.messageId,
      fromMe: messages.fromMe,
      text: messages.text,
      timestamp: messages.timestamp,
      status: messages.status,
      isFromAgent: messages.isFromAgent,
      mediaType: messages.mediaType,
      mediaUrl: messages.mediaUrl,
      // ✅ NECESSÁRIO para mostrar player
      mediaKey: messages.mediaKey,
      directPath: messages.directPath,
      mediaMimeType: messages.mediaMimeType,
      mediaDuration: messages.mediaDuration,
      mediaCaption: messages.mediaCaption,
      createdAt: messages.createdAt
    }).from(messages).where(eq(messages.conversationId, conversationId)).orderBy(messages.timestamp);
    memoryCache.set(cacheKey, result, 6e4);
    return result;
  }
  async getLastMessageByConversationId(conversationId) {
    const cacheKey = `messages:${conversationId}`;
    const cached = memoryCache.get(cacheKey);
    if (cached !== null) {
      return cached[cached.length - 1];
    }
    const [lastMessage] = await db.select({
      id: messages.id,
      fromMe: messages.fromMe,
      text: messages.text,
      timestamp: messages.timestamp
    }).from(messages).where(eq(messages.conversationId, conversationId)).orderBy(desc(messages.timestamp), desc(messages.createdAt)).limit(1);
    return lastMessage;
  }
  // Paginação: carrega as N mensagens mais recentes (ou antes de um cursor)
  async getMessagesByConversationIdPaginated(conversationId, limit = 50, before) {
    const fetchLimit = limit + 1;
    const conditions = [eq(messages.conversationId, conversationId)];
    if (before) {
      conditions.push(lt(messages.timestamp, before));
    }
    const result = await db.select({
      id: messages.id,
      conversationId: messages.conversationId,
      messageId: messages.messageId,
      fromMe: messages.fromMe,
      text: messages.text,
      timestamp: messages.timestamp,
      status: messages.status,
      isFromAgent: messages.isFromAgent,
      mediaType: messages.mediaType,
      mediaUrl: messages.mediaUrl,
      mediaKey: messages.mediaKey,
      directPath: messages.directPath,
      mediaMimeType: messages.mediaMimeType,
      mediaDuration: messages.mediaDuration,
      mediaCaption: messages.mediaCaption,
      createdAt: messages.createdAt
    }).from(messages).where(and(...conditions)).orderBy(desc(messages.timestamp)).limit(fetchLimit);
    const hasMore = result.length > limit;
    const page = hasMore ? result.slice(0, limit) : result;
    page.reverse();
    return { messages: page, hasMore };
  }
  // Busca mensagens mais recentes que uma data (para sync incremental)
  async getMessagesByConversationIdAfter(conversationId, after, limit = 500) {
    const result = await db.select({
      id: messages.id,
      conversationId: messages.conversationId,
      messageId: messages.messageId,
      fromMe: messages.fromMe,
      text: messages.text,
      timestamp: messages.timestamp,
      status: messages.status,
      isFromAgent: messages.isFromAgent,
      mediaType: messages.mediaType,
      mediaUrl: messages.mediaUrl,
      mediaKey: messages.mediaKey,
      directPath: messages.directPath,
      mediaMimeType: messages.mediaMimeType,
      mediaDuration: messages.mediaDuration,
      mediaCaption: messages.mediaCaption,
      createdAt: messages.createdAt
    }).from(messages).where(and(
      eq(messages.conversationId, conversationId),
      gt(messages.timestamp, after)
    )).orderBy(messages.timestamp).limit(limit);
    return result;
  }
  // Nova função para buscar media_url de uma mensagem específica (lazy loading)
  async getMessageMedia(messageId) {
    const [result] = await db.select({
      mediaUrl: messages.mediaUrl,
      mediaType: messages.mediaType
    }).from(messages).where(eq(messages.id, messageId)).limit(1);
    return result || null;
  }
  async getMessage(id) {
    const [message] = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
    return message;
  }
  // Atualizar mediaUrl de uma mensagem (usado para re-download de mídia)
  async updateMessageMedia(messageId, newMediaUrl) {
    await db.update(messages).set({ mediaUrl: newMediaUrl }).where(or(eq(messages.messageId, messageId), eq(messages.id, messageId)));
    const [msg] = await db.select({ conversationId: messages.conversationId }).from(messages).where(or(eq(messages.messageId, messageId), eq(messages.id, messageId))).limit(1);
    if (msg?.conversationId) {
      memoryCache.invalidate(`messages:${msg.conversationId}`);
    }
  }
  // Versão completa com media_url - usar apenas quando REALMENTE necessário
  async getMessagesByConversationIdWithMedia(conversationId, limit = 50) {
    return await db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(desc(messages.timestamp)).limit(limit);
  }
  async updateMessage(id, data) {
    const currentMessage = await this.getMessage(id);
    const nextMediaType = data.mediaType ?? currentMessage?.mediaType ?? null;
    const nextMediaUrl = data.mediaUrl ?? currentMessage?.mediaUrl ?? null;
    const nextText = typeof data.text === "string" ? data.text : currentMessage?.text ?? null;
    const conversationId = data.conversationId ?? currentMessage?.conversationId;
    if (conversationId && nextMediaType === "audio" && nextMediaUrl && isAudioPlaceholderText(nextText)) {
      try {
        const transcription = await resolveAudioTranscriptionForMessage({
          conversationId,
          mediaType: nextMediaType,
          mediaUrl: nextMediaUrl
        });
        if (transcription) {
          data.text = transcription;
        }
      } catch (error) {
        console.error("Error transcribing audio message in storage.updateMessage:", error);
      }
    }
    const [message] = await db.update(messages).set(data).where(eq(messages.id, id)).returning();
    if (message?.conversationId) {
      memoryCache.invalidate(`messages:${message.conversationId}`);
    }
    return message;
  }
  async getMessageByMessageId(messageId) {
    const [message] = await db.select().from(messages).where(or(eq(messages.messageId, messageId), eq(messages.id, messageId))).limit(1);
    return message;
  }
  async getMessageByConversationAndMessageId(conversationId, messageId) {
    const [message] = await db.select().from(messages).where(and(
      eq(messages.conversationId, conversationId),
      eq(messages.messageId, messageId)
    )).limit(1);
    return message;
  }
  async deleteMessagesByConversationId(conversationId) {
    memoryCache.invalidate(`messages:${conversationId}`);
    await db.delete(messages).where(eq(messages.conversationId, conversationId));
  }
  async createMessage(messageData) {
    const data = { ...messageData };
    memoryCache.invalidate(`messages:${data.conversationId}`);
    if (data.mediaType === "audio" && data.mediaUrl) {
      try {
        const transcription = await resolveAudioTranscriptionForMessage({
          conversationId: data.conversationId,
          mediaType: data.mediaType,
          mediaUrl: data.mediaUrl
        });
        if (transcription) {
          data.text = transcription;
        }
      } catch (error) {
        console.error("Error transcribing audio message in storage.createMessage:", error);
      }
    }
    if (data.mediaType === "image" && data.mediaUrl && !data.fromMe) {
      try {
        let imageUrl = data.mediaUrl;
        if (imageUrl.startsWith("data:")) {
          console.log(`\u{1F5BC}\uFE0F [Storage] Imagem base64 detectada, enviando direto para an\xE1lise...`);
        } else if (imageUrl.startsWith("http://") || imageUrl.startsWith("https://")) {
          console.log(`\u{1F5BC}\uFE0F [Storage] Imagem URL detectada: ${imageUrl.substring(0, 80)}...`);
        } else {
          console.log(`\u{1F5BC}\uFE0F [Storage] Formato de imagem n\xE3o reconhecido, pulando an\xE1lise`);
          imageUrl = "";
        }
        if (imageUrl) {
          console.log(`\u{1F5BC}\uFE0F [Storage] Iniciando an\xE1lise de imagem com Mistral Vision...`);
          const analysisPrompt = `Analise esta imagem e descreva em portugues de forma clara e objetiva.

IMPORTANTE:
- Se for um COMPROVANTE DE PAGAMENTO: extraia valor, data, nome do pagador/recebedor, tipo (PIX, transferencia, boleto)
- Se for um PRODUTO: descreva caracteristicas visuais, marca se visivel
- Se for uma imagem/lista/print de CATALOGO ou PEDIDO: extraia ate 10 itens visiveis em ordem, incluindo codigo, nome, preco, quantidade, tamanho e acabamento quando aparecerem. Nao pare em 3 itens.
- Se for uma DUVIDA/PERGUNTA: descreva o que a pessoa parece querer saber
- Se for DOCUMENTO: identifique o tipo e informacoes relevantes

Responda de forma concisa. Para catalogo/pedido com varios itens, use uma lista curta com ate 10 itens para preservar todos os codigos visiveis.`;
          const conversationRecord = await db.query.conversations.findFirst({
            where: eq(conversations.id, data.conversationId),
            columns: { connectionId: true }
          });
          const connectionRecord = conversationRecord ? await db.query.whatsappConnections.findFirst({
            where: eq(whatsappConnections.id, conversationRecord.connectionId),
            columns: { userId: true }
          }) : null;
          const imageDescription = await analyzeImageWithMistral(
            imageUrl,
            analysisPrompt,
            connectionRecord?.userId
          );
          if (imageDescription && imageDescription.length > 0) {
            console.log(`\u{1F5BC}\uFE0F [Storage] \u2705 An\xE1lise de imagem bem-sucedida: "${imageDescription.substring(0, 100)}..."`);
            let catalogVariationContext = "";
            if (connectionRecord?.userId) {
              try {
                const { data: productsConfig } = await supabase.from("products_config").select("is_active, send_to_ai, image_variations_enabled").eq("user_id", connectionRecord.userId).single();
                if (productsConfig?.is_active === true && productsConfig?.send_to_ai !== false) {
                  const { data: productsData, error: productsError } = await supabase.from("products").select("id, name, price, category, image_url").eq("user_id", connectionRecord.userId).eq("is_active", true);
                  if (productsError) {
                    throw productsError;
                  }
                  const hydratedProducts = attachMediaToProducts(
                    productsData || [],
                    await fetchProductMediaRows({
                      supabase,
                      userId: connectionRecord.userId,
                      productIds: (productsData || []).map((product) => String(product.id))
                    })
                  );
                  const hasVariationAwareCatalog = productsConfig?.image_variations_enabled === true || hydratedProducts.some(
                    (product) => (Array.isArray(product.media_items) ? product.media_items : []).some(
                      (media) => hasCatalogVariationMetadata({
                        variation_code: media?.variation_code ?? null,
                        variation_name: media?.variation_name ?? null,
                        variation_price: media?.variation_price ?? null,
                        variation_stock: media?.variation_stock ?? null
                      })
                    )
                  );
                  if (hasVariationAwareCatalog) {
                    const matchResult = await matchCatalogVariationFromCustomerImage({
                      customerImageDescription: imageDescription,
                      customerMessage: data.text || null,
                      candidates: hydratedProducts.flatMap(
                        (product) => (Array.isArray(product.media_items) ? product.media_items : []).filter((media) => media?.variation_is_active !== false).map((media) => ({
                          mediaId: String(media.id),
                          productId: String(product.id),
                          productName: String(product.name),
                          productCategory: product.category ?? null,
                          productPrice: product.price ?? null,
                          fileName: media.file_name ?? null,
                          caption: media.caption ?? null,
                          variationCode: media.variation_code ?? null,
                          variationName: media.variation_name ?? null,
                          variationPrice: media.variation_price ?? null,
                          variationStock: media.variation_stock ?? null,
                          variationIsActive: media.variation_is_active !== false
                        }))
                      )
                    });
                    if (matchResult?.matched) {
                      const matches = Array.isArray(matchResult.matches) && matchResult.matches.length > 0 ? matchResult.matches.slice(0, 10) : matchResult.mediaId && matchResult.productId ? [{ productId: matchResult.productId, mediaId: matchResult.mediaId }] : [];
                      const matchedDetails = [];
                      const matchedCodes = [];
                      for (const [index, match] of matches.entries()) {
                        const matchedProduct = hydratedProducts.find((product) => String(product.id) === match.productId);
                        const matchedMedia = matchedProduct?.media_items?.find((media) => String(media.id) === match.mediaId);
                        if (!matchedProduct || !matchedMedia) {
                          continue;
                        }
                        const details = [`item ${index + 1}`, `produto ${matchedProduct.name}`];
                        if (typeof matchedMedia.variation_code === "number") {
                          matchedCodes.push(matchedMedia.variation_code);
                          details.push(`codigo ${matchedMedia.variation_code}`);
                        }
                        if (matchedMedia.variation_name) {
                          details.push(`nome ${matchedMedia.variation_name}`);
                        }
                        if (matchedMedia.variation_price) {
                          details.push(`preco ${matchedMedia.variation_price}`);
                        }
                        if (typeof matchedMedia.variation_stock === "number") {
                          details.push(`estoque ${matchedMedia.variation_stock}`);
                        }
                        matchedDetails.push(details.join(" | "));
                      }
                      if (matchedDetails.length > 0) {
                        const codesSummary = matchedCodes.length > 0 ? `codigos selecionados ${matchedCodes.join(", ")} | ` : "";
                        catalogVariationContext = `[CATALOGO_IDENTIFICADO: ${codesSummary}${matchedDetails.join(" ; ")}]`;
                      }
                    }
                  }
                }
              } catch (catalogMatchError) {
                console.warn("[Storage] Falha ao enriquecer imagem com varia\xE7\xE3o do cat\xE1logo:", catalogMatchError);
              }
            }
            data.text = `[IMAGEM ANALISADA: ${imageDescription}]${catalogVariationContext ? `
${catalogVariationContext}` : ""}`;
          } else {
            console.log(`\u{1F5BC}\uFE0F [Storage] \u26A0\uFE0F An\xE1lise de imagem vazia ou nula`);
            data.text = data.text || "(imagem enviada pelo cliente)";
          }
        }
      } catch (error) {
        console.error("Error analyzing image message in storage.createMessage:", error);
        data.text = data.text || "(imagem enviada pelo cliente)";
      }
    }
    const [message] = await db.insert(messages).values(data).returning();
    return message;
  }
  // 🔥 OTIMIZADO: Usar COUNT(*) em vez de trazer todas as linhas
  // Reduz drasticamente o Egress do Supabase
  async getTodayMessagesCount(connectionId) {
    const cacheKey = `todayMsgCount:${connectionId}`;
    const cached = memoryCache.get(cacheKey);
    if (cached !== null) return cached;
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const result = await db.select({ count: sql`count(*)::int` }).from(messages).innerJoin(conversations, eq(messages.conversationId, conversations.id)).where(
      and(
        eq(conversations.connectionId, connectionId),
        gte(messages.timestamp, today)
      )
    );
    const count = result[0]?.count || 0;
    memoryCache.set(cacheKey, count, 6e4);
    return count;
  }
  // 🔥 OTIMIZADO: Usar COUNT(*) em vez de trazer todas as linhas
  // Antes: trazia TODAS as mensagens do agente (milhares de rows com media_url grande)
  // Agora: retorna apenas 1 número, reduz Egress em ~99%
  async getAgentMessagesCount(connectionId) {
    const cacheKey = `agentMsgCount:${connectionId}`;
    const cached = memoryCache.get(cacheKey);
    if (cached !== null) return cached;
    const result = await db.select({ count: sql`count(*)::int` }).from(messages).innerJoin(conversations, eq(messages.conversationId, conversations.id)).where(
      and(
        eq(conversations.connectionId, connectionId),
        eq(messages.isFromAgent, true)
      )
    );
    const count = result[0]?.count || 0;
    memoryCache.set(cacheKey, count, 6e4);
    return count;
  }
  // AI Agent operations
  async getAgentConfig(userId) {
    const [config] = await db.select().from(aiAgentConfig).where(eq(aiAgentConfig.userId, userId));
    return config ? repairMojibakeDeep(config) : void 0;
  }
  async upsertAgentConfig(userId, data) {
    const normalizedData = repairMojibakeDeep(data);
    const [config] = await db.insert(aiAgentConfig).values({ userId, ...normalizedData }).onConflictDoUpdate({
      target: aiAgentConfig.userId,
      set: {
        ...normalizedData,
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    return repairMojibakeDeep(config);
  }
  async updateAgentConfig(userId, data) {
    const normalizedData = repairMojibakeDeep(data);
    const [config] = await db.update(aiAgentConfig).set({ ...normalizedData, updatedAt: /* @__PURE__ */ new Date() }).where(eq(aiAgentConfig.userId, userId)).returning();
    return config ? repairMojibakeDeep(config) : void 0;
  }
  // 🆕 Business Agent Configuration operations (Advanced System)
  async getBusinessAgentConfig(userId) {
    const [config] = await db.select().from(businessAgentConfigs).where(eq(businessAgentConfigs.userId, userId));
    return config ? repairMojibakeDeep(config) : void 0;
  }
  async upsertBusinessAgentConfig(userId, data) {
    const normalizedData = repairMojibakeDeep(data);
    const [config] = await db.insert(businessAgentConfigs).values({ userId, ...normalizedData }).onConflictDoUpdate({
      target: businessAgentConfigs.userId,
      set: {
        ...normalizedData,
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    return repairMojibakeDeep(config);
  }
  async deleteBusinessAgentConfig(userId) {
    await db.delete(businessAgentConfigs).where(eq(businessAgentConfigs.userId, userId));
  }
  /**
   * Verificar se IA está desativada para uma conversa
   * 
   * ⚠️ IMPORTANTE: A IA é controlada APENAS pela tabela agent_disabled_conversations
   * Follow-up é controlado SEPARADAMENTE por conversations.followupActive
   * IA e Follow-up são sistemas INDEPENDENTES!
   * 
   * IA é desativada quando:
   * 1. Existe entrada em agent_disabled_conversations (pausa temporária quando dono responde)
   * 
   * Follow-up é desativado quando:
   * 1. Toggle global em /followup está desativado (followup_configs.is_enabled)
   * 2. Toggle individual na conversa está desativado (conversations.followupActive)
   */
  async isAgentDisabledForConversation(conversationId) {
    const [disabled] = await db.select().from(agentDisabledConversations).where(eq(agentDisabledConversations.conversationId, conversationId));
    return !!disabled;
  }
  async getDisabledConversationIds(conversationIds) {
    const ids = Array.from(new Set(conversationIds.filter(Boolean)));
    if (ids.length === 0) {
      return [];
    }
    const rows = await db.select({ conversationId: agentDisabledConversations.conversationId }).from(agentDisabledConversations).where(inArray(agentDisabledConversations.conversationId, ids));
    return rows.map((row) => row.conversationId);
  }
  async disableAgentForConversation(conversationId, autoReactivateAfterMinutes) {
    await db.insert(agentDisabledConversations).values({
      conversationId,
      ownerLastReplyAt: /* @__PURE__ */ new Date(),
      autoReactivateAfterMinutes: autoReactivateAfterMinutes ?? null,
      clientHasPendingMessage: false,
      clientLastMessageAt: null
    }).onConflictDoUpdate({
      target: agentDisabledConversations.conversationId,
      set: {
        ownerLastReplyAt: /* @__PURE__ */ new Date(),
        autoReactivateAfterMinutes: autoReactivateAfterMinutes ?? null,
        // Reset pending message flag when owner replies again
        clientHasPendingMessage: false
      }
    });
    console.log(`\u{1F916} [STORAGE] IA desativada para conversa ${conversationId} (follow-up permanece no estado atual)`);
  }
  async enableAgentForConversation(conversationId) {
    await db.delete(agentDisabledConversations).where(eq(agentDisabledConversations.conversationId, conversationId));
    console.log(`\u2705 [STORAGE] IA reativada para conversa ${conversationId} (follow-up permanece no estado atual)`);
  }
  async updateDisabledConversationOwnerReply(conversationId, autoReactivateAfterMinutes) {
    const updateData = {
      ownerLastReplyAt: /* @__PURE__ */ new Date(),
      clientHasPendingMessage: false
      // Reset when owner replies again
    };
    if (autoReactivateAfterMinutes !== void 0) {
      updateData.autoReactivateAfterMinutes = autoReactivateAfterMinutes;
    }
    await db.update(agentDisabledConversations).set(updateData).where(eq(agentDisabledConversations.conversationId, conversationId));
  }
  async markClientPendingMessage(conversationId) {
    await db.update(agentDisabledConversations).set({
      clientHasPendingMessage: true,
      clientLastMessageAt: /* @__PURE__ */ new Date()
    }).where(eq(agentDisabledConversations.conversationId, conversationId));
  }
  async getConversationsToAutoReactivate() {
    try {
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const result = await pool2.query(`
        SELECT
          adc.conversation_id as "conversationId",
          adc.client_last_message_at as "clientLastMessageAt",
          adc.client_has_pending_message as "clientHasPendingMessage",
          adc.owner_last_reply_at as "ownerLastReplyAt",
          adc.auto_reactivate_after_minutes as "autoReactivateAfterMinutes"
        FROM agent_disabled_conversations adc
        INNER JOIN conversations c ON c.id = adc.conversation_id
        INNER JOIN whatsapp_connections wc ON wc.id = c.connection_id
        INNER JOIN ai_agent_config aic ON aic.user_id = wc.user_id AND aic.is_active = true
        INNER JOIN business_agent_configs bac ON bac.user_id = wc.user_id AND bac.is_active = true
        WHERE 
          adc.owner_last_reply_at IS NOT NULL
          AND adc.auto_reactivate_after_minutes IS NOT NULL
          AND adc.auto_reactivate_after_minutes > 0
          AND adc.owner_last_reply_at + (adc.auto_reactivate_after_minutes * INTERVAL '1 minute') <= NOW()
          AND COALESCE(c.is_closed, false) = false
          AND COALESCE(wc.ai_enabled, true) = true
          AND (c.remote_jid IS NULL OR c.remote_jid NOT ILIKE '%@g.us')
        ORDER BY
          CASE WHEN adc.client_has_pending_message = true THEN 0 ELSE 1 END ASC,
          adc.client_last_message_at DESC NULLS LAST,
          adc.owner_last_reply_at + (adc.auto_reactivate_after_minutes * INTERVAL '1 minute') DESC
        LIMIT 10
      `);
      return result.rows.map((r) => ({
        conversationId: r.conversationId,
        clientLastMessageAt: r.clientLastMessageAt ? new Date(r.clientLastMessageAt) : null,
        clientHasPendingMessage: r.clientHasPendingMessage === true,
        ownerLastReplyAt: r.ownerLastReplyAt ? new Date(r.ownerLastReplyAt) : null,
        autoReactivateAfterMinutes: Number.isFinite(Number(r.autoReactivateAfterMinutes)) ? Number(r.autoReactivateAfterMinutes) : null
      }));
    } catch (error) {
      console.error(`\u274C [STORAGE] Erro em getConversationsToAutoReactivate:`, error);
      return [];
    }
  }
  /**
   * 🔥 OTIMIZAÇÃO: Verifica rapidamente se há conversas para reativar
   * Usa EXISTS que é muito mais leve que SELECT * para verificação
   * 🐛 FIX CRÍTICO: NÃO usar COALESCE! Quando auto_reactivate_after_minutes é NULL,
   * significa "NUNCA reativar automaticamente" - essas conversas NÃO devem ser consideradas!
   */
  async hasConversationsToAutoReactivate() {
    try {
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const result = await pool2.query(`
        SELECT EXISTS (
          SELECT 1
          FROM agent_disabled_conversations adc
          INNER JOIN conversations c ON c.id = adc.conversation_id
          INNER JOIN whatsapp_connections wc ON wc.id = c.connection_id
          INNER JOIN ai_agent_config aic ON aic.user_id = wc.user_id AND aic.is_active = true
          INNER JOIN business_agent_configs bac ON bac.user_id = wc.user_id AND bac.is_active = true
          WHERE
            adc.owner_last_reply_at IS NOT NULL
            AND adc.auto_reactivate_after_minutes IS NOT NULL
            AND adc.auto_reactivate_after_minutes > 0
            AND adc.owner_last_reply_at + (adc.auto_reactivate_after_minutes * INTERVAL '1 minute') <= NOW()
            AND COALESCE(c.is_closed, false) = false
            AND COALESCE(wc.ai_enabled, true) = true
            AND (c.remote_jid IS NULL OR c.remote_jid NOT ILIKE '%@g.us')
          LIMIT 1
        ) as has_pending
      `);
      return result.rows[0]?.has_pending === true;
    } catch (error) {
      console.error(`\u274C [STORAGE] Erro em hasConversationsToAutoReactivate:`, error);
      return false;
    }
  }
  /**
   * 🔥 OTIMIZAÇÃO: Conta conversas com timers ativos (para ajuste dinâmico de intervalo)
   * 🐛 FIX: Contar APENAS conversas que têm auto_reactivate_after_minutes configurado
   * Conversas com NULL não devem ser contadas pois nunca serão reativadas automaticamente
   */
  async countActiveAutoReactivateTimers() {
    try {
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const result = await pool2.query(`
        SELECT COUNT(*) as count 
        FROM agent_disabled_conversations
        WHERE auto_reactivate_after_minutes IS NOT NULL
      `);
      return parseInt(result.rows[0]?.count || "0", 10);
    } catch (error) {
      console.error(`\u274C [STORAGE] Erro em countActiveAutoReactivateTimers:`, error);
      return 0;
    }
  }
  async getDisabledConversationDetails(conversationId) {
    const [result] = await db.select({
      ownerLastReplyAt: agentDisabledConversations.ownerLastReplyAt,
      autoReactivateAfterMinutes: agentDisabledConversations.autoReactivateAfterMinutes,
      clientHasPendingMessage: agentDisabledConversations.clientHasPendingMessage
    }).from(agentDisabledConversations).where(eq(agentDisabledConversations.conversationId, conversationId));
    if (!result) return null;
    return {
      ownerLastReplyAt: result.ownerLastReplyAt,
      autoReactivateAfterMinutes: result.autoReactivateAfterMinutes,
      clientHasPendingMessage: result.clientHasPendingMessage ?? false
    };
  }
  // Plan operations
  async getAllPlans() {
    return await withRetry(() => db.select().from(plans).orderBy(plans.ordem));
  }
  async getActivePlans() {
    return await db.select().from(plans).where(eq(plans.ativo, true)).orderBy(plans.ordem);
  }
  async getPublicCatalogPlans() {
    const activePlans = await this.getActivePlans();
    return getPublicCatalogPlans(activePlans);
  }
  async getPlan(id) {
    const [plan] = await db.select().from(plans).where(eq(plans.id, id));
    return plan;
  }
  async getPlanBySlug(slug) {
    try {
      const [plan] = await db.select().from(plans).where(eq(plans.linkSlug, slug));
      return plan;
    } catch (error) {
      console.error("Error in getPlanBySlug:", error);
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const result = await pool2.query(
        "SELECT * FROM plans WHERE link_slug = $1",
        [slug]
      );
      if (result.rows.length === 0) return void 0;
      const row = result.rows[0];
      return {
        id: row.id,
        nome: row.nome,
        valor: row.valor,
        tipo: row.tipo,
        features: row.features,
        ativo: row.ativo,
        ordem: row.ordem,
        codigoPersonalizado: row.codigo_personalizado,
        valorPrimeiraCobranca: row.valor_primeira_cobranca,
        linkSlug: row.link_slug,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      };
    }
  }
  async createPlan(planData) {
    const [plan] = await db.insert(plans).values(planData).returning();
    return plan;
  }
  async updatePlan(id, data) {
    const [plan] = await db.update(plans).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(plans.id, id)).returning();
    return plan;
  }
  async deletePlan(id) {
    await db.delete(plans).where(eq(plans.id, id));
  }
  // Coupon operations
  async getCouponByCode(code) {
    try {
      const [coupon] = await db.select().from(coupons).where(eq(coupons.code, code.toUpperCase()));
      return coupon;
    } catch (error) {
      console.error("Error in getCouponByCode with Drizzle, trying raw query:", error);
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const result = await pool2.query(
        "SELECT * FROM coupons WHERE UPPER(code) = $1",
        [code.toUpperCase()]
      );
      if (result.rows.length === 0) return void 0;
      const row = result.rows[0];
      return {
        id: row.id,
        code: row.code,
        discountType: row.discount_type,
        discountValue: row.discount_value,
        finalPrice: row.final_price,
        isActive: row.is_active,
        maxUses: row.max_uses,
        currentUses: row.current_uses,
        applicablePlans: row.applicable_plans,
        validFrom: row.valid_from,
        validUntil: row.valid_until,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      };
    }
  }
  async getAllCoupons() {
    try {
      return await db.select().from(coupons).orderBy(desc(coupons.createdAt));
    } catch (error) {
      console.error("Error in getAllCoupons with Drizzle, trying raw query:", error);
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const result = await pool2.query("SELECT * FROM coupons ORDER BY created_at DESC");
      return result.rows.map((row) => ({
        id: row.id,
        code: row.code,
        discountType: row.discount_type,
        discountValue: row.discount_value,
        finalPrice: row.final_price,
        isActive: row.is_active,
        maxUses: row.max_uses,
        currentUses: row.current_uses,
        applicablePlans: row.applicable_plans,
        validFrom: row.valid_from,
        validUntil: row.valid_until,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      }));
    }
  }
  async createCoupon(couponData) {
    try {
      const [coupon] = await db.insert(coupons).values({
        ...couponData,
        code: couponData.code.toUpperCase()
      }).returning();
      return coupon;
    } catch (error) {
      console.error("Error in createCoupon with Drizzle, trying raw query:", error);
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const result = await pool2.query(`
        INSERT INTO coupons (code, discount_type, discount_value, final_price, is_active, max_uses, current_uses, applicable_plans, valid_until)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `, [
        couponData.code.toUpperCase(),
        couponData.discountType || "fixed_price",
        couponData.discountValue || "0",
        couponData.finalPrice,
        couponData.isActive !== false,
        couponData.maxUses || null,
        couponData.currentUses || 0,
        couponData.applicablePlans ? JSON.stringify(couponData.applicablePlans) : null,
        couponData.validUntil || null
      ]);
      const row = result.rows[0];
      return {
        id: row.id,
        code: row.code,
        discountType: row.discount_type,
        discountValue: row.discount_value,
        finalPrice: row.final_price,
        isActive: row.is_active,
        maxUses: row.max_uses,
        currentUses: row.current_uses,
        applicablePlans: row.applicable_plans,
        validFrom: row.valid_from,
        validUntil: row.valid_until,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      };
    }
  }
  async updateCoupon(id, data) {
    try {
      const updateData = { ...data, updatedAt: /* @__PURE__ */ new Date() };
      if (data.code) {
        updateData.code = data.code.toUpperCase();
      }
      const [coupon] = await db.update(coupons).set(updateData).where(eq(coupons.id, id)).returning();
      return coupon;
    } catch (error) {
      console.error("Error in updateCoupon with Drizzle, trying raw query:", error);
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      const setClauses = [];
      const values = [];
      let paramIndex = 1;
      if (data.code !== void 0) {
        setClauses.push(`code = $${paramIndex++}`);
        values.push(data.code.toUpperCase());
      }
      if (data.finalPrice !== void 0) {
        setClauses.push(`final_price = $${paramIndex++}`);
        values.push(data.finalPrice);
      }
      if (data.isActive !== void 0) {
        setClauses.push(`is_active = $${paramIndex++}`);
        values.push(data.isActive);
      }
      if (data.maxUses !== void 0) {
        setClauses.push(`max_uses = $${paramIndex++}`);
        values.push(data.maxUses);
      }
      if (data.validUntil !== void 0) {
        setClauses.push(`valid_until = $${paramIndex++}`);
        values.push(data.validUntil);
      }
      if (data.applicablePlans !== void 0) {
        setClauses.push(`applicable_plans = $${paramIndex++}`);
        values.push(data.applicablePlans ? JSON.stringify(data.applicablePlans) : null);
      }
      setClauses.push(`updated_at = $${paramIndex++}`);
      values.push(/* @__PURE__ */ new Date());
      values.push(id);
      const result = await pool2.query(`
        UPDATE coupons SET ${setClauses.join(", ")} WHERE id = $${paramIndex}
        RETURNING *
      `, values);
      const row = result.rows[0];
      return {
        id: row.id,
        code: row.code,
        discountType: row.discount_type,
        discountValue: row.discount_value,
        finalPrice: row.final_price,
        isActive: row.is_active,
        maxUses: row.max_uses,
        currentUses: row.current_uses,
        applicablePlans: row.applicable_plans,
        validFrom: row.valid_from,
        validUntil: row.valid_until,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      };
    }
  }
  async deleteCoupon(id) {
    try {
      await db.delete(coupons).where(eq(coupons.id, id));
    } catch (error) {
      console.error("Error in deleteCoupon with Drizzle, trying raw query:", error);
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      await pool2.query("DELETE FROM coupons WHERE id = $1", [id]);
    }
  }
  async incrementCouponUsage(id) {
    try {
      await db.update(coupons).set({ currentUses: sql`${coupons.currentUses} + 1`, updatedAt: /* @__PURE__ */ new Date() }).where(eq(coupons.id, id));
    } catch (error) {
      console.error("Error in incrementCouponUsage with Drizzle, trying raw query:", error);
      const { pool: pool2 } = await import("./db-JX2B2FPR.js");
      await pool2.query("UPDATE coupons SET current_uses = current_uses + 1, updated_at = NOW() WHERE id = $1", [id]);
    }
  }
  // Subscription operations
  async getSubscription(id) {
    const result = await db.select().from(subscriptions).innerJoin(plans, eq(subscriptions.planId, plans.id)).where(eq(subscriptions.id, id)).limit(1);
    if (result.length === 0) return void 0;
    return {
      ...result[0].subscriptions,
      plan: result[0].plans
    };
  }
  async getUserSubscription(userId) {
    const activeResult = await db.select().from(subscriptions).innerJoin(plans, eq(subscriptions.planId, plans.id)).where(and(
      eq(subscriptions.userId, userId),
      eq(subscriptions.status, "active")
    )).orderBy(desc(subscriptions.createdAt)).limit(1);
    if (activeResult.length > 0) {
      return {
        ...activeResult[0].subscriptions,
        plan: activeResult[0].plans
      };
    }
    const result = await db.select().from(subscriptions).innerJoin(plans, eq(subscriptions.planId, plans.id)).where(eq(subscriptions.userId, userId)).orderBy(desc(subscriptions.createdAt));
    if (result.length === 0) return void 0;
    const subscriptionIds = result.map((row) => row.subscriptions.id);
    const approvedReceiptRows = subscriptionIds.length > 0 ? await db.select({
      subscriptionId: paymentReceipts.subscriptionId,
      approvedReceiptAt: sql`max(coalesce(${paymentReceipts.reviewedAt}, ${paymentReceipts.updatedAt}, ${paymentReceipts.createdAt}))`
    }).from(paymentReceipts).where(and(
      inArray(paymentReceipts.subscriptionId, subscriptionIds),
      eq(paymentReceipts.status, "approved")
    )).groupBy(paymentReceipts.subscriptionId) : [];
    const approvedReceiptAtBySubscriptionId = new Map(
      approvedReceiptRows.map((row) => [row.subscriptionId, row.approvedReceiptAt ?? null])
    );
    const candidates = result.map((row) => ({
      ...row.subscriptions,
      plan: row.plans,
      approvedReceiptAt: approvedReceiptAtBySubscriptionId.get(row.subscriptions.id) ?? null,
      planPeriodicity: row.plans.periodicidade ?? null,
      planFrequencyDays: row.plans.frequenciaDias ?? null
    }));
    const preferred = pickPreferredSubscriptionCandidate(candidates);
    if (!preferred) {
      return {
        ...result[0].subscriptions,
        plan: result[0].plans
      };
    }
    if (shouldAutoActivateSubscriptionFromApprovedReceipt(preferred)) {
      const activationWindow = resolveApprovedReceiptActivationWindow(preferred);
      const repairedSubscription = await this.updateSubscription(preferred.id, {
        status: "active",
        pendingReceipt: false,
        dataInicio: activationWindow.dataInicio,
        dataFim: activationWindow.dataFim,
        nextPaymentDate: activationWindow.nextPaymentDate,
        paymentMethod: preferred.paymentMethod || "pix_manual"
      });
      console.log(
        `[SUBSCRIPTION REPAIR] Auto-activated subscription ${preferred.id} for user ${userId} from approved manual receipt`
      );
      return {
        ...repairedSubscription,
        plan: preferred.plan
      };
    }
    const { plan, approvedReceiptAt, planPeriodicity, planFrequencyDays, ...subscriptionData } = preferred;
    return {
      ...subscriptionData,
      plan
    };
  }
  async getAllSubscriptions() {
    const result = await withRetry(
      () => db.select().from(subscriptions).innerJoin(plans, eq(subscriptions.planId, plans.id)).innerJoin(users, eq(subscriptions.userId, users.id)).orderBy(desc(subscriptions.createdAt))
    );
    return result.map((row) => ({
      ...row.subscriptions,
      plan: row.plans,
      user: row.users
    }));
  }
  async createSubscription(subscriptionData) {
    const [subscription] = await db.insert(subscriptions).values(subscriptionData).returning();
    return subscription;
  }
  async updateSubscription(id, data) {
    const [subscription] = await db.update(subscriptions).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(subscriptions.id, id)).returning();
    if (subscription?.status === "active" && data.status === "active") {
      void this.markRodrigoPaidLeadAttribution(subscription).catch((error) => {
        console.warn("[Rodrigo Paid Lead] Failed to tag paid lead:", error);
      });
    }
    return subscription;
  }
  buildPaidLeadPhoneCandidates(user) {
    const candidates = /* @__PURE__ */ new Set();
    for (const value of [user.phone, user.whatsappNumber]) {
      const digits = normalizePhoneToDigits(value || "");
      if (digits) {
        candidates.add(digits);
        candidates.add(`+${digits}`);
      }
      for (const variant of buildBrazilWhatsAppPhoneVariants(value)) {
        candidates.add(variant);
        candidates.add(`+${variant}`);
      }
    }
    return Array.from(candidates).filter(Boolean);
  }
  async getRodrigoPaidTag(ownerUserId) {
    const existingTags = await this.getTagsByUserId(ownerUserId);
    const existing = existingTags.find((tag) => tag.name.trim().toLowerCase() === "pago");
    if (existing) return existing;
    await this.createDefaultTags(ownerUserId);
    const afterDefaults = await this.getTagsByUserId(ownerUserId);
    const defaultPaid = afterDefaults.find((tag) => tag.name.trim().toLowerCase() === "pago");
    if (defaultPaid) return defaultPaid;
    const [created] = await db.insert(tags).values({
      userId: ownerUserId,
      name: "Pago",
      color: "#3b82f6",
      icon: "check-circle",
      position: 3,
      isDefault: true
    }).onConflictDoNothing().returning();
    if (created) return created;
    const [fallback] = await db.select().from(tags).where(and(eq(tags.userId, ownerUserId), eq(tags.name, "Pago"))).limit(1);
    return fallback;
  }
  async markRodrigoPaidLeadAttribution(subscription) {
    const paidUser = await this.getUser(subscription.userId);
    if (!paidUser) return;
    const phoneCandidates = this.buildPaidLeadPhoneCandidates(paidUser);
    if (!phoneCandidates.length) return;
    const [ownerUser] = await db.select().from(users).where(eq(users.email, RODRIGO_PAID_LEAD_OWNER_EMAIL)).limit(1);
    const ownerAdmin = await this.getAdminByEmail(RODRIGO_PAID_LEAD_OWNER_EMAIL);
    if (!ownerUser && !ownerAdmin) return;
    let crmConversation;
    let nativeWhatsappLabelResult = null;
    if (ownerUser) {
      const ownerConnection = await this.getUserActiveConnection(ownerUser.id);
      if (ownerConnection?.id) {
        const [conversation] = await db.select().from(conversations).where(
          and(
            eq(conversations.connectionId, ownerConnection.id),
            inArray(conversations.contactNumber, phoneCandidates)
          )
        ).orderBy(desc(conversations.lastMessageTime), desc(conversations.updatedAt)).limit(1);
        crmConversation = conversation;
        const paidTag = await this.getRodrigoPaidTag(ownerUser.id);
        if (crmConversation && paidTag) {
          await this.addTagToConversation(crmConversation.id, paidTag.id);
          try {
            const { applyNativeWhatsappChatLabel } = await import("./whatsapp-ORIGKV64.js");
            nativeWhatsappLabelResult = await applyNativeWhatsappChatLabel({
              connectionId: crmConversation.connectionId,
              remoteJid: crmConversation.remoteJid,
              contactNumber: crmConversation.contactNumber,
              jidSuffix: crmConversation.jidSuffix,
              labelId: "agentezap_pago",
              labelName: "Pago",
              color: 2
            });
          } catch (error) {
            nativeWhatsappLabelResult = {
              applied: false,
              skipped: "native_label_import_failed",
              error: error instanceof Error ? error.message : String(error)
            };
          }
        }
      }
    }
    let adminConversationId = null;
    if (ownerAdmin?.id) {
      const [adminConversation] = await db.select().from(adminConversations).where(
        and(
          eq(adminConversations.adminId, ownerAdmin.id),
          inArray(adminConversations.contactNumber, phoneCandidates),
          adminConversationIsVisibleCondition()
        )
      ).orderBy(desc(adminConversations.lastMessageTime), desc(adminConversations.createdAt)).limit(1);
      if (adminConversation) {
        adminConversationId = adminConversation.id;
        await db.update(adminConversations).set({
          paymentStatus: "paid",
          followupForNonPayers: false,
          followupActive: false,
          nextFollowupAt: null,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq(adminConversations.id, adminConversation.id));
      }
    }
    if (!crmConversation && !adminConversationId) return;
    const metadata = subscription.metadata || {};
    const previousAttribution = metadata.rodrigoPaidLeadAttribution || {};
    const plan = await this.getPlan(subscription.planId).catch(() => void 0);
    const value = Number.parseFloat(String(plan?.valor || "0")) || 0;
    const whatsappAdsAttribution = this.pickBestWhatsappAdsAttribution(
      await this.getConversationWhatsappAdsAttribution(crmConversation?.id),
      await this.getAdminConversationWhatsappAdsAttribution(adminConversationId),
      previousAttribution.whatsappAdsAttribution
    );
    let metaCapiStatus = previousAttribution.metaCapiStatus || "not_attempted";
    let metaCapiEventId = previousAttribution.metaCapiEventId || null;
    let metaCapiError = previousAttribution.metaCapiError || null;
    if (previousAttribution.metaCapiStatus !== "sent") {
      try {
        const result = await sendMetaPaidWhatsappConversion({
          eventId: `subscription:${subscription.id}:paid`,
          phone: paidUser.phone,
          email: paidUser.email,
          name: paidUser.name,
          submittedAt: /* @__PURE__ */ new Date(),
          value,
          currency: "BRL",
          planName: plan?.nome || "Assinatura AgenteZap",
          subscriptionId: subscription.id,
          whatsappAdsAttribution
        });
        metaCapiEventId = result.eventId;
        if (result.sent) {
          metaCapiStatus = "sent";
          metaCapiError = null;
        } else {
          metaCapiStatus = "skipped";
          metaCapiError = "reason" in result ? result.reason : "Evento ignorado pela configuracao.";
        }
      } catch (error) {
        metaCapiStatus = "failed";
        metaCapiError = error instanceof Error ? error.message : "Falha desconhecida no envio Meta CAPI.";
      }
    }
    await db.update(subscriptions).set({
      metadata: {
        ...metadata,
        rodrigoPaidLeadAttribution: {
          ...previousAttribution,
          taggedAt: (/* @__PURE__ */ new Date()).toISOString(),
          ownerUserId: ownerUser?.id || null,
          adminId: ownerAdmin?.id || null,
          crmConversationId: crmConversation?.id || null,
          adminConversationId,
          whatsappAdsAttribution: whatsappAdsAttribution || previousAttribution.whatsappAdsAttribution || null,
          whatsappAdsAttributionCaptured: Boolean(whatsappAdsAttribution?.ctwaClid),
          nativeWhatsappLabelResult,
          metaCapiStatus,
          metaCapiEventId,
          metaCapiError
        }
      },
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(subscriptions.id, subscription.id));
  }
  // Payment operations
  async getPayment(id) {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment;
  }
  async getPaymentBySubscriptionId(subscriptionId) {
    const [payment] = await db.select().from(payments).where(eq(payments.subscriptionId, subscriptionId)).orderBy(desc(payments.createdAt)).limit(1);
    return payment;
  }
  async getPendingPayments() {
    const result = await db.select().from(payments).innerJoin(subscriptions, eq(payments.subscriptionId, subscriptions.id)).innerJoin(plans, eq(subscriptions.planId, plans.id)).innerJoin(users, eq(subscriptions.userId, users.id)).where(eq(payments.status, "pending")).orderBy(desc(payments.createdAt));
    return result.map((row) => ({
      ...row.payments,
      subscription: {
        ...row.subscriptions,
        user: row.users,
        plan: row.plans
      }
    }));
  }
  async createPayment(paymentData) {
    const [payment] = await db.insert(payments).values(paymentData).returning();
    return payment;
  }
  async updatePayment(id, data) {
    const [payment] = await db.update(payments).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(payments.id, id)).returning();
    return payment;
  }
  // Payment History operations (MercadoPago, etc)
  async createPaymentHistory(paymentData) {
    const [payment] = await db.insert(paymentHistory).values(paymentData).returning();
    return payment;
  }
  async getPaymentHistory(id) {
    const [payment] = await db.select().from(paymentHistory).where(eq(paymentHistory.id, id));
    return payment;
  }
  async getPaymentHistoryByMpPaymentId(mpPaymentId) {
    const [payment] = await db.select().from(paymentHistory).where(eq(paymentHistory.mpPaymentId, mpPaymentId));
    return payment;
  }
  async getPaymentHistoryBySubscription(subscriptionId) {
    return await db.select().from(paymentHistory).where(eq(paymentHistory.subscriptionId, subscriptionId)).orderBy(desc(paymentHistory.createdAt));
  }
  async getPaymentHistoryByUser(userId) {
    return await db.select().from(paymentHistory).where(eq(paymentHistory.userId, userId)).orderBy(desc(paymentHistory.createdAt));
  }
  async getAllPaymentHistory() {
    const result = await db.select().from(paymentHistory).leftJoin(subscriptions, eq(paymentHistory.subscriptionId, subscriptions.id)).leftJoin(users, eq(paymentHistory.userId, users.id)).orderBy(desc(paymentHistory.createdAt));
    return result.map((row) => ({
      ...row.payment_history,
      subscription: row.subscriptions || void 0,
      user: row.users || void 0
    }));
  }
  async updatePaymentHistory(id, data) {
    const [payment] = await db.update(paymentHistory).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(paymentHistory.id, id)).returning();
    return payment;
  }
  // System config operations
  async getSystemConfig(key) {
    const [config] = await db.select().from(systemConfig).where(eq(systemConfig.chave, key));
    return config;
  }
  async getSystemConfigs(keys) {
    const configs = await db.select().from(systemConfig).where(inArray(systemConfig.chave, keys));
    const result = /* @__PURE__ */ new Map();
    for (const config of configs) {
      if (config.valor !== null) {
        result.set(config.chave, config.valor);
      }
    }
    return result;
  }
  async updateSystemConfig(key, value) {
    const [config] = await db.insert(systemConfig).values({ chave: key, valor: value }).onConflictDoUpdate({
      target: systemConfig.chave,
      set: { valor: value, updatedAt: /* @__PURE__ */ new Date() }
    }).returning();
    return config;
  }
  // Admin operations
  async getAdminById(id) {
    const [admin] = await db.select().from(admins).where(eq(admins.id, id)).limit(1);
    return admin;
  }
  async getAdminByEmail(email) {
    const [admin] = await db.select().from(admins).where(eq(admins.email, email));
    return admin;
  }
  async getAllAdmins() {
    return await withRetry(() => db.select().from(admins));
  }
  // Admin WhatsApp connection operations
  async getAdminWhatsappConnection(adminId) {
    const [connection] = await db.select().from(adminWhatsappConnection).where(eq(adminWhatsappConnection.adminId, adminId));
    return sanitizeAdminWhatsappConnection(connection);
  }
  async createAdminWhatsappConnection(connection) {
    const [created] = await db.insert(adminWhatsappConnection).values(sanitizeAdminWhatsappConnection(connection)).returning();
    return sanitizeAdminWhatsappConnection(created);
  }
  async updateAdminWhatsappConnection(adminId, data) {
    const [updated] = await db.update(adminWhatsappConnection).set({
      ...sanitizeAdminWhatsappConnection(data),
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminWhatsappConnection.adminId, adminId)).returning();
    return sanitizeAdminWhatsappConnection(updated);
  }
  // Admin stats
  async getAllUsers() {
    return await withRetry(() => db.select().from(users).orderBy(desc(users.createdAt)));
  }
  async getTotalRevenue() {
    const historyResult = await db.select({ total: sql`COALESCE(SUM(CAST(${paymentHistory.amount} AS NUMERIC)), 0)` }).from(paymentHistory).where(eq(paymentHistory.status, "approved"));
    const historyTotal = Number(historyResult[0]?.total || 0);
    if (historyTotal > 0) {
      return historyTotal;
    }
    const legacyResult = await db.select({ total: sql`COALESCE(SUM(CAST(${payments.valor} AS NUMERIC)), 0)` }).from(payments).where(eq(payments.status, "paid"));
    return Number(legacyResult[0]?.total || 0);
  }
  // 🔥 OTIMIZADO: Usar COUNT(*) em vez de trazer todas as linhas
  async getActiveSubscriptionsCount() {
    const result = await db.select({ count: sql`count(*)::int` }).from(subscriptions).where(eq(subscriptions.status, "active"));
    return result[0]?.count || 0;
  }
  async getAdminBusinessDashboardReport() {
    const [allUsers, allConnections, allSubscriptions, allPaymentHistory, pendingReceiptCount, activePlansCount] = await withRetry(
      () => Promise.all([
        this.getAllUsers(),
        this.getAllConnections(),
        this.getAllSubscriptions(),
        this.getAllPaymentHistory(),
        db.select({ count: sql`count(*)::int` }).from(paymentReceipts).where(eq(paymentReceipts.status, "pending")).then((result) => result[0]?.count || 0),
        db.select({ count: sql`count(*)::int` }).from(plans).where(eq(plans.ativo, true)).then((result) => result[0]?.count || 0)
      ])
    );
    return buildAdminBusinessDashboardReport({
      users: allUsers,
      connections: allConnections,
      subscriptions: allSubscriptions,
      paymentHistory: allPaymentHistory,
      pendingReceiptsCount: pendingReceiptCount,
      activePlansCount
    });
  }
  // ======================================================================
  // WhatsApp Contacts Operations (FIX LID 2025)
  // Persistent storage for @lid → phoneNumber mappings
  // ======================================================================
  /**
   * Upsert (Insert or Update) a WhatsApp contact
   * Uses ON CONFLICT to avoid duplicates and update existing records
   */
  async upsertContact(contact) {
    const [upserted] = await db.insert(whatsappContacts).values({
      ...contact,
      lastSyncedAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    }).onConflictDoUpdate({
      target: [whatsappContacts.connectionId, whatsappContacts.contactId],
      set: {
        lid: contact.lid,
        phoneNumber: contact.phoneNumber,
        name: contact.name,
        imgUrl: contact.imgUrl,
        lastSyncedAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    console.log(`[DB] Upserted contact: ${contact.contactId}${contact.phoneNumber ? ` (phoneNumber: ${contact.phoneNumber})` : ""}`);
    return upserted;
  }
  /**
   * Batch upsert multiple contacts at once (more efficient than individual inserts)
   * Used during initial sync when Baileys emits many contacts.upsert events
   */
  async batchUpsertContacts(contacts) {
    if (contacts.length === 0) return;
    const now = /* @__PURE__ */ new Date();
    const contactsWithTimestamps = contacts.map((c) => ({
      ...c,
      lastSyncedAt: now,
      updatedAt: now
    }));
    const CHUNK_SIZE = 200;
    for (let i = 0; i < contactsWithTimestamps.length; i += CHUNK_SIZE) {
      const chunk = contactsWithTimestamps.slice(i, i + CHUNK_SIZE);
      await db.insert(whatsappContacts).values(chunk).onConflictDoUpdate({
        target: [whatsappContacts.connectionId, whatsappContacts.contactId],
        set: {
          lid: sql`EXCLUDED.lid`,
          phoneNumber: sql`EXCLUDED.phone_number`,
          name: sql`EXCLUDED.name`,
          imgUrl: sql`EXCLUDED.img_url`,
          lastSyncedAt: now,
          updatedAt: now
        }
      });
    }
    console.log(`[DB] Batch upserted ${contacts.length} contacts`);
  }
  /**
   * Get contact by LID (primary use case for @lid resolution)
   * Query: SELECT * FROM whatsapp_contacts WHERE lid = ? AND connection_id = ?
   */
  async getContactByLid(lid, connectionId) {
    const [contact] = await db.select().from(whatsappContacts).where(and(
      eq(whatsappContacts.lid, lid),
      eq(whatsappContacts.connectionId, connectionId)
    )).limit(1);
    if (contact) {
      console.log(`[DB] Contact found by LID: ${lid} \u2192 ${contact.phoneNumber || "no phone"}`);
    }
    return contact;
  }
  /**
   * Get contact by contactId (general lookup)
   * Query: SELECT * FROM whatsapp_contacts WHERE contact_id = ? AND connection_id = ?
   */
  async getContactById(contactId, connectionId) {
    const [contact] = await db.select().from(whatsappContacts).where(and(
      eq(whatsappContacts.contactId, contactId),
      eq(whatsappContacts.connectionId, connectionId)
    )).limit(1);
    return contact;
  }
  /**
   * Get all contacts for a specific connection (cache warming)
   * Used when restoring session to pre-populate in-memory cache
   */
  async getContactsByConnectionId(connectionId) {
    const contacts = await db.select().from(whatsappContacts).where(eq(whatsappContacts.connectionId, connectionId)).orderBy(desc(whatsappContacts.lastSyncedAt));
    console.log(`[DB] Loaded ${contacts.length} contacts for connection ${connectionId}`);
    return contacts;
  }
  /**
   * Delete contacts from inactive connections (data retention policy)
   * Should be run periodically (e.g., daily cron job)
   * Query: DELETE FROM whatsapp_contacts WHERE connection_id IN (...)
   */
  async deleteOldContacts(daysOld = 90) {
    const cutoffDate = /* @__PURE__ */ new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);
    const inactiveConnections = await db.select({ id: whatsappConnections.id }).from(whatsappConnections).where(and(
      eq(whatsappConnections.isConnected, false),
      sql`${whatsappConnections.updatedAt} < ${cutoffDate}`
    ));
    if (inactiveConnections.length === 0) {
      console.log(`[DB] No inactive connections older than ${daysOld} days`);
      return 0;
    }
    const connectionIds = inactiveConnections.map((c) => c.id);
    const deleted = await db.delete(whatsappContacts).where(sql`${whatsappContacts.connectionId} = ANY(${connectionIds})`);
    console.log(`[DB] Deleted contacts from ${connectionIds.length} inactive connections (${daysOld}+ days old)`);
    return deleted.rowCount || 0;
  }
  // ==================== CAMPAIGN OPERATIONS (In-Memory) ====================
  async getCampaigns(userId) {
    return campaignsStore.get(userId) || [];
  }
  async getCampaign(userId, id) {
    const campaigns = campaignsStore.get(userId) || [];
    return campaigns.find((c) => c.id === id);
  }
  async createCampaign(campaign) {
    const userId = campaign.userId;
    const campaigns = campaignsStore.get(userId) || [];
    const newCampaign = {
      ...campaign,
      id: campaign.id || `campaign_${Date.now()}`,
      // ✅ Usar ID fornecido ou gerar novo
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    campaigns.push(newCampaign);
    campaignsStore.set(userId, campaigns);
    return newCampaign;
  }
  async updateCampaign(userId, id, data) {
    const campaigns = campaignsStore.get(userId) || [];
    const index = campaigns.findIndex((c) => c.id === id);
    if (index !== -1) {
      campaigns[index] = { ...campaigns[index], ...data, updatedAt: /* @__PURE__ */ new Date() };
      campaignsStore.set(userId, campaigns);
      return campaigns[index];
    }
    return null;
  }
  async deleteCampaign(userId, id) {
    const campaigns = campaignsStore.get(userId) || [];
    const filtered = campaigns.filter((c) => c.id !== id);
    campaignsStore.set(userId, filtered);
  }
  // ==================== CONTACT LIST OPERATIONS (Supabase/PostgreSQL) ====================
  async getContactLists(userId) {
    try {
      const result = await db.select().from(contactLists).where(eq(contactLists.userId, userId)).orderBy(desc(contactLists.createdAt));
      return result;
    } catch (error) {
      console.error("[CONTACT_LISTS] Error fetching lists:", error);
      return [];
    }
  }
  async getContactList(userId, id) {
    try {
      const [result] = await db.select().from(contactLists).where(and(
        eq(contactLists.userId, userId),
        eq(contactLists.id, id)
      )).limit(1);
      return result;
    } catch (error) {
      console.error("[CONTACT_LISTS] Error fetching list:", error);
      return void 0;
    }
  }
  async createContactList(list) {
    try {
      const contactsArray = list.contacts || [];
      const [result] = await db.insert(contactLists).values({
        userId: list.userId,
        name: list.name,
        description: list.description || null,
        contacts: contactsArray,
        contactCount: contactsArray.length
      }).returning();
      return result;
    } catch (error) {
      console.error("[CONTACT_LISTS] Error creating list:", error);
      throw error;
    }
  }
  async updateContactList(userId, id, data) {
    try {
      const updateData = {
        updatedAt: /* @__PURE__ */ new Date()
      };
      if (data.name !== void 0) updateData.name = data.name;
      if (data.description !== void 0) updateData.description = data.description;
      if (data.contacts !== void 0) {
        updateData.contacts = data.contacts;
        updateData.contactCount = data.contacts.length;
      }
      const [result] = await db.update(contactLists).set(updateData).where(and(
        eq(contactLists.userId, userId),
        eq(contactLists.id, id)
      )).returning();
      return result;
    } catch (error) {
      console.error("[CONTACT_LISTS] Error updating list:", error);
      return null;
    }
  }
  async deleteContactList(userId, id) {
    try {
      await db.delete(contactLists).where(and(
        eq(contactLists.userId, userId),
        eq(contactLists.id, id)
      ));
    } catch (error) {
      console.error("[CONTACT_LISTS] Error deleting list:", error);
    }
  }
  async addContactsToList(userId, listId, contacts) {
    try {
      const [list] = await db.select().from(contactLists).where(and(
        eq(contactLists.userId, userId),
        eq(contactLists.id, listId)
      )).limit(1);
      if (!list) {
        return { success: false, message: "Lista n\xE3o encontrada" };
      }
      const existingContacts = list.contacts || [];
      const existingPhones = new Set(existingContacts.map((c) => c.phone));
      const newContacts = contacts.filter((c) => !existingPhones.has(c.phone));
      const mergedContacts = [...existingContacts, ...newContacts];
      const [result] = await db.update(contactLists).set({
        contacts: mergedContacts,
        contactCount: mergedContacts.length,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq(contactLists.id, listId)).returning();
      return {
        success: true,
        totalContacts: mergedContacts.length,
        addedCount: newContacts.length
      };
    } catch (error) {
      console.error("[CONTACT_LISTS] Error adding contacts:", error);
      return { success: false };
    }
  }
  async removeContactFromList(userId, listId, phone) {
    try {
      const [list] = await db.select().from(contactLists).where(and(
        eq(contactLists.userId, userId),
        eq(contactLists.id, listId)
      )).limit(1);
      if (!list) {
        return { success: false, message: "Lista n\xE3o encontrada" };
      }
      const existingContacts = list.contacts || [];
      const filteredContacts = existingContacts.filter((c) => c.phone !== phone);
      const [result] = await db.update(contactLists).set({
        contacts: filteredContacts,
        contactCount: filteredContacts.length,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq(contactLists.id, listId)).returning();
      return { success: true, totalContacts: filteredContacts.length };
    } catch (error) {
      console.error("[CONTACT_LISTS] Error removing contact:", error);
      return { success: false };
    }
  }
  async getSyncedContacts(userId) {
    return syncedContactsStore.get(userId) || [];
  }
  async saveSyncedContacts(userId, contacts) {
    const existing = syncedContactsStore.get(userId) || [];
    const merged = [...existing];
    for (const contact of contacts) {
      const existingIndex = merged.findIndex((c) => c.phone === contact.phone);
      if (existingIndex === -1) {
        merged.push(contact);
      } else {
        merged[existingIndex] = { ...merged[existingIndex], ...contact };
      }
    }
    syncedContactsStore.set(userId, merged);
  }
  async getUserActiveConnection(userId) {
    const [connection] = await db.select().from(whatsappConnections).where(and(
      eq(whatsappConnections.userId, userId),
      eq(whatsappConnections.isConnected, true)
    )).orderBy(desc(whatsappConnections.createdAt)).limit(1);
    return connection;
  }
  // ========================================================================
  // ADMIN CONVERSATIONS - Conversas do WhatsApp do admin com clientes
  // ========================================================================
  async getAdminConversations(adminId) {
    const result = await db.select().from(adminConversations).where(and(
      eq(adminConversations.adminId, adminId),
      adminConversationIsVisibleCondition()
    )).orderBy(desc(adminConversations.lastMessageTime));
    return result;
  }
  async getAdminConversation(id) {
    const [result] = await db.select().from(adminConversations).where(and(
      eq(adminConversations.id, id),
      adminConversationIsVisibleCondition()
    ));
    return result;
  }
  // Busca conversa do admin pelo número de telefone (sistema single-admin)
  async getAdminConversationByPhone(contactNumber) {
    const [result] = await db.select().from(adminConversations).where(and(
      eq(adminConversations.contactNumber, contactNumber),
      adminConversationIsVisibleCondition()
    )).orderBy(desc(adminConversations.lastMessageTime), desc(adminConversations.createdAt));
    return result;
  }
  async getAdminConversationByContact(adminId, contactNumber) {
    const [result] = await db.select().from(adminConversations).where(and(
      eq(adminConversations.adminId, adminId),
      eq(adminConversations.contactNumber, contactNumber),
      adminConversationIsVisibleCondition()
    )).orderBy(desc(adminConversations.lastMessageTime), desc(adminConversations.createdAt));
    return result;
  }
  async createAdminConversation(data) {
    const globalFollowupConfig = normalizeAdminFollowupConfig(await getAdminFollowupGlobalConfig());
    const [result] = await db.insert(adminConversations).values({
      adminId: data.adminId,
      contactNumber: data.contactNumber,
      remoteJid: data.remoteJid,
      contactName: data.contactName,
      contactAvatar: data.contactAvatar,
      isAgentEnabled: data.isAgentEnabled ?? true,
      unreadCount: 0,
      followupActive: false,
      followupStage: 0,
      nextFollowupAt: null,
      followupConfig: globalFollowupConfig
    }).returning();
    return result;
  }
  async updateAdminConversation(id, data) {
    const [result] = await db.update(adminConversations).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(adminConversations.id, id)).returning();
    return result;
  }
  async getOrCreateAdminConversation(adminId, contactNumber, remoteJid, contactName, contactAvatar) {
    let conversation = await this.getAdminConversationByContact(adminId, contactNumber);
    if (!conversation) {
      conversation = await this.createAdminConversation({
        adminId,
        contactNumber,
        remoteJid,
        contactName,
        contactAvatar
      });
    } else if (contactName || contactAvatar || isLegacyAdminFollowupConfig(conversation.followupConfig)) {
      const updates = {};
      if (contactName && conversation.contactName !== contactName) updates.contactName = contactName;
      if (contactAvatar && conversation.contactAvatar !== contactAvatar) updates.contactAvatar = contactAvatar;
      if (isLegacyAdminFollowupConfig(conversation.followupConfig)) {
        updates.followupConfig = normalizeAdminFollowupConfig(await getAdminFollowupGlobalConfig());
      }
      if (Object.keys(updates).length > 0) {
        conversation = await this.updateAdminConversation(conversation.id, updates);
      }
    }
    return conversation;
  }
  // Admin Messages
  async getAdminMessages(conversationId) {
    const result = await db.select().from(adminMessages).where(eq(adminMessages.conversationId, conversationId)).orderBy(adminMessages.timestamp);
    return result;
  }
  async getAdminMessageByMessageId(messageId) {
    const [result] = await db.select().from(adminMessages).where(eq(adminMessages.messageId, messageId)).limit(1);
    return result;
  }
  async getLastAdminMessageByConversationId(conversationId) {
    const [result] = await db.select({
      id: adminMessages.id,
      fromMe: adminMessages.fromMe,
      text: adminMessages.text,
      timestamp: adminMessages.timestamp
    }).from(adminMessages).where(eq(adminMessages.conversationId, conversationId)).orderBy(desc(adminMessages.timestamp), desc(adminMessages.id)).limit(1);
    return result;
  }
  async createAdminMessage(data) {
    const messageData = { ...data };
    if (messageData.mediaType === "audio" && messageData.mediaUrl) {
      try {
        let audioBuffer = null;
        const origem = messageData.fromMe ? "dono" : "cliente";
        if (messageData.mediaUrl.startsWith("data:")) {
          const base64Part = messageData.mediaUrl.split(",")[1];
          if (base64Part) {
            audioBuffer = Buffer.from(base64Part, "base64");
            console.log(`\u{1F3A4} [Storage Admin] \xC1udio base64 do ${origem}: ${audioBuffer.length} bytes`);
          }
        } else if (messageData.mediaUrl.startsWith("http://") || messageData.mediaUrl.startsWith("https://")) {
          console.log(`\u{1F3A4} [Storage Admin] Baixando \xE1udio do ${origem} de URL externa...`);
          try {
            const audioResponse = await fetch(messageData.mediaUrl);
            if (audioResponse.ok) {
              const arrayBuffer = await audioResponse.arrayBuffer();
              audioBuffer = Buffer.from(arrayBuffer);
              console.log(`\u{1F3A4} [Storage Admin] \xC1udio do ${origem} baixado: ${audioBuffer.length} bytes`);
            } else {
              console.error(`\u{1F3A4} [Storage Admin] Erro ao baixar \xE1udio: HTTP ${audioResponse.status}`);
            }
          } catch (fetchError) {
            console.error(`\u{1F3A4} [Storage Admin] Erro ao fazer fetch do \xE1udio:`, fetchError);
          }
        }
        if (audioBuffer && audioBuffer.length > 0) {
          console.log(`\u{1F3A4} [Storage Admin] Transcrevendo \xE1udio do ${origem} (${audioBuffer.length} bytes)...`);
          const transcription = await transcribeAudioWithMistral(audioBuffer, {
            fileName: `whatsapp-audio-${origem}.ogg`
          });
          if (transcription && transcription.length > 0) {
            console.log(`\u{1F3A4} [Storage Admin] \u2705 Transcri\xE7\xE3o do ${origem}: ${transcription.substring(0, 100)}...`);
            messageData.text = transcription;
          } else {
            console.log(`\u{1F3A4} [Storage Admin] \u26A0\uFE0F Transcri\xE7\xE3o vazia para \xE1udio do ${origem}`);
          }
        } else {
          console.log(`\u{1F3A4} [Storage Admin] \u26A0\uFE0F N\xE3o foi poss\xEDvel obter buffer do \xE1udio do ${origem}`);
        }
      } catch (error) {
        console.error("[Storage Admin] Erro ao transcrever \xE1udio:", error);
      }
    }
    if (messageData.mediaType === "image" && messageData.mediaUrl) {
      try {
        let imageUrl = messageData.mediaUrl;
        if (imageUrl.startsWith("data:")) {
          console.log(`\u{1F5BC}\uFE0F [Storage Admin] Imagem base64 detectada, enviando direto para an\xE1lise...`);
        } else if (imageUrl.startsWith("http://") || imageUrl.startsWith("https://")) {
          console.log(`\u{1F5BC}\uFE0F [Storage Admin] Imagem URL detectada: ${imageUrl.substring(0, 80)}...`);
        } else {
          console.log(`\u{1F5BC}\uFE0F [Storage Admin] Formato de imagem n\xE3o reconhecido, pulando an\xE1lise`);
          imageUrl = "";
        }
        if (imageUrl) {
          console.log(`\u{1F5BC}\uFE0F [Storage Admin] Iniciando an\xE1lise de imagem com Mistral Vision...`);
          const analysisPrompt = `Analise esta imagem e descreva em portugu\xEAs de forma clara e objetiva.

IMPORTANTE:
- Se for um COMPROVANTE DE PAGAMENTO: extraia valor, data, nome do pagador/recebedor, tipo (PIX, transfer\xEAncia, boleto)
- Se for um PRODUTO: descreva caracter\xEDsticas visuais, marca se vis\xEDvel
- Se for uma D\xDAVIDA/PERGUNTA: descreva o que a pessoa parece querer saber
- Se for DOCUMENTO: identifique o tipo e informa\xE7\xF5es relevantes

Responda de forma concisa (m\xE1ximo 3 frases) descrevendo o que voc\xEA v\xEA.`;
          const imageDescription = await analyzeImageWithMistral(imageUrl, analysisPrompt);
          if (imageDescription && imageDescription.length > 0) {
            console.log(`\u{1F5BC}\uFE0F [Storage Admin] \u2705 An\xE1lise de imagem bem-sucedida: "${imageDescription.substring(0, 100)}..."`);
            messageData.text = `[IMAGEM ANALISADA: ${imageDescription}]`;
          } else {
            console.log(`\u{1F5BC}\uFE0F [Storage Admin] \u26A0\uFE0F An\xE1lise de imagem vazia ou nula`);
            messageData.text = messageData.text || "(imagem enviada pelo cliente)";
          }
        }
      } catch (error) {
        console.error("[Storage Admin] Erro ao analisar imagem:", error);
        messageData.text = messageData.text || "(imagem enviada pelo cliente)";
      }
    }
    const [result] = await db.insert(adminMessages).values({
      conversationId: messageData.conversationId,
      messageId: messageData.messageId,
      fromMe: messageData.fromMe,
      text: messageData.text,
      timestamp: messageData.timestamp,
      status: messageData.status,
      isFromAgent: messageData.isFromAgent ?? false,
      mediaType: messageData.mediaType,
      mediaUrl: messageData.mediaUrl,
      mediaMimeType: messageData.mediaMimeType,
      mediaCaption: messageData.mediaCaption
    }).returning();
    return result;
  }
  async updateAdminMessage(id, data) {
    const [result] = await db.update(adminMessages).set(data).where(eq(adminMessages.id, id)).returning();
    return result;
  }
  async toggleAdminConversationAgent(conversationId, enabled, options) {
    const current = await this.getAdminConversation(conversationId);
    const nextContextState = {
      ...current?.contextState || {}
    };
    if (options?.manual === true) {
      nextContextState.manualAgentPause = !enabled;
      nextContextState.manualAgentPauseUpdatedAt = (/* @__PURE__ */ new Date()).toISOString();
    } else if (enabled && nextContextState.manualAgentPause !== true) {
      delete nextContextState.manualAgentPause;
      delete nextContextState.manualAgentPauseUpdatedAt;
    }
    const [result] = await db.update(adminConversations).set({
      isAgentEnabled: enabled,
      contextState: nextContextState,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminConversations.id, conversationId)).returning();
    return result;
  }
  async toggleAdminConversationFollowup(conversationId, active, options) {
    const current = await this.getAdminConversation(conversationId);
    if (!current) return void 0;
    const nextContextState = {
      ...current?.contextState || {}
    };
    if (options?.manual === true) {
      nextContextState.manualFollowupPause = !active;
      nextContextState.manualFollowupPauseUpdatedAt = (/* @__PURE__ */ new Date()).toISOString();
    } else if (active && !isAdminConversationFollowupManuallyPaused(current)) {
      delete nextContextState.manualFollowupPause;
      delete nextContextState.manualFollowupPauseUpdatedAt;
    }
    const [result] = await db.update(adminConversations).set({
      followupActive: active,
      nextFollowupAt: null,
      followupStage: active && options?.resetToStageZero !== false ? 0 : current.followupStage,
      // Follow-up e IA ao vivo precisam permanecer independentes.
      isAgentEnabled: current.isAgentEnabled,
      contextState: nextContextState,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminConversations.id, conversationId)).returning();
    return result;
  }
  async clearAdminConversationMessages(conversationId) {
    const result = await db.delete(adminMessages).where(eq(adminMessages.conversationId, conversationId));
    await db.update(adminConversations).set({
      lastMessageText: null,
      lastMessageTime: null,
      unreadCount: 0,
      isAgentEnabled: true,
      followupActive: true,
      followupStage: 0,
      nextFollowupAt: null,
      paymentStatus: "pending",
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminConversations.id, conversationId));
    console.log(`\u{1F5D1}\uFE0F [STORAGE] Mensagens da conversa ${conversationId} limpas`);
    return result.rowCount || 0;
  }
  async isAdminAgentEnabledForConversation(conversationId) {
    const [conversation] = await db.select({ isAgentEnabled: adminConversations.isAgentEnabled }).from(adminConversations).where(eq(adminConversations.id, conversationId));
    return conversation?.isAgentEnabled ?? true;
  }
  // =============================================================================
  // ADMIN AGENT MEDIA - Persistência de mídias do admin agent
  // =============================================================================
  async getAllAdminMedia(adminId) {
    return await db.select().from(adminAgentMedia).where(eq(adminAgentMedia.adminId, adminId)).orderBy(desc(adminAgentMedia.displayOrder), desc(adminAgentMedia.createdAt));
  }
  async getActiveAdminMedia(adminId) {
    return await db.select().from(adminAgentMedia).where(eq(adminAgentMedia.isActive, true)).orderBy(desc(adminAgentMedia.displayOrder), desc(adminAgentMedia.createdAt));
  }
  async getAdminMediaById(id) {
    const [result] = await db.select().from(adminAgentMedia).where(eq(adminAgentMedia.id, id));
    return result;
  }
  async getAdminMediaByName(adminId, name) {
    const normalizedName = name.toUpperCase().replace(/\s+/g, "_");
    const [result] = await db.select().from(adminAgentMedia).where(and(
      eq(adminAgentMedia.name, normalizedName),
      eq(adminAgentMedia.isActive, true)
    ));
    return result;
  }
  async createAdminMedia(mediaData) {
    const [result] = await db.insert(adminAgentMedia).values({
      ...mediaData,
      name: mediaData.name.toUpperCase().replace(/\s+/g, "_")
      // Normalizar nome
    }).returning();
    return result;
  }
  async updateAdminMedia(id, mediaData) {
    const [result] = await db.update(adminAgentMedia).set({
      ...mediaData,
      name: mediaData.name ? mediaData.name.toUpperCase().replace(/\s+/g, "_") : void 0,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminAgentMedia.id, id)).returning();
    return result;
  }
  async deleteAdminMedia(id) {
    const result = await db.delete(adminAgentMedia).where(eq(adminAgentMedia.id, id));
    return result.rowCount > 0;
  }
  async toggleAdminMediaActive(id, isActive) {
    const [result] = await db.update(adminAgentMedia).set({ isActive, updatedAt: /* @__PURE__ */ new Date() }).where(eq(adminAgentMedia.id, id)).returning();
    return result;
  }
  // =============================================================================
  // MEDIA FLOWS - Sequencia de midias por agente
  // =============================================================================
  async getMediaFlows() {
    return await db.select().from(mediaFlows).orderBy(desc(mediaFlows.createdAt));
  }
  async getMediaFlow(id) {
    const [result] = await db.select().from(mediaFlows).where(eq(mediaFlows.id, id));
    return result;
  }
  async createMediaFlow(data) {
    const [result] = await db.insert(mediaFlows).values(data).returning();
    return result;
  }
  async updateMediaFlow(id, data) {
    const [result] = await db.update(mediaFlows).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(mediaFlows.id, id)).returning();
    return result;
  }
  async deleteMediaFlow(id) {
    await db.delete(mediaFlows).where(eq(mediaFlows.id, id));
  }
  async getMediaFlowItems(flowId) {
    return await db.select().from(mediaFlowItems).where(eq(mediaFlowItems.flowId, flowId)).orderBy(asc(mediaFlowItems.displayOrder), asc(mediaFlowItems.createdAt));
  }
  async createMediaFlowItem(data) {
    const [result] = await db.insert(mediaFlowItems).values(data).returning();
    return result;
  }
  async updateMediaFlowItem(id, data) {
    const [result] = await db.update(mediaFlowItems).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(mediaFlowItems.id, id)).returning();
    return result;
  }
  async deleteMediaFlowItem(id) {
    await db.delete(mediaFlowItems).where(eq(mediaFlowItems.id, id));
  }
  async reorderMediaFlowItems(flowId, orderedIds) {
    for (let index = 0; index < orderedIds.length; index++) {
      await db.update(mediaFlowItems).set({ displayOrder: index, updatedAt: /* @__PURE__ */ new Date() }).where(and(eq(mediaFlowItems.flowId, flowId), eq(mediaFlowItems.id, orderedIds[index])));
    }
  }
  /**
   * Reset completo de um cliente pelo número de telefone
   * Exclui: conversa admin, mensagens admin, sessão em memória, user (se existir)
   * Usado para testes - permite testar como cliente novo
   */
  async resetClientByPhone(phoneNumber) {
    const result = {
      conversationDeleted: false,
      messagesDeleted: 0,
      userDeleted: false,
      connectionDeleted: false,
      subscriptionDeleted: false,
      agentConfigDeleted: false,
      businessAgentConfigDeleted: false,
      mediaDeleted: 0
    };
    const normalizePhone = (value) => String(value || "").replace(/\D/g, "");
    const cleanPhone = normalizePhone(phoneNumber);
    const authEmails = new Set(
      [
        `${cleanPhone}@agentezap.online`,
        `${cleanPhone}@agentezap.com`,
        `${cleanPhone}@agentezap.temp`
      ].map((value) => value.toLowerCase()).filter(Boolean)
    );
    console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Iniciando reset para ${phoneNumber} -> ${cleanPhone}...`);
    try {
      const adminConv = await this.getAdminConversationByPhone(cleanPhone);
      if (adminConv) {
        const messagesResult = await db.delete(adminMessages).where(eq(adminMessages.conversationId, adminConv.id));
        result.messagesDeleted = messagesResult.rowCount || 0;
        console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] ${result.messagesDeleted} mensagens admin exclu\xEDdas`);
        await db.delete(adminConversations).where(eq(adminConversations.id, adminConv.id));
        result.conversationDeleted = true;
        console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Conversa admin exclu\xEDda`);
      }
      let [user] = await db.select().from(users).where(eq(users.phone, cleanPhone));
      if (!user) {
        const allUsers = await db.select().from(users);
        user = allUsers.find((candidate) => normalizePhone(candidate.phone) === cleanPhone);
      }
      if (user) {
        if (user.email) {
          authEmails.add(String(user.email).toLowerCase());
        }
        const agentResult = await db.delete(aiAgentConfig).where(eq(aiAgentConfig.userId, user.id));
        result.agentConfigDeleted = (agentResult.rowCount || 0) > 0;
        if (result.agentConfigDeleted) {
          console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Config do agente exclu\xEDda`);
        }
        const businessAgentResult = await db.delete(businessAgentConfigs).where(eq(businessAgentConfigs.userId, user.id));
        result.businessAgentConfigDeleted = (businessAgentResult.rowCount || 0) > 0;
        if (result.businessAgentConfigDeleted) {
          console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Config estruturada do agente exclu\xEDda`);
        }
        const mediaResult = await db.delete(agentMediaLibrary).where(eq(agentMediaLibrary.userId, user.id));
        result.mediaDeleted = mediaResult.rowCount || 0;
        if (result.mediaDeleted > 0) {
          console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] ${result.mediaDeleted} m\xEDdias do agente exclu\xEDdas`);
        }
        const [connection] = await db.select().from(whatsappConnections).where(eq(whatsappConnections.userId, user.id));
        if (connection) {
          const userConversations = await db.select().from(conversations).where(eq(conversations.connectionId, connection.id));
          for (const conv of userConversations) {
            await db.delete(messages).where(eq(messages.conversationId, conv.id));
          }
          await db.delete(conversations).where(eq(conversations.connectionId, connection.id));
          await db.delete(whatsappConnections).where(eq(whatsappConnections.id, connection.id));
          result.connectionDeleted = true;
          console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Conex\xE3o WhatsApp exclu\xEDda`);
        }
        const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.userId, user.id));
        if (subscription) {
          await db.delete(payments).where(eq(payments.subscriptionId, subscription.id));
          await db.delete(subscriptions).where(eq(subscriptions.id, subscription.id));
          result.subscriptionDeleted = true;
          console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Subscription exclu\xEDda`);
        }
        await db.execute(sql`delete from admin_notification_logs where user_id = ${user.id}`);
        await db.execute(sql`delete from audio_config where user_id = ${user.id}`);
        await db.execute(sql`delete from daily_usage where user_id = ${user.id}`);
        await db.execute(sql`delete from products_config where user_id = ${user.id}`);
        await db.execute(sql`delete from appointments where user_id = ${user.id}`);
        await db.execute(sql`delete from scheduling_exceptions where user_id = ${user.id}`);
        await db.execute(sql`delete from google_calendar_tokens where user_id = ${user.id}`);
        await db.execute(
          sql`delete from professional_services
              where professional_id in (select id from scheduling_professionals where user_id = ${user.id})
                 or service_id in (select id from scheduling_services where user_id = ${user.id})`
        );
        await db.execute(sql`delete from scheduling_professionals where user_id = ${user.id}`);
        await db.execute(sql`delete from scheduling_services where user_id = ${user.id}`);
        await db.execute(sql`delete from scheduling_config where user_id = ${user.id}`);
        await db.execute(
          sql`delete from order_items
              where order_id in (select id from delivery_orders where user_id = ${user.id})`
        );
        await db.execute(sql`delete from delivery_orders where user_id = ${user.id}`);
        await db.execute(sql`delete from delivery_carts where user_id = ${user.id}`);
        await db.execute(sql`delete from menu_items where user_id = ${user.id}`);
        await db.execute(sql`delete from menu_categories where user_id = ${user.id}`);
        await db.execute(sql`delete from scheduled_status where user_id = ${user.id}`);
        await db.execute(
          sql`delete from status_rotation_items
              where rotation_id in (select id from status_rotation where user_id = ${user.id})`
        );
        await db.execute(sql`delete from status_rotation where user_id = ${user.id}`);
        const structuredTables = ["salon_config", "delivery_config", "admin_test_tokens"];
        for (const tableName of structuredTables) {
          try {
            await db.execute(sql.raw(`delete from ${tableName} where user_id = '${user.id}'`));
          } catch (structuredCleanupError) {
            const message = String(structuredCleanupError?.message || "");
            if (!/does not exist/i.test(message) && !/relation .* does not exist/i.test(message)) {
              console.warn(`\u26A0\uFE0F [RESET CLIENT] Falha ao limpar ${tableName}: ${message}`);
            }
          }
        }
        const tagRows = await db.execute(sql`select id from tags where user_id = ${user.id}`);
        const tagIds = Array.from(
          new Set(
            (tagRows?.rows || []).map((row) => row?.id).filter((value) => typeof value === "string" && value.length > 0)
          )
        );
        if (tagIds.length > 0) {
          await db.execute(
            sql`delete from conversation_tags where tag_id in (${sql.join(
              tagIds.map((id) => sql`${id}`),
              sql`, `
            )})`
          );
        }
        await db.execute(sql`delete from tags where user_id = ${user.id}`);
        const teamMemberRows = await db.execute(sql`select id from team_members where owner_id = ${user.id}`);
        const teamMemberIds = Array.from(
          new Set(
            (teamMemberRows?.rows || []).map((row) => row?.id).filter((value) => typeof value === "string" && value.length > 0)
          )
        );
        if (teamMemberIds.length > 0) {
          await db.execute(
            sql`delete from connection_members where member_id in (${sql.join(
              teamMemberIds.map((id) => sql`${id}`),
              sql`, `
            )})`
          );
          await db.execute(
            sql`delete from routing_logs where assigned_to_member_id in (${sql.join(
              teamMemberIds.map((id) => sql`${id}`),
              sql`, `
            )})`
          );
          await db.execute(
            sql`delete from sector_members where member_id in (${sql.join(
              teamMemberIds.map((id) => sql`${id}`),
              sql`, `
            )})`
          );
          await db.execute(
            sql`delete from team_member_sessions where member_id in (${sql.join(
              teamMemberIds.map((id) => sql`${id}`),
              sql`, `
            )})`
          );
        }
        await db.execute(sql`delete from team_members where owner_id = ${user.id}`);
        await db.delete(users).where(eq(users.id, user.id));
        result.userDeleted = true;
        console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Usu\xE1rio exclu\xEDdo`);
      }
      if (authEmails.size > 0) {
        try {
          const attemptedAuthIds = /* @__PURE__ */ new Set();
          if (user?.id) {
            attemptedAuthIds.add(String(user.id));
            const { error: deleteByIdError } = await supabase.auth.admin.deleteUser(String(user.id));
            if (deleteByIdError) {
              console.warn(`\u26A0\uFE0F [RESET CLIENT] Falha ao excluir Auth por user.id ${user.id}: ${deleteByIdError.message}`);
            } else {
              console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Usu\xE1rio Auth exclu\xEDdo por user.id: ${user.id}`);
            }
          }
          const { data, error } = await supabase.auth.admin.listUsers();
          if (error) {
            console.warn(`\u26A0\uFE0F [RESET CLIENT] Falha ao listar usu\xE1rios no Auth: ${error.message}`);
          } else {
            const authUsers = Array.isArray(data?.users) ? data.users : [];
            for (const authUser of authUsers) {
              if (attemptedAuthIds.has(String(authUser?.id || ""))) continue;
              const authEmail = String(authUser?.email || "").toLowerCase();
              if (!authEmail || !authEmails.has(authEmail)) continue;
              const { error: deleteError } = await supabase.auth.admin.deleteUser(authUser.id);
              if (deleteError) {
                console.warn(`\u26A0\uFE0F [RESET CLIENT] Falha ao excluir Auth ${authEmail}: ${deleteError.message}`);
              } else {
                console.log(`\u{1F5D1}\uFE0F [RESET CLIENT] Usu\xE1rio Auth exclu\xEDdo: ${authEmail}`);
              }
            }
          }
        } catch (authCleanupError) {
          console.warn(`\u26A0\uFE0F [RESET CLIENT] Erro ao limpar Auth do Supabase:`, authCleanupError);
        }
      }
      console.log(`\u2705 [RESET CLIENT] Reset completo para ${phoneNumber}`, result);
      return result;
    } catch (error) {
      console.error(`\u274C [RESET CLIENT] Erro ao resetar cliente:`, error);
      throw error;
    }
  }
  /**
   * Reset SEGURO de conta de teste com validações rigorosas.
   * Em fluxos administrativos, pode receber forceAnyAccount para
   * remover qualquer conta vinculada ao telefone.
   */
  async resetTestAccountSafely(phoneNumber, options) {
    try {
      const normalizePhone = (value) => String(value || "").replace(/\D/g, "");
      const cleanPhone = normalizePhone(phoneNumber);
      const forceAnyAccount = options?.forceAnyAccount === true;
      console.log(
        `\u{1F50D} [SAFE RESET] Verificando seguranca para ${phoneNumber} -> ${cleanPhone}... modo=${forceAnyAccount ? "FORCED" : "SAFE"}`
      );
      let [user] = await db.select().from(users).where(eq(users.phone, cleanPhone));
      if (!user) {
        const allUsers = await db.select().from(users);
        user = allUsers.find((u) => normalizePhone(u.phone) === cleanPhone);
      }
      if (!user) {
        console.log(`\u26A0\uFE0F [SAFE RESET] Nenhum usuario encontrado para ${cleanPhone}`);
        const adminConv = await this.getAdminConversationByPhone(cleanPhone);
        if (adminConv) {
          await db.delete(adminMessages).where(eq(adminMessages.conversationId, adminConv.id));
          await db.delete(adminConversations).where(eq(adminConversations.id, adminConv.id));
        }
        return {
          success: true,
          result: { userDeleted: false, conversationDeleted: !!adminConv }
        };
      }
      if (!forceAnyAccount) {
        const userEmail = String(user.email || "").toLowerCase().trim();
        const managedEmails = /* @__PURE__ */ new Set([
          `${cleanPhone}@agentezap.online`,
          `${cleanPhone}@agentezap.com`,
          `${cleanPhone}@agentezap.temp`
        ]);
        if (!managedEmails.has(userEmail)) {
          return {
            success: false,
            error: `\u26D4 Conta nao elegivel para reset seguro. Email atual: ${user.email || "nao definido"}.`
          };
        }
      }
      const [connection] = await db.select().from(whatsappConnections).where(eq(whatsappConnections.userId, user.id));
      if (connection && connection.isConnected) {
        console.log(`\u26A0\uFE0F [SAFE RESET] Usu\xE1rio tem WhatsApp conectado. Desconectando for\xE7adamente para permitir reset...`);
        await db.update(whatsappConnections).set({ isConnected: false, qrCode: null }).where(eq(whatsappConnections.id, connection.id));
      }
      if (connection) {
        const [hasRealConversations] = await db.select({ count: sql`count(*)` }).from(conversations).where(eq(conversations.connectionId, connection.id));
        if (hasRealConversations && Number(hasRealConversations.count) > 0) {
          console.log(`\u26A0\uFE0F [SAFE RESET] Usu\xE1rio tem conversas reais (${hasRealConversations.count}). Apagando conversas para permitir reset...`);
          await db.delete(conversations).where(eq(conversations.connectionId, connection.id));
        }
      }
      const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.userId, user.id));
      if (!forceAnyAccount && subscription && subscription.status !== "trialing" && subscription.status !== "inactive") {
        return {
          success: false,
          error: `\u26D4 Usu\xE1rio tem assinatura ativa (${subscription.status})! N\xE3o pode deletar conta com pagamento ativo.`
        };
      }
      if (!forceAnyAccount && subscription) {
        const [hasPayments] = await db.select({ count: sql`count(*)` }).from(payments).where(eq(payments.subscriptionId, subscription.id));
        if (hasPayments && Number(hasPayments.count) > 0) {
          return {
            success: false,
            error: "\u26D4 Usu\xE1rio tem pagamentos registrados! N\xE3o pode deletar conta com hist\xF3rico financeiro."
          };
        }
      }
      const createdAtDate = user.createdAt ? new Date(user.createdAt) : /* @__PURE__ */ new Date();
      const accountAge = Date.now() - createdAtDate.getTime();
      const daysOld = accountAge / (1e3 * 60 * 60 * 24);
      if (!forceAnyAccount && daysOld > 30) {
        return {
          success: false,
          error: `\u26D4 Conta tem mais de 30 dias (${Math.floor(daysOld)} dias). Muito antiga para reset autom\xE1tico.`
        };
      }
      console.log(
        `\u2705 [SAFE RESET] ${forceAnyAccount ? "Reset forcado autorizado" : "Validacoes OK"} para ${cleanPhone}. Procedendo com reset...`
      );
      const result = await this.resetClientByPhone(cleanPhone);
      return {
        success: true,
        result
      };
    } catch (error) {
      console.error(`\u274C [SAFE RESET] Erro ao resetar:`, error);
      return {
        success: false,
        error: `Erro t\xE9cnico: ${error.message}`
      };
    }
  }
  // ==================== QUICK REPLIES / RESPOSTAS RÁPIDAS ====================
  async getQuickReplies(adminId) {
    const { adminQuickReplies } = await import("./schema-2CJPU7MX.js");
    return db.select().from(adminQuickReplies).where(eq(adminQuickReplies.adminId, adminId)).orderBy(adminQuickReplies.createdAt);
  }
  async getQuickReply(id) {
    const { adminQuickReplies } = await import("./schema-2CJPU7MX.js");
    const [reply] = await db.select().from(adminQuickReplies).where(eq(adminQuickReplies.id, id));
    return reply;
  }
  async createQuickReply(data) {
    const { adminQuickReplies } = await import("./schema-2CJPU7MX.js");
    const [reply] = await db.insert(adminQuickReplies).values(data).returning();
    return reply;
  }
  async updateQuickReply(id, data) {
    const { adminQuickReplies } = await import("./schema-2CJPU7MX.js");
    const [reply] = await db.update(adminQuickReplies).set(data).where(eq(adminQuickReplies.id, id)).returning();
    return reply;
  }
  async deleteQuickReply(id) {
    const { adminQuickReplies } = await import("./schema-2CJPU7MX.js");
    await db.delete(adminQuickReplies).where(eq(adminQuickReplies.id, id));
  }
  async incrementQuickReplyUsage(id) {
    const { adminQuickReplies } = await import("./schema-2CJPU7MX.js");
    await db.update(adminQuickReplies).set({
      usageCount: sql`${adminQuickReplies.usageCount} + 1`,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminQuickReplies.id, id));
  }
  // ==================== USER QUICK REPLIES / RESPOSTAS RÁPIDAS USUÁRIOS ====================
  async getUserQuickReplies(userId) {
    const { userQuickReplies } = await import("./schema-2CJPU7MX.js");
    return db.select().from(userQuickReplies).where(eq(userQuickReplies.userId, userId)).orderBy(userQuickReplies.createdAt);
  }
  async getUserQuickReply(id) {
    const { userQuickReplies } = await import("./schema-2CJPU7MX.js");
    const [reply] = await db.select().from(userQuickReplies).where(eq(userQuickReplies.id, id));
    return reply;
  }
  async createUserQuickReply(data) {
    const { userQuickReplies } = await import("./schema-2CJPU7MX.js");
    const [reply] = await db.insert(userQuickReplies).values(data).returning();
    return reply;
  }
  async updateUserQuickReply(id, data) {
    const { userQuickReplies } = await import("./schema-2CJPU7MX.js");
    const [reply] = await db.update(userQuickReplies).set(data).where(eq(userQuickReplies.id, id)).returning();
    return reply;
  }
  async deleteUserQuickReply(id) {
    const { userQuickReplies } = await import("./schema-2CJPU7MX.js");
    await db.delete(userQuickReplies).where(eq(userQuickReplies.id, id));
  }
  async incrementUserQuickReplyUsage(id) {
    const { userQuickReplies } = await import("./schema-2CJPU7MX.js");
    await db.update(userQuickReplies).set({
      usageCount: sql`${userQuickReplies.usageCount} + 1`,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(userQuickReplies.id, id));
  }
  // ==================== EXCLUSION LIST / LISTA DE EXCLUSÃO ====================
  /**
   * Normaliza um número de telefone brasileiro para comparação
   * Retorna array com todas as variações possíveis do número
   * Ex: 5517991956944 -> ['5517991956944', '17991956944', '991956944']
   */
  normalizePhoneForComparison(phoneNumber) {
    const variations = normalizePhoneForComparison(phoneNumber);
    console.log(`\u{1F4DE} [EXCLUSION] Normalizando n\xFAmero ${phoneNumber} -> chaves: [${variations.join(", ")}]`);
    return variations;
  }
  /**
   * Verifica se um número está na lista de exclusão de um usuário
   * @param userId ID do usuário
   * @param phoneNumber Número de telefone (apenas dígitos)
   * @returns true se o número está excluído e ativo
   */
  async isNumberExcluded(userId, phoneNumber) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    const config = await this.getExclusionConfig(userId);
    if (config && config.isEnabled === false) {
      console.log(`\u{1F6AB} [EXCLUSION] Lista de exclus\xE3o DESATIVADA explicitamente para usu\xE1rio ${userId}`);
      return false;
    }
    console.log(`\u{1F50D} [EXCLUSION] Verificando lista de exclus\xE3o para usu\xE1rio ${userId} (config=${config ? "exists" : "default"}, isEnabled=${config?.isEnabled ?? "default=true"})`);
    const numberVariations = this.normalizePhoneForComparison(phoneNumber);
    const items = await db.select().from(exclusionList).where(
      and(
        eq(exclusionList.userId, userId),
        eq(exclusionList.isActive, true)
      )
    );
    const isExcluded = items.some((item) => phoneNumbersMatch(item.phoneNumber, phoneNumber));
    console.log(`\u{1F4DE} [EXCLUSION] Verificando ${phoneNumber} (varia\xE7\xF5es: ${numberVariations.join(", ")}) -> ${isExcluded ? "\u{1F6AB} EXCLU\xCDDO" : "\u2705 Permitido"}`);
    return isExcluded;
  }
  /**
   * Verifica se um número está excluído de follow-up
   * @param userId ID do usuário
   * @param phoneNumber Número de telefone (apenas dígitos)
   * @returns true se o número está excluído de follow-up
   */
  async isNumberExcludedFromFollowup(userId, phoneNumber) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    const config = await this.getExclusionConfig(userId);
    if (config && config.isEnabled === false) {
      console.log(`\u{1F6AB} [EXCLUSION] Lista de exclus\xE3o DESATIVADA explicitamente para usu\xE1rio ${userId}`);
      return false;
    }
    if (config && config.followupExclusionEnabled === false) {
      console.log(`\u{1F6AB} [EXCLUSION] Exclus\xE3o de follow-up DESATIVADA explicitamente para usu\xE1rio ${userId}`);
      return false;
    }
    console.log(`\u{1F50D} [EXCLUSION-FOLLOWUP] Verificando lista de exclus\xE3o para usu\xE1rio ${userId} (config=${config ? "exists" : "default"}, isEnabled=${config?.isEnabled ?? "default=true"}, followupExclusionEnabled=${config?.followupExclusionEnabled ?? "default=true"})`);
    const numberVariations = this.normalizePhoneForComparison(phoneNumber);
    const items = await db.select().from(exclusionList).where(
      and(
        eq(exclusionList.userId, userId),
        eq(exclusionList.isActive, true),
        eq(exclusionList.excludeFromFollowup, true)
      )
    );
    const isExcluded = items.some((item) => phoneNumbersMatch(item.phoneNumber, phoneNumber));
    console.log(`\u{1F4DE} [EXCLUSION-FOLLOWUP] Verificando ${phoneNumber} -> ${isExcluded ? "\u{1F6AB} EXCLU\xCDDO DE FOLLOW-UP" : "\u2705 Follow-up permitido"}`);
    return isExcluded;
  }
  /**
   * Obtém configuração de exclusão do usuário
   */
  async getExclusionConfig(userId) {
    const { exclusionConfig } = await import("./schema-2CJPU7MX.js");
    const [config] = await db.select().from(exclusionConfig).where(eq(exclusionConfig.userId, userId));
    return config;
  }
  /**
   * Cria ou atualiza configuração de exclusão do usuário
   */
  async upsertExclusionConfig(userId, data) {
    const { exclusionConfig } = await import("./schema-2CJPU7MX.js");
    const existing = await this.getExclusionConfig(userId);
    if (existing) {
      const [config] = await db.update(exclusionConfig).set({
        ...data,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq(exclusionConfig.userId, userId)).returning();
      return config;
    } else {
      const [config] = await db.insert(exclusionConfig).values({
        userId,
        isEnabled: data.isEnabled ?? true,
        followupExclusionEnabled: data.followupExclusionEnabled ?? true
      }).returning();
      return config;
    }
  }
  /**
   * Obtém todos os números da lista de exclusão do usuário
   */
  async getExclusionList(userId) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    return db.select().from(exclusionList).where(eq(exclusionList.userId, userId)).orderBy(desc(exclusionList.createdAt));
  }
  /**
   * Obtém um item da lista de exclusão por ID
   */
  async getExclusionListItem(id) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    const [item] = await db.select().from(exclusionList).where(eq(exclusionList.id, id));
    return item;
  }
  /**
   * Adiciona um número à lista de exclusão
   */
  async addToExclusionList(data) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    const cleanNumber = normalizePhoneToDigits(data.phoneNumber);
    const existing = await db.select().from(exclusionList).where(
      and(
        eq(exclusionList.userId, data.userId),
        eq(exclusionList.phoneNumber, cleanNumber)
      )
    );
    if (existing.length > 0) {
      const [item2] = await db.update(exclusionList).set({
        contactName: data.contactName,
        reason: data.reason,
        excludeFromFollowup: data.excludeFromFollowup ?? true,
        isActive: data.isActive ?? true,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq(exclusionList.id, existing[0].id)).returning();
      return item2;
    }
    const [item] = await db.insert(exclusionList).values({
      userId: data.userId,
      phoneNumber: cleanNumber,
      contactName: data.contactName,
      reason: data.reason,
      excludeFromFollowup: data.excludeFromFollowup ?? true,
      isActive: data.isActive ?? true
    }).returning();
    return item;
  }
  /**
   * Atualiza um item da lista de exclusão
   */
  async updateExclusionListItem(id, data) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    const [item] = await db.update(exclusionList).set({
      ...data,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(exclusionList.id, id)).returning();
    return item;
  }
  /**
   * Remove um número da lista de exclusão (soft delete - desativa)
   */
  async removeFromExclusionList(id) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    await db.update(exclusionList).set({
      isActive: false,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(exclusionList.id, id));
  }
  /**
   * Remove permanentemente um número da lista de exclusão
   */
  async deleteFromExclusionList(id) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    await db.delete(exclusionList).where(eq(exclusionList.id, id));
  }
  /**
   * Reativa um número na lista de exclusão
   */
  async reactivateExclusionListItem(id) {
    const { exclusionList } = await import("./schema-2CJPU7MX.js");
    const [item] = await db.update(exclusionList).set({
      isActive: true,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(exclusionList.id, id)).returning();
    return item;
  }
  // =============================================================================
  // DAILY USAGE TRACKING - Rastreamento de uso diário para limites free
  // =============================================================================
  /**
   * Obtém ou cria o registro de uso diário para um usuário
   */
  async getDailyUsage(userId) {
    const { dailyUsage } = await import("./schema-2CJPU7MX.js");
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const [existing] = await db.select().from(dailyUsage).where(
      and(
        eq(dailyUsage.userId, userId),
        eq(dailyUsage.usageDate, today)
      )
    );
    if (existing) {
      return {
        promptEditsCount: existing.promptEditsCount,
        simulatorMessagesCount: existing.simulatorMessagesCount
      };
    }
    return { promptEditsCount: 0, simulatorMessagesCount: 0 };
  }
  /**
   * Incrementa o contador de edições de prompt do dia
   */
  async incrementPromptEdits(userId) {
    const { dailyUsage } = await import("./schema-2CJPU7MX.js");
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const updated = await db.update(dailyUsage).set({
      promptEditsCount: sql`${dailyUsage.promptEditsCount} + 1`,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(
      and(
        eq(dailyUsage.userId, userId),
        eq(dailyUsage.usageDate, today)
      )
    ).returning();
    if (updated.length > 0) {
      return updated[0].promptEditsCount;
    }
    const [newRecord] = await db.insert(dailyUsage).values({
      userId,
      usageDate: today,
      promptEditsCount: 1,
      simulatorMessagesCount: 0
    }).returning();
    return newRecord.promptEditsCount;
  }
  /**
   * Incrementa o contador de mensagens do simulador do dia
   */
  async incrementSimulatorMessages(userId) {
    const { dailyUsage } = await import("./schema-2CJPU7MX.js");
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const updated = await db.update(dailyUsage).set({
      simulatorMessagesCount: sql`${dailyUsage.simulatorMessagesCount} + 1`,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(
      and(
        eq(dailyUsage.userId, userId),
        eq(dailyUsage.usageDate, today)
      )
    ).returning();
    if (updated.length > 0) {
      return updated[0].simulatorMessagesCount;
    }
    const [newRecord] = await db.insert(dailyUsage).values({
      userId,
      usageDate: today,
      promptEditsCount: 0,
      simulatorMessagesCount: 1
    }).returning();
    return newRecord.simulatorMessagesCount;
  }
  // ============================================================================
  // TAGS / ETIQUETAS - CRUD Operations
  // ============================================================================
  /**
   * Obtém todas as tags de um usuário
   */
  async getTagsByUserId(userId) {
    return await db.select().from(tags).where(eq(tags.userId, userId)).orderBy(tags.position, tags.name);
  }
  /**
   * Obtém uma tag por ID
   */
  async getTag(id) {
    const [tag] = await db.select().from(tags).where(eq(tags.id, id));
    return tag;
  }
  /**
   * Cria uma nova tag
   */
  async createTag(tagData) {
    const [newTag] = await db.insert(tags).values(tagData).returning();
    return newTag;
  }
  /**
   * Atualiza uma tag existente
   */
  async updateTag(id, data) {
    const [updated] = await db.update(tags).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(tags.id, id)).returning();
    return updated;
  }
  /**
   * Deleta uma tag e remove todas as associações
   */
  async deleteTag(id) {
    await db.delete(tags).where(eq(tags.id, id));
  }
  /**
   * Cria tags padrão do WhatsApp Business para um usuário
   */
  async createDefaultTags(userId) {
    const defaultTags = [
      { name: "Novo cliente", color: "#22c55e", icon: "user-plus", position: 0, isDefault: true },
      { name: "Novo pedido", color: "#eab308", icon: "shopping-bag", position: 1, isDefault: true },
      { name: "Pagamento pendente", color: "#f97316", icon: "clock", position: 2, isDefault: true },
      { name: "Pago", color: "#3b82f6", icon: "check-circle", position: 3, isDefault: true },
      { name: "Pedido finalizado", color: "#ef4444", icon: "package", position: 4, isDefault: true },
      { name: "VIP", color: "#a855f7", icon: "star", position: 5, isDefault: true }
    ];
    const createdTags = [];
    for (const tagData of defaultTags) {
      try {
        const [newTag] = await db.insert(tags).values({ ...tagData, userId }).onConflictDoNothing().returning();
        if (newTag) createdTags.push(newTag);
      } catch (error) {
        console.log(`Tag "${tagData.name}" j\xE1 existe para o usu\xE1rio`);
      }
    }
    return createdTags;
  }
  // ============================================================================
  // CONVERSATION TAGS - Associação de Tags a Conversas
  // ============================================================================
  /**
   * Obtém todas as tags de uma conversa
   */
  async getConversationTags(conversationId) {
    const result = await db.select({
      tag: tags
    }).from(conversationTags).innerJoin(tags, eq(conversationTags.tagId, tags.id)).where(eq(conversationTags.conversationId, conversationId));
    return result.map((r) => r.tag);
  }
  /**
   * 🔥 OTIMIZADO: Batch - obtém tags para múltiplas conversas em 1 query (evita N+1)
   */
  async getTagsForConversations(conversationIds) {
    if (conversationIds.length === 0) return /* @__PURE__ */ new Map();
    const allTags = await db.select({
      conversationId: conversationTags.conversationId,
      tag: tags
    }).from(conversationTags).innerJoin(tags, eq(conversationTags.tagId, tags.id)).where(inArray(conversationTags.conversationId, conversationIds));
    const tagsByConversation = /* @__PURE__ */ new Map();
    for (const { conversationId, tag } of allTags) {
      if (!tagsByConversation.has(conversationId)) {
        tagsByConversation.set(conversationId, []);
      }
      tagsByConversation.get(conversationId).push(tag);
    }
    return tagsByConversation;
  }
  /**
   * Obtém conversas filtradas por tag
   */
  async getConversationsByTag(tagId, connectionId) {
    const result = await db.select({
      conversation: conversations
    }).from(conversationTags).innerJoin(conversations, eq(conversationTags.conversationId, conversations.id)).where(
      and(
        eq(conversationTags.tagId, tagId),
        eq(conversations.connectionId, connectionId)
      )
    ).orderBy(sql`${conversations.lastMessageTime} DESC NULLS LAST`);
    return result.map((r) => r.conversation);
  }
  /**
   * Adiciona uma tag a uma conversa
   */
  async addTagToConversation(conversationId, tagId) {
    const [result] = await db.insert(conversationTags).values({ conversationId, tagId }).onConflictDoNothing().returning();
    const conversation = await this.getConversation(conversationId);
    if (conversation?.connectionId) {
      this.invalidateConversationListCaches(conversation.connectionId);
    }
    return result;
  }
  /**
   * Remove uma tag de uma conversa
   */
  async removeTagFromConversation(conversationId, tagId) {
    await db.delete(conversationTags).where(
      and(
        eq(conversationTags.conversationId, conversationId),
        eq(conversationTags.tagId, tagId)
      )
    );
    const conversation = await this.getConversation(conversationId);
    if (conversation?.connectionId) {
      this.invalidateConversationListCaches(conversation.connectionId);
    }
  }
  /**
   * Atualiza todas as tags de uma conversa (substitui as existentes)
   */
  async setConversationTags(conversationId, tagIds) {
    await db.delete(conversationTags).where(eq(conversationTags.conversationId, conversationId));
    if (tagIds.length > 0) {
      await db.insert(conversationTags).values(tagIds.map((tagId) => ({ conversationId, tagId }))).onConflictDoNothing();
    }
    const conversation = await this.getConversation(conversationId);
    if (conversation?.connectionId) {
      this.invalidateConversationListCaches(conversation.connectionId);
    }
  }
  /**
   * Adiciona tags a várias conversas (mantém tags existentes).
   */
  async addTagsToConversations(conversationIds, tagIds) {
    if (conversationIds.length === 0 || tagIds.length === 0) return;
    const values = conversationIds.flatMap(
      (conversationId) => tagIds.map((tagId) => ({ conversationId, tagId }))
    );
    await db.insert(conversationTags).values(values).onConflictDoNothing();
    const affectedConnections = await db.selectDistinct({ connectionId: conversations.connectionId }).from(conversations).where(inArray(conversations.id, conversationIds));
    for (const entry of affectedConnections) {
      if (entry.connectionId) {
        this.invalidateConversationListCaches(entry.connectionId);
      }
    }
  }
  /**
   * Obtém conversas com suas tags para um connectionId
   * 🔥 OTIMIZADO: Cache de 15s para evitar queries repetidas em polling
   */
  async getConversationsWithTags(connectionId, limit, offset) {
    const isFirstPage = limit != null && (!offset || offset === 0);
    if (limit == null) {
      const cacheKey = `convWithTags:${connectionId}`;
      const cached = memoryCache.get(cacheKey);
      if (cached !== null) return cached;
    } else if (isFirstPage) {
      const cacheKey = `convWithTags:${connectionId}:page0:${limit}`;
      const cached = memoryCache.get(cacheKey);
      if (cached !== null) return cached;
    }
    const countCacheKey = `convCount:${connectionId}`;
    let total = memoryCache.get(countCacheKey);
    if (total === null) {
      const countResult = await db.select({ count: sql`count(*)` }).from(conversations).where(eq(conversations.connectionId, connectionId));
      total = Number(countResult[0]?.count || 0);
      memoryCache.set(countCacheKey, total, 12e4);
    }
    let query = db.select().from(conversations).where(eq(conversations.connectionId, connectionId)).orderBy(sql`${conversations.lastMessageTime} DESC NULLS LAST`);
    if (limit != null) {
      query = query.limit(limit);
    }
    if (offset != null && offset > 0) {
      query = query.offset(offset);
    }
    const allConversations = await query;
    const conversationIds = allConversations.map((c) => c.id);
    if (conversationIds.length === 0) {
      return { data: [], total };
    }
    const allTags = await db.select({
      conversationId: conversationTags.conversationId,
      tag: tags
    }).from(conversationTags).innerJoin(tags, eq(conversationTags.tagId, tags.id)).where(inArray(conversationTags.conversationId, conversationIds));
    const tagsByConversation = /* @__PURE__ */ new Map();
    for (const { conversationId, tag } of allTags) {
      if (!tagsByConversation.has(conversationId)) {
        tagsByConversation.set(conversationId, []);
      }
      tagsByConversation.get(conversationId).push(tag);
    }
    const data = allConversations.map((conv) => ({
      ...conv,
      tags: tagsByConversation.get(conv.id) || []
    }));
    const result = { data, total };
    if (limit == null) {
      const cacheKey = `convWithTags:${connectionId}`;
      memoryCache.set(cacheKey, result, 6e4);
    } else if (isFirstPage) {
      const cacheKey = `convWithTags:${connectionId}:page0:${limit}`;
      memoryCache.set(cacheKey, result, 45e3);
    }
    return result;
  }
  async getAttentionQueue(filters) {
    const limit = Math.max(1, Math.min(filters.limit ?? 50, 200));
    const offset = Math.max(0, filters.offset ?? 0);
    const normalizedQuery = (filters.query || "").trim().toLowerCase();
    const priorityScore = buildAttentionPriorityScore();
    const whereClauses = [];
    if (filters.connectionIds.length === 0) {
      return { data: [], total: 0, hasMore: false, offset, limit };
    }
    whereClauses.push(inArray(conversations.connectionId, filters.connectionIds));
    if (filters.mode === "critical") {
      whereClauses.push(eq(conversations.attentionPriority, "critica"));
      whereClauses.push(eq(conversations.needsHumanAttention, true));
    } else if (filters.mode === "high") {
      whereClauses.push(inArray(conversations.attentionPriority, ["critica", "alta"]));
      whereClauses.push(eq(conversations.needsHumanAttention, true));
    } else if (filters.mode === "needsHumanAttention") {
      whereClauses.push(eq(conversations.needsHumanAttention, true));
    }
    if (normalizedQuery) {
      const likeTerm = `%${normalizedQuery}%`;
      whereClauses.push(
        or(
          sql`lower(coalesce(${conversations.contactName}, '')) like ${likeTerm}`,
          sql`lower(coalesce(${conversations.contactNumber}, '')) like ${likeTerm}`,
          sql`lower(coalesce(${conversations.lastMessageText}, '')) like ${likeTerm}`,
          sql`lower(coalesce(${conversations.attentionReason}, '')) like ${likeTerm}`
        )
      );
    }
    const whereCondition = and(...whereClauses);
    const totalResult = await db.select({ count: sql`count(*)::int` }).from(conversations).where(whereCondition);
    const data = await db.select().from(conversations).where(whereCondition).orderBy(
      sql`${conversations.needsHumanAttention} DESC`,
      sql`${priorityScore} DESC`,
      sql`${conversations.attentionQualifiedAt} DESC NULLS LAST`,
      sql`${conversations.lastMessageTime} DESC NULLS LAST`
    ).limit(limit).offset(offset);
    const total = totalResult[0]?.count || 0;
    return {
      data,
      total,
      hasMore: offset + data.length < total,
      offset,
      limit
    };
  }
  /**
   * searchConversations — Parte 9: Busca por contato (nome/número) e por conteúdo de mensagens
   * Retorna conversas que correspondem ao termo, com o trecho de mensagem mais relevante (snippet).
   */
  async searchConversations(connectionId, query, limit = 30) {
    if (!query || query.trim().length < 2) return [];
    const term = query.trim().toLowerCase();
    const likeTerm = `%${term}%`;
    const byContact = await db.select().from(conversations).where(
      and(
        eq(conversations.connectionId, connectionId),
        or(
          sql`lower(${conversations.contactName}) like ${likeTerm}`,
          sql`lower(${conversations.contactNumber}) like ${likeTerm}`
        )
      )
    ).orderBy(sql`${conversations.lastMessageTime} DESC NULLS LAST`).limit(limit);
    const byMessage = await db.select({
      conv: conversations,
      msgText: messages.text,
      msgFromMe: messages.fromMe,
      msgTime: messages.timestamp
    }).from(messages).innerJoin(conversations, eq(messages.conversationId, conversations.id)).where(
      and(
        eq(conversations.connectionId, connectionId),
        sql`lower(${messages.text}) like ${likeTerm}`
      )
    ).orderBy(sql`${messages.timestamp} DESC`).limit(limit * 3);
    const seen = /* @__PURE__ */ new Set();
    const merged = [];
    for (const c of byContact) {
      if (!seen.has(c.id)) {
        seen.add(c.id);
        merged.push({ ...c, snippet: null });
      }
    }
    for (const row of byMessage) {
      const conv = row.conv;
      if (!seen.has(conv.id)) {
        seen.add(conv.id);
        merged.push({
          ...conv,
          snippet: row.msgText,
          snippetFromMe: row.msgFromMe
        });
      } else {
        const existing = merged.find((m) => m.id === conv.id);
        if (existing && !existing.snippet) {
          existing.snippet = row.msgText;
          existing.snippetFromMe = row.msgFromMe;
        }
      }
    }
    const topResults = merged.slice(0, limit);
    if (topResults.length === 0) return [];
    const convIds = topResults.map((c) => c.id);
    const allTagRows = await db.select({ conversationId: conversationTags.conversationId, tag: tags }).from(conversationTags).innerJoin(tags, eq(conversationTags.tagId, tags.id)).where(inArray(conversationTags.conversationId, convIds));
    const tagsByConv = /* @__PURE__ */ new Map();
    for (const { conversationId, tag } of allTagRows) {
      if (!tagsByConv.has(conversationId)) tagsByConv.set(conversationId, []);
      tagsByConv.get(conversationId).push(tag);
    }
    return topResults.map((c) => ({
      ...c,
      tags: tagsByConv.get(c.id) || []
    }));
  }
  // ============================================
  // RESELLER FUNCTIONS - Sistema de Revenda White-Label
  // ============================================
  /**
   * Cria um novo revendedor
   */
  async createReseller(data) {
    const [result] = await db.insert(resellers).values(data).returning();
    return result;
  }
  /**
   * Obtém revendedor por ID
   */
  async getReseller(id) {
    const [result] = await db.select().from(resellers).where(eq(resellers.id, id)).limit(1);
    return result;
  }
  /**
   * Obtém revendedor pelo ID do usuário
   */
  async getResellerByUserId(userId) {
    const [result] = await db.select().from(resellers).where(eq(resellers.userId, userId)).limit(1);
    return result;
  }
  /**
   * Obtém revendedor pelo domínio customizado
   */
  async getResellerByDomain(domain) {
    const [result] = await db.select().from(resellers).where(eq(resellers.customDomain, domain)).limit(1);
    return result;
  }
  /**
   * Obtém revendedor pelo subdomínio
   */
  async getResellerBySubdomain(subdomain) {
    const [result] = await db.select().from(resellers).where(eq(resellers.subdomain, subdomain)).limit(1);
    return result;
  }
  /**
   * Atualiza revendedor
   */
  async updateReseller(id, data) {
    const [result] = await db.update(resellers).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(resellers.id, id)).returning();
    return result;
  }
  /**
   * Obtém revendedor por ID
   */
  async getResellerById(id) {
    const [result] = await db.select().from(resellers).where(eq(resellers.id, id)).limit(1);
    return result;
  }
  /**
   * Lista todos os revendedores (admin)
   */
  async getAllResellers() {
    const allResellers = await db.select().from(resellers).orderBy(desc(resellers.createdAt));
    const results = [];
    for (const reseller of allResellers) {
      const [user] = await db.select().from(users).where(eq(users.id, reseller.userId)).limit(1);
      const clientCountResult = await db.select({ count: sql`count(*)` }).from(resellerClients).where(eq(resellerClients.resellerId, reseller.id));
      results.push({
        ...reseller,
        user: user || null,
        clientCount: Number(clientCountResult[0]?.count || 0)
      });
    }
    return results;
  }
  /**
   * Verifica se subdomínio está disponível
   */
  async isSubdomainAvailable(subdomain) {
    const [existing] = await db.select().from(resellers).where(eq(resellers.subdomain, subdomain)).limit(1);
    return !existing;
  }
  /**
   * Verifica se domínio está disponível
   */
  async isDomainAvailable(domain) {
    const [existing] = await db.select().from(resellers).where(eq(resellers.customDomain, domain)).limit(1);
    return !existing;
  }
  // ============================================
  // RESELLER CLIENTS FUNCTIONS
  // ============================================
  /**
   * Cria um novo cliente do revendedor
   */
  async createResellerClient(data) {
    const [result] = await db.insert(resellerClients).values(data).returning();
    await db.update(users).set({ resellerId: data.resellerId }).where(eq(users.id, data.userId));
    return result;
  }
  /**
   * Obtém cliente do revendedor por ID
   */
  async getResellerClient(id) {
    const [result] = await db.select().from(resellerClients).where(eq(resellerClients.id, id)).limit(1);
    return result;
  }
  /**
   * Obtém cliente do revendedor por ID (número)
   */
  async getResellerClientById(id) {
    const [result] = await db.select().from(resellerClients).where(eq(resellerClients.id, id)).limit(1);
    return result;
  }
  /**
   * Obtém cliente do revendedor pelo ID do usuário
   */
  async getResellerClientByUserId(userId) {
    const [result] = await db.select().from(resellerClients).where(eq(resellerClients.userId, userId)).limit(1);
    return result;
  }
  /**
   * Lista clientes de um revendedor
   */
  async getResellerClients(resellerId) {
    const clients = await db.select().from(resellerClients).where(eq(resellerClients.resellerId, resellerId)).orderBy(desc(resellerClients.createdAt));
    const results = [];
    for (const client of clients) {
      const [user] = await db.select().from(users).where(eq(users.id, client.userId)).limit(1);
      const payments2 = await db.select().from(resellerPayments).where(and(
        eq(resellerPayments.resellerId, resellerId),
        eq(resellerPayments.resellerClientId, client.id),
        eq(resellerPayments.status, "paid")
      )).orderBy(resellerPayments.paidAt);
      const firstPaymentDate = payments2.length > 0 && payments2[0].paidAt ? payments2[0].paidAt : null;
      const lastPaymentDate = payments2.length > 0 && payments2[payments2.length - 1].paidAt ? payments2[payments2.length - 1].paidAt : null;
      const isOverdue = !client.isFreeClient && client.nextPaymentDate !== null && new Date(client.nextPaymentDate) < /* @__PURE__ */ new Date();
      const monthsInSystem = payments2.length;
      results.push({
        ...client,
        user: user || null,
        firstPaymentDate,
        lastPaymentDate,
        isOverdue,
        monthsInSystem
      });
    }
    return results;
  }
  /**
   * Atualiza cliente do revendedor
   */
  async updateResellerClient(id, data) {
    const [result] = await db.update(resellerClients).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(resellerClients.id, id)).returning();
    return result;
  }
  /**
   * Suspende cliente do revendedor
   */
  async suspendResellerClient(id) {
    const [result] = await db.update(resellerClients).set({ status: "suspended", suspendedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq(resellerClients.id, id)).returning();
    return result;
  }
  /**
   * Reativa cliente do revendedor
   */
  async reactivateResellerClient(id) {
    const [result] = await db.update(resellerClients).set({ status: "active", suspendedAt: null, updatedAt: /* @__PURE__ */ new Date() }).where(eq(resellerClients.id, id)).returning();
    return result;
  }
  /**
   * Cancela cliente do revendedor
   */
  async cancelResellerClient(id) {
    const [result] = await db.update(resellerClients).set({ status: "cancelled", cancelledAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq(resellerClients.id, id)).returning();
    return result;
  }
  /**
   * Conta clientes ativos de um revendedor
   */
  async countActiveResellerClients(resellerId) {
    const [result] = await db.select({ count: sql`count(*)` }).from(resellerClients).where(and(eq(resellerClients.resellerId, resellerId), eq(resellerClients.status, "active")));
    return Number(result?.count || 0);
  }
  /**
   * Conta clientes gratuitos de um revendedor (máximo 1)
   */
  async countFreeResellerClients(resellerId) {
    const [result] = await db.select({ count: sql`count(*)` }).from(resellerClients).where(and(
      eq(resellerClients.resellerId, resellerId),
      eq(resellerClients.isFreeClient, true)
    ));
    return Number(result?.count || 0);
  }
  // ============================================
  // RESELLER PAYMENTS FUNCTIONS
  // ============================================
  /**
   * Cria um novo pagamento do revendedor
   */
  async createResellerPayment(data) {
    const [result] = await db.insert(resellerPayments).values(data).returning();
    return result;
  }
  /**
   * Obtém pagamento do revendedor por ID
   */
  async getResellerPayment(id) {
    const [result] = await db.select().from(resellerPayments).where(eq(resellerPayments.id, id)).limit(1);
    return result;
  }
  /**
   * Lista pagamentos de um revendedor
   */
  async getResellerPayments(resellerId, limit = 50) {
    return db.select().from(resellerPayments).where(eq(resellerPayments.resellerId, resellerId)).orderBy(desc(resellerPayments.createdAt)).limit(limit);
  }
  /**
   * Atualiza pagamento do revendedor
   */
  async updateResellerPayment(id, data) {
    const [result] = await db.update(resellerPayments).set(data).where(eq(resellerPayments.id, id)).returning();
    return result;
  }
  /**
   * Obtém métricas do revendedor
   */
  async getResellerDashboardMetrics(resellerId) {
    const clientStats = await db.select({
      status: resellerClients.status,
      count: sql`count(*)`
    }).from(resellerClients).where(eq(resellerClients.resellerId, resellerId)).groupBy(resellerClients.status);
    const stats = {
      totalClients: 0,
      activeClients: 0,
      suspendedClients: 0,
      cancelledClients: 0
    };
    for (const { status, count } of clientStats) {
      const countNum = Number(count);
      stats.totalClients += countNum;
      if (status === "active") stats.activeClients = countNum;
      if (status === "suspended") stats.suspendedClients = countNum;
      if (status === "cancelled") stats.cancelledClients = countNum;
    }
    const [totalRevenueResult] = await db.select({ total: sql`COALESCE(SUM(amount), 0)` }).from(resellerPayments).where(and(eq(resellerPayments.resellerId, resellerId), eq(resellerPayments.status, "approved")));
    const startOfMonth2 = /* @__PURE__ */ new Date();
    startOfMonth2.setDate(1);
    startOfMonth2.setHours(0, 0, 0, 0);
    const [monthlyRevenueResult] = await db.select({ total: sql`COALESCE(SUM(amount), 0)` }).from(resellerPayments).where(
      and(
        eq(resellerPayments.resellerId, resellerId),
        eq(resellerPayments.status, "approved"),
        gte(resellerPayments.createdAt, startOfMonth2)
      )
    );
    const reseller = await this.getReseller(resellerId);
    const costPerClient = Number(reseller?.costPerClient || 49.99);
    const monthlyPrice = Number(reseller?.clientMonthlyPrice || 99.99);
    const monthlyCost = stats.activeClients * costPerClient;
    const monthlyRevenue = stats.activeClients * monthlyPrice;
    return {
      ...stats,
      totalRevenue: Number(totalRevenueResult?.total || 0),
      monthlyRevenue,
      monthlyCost,
      monthlyProfit: monthlyRevenue - monthlyCost
    };
  }
  // ============================================
  // RESELLER INVOICES FUNCTIONS (Flow 2: Reseller -> System)
  // ============================================
  /**
   * Cria uma nova fatura do revendedor para o sistema
   */
  async createResellerInvoice(data) {
    const [result] = await db.insert(resellerInvoices).values(data).returning();
    return result;
  }
  /**
   * Obtém fatura do revendedor por ID
   */
  async getResellerInvoice(id) {
    const [result] = await db.select().from(resellerInvoices).where(eq(resellerInvoices.id, id)).limit(1);
    return result;
  }
  /**
   * Lista faturas de um revendedor
   */
  async getResellerInvoices(resellerId, limit = 50) {
    return db.select().from(resellerInvoices).where(eq(resellerInvoices.resellerId, resellerId)).orderBy(desc(resellerInvoices.createdAt)).limit(limit);
  }
  /**
   * Obtém fatura por mês de referência
   */
  async getResellerInvoiceByMonth(resellerId, referenceMonth) {
    const [result] = await db.select().from(resellerInvoices).where(
      and(
        eq(resellerInvoices.resellerId, resellerId),
        eq(resellerInvoices.referenceMonth, referenceMonth)
      )
    ).limit(1);
    return result;
  }
  /**
   * Atualiza fatura do revendedor
   */
  async updateResellerInvoice(id, data) {
    const [result] = await db.update(resellerInvoices).set(data).where(eq(resellerInvoices.id, id)).returning();
    return result;
  }
  /**
   * Obtém faturas pendentes ou vencidas de um revendedor
   */
  async getResellerPendingInvoices(resellerId) {
    return db.select().from(resellerInvoices).where(
      and(
        eq(resellerInvoices.resellerId, resellerId),
        sql`${resellerInvoices.status} IN ('pending', 'overdue')`
      )
    ).orderBy(desc(resellerInvoices.dueDate));
  }
  /**
   * Cria fatura com itens (transacional)
   */
  async createResellerInvoiceWithItems(invoice, items) {
    return await db.transaction(async (tx) => {
      const [newInvoice] = await tx.insert(resellerInvoices).values(invoice).returning();
      if (items.length > 0) {
        const itemsWithId = items.map((item) => ({
          ...item,
          invoiceId: newInvoice.id
        }));
        await tx.insert(resellerInvoiceItems).values(itemsWithId);
      }
      return newInvoice;
    });
  }
  /**
   * Obtém fatura pelo ID do Mercado Pago
   */
  async getResellerInvoiceByMpPaymentId(mpPaymentId) {
    const [result] = await db.select().from(resellerInvoices).where(eq(resellerInvoices.mpPaymentId, mpPaymentId)).limit(1);
    return result;
  }
  /**
   * Obtém itens de uma fatura
   */
  async getResellerInvoiceItems(invoiceId) {
    return db.select().from(resellerInvoiceItems).where(eq(resellerInvoiceItems.invoiceId, invoiceId));
  }
  // ============================================================================
  // SISTEMA DE SUSPENSÃO POR VIOLAÇÃO DE POLÍTICAS
  // ============================================================================
  /**
   * Verifica se um usuário está suspenso por violação de políticas
   */
  async isUserSuspended(userId) {
    const [user] = await db.select({
      suspendedAt: users.suspendedAt,
      suspensionReason: users.suspensionReason,
      suspensionType: users.suspensionType,
      refundedAt: users.refundedAt,
      refundAmount: users.refundAmount
    }).from(users).where(eq(users.id, userId));
    if (!user || !user.suspendedAt) {
      return { suspended: false };
    }
    return {
      suspended: true,
      data: {
        reason: user.suspensionReason,
        type: user.suspensionType,
        suspendedAt: user.suspendedAt,
        refundedAt: user.refundedAt,
        refundAmount: user.refundAmount ? parseFloat(user.refundAmount) : null
      }
    };
  }
  /**
   * Suspende um usuário por violação de políticas
   */
  async suspendUser(userId, violationType, reason, adminId, evidence, refundAmount) {
    const now = /* @__PURE__ */ new Date();
    await db.update(users).set({
      suspendedAt: now,
      suspensionReason: reason,
      suspensionType: violationType,
      refundedAt: refundAmount ? now : null,
      refundAmount: refundAmount ? refundAmount.toString() : null,
      updatedAt: now
    }).where(eq(users.id, userId));
    await db.execute(sql`
      INSERT INTO policy_violations (user_id, violation_type, description, status, resulted_in_suspension, admin_id, evidence, internal_notes)
      VALUES (${userId}, ${violationType}, ${reason}, 'confirmed', true, ${adminId || null}, ${JSON.stringify(evidence || [])}, ${"Suspens\xE3o aplicada em " + now.toISOString()})
    `);
    const [agentConfig] = await db.select().from(aiAgentConfig).where(eq(aiAgentConfig.userId, userId));
    if (agentConfig) {
      await db.update(aiAgentConfig).set({ isActive: false }).where(eq(aiAgentConfig.userId, userId));
    }
    console.log(`\u{1F6AB} [SUSPENSION] Usu\xE1rio ${userId} suspenso por ${violationType}: ${reason}`);
  }
  /**
   * Obtém todos os usuários suspensos (para admin)
   */
  async getSuspendedUsers() {
    const result = await db.execute(sql`
      SELECT 
        u.id,
        u.email,
        u.name,
        u.phone,
        u.suspended_at as "suspendedAt",
        u.suspension_reason as "suspensionReason",
        u.suspension_type as "suspensionType",
        u.refunded_at as "refundedAt",
        u.refund_amount as "refundAmount",
        pv.description as "violationDescription",
        pv.evidence,
        pv.created_at as "violationDate"
      FROM users u
      LEFT JOIN policy_violations pv ON pv.user_id = u.id AND pv.resulted_in_suspension = true
      WHERE u.suspended_at IS NOT NULL
      ORDER BY u.suspended_at DESC
    `);
    return result.rows;
  }
  /**
   * Remove suspensão de um usuário (para admin reverter se necessário)
   */
  async unsuspendUser(userId, adminNote) {
    await db.update(users).set({
      suspendedAt: null,
      suspensionReason: null,
      suspensionType: null,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(users.id, userId));
    const revertNote = `
Revertido: ${adminNote || "Sem motivo especificado"} em ${(/* @__PURE__ */ new Date()).toISOString()}`;
    await db.execute(sql`
      UPDATE policy_violations
      SET status = 'dismissed', 
          internal_notes = COALESCE(internal_notes, '') || ${revertNote},
          updated_at = now()
      WHERE user_id = ${userId} AND resulted_in_suspension = true
    `);
    console.log(`\u2705 [SUSPENSION] Suspens\xE3o removida do usu\xE1rio ${userId}`);
  }
  // ==================== TEAM MEMBERS ====================
  /**
   * Buscar todos os membros de um dono
   */
  async getTeamMembers(ownerId) {
    return await db.select().from(teamMembers).where(eq(teamMembers.ownerId, ownerId)).orderBy(desc(teamMembers.createdAt));
  }
  /**
   * Buscar membro por ID
   */
  async getTeamMember(id) {
    const [member] = await db.select().from(teamMembers).where(eq(teamMembers.id, id));
    return member;
  }
  /**
   * Buscar membro por email (dentro do mesmo dono)
   */
  async getTeamMemberByEmail(ownerId, email) {
    const [member] = await db.select().from(teamMembers).where(and(eq(teamMembers.ownerId, ownerId), eq(teamMembers.email, email)));
    return member;
  }
  /**
   * Buscar membro por email (global - para login)
   */
  async getTeamMemberByEmailGlobal(email) {
    const [member] = await db.select().from(teamMembers).where(eq(teamMembers.email, email));
    return member;
  }
  /**
   * Criar novo membro
   */
  async createTeamMember(data) {
    const [member] = await db.insert(teamMembers).values({
      ...data,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    }).returning();
    return member;
  }
  /**
   * Atualizar membro
   */
  async updateTeamMember(id, data) {
    const [member] = await db.update(teamMembers).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(teamMembers.id, id)).returning();
    return member;
  }
  /**
   * Excluir membro
   */
  async deleteTeamMember(id) {
    await db.delete(teamMemberSessions).where(eq(teamMemberSessions.memberId, id));
    await db.delete(teamMembers).where(eq(teamMembers.id, id));
  }
  // ==================== TEAM MEMBER SESSIONS ====================
  /**
   * Criar sessão de membro
   */
  async createTeamMemberSession(data) {
    const [session2] = await db.insert(teamMemberSessions).values({
      ...data,
      createdAt: /* @__PURE__ */ new Date()
    }).returning();
    return session2;
  }
  /**
   * Buscar sessão por token
   */
  async getTeamMemberSession(token) {
    const [session2] = await db.select().from(teamMemberSessions).where(eq(teamMemberSessions.token, token));
    return session2;
  }
  /**
   * Deletar sessão por token
   */
  async deleteTeamMemberSession(token) {
    await db.delete(teamMemberSessions).where(eq(teamMemberSessions.token, token));
  }
  /**
   * Limpar sessões expiradas
   */
  async cleanExpiredTeamMemberSessions() {
    await db.delete(teamMemberSessions).where(lte(teamMemberSessions.expiresAt, /* @__PURE__ */ new Date()));
  }
  // ==================== AUDIO CONFIG (TTS) ====================
  /**
   * Buscar configuração de áudio do usuário
   */
  async getAudioConfig(userId) {
    const [config] = await db.select().from(audioConfig).where(eq(audioConfig.userId, userId));
    return config;
  }
  /**
   * Criar configuração de áudio padrão
   * NOTA: Por padrão, TTS começa DESATIVADO - usuário precisa ativar manualmente via toggle
   */
  async createAudioConfig(userId) {
    const [config] = await db.insert(audioConfig).values({
      userId,
      isEnabled: false,
      // DESATIVADO por padrão - ativar via toggle
      voiceType: "female",
      responseMode: "first_message_text_audio_then_mirror",
      speed: "1.00"
    }).returning();
    return config;
  }
  /**
   * Atualizar configuração de áudio
   */
  async updateAudioConfig(userId, data) {
    await ensureAudioResponseModeConstraint();
    const existing = await this.getAudioConfig(userId);
    if (!existing) {
      const [config2] = await db.insert(audioConfig).values({
        userId,
        isEnabled: data.isEnabled ?? false,
        // DESATIVADO por padrão
        voiceType: data.voiceType ?? "female",
        responseMode: data.responseMode ?? "first_message_text_audio_then_mirror",
        speed: data.speed ?? "1.00"
      }).returning();
      return config2;
    }
    const [config] = await db.update(audioConfig).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where(eq(audioConfig.userId, userId)).returning();
    return config;
  }
  /**
   * Buscar contador de mensagens de áudio do dia
   */
  async getAudioMessageCounter(userId) {
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const [counter] = await db.select().from(audioMessageCounter).where(and(eq(audioMessageCounter.userId, userId), eq(audioMessageCounter.date, today)));
    return counter;
  }
  /**
   * Incrementar contador de mensagens de áudio
   * Retorna o novo contador ou undefined se limite atingido
   */
  async incrementAudioMessageCounter(userId) {
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    let counter = await this.getAudioMessageCounter(userId);
    if (!counter) {
      const [newCounter] = await db.insert(audioMessageCounter).values({
        userId,
        date: today,
        count: 1,
        dailyLimit: 30
      }).returning();
      return { count: 1, limit: 30, canSend: true };
    }
    if (counter.count >= 30) {
      return { count: counter.count, limit: 30, canSend: false };
    }
    const [updated] = await db.update(audioMessageCounter).set({ count: counter.count + 1, dailyLimit: 30, updatedAt: /* @__PURE__ */ new Date() }).where(eq(audioMessageCounter.id, counter.id)).returning();
    return { count: updated.count, limit: 30, canSend: true };
  }
  /**
   * Verificar se usuário pode enviar mais áudios hoje
   */
  async canSendAudio(userId) {
    const config = await this.getAudioConfig(userId);
    if (!config) {
      await this.createAudioConfig(userId);
    }
    if (config && !config.isEnabled) {
      return { canSend: false, remaining: 0, limit: 30, used: 0, isUnlimited: false };
    }
    const counter = await this.getAudioMessageCounter(userId);
    if (!counter) {
      return {
        canSend: true,
        remaining: 30,
        limit: 30,
        used: 0,
        isUnlimited: false
      };
    }
    const remaining = Math.max(0, 30 - counter.count);
    return { canSend: remaining > 0, remaining, limit: 30, used: counter.count, isUnlimited: false };
  }
  // ========================================================================
  // Admin Notification operations
  // ========================================================================
  async getAdminNotificationConfig(adminId) {
    try {
      const result = await db.execute(sql`
        SELECT * FROM admin_notification_config WHERE admin_id = ${adminId} LIMIT 1
      `);
      return sanitizeAdminNotificationConfig(result.rows[0]);
    } catch (error) {
      console.error("Error getting admin notification config:", error);
      return void 0;
    }
  }
  async updateAdminNotificationConfig(adminId, data) {
    try {
      const sanitizedData = sanitizeAdminNotificationConfig({ ...data || {} }) || {};
      const existing = await this.getAdminNotificationConfig(adminId);
      const paymentDays = sanitizedData.paymentReminderDaysBefore || [7, 3, 1];
      const overdueDays = sanitizedData.overdueReminderDaysAfter || [1, 3, 7, 14];
      const businessDays = sanitizedData.businessDays || [1, 2, 3, 4, 5];
      let welcomeVariationsArray = [];
      if (Array.isArray(sanitizedData.welcomeMessageVariations)) {
        welcomeVariationsArray = sanitizedData.welcomeMessageVariations.map(
          (v) => typeof v === "string" ? v : String(v)
        ).filter((v) => v && v.trim());
      }
      const welcomeVariationsSQL = welcomeVariationsArray.length > 0 ? `ARRAY[${welcomeVariationsArray.map((v) => `'${v.replace(/'/g, "''")}'`).join(",")}]::text[]` : `ARRAY[]::text[]`;
      if (!existing) {
        await db.execute(sql`
          INSERT INTO admin_notification_config (
            admin_id, 
            payment_reminder_enabled, 
            payment_reminder_days_before,
            payment_reminder_message_template,
            payment_reminder_ai_enabled,
            payment_reminder_ai_prompt,
            overdue_reminder_enabled,
            overdue_reminder_days_after,
            overdue_reminder_message_template,
            overdue_reminder_ai_enabled,
            overdue_reminder_ai_prompt,
            periodic_checkin_enabled,
            periodic_checkin_min_days,
            periodic_checkin_max_days,
            periodic_checkin_message_template,
            checkin_ai_enabled,
            checkin_ai_prompt,
            broadcast_enabled,
            broadcast_antibot_variation,
            broadcast_ai_variation,
            broadcast_min_interval_seconds,
            broadcast_max_interval_seconds,
            disconnected_alert_enabled,
            disconnected_alert_hours,
            disconnected_alert_message_template,
            disconnected_ai_enabled,
            disconnected_ai_prompt,
            ai_variation_enabled,
            ai_variation_prompt,
            business_hours_start,
            business_hours_end,
            business_days,
            respect_business_hours,
            welcome_message_enabled,
            welcome_message_variations,
            welcome_message_ai_enabled,
            welcome_message_ai_prompt
          ) VALUES (
            ${adminId},
            ${sanitizedData.paymentReminderEnabled ?? true},
            ARRAY[${sql.raw(paymentDays.join(","))}]::integer[],
            ${sanitizedData.paymentReminderMessageTemplate || ""},
            ${sanitizedData.paymentReminderAiEnabled ?? false},
            ${sanitizedData.paymentReminderAiPrompt || ""},
            ${sanitizedData.overdueReminderEnabled ?? true},
            ARRAY[${sql.raw(overdueDays.join(","))}]::integer[],
            ${sanitizedData.overdueReminderMessageTemplate || ""},
            ${sanitizedData.overdueReminderAiEnabled ?? false},
            ${sanitizedData.overdueReminderAiPrompt || ""},
            ${sanitizedData.periodicCheckinEnabled ?? true},
            ${sanitizedData.periodicCheckinMinDays ?? 7},
            ${sanitizedData.periodicCheckinMaxDays ?? 15},
            ${sanitizedData.periodicCheckinMessageTemplate || ""},
            ${sanitizedData.checkinAiEnabled ?? false},
            ${sanitizedData.checkinAiPrompt || ""},
            ${sanitizedData.broadcastEnabled ?? true},
            ${sanitizedData.broadcastAntibotVariation ?? true},
            ${sanitizedData.broadcastAiVariation ?? false},
            ${sanitizedData.broadcastMinIntervalSeconds ?? 60},
            ${sanitizedData.broadcastMaxIntervalSeconds ?? 90},
            ${sanitizedData.disconnectedAlertEnabled ?? true},
            ${sanitizedData.disconnectedAlertHours ?? 2},
            ${sanitizedData.disconnectedAlertMessageTemplate || ""},
            ${sanitizedData.disconnectedAiEnabled ?? false},
            ${sanitizedData.disconnectedAiPrompt || ""},
            ${sanitizedData.aiVariationEnabled ?? false},
            ${sanitizedData.aiVariationPrompt || ""},
            ${sanitizedData.businessHoursStart || "09:00"},
            ${sanitizedData.businessHoursEnd || "18:00"},
            ARRAY[${sql.raw(businessDays.join(","))}]::integer[],
            ${sanitizedData.respectBusinessHours ?? true},
            ${sanitizedData.welcomeMessageEnabled ?? true},
            ${sql.raw(welcomeVariationsSQL)},
            ${sanitizedData.welcomeMessageAiEnabled ?? false},
            ${sanitizedData.welcomeMessageAiPrompt || ""}
          )
        `);
      } else {
        await db.execute(sql`
          UPDATE admin_notification_config SET
            payment_reminder_enabled = ${sanitizedData.paymentReminderEnabled},
            payment_reminder_days_before = ARRAY[${sql.raw(paymentDays.join(","))}]::integer[],
            payment_reminder_message_template = ${sanitizedData.paymentReminderMessageTemplate},
            payment_reminder_ai_enabled = ${sanitizedData.paymentReminderAiEnabled ?? false},
            payment_reminder_ai_prompt = ${sanitizedData.paymentReminderAiPrompt || ""},
            overdue_reminder_enabled = ${sanitizedData.overdueReminderEnabled},
            overdue_reminder_days_after = ARRAY[${sql.raw(overdueDays.join(","))}]::integer[],
            overdue_reminder_message_template = ${sanitizedData.overdueReminderMessageTemplate},
            overdue_reminder_ai_enabled = ${sanitizedData.overdueReminderAiEnabled ?? false},
            overdue_reminder_ai_prompt = ${sanitizedData.overdueReminderAiPrompt || ""},
            periodic_checkin_enabled = ${sanitizedData.periodicCheckinEnabled},
            periodic_checkin_min_days = ${sanitizedData.periodicCheckinMinDays},
            periodic_checkin_max_days = ${sanitizedData.periodicCheckinMaxDays},
            periodic_checkin_message_template = ${sanitizedData.periodicCheckinMessageTemplate},
            checkin_ai_enabled = ${sanitizedData.checkinAiEnabled ?? false},
            checkin_ai_prompt = ${sanitizedData.checkinAiPrompt || ""},
            broadcast_enabled = ${sanitizedData.broadcastEnabled},
            broadcast_antibot_variation = ${sanitizedData.broadcastAntibotVariation},
            broadcast_ai_variation = ${sanitizedData.broadcastAiVariation ?? false},
            broadcast_min_interval_seconds = ${sanitizedData.broadcastMinIntervalSeconds},
            broadcast_max_interval_seconds = ${sanitizedData.broadcastMaxIntervalSeconds},
            disconnected_alert_enabled = ${sanitizedData.disconnectedAlertEnabled},
            disconnected_alert_hours = ${sanitizedData.disconnectedAlertHours},
            disconnected_alert_message_template = ${sanitizedData.disconnectedAlertMessageTemplate},
            disconnected_ai_enabled = ${sanitizedData.disconnectedAiEnabled ?? false},
            disconnected_ai_prompt = ${sanitizedData.disconnectedAiPrompt || ""},
            ai_variation_enabled = ${sanitizedData.aiVariationEnabled ?? false},
            ai_variation_prompt = ${sanitizedData.aiVariationPrompt || ""},
            business_hours_start = ${sanitizedData.businessHoursStart},
            business_hours_end = ${sanitizedData.businessHoursEnd},
            business_days = ARRAY[${sql.raw(businessDays.join(","))}]::integer[],
            respect_business_hours = ${sanitizedData.respectBusinessHours},
            welcome_message_enabled = ${sanitizedData.welcomeMessageEnabled},
            welcome_message_variations = ${sql.raw(welcomeVariationsSQL)},
            welcome_message_ai_enabled = ${sanitizedData.welcomeMessageAiEnabled ?? false},
            welcome_message_ai_prompt = ${sanitizedData.welcomeMessageAiPrompt || ""},
            updated_at = now()
          WHERE admin_id = ${adminId}
        `);
      }
      const currentConfig = await this.getAdminNotificationConfig(adminId);
      if (currentConfig) {
        const disabledTypesByModule = [
          {
            enabled: currentConfig.payment_reminder_enabled === true,
            types: ["payment_reminder"],
            moduleName: "payment_reminder"
          },
          {
            enabled: currentConfig.overdue_reminder_enabled === true,
            types: ["overdue_reminder"],
            moduleName: "overdue_reminder"
          },
          {
            enabled: currentConfig.periodic_checkin_enabled === true,
            types: ["checkin", "periodic_checkin"],
            moduleName: "checkin"
          },
          {
            enabled: currentConfig.disconnected_alert_enabled === true,
            types: ["disconnected", "disconnected_alert"],
            moduleName: "disconnected"
          }
        ];
        for (const moduleConfig of disabledTypesByModule) {
          if (moduleConfig.enabled) continue;
          for (const notificationType of moduleConfig.types) {
            await db.execute(sql`
              UPDATE scheduled_notifications
              SET
                status = 'cancelled',
                updated_at = NOW(),
                error_message = COALESCE(
                  NULLIF(error_message, ''),
                  ${`Cancelado automaticamente: m\xF3dulo ${moduleConfig.moduleName} desativado`}
                )
              WHERE admin_id = ${adminId}
                AND status = 'pending'
                AND notification_type = ${notificationType}
            `);
          }
        }
      }
    } catch (error) {
      console.error("Error updating admin notification config:", error);
      throw error;
    }
  }
  async getAdminBroadcasts(adminId) {
    try {
      const result = await db.execute(sql`
        SELECT * FROM admin_broadcasts 
        WHERE admin_id = ${adminId}
        ORDER BY created_at DESC
        LIMIT 50
      `);
      return result.rows;
    } catch (error) {
      console.error("Error getting admin broadcasts:", error);
      return [];
    }
  }
  async getRunningAdminBroadcasts() {
    try {
      const result = await db.execute(sql`
        SELECT * FROM admin_broadcasts
        WHERE status = 'sending'
        ORDER BY updated_at ASC
      `);
      return result.rows || [];
    } catch (error) {
      console.error("Error getting running admin broadcasts:", error);
      return [];
    }
  }
  async getAdminBroadcast(adminId, id) {
    try {
      const result = await db.execute(sql`
        SELECT * FROM admin_broadcasts 
        WHERE admin_id = ${adminId} AND id = ${id}
        LIMIT 1
      `);
      return result.rows[0];
    } catch (error) {
      console.error("Error getting admin broadcast:", error);
      return void 0;
    }
  }
  async createAdminBroadcast(data) {
    try {
      const id = `broadcast_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await db.execute(sql`
        INSERT INTO admin_broadcasts (
          id, admin_id, name, message_template, target_type, 
          target_filter, ai_variation, antibot_enabled, status,
          total_recipients, sent_count, failed_count, source_type,
          custom_recipients, campaign_context, custom_min_interval_seconds,
          custom_max_interval_seconds, custom_batch_size, custom_batch_pause_seconds
        ) VALUES (
          ${id}, ${data.adminId}, ${data.name}, ${data.messageTemplate},
          ${data.targetType}, ${JSON.stringify(data.targetFilter || {})},
          ${data.aiVariation}, ${data.antibotEnabled}, ${data.status},
          ${data.totalRecipients}, ${data.sentCount}, ${data.failedCount},
          ${data.sourceType || "users"},
          ${JSON.stringify(data.customRecipients || [])},
          ${JSON.stringify(data.campaignContext || {})},
          ${data.customMinIntervalSeconds ?? null},
          ${data.customMaxIntervalSeconds ?? null},
          ${data.customBatchSize ?? null},
          ${data.customBatchPauseSeconds ?? null}
        )
      `);
      return id;
    } catch (error) {
      console.error("Error creating admin broadcast:", error);
      throw error;
    }
  }
  async updateAdminBroadcast(adminId, id, data) {
    try {
      if (data.targetFilter !== void 0 || data.totalRecipients !== void 0) {
        await db.execute(sql`UPDATE admin_broadcasts SET 
          target_filter = ${JSON.stringify(data.targetFilter || {})},
          total_recipients = ${data.totalRecipients ?? 0},
          updated_at = now()
          WHERE admin_id = ${adminId} AND id = ${id}`);
      } else if (data.status !== void 0 && data.completedAt !== void 0) {
        await db.execute(sql`UPDATE admin_broadcasts SET 
          status = ${data.status}, 
          sent_count = ${data.sentCount ?? 0}, 
          failed_count = ${data.failedCount ?? 0}, 
          completed_at = ${data.completedAt}, 
          updated_at = now() 
          WHERE admin_id = ${adminId} AND id = ${id}`);
      } else if (data.status !== void 0 && data.startedAt !== void 0) {
        await db.execute(sql`UPDATE admin_broadcasts SET 
          status = ${data.status}, 
          started_at = ${data.startedAt}, 
          updated_at = now() 
          WHERE admin_id = ${adminId} AND id = ${id}`);
      } else if (data.status !== void 0) {
        await db.execute(sql`UPDATE admin_broadcasts SET 
          status = ${data.status}, 
          updated_at = now() 
          WHERE admin_id = ${adminId} AND id = ${id}`);
      } else if (data.sentCount !== void 0 || data.failedCount !== void 0) {
        await db.execute(sql`UPDATE admin_broadcasts SET 
          sent_count = ${data.sentCount ?? 0}, 
          failed_count = ${data.failedCount ?? 0}, 
          updated_at = now() 
          WHERE admin_id = ${adminId} AND id = ${id}`);
      }
    } catch (error) {
      console.error("Error updating admin broadcast:", error);
      throw error;
    }
  }
  async cancelAdminBroadcast(adminId, id) {
    try {
      await db.execute(sql`
        UPDATE admin_broadcasts 
        SET status = 'cancelled', updated_at = now()
        WHERE admin_id = ${adminId} AND id = ${id}
      `);
    } catch (error) {
      console.error("Error cancelling admin broadcast:", error);
      throw error;
    }
  }
  async createAdminNotificationLog(data) {
    try {
      const id = `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await db.execute(sql`
        INSERT INTO admin_notification_logs (
          id, admin_id, user_id, notification_type,
          recipient_phone, recipient_name, message_sent,
          message_original, status, metadata
        ) VALUES (
          ${id}, ${data.adminId}, ${data.userId}, ${data.notificationType},
          ${data.recipientPhone}, ${data.recipientName}, ${data.messageSent},
          ${data.messageOriginal}, ${data.status || "pending"},
          ${JSON.stringify(data.metadata || {})}
        )
      `);
      return id;
    } catch (error) {
      console.error("Error creating admin notification log:", error);
      throw error;
    }
  }
  // ============================================================
  // BROADCAST MESSAGE LOGS
  // ============================================================
  async ensureBroadcastMessagesTable() {
    try {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS admin_broadcast_messages (
          id TEXT PRIMARY KEY,
          broadcast_id TEXT NOT NULL,
          admin_id TEXT NOT NULL,
          user_id TEXT,
          recipient_phone TEXT NOT NULL,
          recipient_name TEXT NOT NULL DEFAULT 'Cliente',
          message_original TEXT,
          message_sent TEXT NOT NULL,
          ai_varied BOOLEAN DEFAULT false,
          status TEXT DEFAULT 'sent',
          error_message TEXT,
          sent_at TIMESTAMP DEFAULT now()
        )
      `);
      await db.execute(sql`
        CREATE INDEX IF NOT EXISTS idx_broadcast_messages_broadcast_id 
        ON admin_broadcast_messages(broadcast_id)
      `);
      console.log("\u2705 [DB] Tabela admin_broadcast_messages garantida");
    } catch (error) {
      console.error("Error ensuring broadcast_messages table:", error);
    }
  }
  async createBroadcastMessage(data) {
    try {
      const id = `bm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await db.execute(sql`
        INSERT INTO admin_broadcast_messages (
          id, broadcast_id, admin_id, user_id,
          recipient_phone, recipient_name,
          message_original, message_sent,
          ai_varied, status, error_message, sent_at
        ) VALUES (
          ${id}, ${data.broadcastId}, ${data.adminId}, ${data.userId || null},
          ${data.recipientPhone}, ${data.recipientName},
          ${data.messageOriginal}, ${data.messageSent},
          ${data.aiVaried}, ${data.status}, ${data.errorMessage || null}, now()
        )
      `);
      return id;
    } catch (error) {
      console.error("Error creating broadcast message log:", error);
      return "";
    }
  }
  async getBroadcastMessages(broadcastId) {
    try {
      const result = await db.execute(sql`
        SELECT * FROM admin_broadcast_messages 
        WHERE broadcast_id = ${broadcastId}
        ORDER BY sent_at ASC
      `);
      return result.rows || [];
    } catch (error) {
      console.error("Error getting broadcast messages:", error);
      return [];
    }
  }
  // ============================================================
  // FOLLOW-UP PARA NÃO PAGANTES
  // ============================================================
  /**
   * Busca configuração de follow-up para não pagantes
   */
  async getNotapayerFollowupConfig() {
    try {
      const result = await db.execute(sql`
        SELECT * FROM followup_configs WHERE id = 1 LIMIT 1
      `);
      return result.rows[0];
    } catch (error) {
      console.error("Error getting notapayer followup config:", error);
      return null;
    }
  }
  /**
   * Atualiza configuração de follow-up para não pagantes
   */
  async updateNotapayerFollowupConfig(data) {
    try {
      const existing = await this.getNotapayerFollowupConfig();
      if (!existing) {
        await db.execute(sql`
          INSERT INTO followup_configs (
            id, is_enabled, active_days, max_attempts,
            message_template, tone, use_emojis, active_days_start, active_days_end
          ) VALUES (
            1, ${data.isEnabled ?? false}, ${data.activeDays ?? 3}, ${data.maxAttempts ?? 3},
            ${data.messageTemplate ?? "Ol\xE1! Seu plano expirou. Quer renovar?"}, ${data.tone ?? "friendly"},
            ${data.useEmojis ?? true}, ${data.activeDaysStart ?? 1}, ${data.activeDaysEnd ?? 7}
          )
        `);
        return data;
      }
      await db.execute(sql`
        UPDATE followup_configs SET
          is_enabled = ${data.isEnabled ?? existing.is_enabled},
          active_days = ${data.activeDays ?? existing.active_days},
          max_attempts = ${data.maxAttempts ?? existing.max_attempts},
          message_template = ${data.messageTemplate ?? existing.message_template},
          tone = ${data.tone ?? existing.tone},
          use_emojis = ${data.useEmojis ?? existing.use_emojis},
          active_days_start = ${data.activeDaysStart ?? existing.active_days_start},
          active_days_end = ${data.activeDaysEnd ?? existing.active_days_end},
          updated_at = NOW()
        WHERE id = 1
      `);
      return data;
    } catch (error) {
      console.error("Error updating notapayer followup config:", error);
      throw error;
    }
  }
  /**
   * Busca tentativas de follow-up para um usuário
   */
  async getNotapayerFollowupAttempts(userId) {
    try {
      const result = await db.execute(sql`
        SELECT * FROM followup_attempts
        WHERE user_id = ${userId}
        ORDER BY sent_at DESC
        LIMIT 20
      `);
      return result.rows || [];
    } catch (error) {
      console.error("Error getting notapayer followup attempts:", error);
      return [];
    }
  }
  /**
   * Busca histórico completo de follow-ups
   */
  async getNotapayerFollowupHistory(limit = 100) {
    try {
      const result = await db.execute(sql`
        SELECT * FROM followup_attempts
        ORDER BY sent_at DESC
        LIMIT ${limit}
      `);
      return result.rows || [];
    } catch (error) {
      console.error("Error getting notapayer followup history:", error);
      return [];
    }
  }
  /**
   * Cria registro de tentativa de follow-up
   */
  async createNotapayerFollowupAttempt(data) {
    try {
      await db.execute(sql`
        INSERT INTO followup_attempts (user_id, subscription_id, message, sent_at, status)
        VALUES (${data.userId}, ${data.subscriptionId}, ${data.message}, ${data.sentAt.toISOString()}, ${data.status})
      `);
    } catch (error) {
      console.error("Error creating notapayer followup attempt:", error);
    }
  }
  /**
   * Lista não pagantes elegíveis para follow-up
   */
  async getNotapayerFollowupList(config) {
    try {
      const now = /* @__PURE__ */ new Date();
      const activeDaysStart = config.active_days_start || 1;
      const activeDaysEnd = config.active_days_end || 7;
      const result = await db.execute(sql`
        SELECT
          s.id as subscription_id,
          s.user_id,
          u.name as user_name,
          u.email as user_email,
          u.whatsapp_number as phone,
          p.name as plan_name,
          p.price as plan_price,
          s.expires_at as expires_at,
          s.cancelled_at as cancelled_at
        FROM subscriptions s
        JOIN users u ON u.id = s.user_id
        JOIN plans p ON p.id = s.plan_id
        WHERE s.cancelled_at IS NULL
          AND s.expires_at <= ${now}
          AND s.status = 'expired'
        ORDER BY s.expires_at DESC
      `);
      const subscriptions2 = result.rows || [];
      const eligible = subscriptions2.filter((sub) => {
        const daysSinceExpiry = Math.floor(
          (now.getTime() - new Date(sub.expires_at).getTime()) / (1e3 * 60 * 60 * 24)
        );
        return daysSinceExpiry >= activeDaysStart && daysSinceExpiry <= activeDaysEnd;
      });
      return await Promise.all(
        eligible.map(async (sub) => {
          const attempts = await this.getNotapayerFollowupAttempts(sub.user_id);
          return {
            ...sub,
            daysSinceExpiry: Math.floor(
              (now.getTime() - new Date(sub.expires_at).getTime()) / (1e3 * 60 * 60 * 24)
            ),
            attempts: attempts.length,
            lastAttempt: attempts[0]
          };
        })
      );
    } catch (error) {
      console.error("Error getting notapayer followup list:", error);
      return [];
    }
  }
  // ============================================================
  // FOLLOW-UP CONFIGURATION (GLOBAL)
  // ============================================================
  /**
   * Get global follow-up configuration
   * GET /api/followup/config
   */
  async getFollowupConfig() {
    try {
      const result = await db.execute(sql`
        SELECT * FROM followup_configs WHERE id = 'global'
      `);
      if (result.rows && result.rows.length > 0) {
        return result.rows[0];
      }
      return null;
    } catch (error) {
      console.error("Error getting followup config:", error);
      return null;
    }
  }
  /**
   * Update global follow-up configuration
   * PUT /api/followup/config
   */
  async updateFollowupConfig(data) {
    try {
      const existing = await this.getFollowupConfig();
      if (!existing) {
        await db.execute(sql`
          INSERT INTO followup_configs (
            id, is_enabled, max_attempts, intervals_minutes,
            infinite_loop, infinite_loop_min_days, infinite_loop_max_days,
            respect_business_hours, business_hours_start, business_hours_end,
            business_days, use_emojis, tone
          ) VALUES (
            'global', ${data.isEnabled ?? true}, ${data.maxAttempts ?? 8},
            ${JSON.stringify(data.intervalsMinutes ?? [10, 30, 180, 1440])},
            ${data.infiniteLoop ?? true}, ${data.infiniteLoopMinDays ?? 15}, ${data.infiniteLoopMaxDays ?? 30},
            ${data.respectBusinessHours ?? true}, ${data.businessHoursStart ?? "09:00"}, ${data.businessHoursEnd ?? "18:00"},
            ${JSON.stringify(data.businessDays ?? [1, 2, 3, 4, 5])},
            ${data.useEmojis ?? true}, ${data.tone ?? "friendly"}
          )
        `);
        return data;
      }
      await db.execute(sql`
        UPDATE followup_configs SET
          is_enabled = ${data.isEnabled ?? existing.is_enabled},
          max_attempts = ${data.maxAttempts ?? existing.max_attempts},
          intervals_minutes = ${JSON.stringify(data.intervalsMinutes ?? existing.intervals_minutes)},
          infinite_loop = ${data.infiniteLoop ?? existing.infinite_loop},
          infinite_loop_min_days = ${data.infiniteLoopMinDays ?? existing.infinite_loop_min_days},
          infinite_loop_max_days = ${data.infiniteLoopMaxDays ?? existing.infinite_loop_max_days},
          respect_business_hours = ${data.respectBusinessHours ?? existing.respect_business_hours},
          business_hours_start = ${data.businessHoursStart ?? existing.business_hours_start},
          business_hours_end = ${data.businessHoursEnd ?? existing.business_hours_end},
          business_days = ${JSON.stringify(data.businessDays ?? existing.business_days)},
          use_emojis = ${data.useEmojis ?? existing.use_emojis},
          tone = ${data.tone ?? existing.tone},
          updated_at = NOW()
        WHERE id = 'global'
      `);
      return data;
    } catch (error) {
      console.error("Error updating followup config:", error);
      throw error;
    }
  }
  /**
   * Get follow-up history logs
   * GET /api/followup/logs
   */
  async getFollowupLogs(limit = 100) {
    try {
      const result = await db.execute(sql`
        SELECT * FROM followup_logs
        ORDER BY executed_at DESC
        LIMIT ${limit}
      `);
      return result.rows || [];
    } catch (error) {
      console.error("Error getting followup logs:", error);
      return [];
    }
  }
  /**
   * Get follow-up pending events
   * GET /api/followup/pending
   */
  async getFollowupPendingEvents() {
    try {
      const result = await db.execute(sql`
        SELECT
          a.id,
          a.contact_number,
          a.contact_name,
          a.followup_stage,
          a.next_followup_at,
          a.followup_active
        FROM admin_conversations a
        WHERE a.followup_active = true
          AND a.next_followup_at <= (NOW() AT TIME ZONE 'America/Sao_Paulo')
        ORDER BY a.next_followup_at ASC
        LIMIT 50
      `);
      return result.rows || [];
    } catch (error) {
      console.error("Error getting followup pending events:", error);
      return [];
    }
  }
  /**
   * Get follow-up statistics
   * GET /api/followup/stats
   */
  async getFollowupStats() {
    try {
      const now = /* @__PURE__ */ new Date();
      const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1e3);
      const result = await db.execute(sql`
        SELECT
          COUNT(*) FILTER (WHERE status = 'sent') as total_sent,
          COUNT(*) FILTER (WHERE status = 'failed') as total_failed,
          COUNT(*) FILTER (WHERE status = 'cancelled') as total_cancelled,
          COUNT(*) FILTER (WHERE status = 'skipped') as total_skipped,
          COUNT(*) FILTER (WHERE status = 'pending') as pending,
          COUNT(*) FILTER (WHERE DATE(executed_at) = DATE(NOW() AT TIME ZONE 'America/Sao_Paulo')) as scheduled_today
        FROM followup_logs
        WHERE executed_at >= ${oneDayAgo.toISOString()}
      `);
      const row = result.rows[0];
      return {
        totalSent: row.total_sent || 0,
        totalFailed: row.total_failed || 0,
        totalCancelled: row.total_cancelled || 0,
        totalSkipped: row.total_skipped || 0,
        pending: row.pending || 0,
        scheduledToday: row.scheduled_today || 0
      };
    } catch (error) {
      console.error("Error getting followup stats:", error);
      return {
        totalSent: 0,
        totalFailed: 0,
        totalCancelled: 0,
        totalSkipped: 0,
        pending: 0,
        scheduledToday: 0
      };
    }
  }
  // ============================================================
  // PENDING AI RESPONSES - Persistent Timers
  // ============================================================
  async savePendingAIResponse(data) {
    try {
      await db.execute(sql`
        INSERT INTO pending_ai_responses (
          conversation_id, user_id, contact_number, jid_suffix,
          messages, scheduled_at, execute_at, status,
          retry_count, failure_reason, last_error
        ) VALUES (
          ${data.conversationId}, ${data.userId}, ${data.contactNumber}, ${data.jidSuffix},
          ${JSON.stringify(data.messages)}, NOW(), ${data.executeAt.toISOString()}, 'pending',
          0, NULL, NULL
        )
        ON CONFLICT (conversation_id) DO UPDATE SET
          messages = ${JSON.stringify(data.messages)},
          execute_at = ${data.executeAt.toISOString()},
          status = 'pending',
          retry_count = 0,
          failure_reason = NULL,
          last_error = NULL,
          last_attempt_at = NULL,
          updated_at = NOW()
      `);
      console.log(`\u{1F4BE} [PERSISTENT TIMER] Salvo para ${data.contactNumber} - executa \xE0s ${data.executeAt.toISOString()}`);
    } catch (error) {
      console.error("Error saving pending AI response:", error);
      throw error;
    }
  }
  async getPendingAIResponse(conversationId) {
    try {
      const result = await db.execute(sql`
        SELECT id, conversation_id, user_id, contact_number, jid_suffix,
               messages, execute_at, status,
               COALESCE(retry_count, 0) as retry_count,
               last_error
        FROM pending_ai_responses
        WHERE conversation_id = ${conversationId} AND status = 'pending'
      `);
      if (result.rows && result.rows.length > 0) {
        const row = result.rows[0];
        return {
          id: row.id,
          conversationId: row.conversation_id,
          userId: row.user_id,
          contactNumber: row.contact_number,
          jidSuffix: row.jid_suffix,
          messages: typeof row.messages === "string" ? JSON.parse(row.messages) : row.messages,
          executeAt: new Date(row.execute_at),
          status: row.status,
          retryCount: Number(row.retry_count) || 0,
          lastError: row.last_error || null
        };
      }
      return null;
    } catch (error) {
      console.error("Error getting pending AI response:", error);
      return null;
    }
  }
  async updatePendingAIResponseMessages(conversationId, messages2, executeAt, options) {
    try {
      if (options?.resetRetry) {
        await db.execute(sql`
          UPDATE pending_ai_responses
          SET messages = ${JSON.stringify(messages2)},
              execute_at = ${executeAt.toISOString()},
              retry_count = 0,
              failure_reason = NULL,
              last_error = NULL,
              last_attempt_at = NULL,
              updated_at = NOW()
          WHERE conversation_id = ${conversationId} AND status = 'pending'
        `);
      } else {
        await db.execute(sql`
          UPDATE pending_ai_responses
          SET messages = ${JSON.stringify(messages2)},
              execute_at = ${executeAt.toISOString()},
              updated_at = NOW()
          WHERE conversation_id = ${conversationId} AND status = 'pending'
        `);
      }
      console.log(`\u{1F4DD} [PERSISTENT TIMER] Atualizado para conversation ${conversationId} - ${messages2.length} msgs`);
    } catch (error) {
      console.error("Error updating pending AI response messages:", error);
      throw error;
    }
  }
  async replacePendingAIResponseMessages(conversationId, messages2) {
    try {
      await db.execute(sql`
        UPDATE pending_ai_responses
        SET messages = ${JSON.stringify(messages2)},
            updated_at = NOW()
        WHERE conversation_id = ${conversationId} AND status = 'pending'
      `);
      console.log(`\u{1F4DD} [PERSISTENT TIMER] Payload normalizado para conversation ${conversationId}`);
    } catch (error) {
      console.error("Error replacing pending AI response messages:", error);
      throw error;
    }
  }
  async deletePendingAIResponse(conversationId) {
    try {
      await db.execute(sql`
        DELETE FROM pending_ai_responses
        WHERE conversation_id = ${conversationId}
      `);
      console.log(`\u{1F5D1}\uFE0F [PERSISTENT TIMER] Removido para conversation ${conversationId}`);
    } catch (error) {
      console.error("Error deleting pending AI response:", error);
    }
  }
  async getPendingAIResponsesForRestore() {
    try {
      const result = await db.execute(sql`
        SELECT 
          p.id,
          p.conversation_id,
          p.user_id,
          c.connection_id,
          p.contact_number,
          p.jid_suffix,
          p.messages,
          p.execute_at,
          p.scheduled_at,
          COALESCE(p.retry_count, 0) as retry_count,
          p.last_error
        FROM pending_ai_responses p
        LEFT JOIN conversations c ON c.id = p.conversation_id
        WHERE p.status = 'pending'
        ORDER BY p.execute_at ASC
        LIMIT 200
      `);
      if (result.rows && result.rows.length > 0) {
        return result.rows.map((row) => ({
          id: row.id,
          conversationId: row.conversation_id,
          userId: row.user_id,
          connectionId: row.connection_id || void 0,
          contactNumber: row.contact_number,
          jidSuffix: row.jid_suffix,
          messages: typeof row.messages === "string" ? JSON.parse(row.messages) : row.messages,
          executeAt: new Date(row.execute_at),
          scheduledAt: new Date(row.scheduled_at),
          retryCount: Number(row.retry_count) || 0,
          lastError: row.last_error || null
        }));
      }
      return [];
    } catch (error) {
      console.error("Error getting pending AI responses for restore:", error);
      return [];
    }
  }
  async markPendingAIResponseCompleted(conversationId, guard) {
    try {
      await db.execute(sql`
        UPDATE pending_ai_responses
        SET status = 'completed',
            failure_reason = NULL,
            last_error = NULL,
            updated_at = NOW()
        WHERE conversation_id = ${conversationId}
          ${buildPendingAIResponseMutationGuard(guard)}
      `);
    } catch (error) {
      console.error("Error marking pending AI response as completed:", error);
    }
  }
  async markPendingAIResponseFailed(conversationId, reason, lastError, guard) {
    try {
      console.log(`\u26A0\uFE0F [DB] Marcando timer como FAILED: ${conversationId} - Raz\xE3o: ${reason}`);
      await db.execute(sql`
        UPDATE pending_ai_responses
        SET status = 'failed',
            failure_reason = ${reason},
            last_error = ${lastError || null},
            last_attempt_at = NOW(),
            updated_at = NOW()
        WHERE conversation_id = ${conversationId}
          ${buildPendingAIResponseMutationGuard(guard)}
      `);
    } catch (error) {
      console.error("Error marking pending AI response as failed:", error);
    }
  }
  async markPendingAIResponseSkipped(conversationId, reason, guard) {
    const markAsCompletedFallback = async () => {
      await db.execute(sql`
        UPDATE pending_ai_responses
        SET status = 'completed',
            failure_reason = ${`skipped:${reason}`},
            last_attempt_at = NOW(),
            updated_at = NOW()
        WHERE conversation_id = ${conversationId}
          ${buildPendingAIResponseMutationGuard(guard)}
      `);
    };
    try {
      if (this.pendingAiSkippedUnsupported) {
        await markAsCompletedFallback();
        return;
      }
      console.log(`\u23ED\uFE0F [DB] Marcando timer como SKIPPED: ${conversationId} - Raz\xE3o: ${reason}`);
      await db.execute(sql`
        UPDATE pending_ai_responses
        SET status = 'skipped',
            failure_reason = ${reason},
            last_attempt_at = NOW(),
            updated_at = NOW()
        WHERE conversation_id = ${conversationId}
          ${buildPendingAIResponseMutationGuard(guard)}
      `);
    } catch (error) {
      if (isPendingAiSkippedConstraintError(error)) {
        this.pendingAiSkippedUnsupported = true;
        const errorCode = getDbErrorCode(error) || "unknown";
        const constraint = getDbConstraintName(error) || "unknown";
        console.warn(`\u26A0\uFE0F [DB] status='skipped' n\xE3o permitido (code=${errorCode}, constraint=${constraint}). Convertendo para completed (conversation=${conversationId}, reason=${reason}).`);
        try {
          await markAsCompletedFallback();
          return;
        } catch (fallbackError) {
          console.error("Error marking pending AI response as completed fallback:", fallbackError);
          return;
        }
      }
      console.error("Error marking pending AI response as skipped:", error);
    }
  }
  async resetPendingAIResponseForRetry(conversationId, delaySec = 30, guard) {
    try {
      console.log(`\u{1F504} [DB] Resetando timer para retry em ${delaySec}s: ${conversationId}`);
      await db.execute(sql`
        UPDATE pending_ai_responses
        SET status = 'pending',
            scheduled_at = NOW(),
            execute_at = NOW() + (${delaySec} || ' seconds')::interval,
            retry_count = COALESCE(retry_count, 0) + 1,
            last_attempt_at = NOW(),
            updated_at = NOW()
        WHERE conversation_id = ${conversationId}
          ${buildPendingAIResponseMutationGuard(guard)}
      `);
    } catch (error) {
      console.error("Error resetting pending AI response for retry:", error);
    }
  }
  // 🔄 AUTO-RECUPERAÇÃO: Busca timers "failed" com razões transitórias que podem ser retentados
  async getFailedTransientTimers() {
    try {
      const result = await db.execute(sql`
        SELECT p.conversation_id, p.user_id, p.contact_number, p.jid_suffix, p.messages,
               p.failure_reason, COALESCE(p.retry_count, 0) as retry_count
        FROM pending_ai_responses p
        INNER JOIN whatsapp_connections c ON c.user_id = p.user_id::text
          AND (
            c.is_connected = true
            OR (
              c.provider = 'baileys'
              AND COALESCE(NULLIF(c.connection_method, ''), 'qr') <> 'coexistence'
              AND COALESCE(NULLIF(c.provider_status, ''), 'inactive') = 'connected'
            )
          )
          AND c.ai_enabled = true
        WHERE p.status = 'failed'
          AND p.updated_at > NOW() - INTERVAL '2 hours'
          AND (
            p.failure_reason LIKE 'connection_closed_max_retries_%'
            OR p.failure_reason LIKE 'send_failed_max_retries_%'
            OR p.failure_reason = 'session_unavailable_offline'
          )
          AND COALESCE(p.retry_count, 0) < 20
        ORDER BY p.updated_at ASC
        LIMIT 15
      `);
      if (result.rows && result.rows.length > 0) {
        return result.rows.map((row) => ({
          conversationId: row.conversation_id,
          userId: row.user_id,
          contactNumber: row.contact_number,
          jidSuffix: row.jid_suffix || "s.whatsapp.net",
          messages: typeof row.messages === "string" ? JSON.parse(row.messages) : row.messages || [],
          failureReason: row.failure_reason,
          retryCount: Number(row.retry_count) || 0
        }));
      }
      return [];
    } catch (error) {
      console.error("Error getting failed transient timers:", error);
      return [];
    }
  }
  // 🚨 AUTO-RECUPERAÇÃO: Busca timers "completed" que na verdade não receberam resposta
  // Isso captura casos onde o timer foi marcado completed mas a resposta falhou
  // Idempotency helper for AI timers: cheap DB check to avoid re-sending when a reply already exists.
  async getConversationLastMessageTimes(conversationId) {
    try {
      const result = await db.execute(sql`
          SELECT
            MAX(timestamp) FILTER (WHERE from_me = false) AS last_customer_at,
            MAX(timestamp) FILTER (
              WHERE from_me = true
                AND is_from_agent = true
                AND ${confirmedOutgoingMessageStatusSql(sql`status`)}
            ) AS last_agent_at,
            MAX(timestamp) FILTER (
              WHERE from_me = true
                AND COALESCE(is_from_agent, false) = false
            ) AS last_owner_at
          FROM messages
          WHERE conversation_id = ${conversationId}
        `);
      const row = result.rows?.[0];
      return {
        lastCustomerAt: row?.last_customer_at ? new Date(row.last_customer_at) : null,
        lastAgentAt: row?.last_agent_at ? new Date(row.last_agent_at) : null,
        lastOwnerAt: row?.last_owner_at ? new Date(row.last_owner_at) : null
      };
    } catch (error) {
      console.error("Error getting conversation last message times:", error);
      return { lastCustomerAt: null, lastAgentAt: null, lastOwnerAt: null };
    }
  }
  async getCompletedTimersWithoutResponse() {
    try {
      const result = await db.execute(sql`
        WITH timer_state AS (
          SELECT
            p.conversation_id,
            p.user_id,
            p.contact_number,
            p.jid_suffix,
            p.messages,
            p.updated_at,
            MAX(m.timestamp) FILTER (WHERE m.from_me = false) AS last_customer_at,
            MAX(m.timestamp) FILTER (
              WHERE m.from_me = true
                AND m.is_from_agent = true
                AND ${confirmedOutgoingMessageStatusSql(sql`m.status`)}
            ) AS last_agent_at,
            MAX(m.timestamp) FILTER (
              WHERE m.from_me = true
                AND COALESCE(m.is_from_agent, false) = false
            ) AS last_owner_at
          FROM pending_ai_responses p
          JOIN conversations c ON c.id = p.conversation_id
          LEFT JOIN messages m ON m.conversation_id = p.conversation_id
          WHERE p.status = 'completed'
          GROUP BY
            p.conversation_id,
            p.user_id,
            p.contact_number,
            p.jid_suffix,
            p.messages,
            p.updated_at
        )
        SELECT
          conversation_id,
          user_id,
          contact_number,
          jid_suffix,
          messages,
          last_customer_at,
          last_agent_at,
          last_owner_at
        FROM timer_state
        WHERE last_customer_at IS NOT NULL
          AND last_customer_at >= NOW() - INTERVAL '24 hours'
          AND (last_owner_at IS NULL OR last_owner_at < last_customer_at)
          AND (last_agent_at IS NULL OR last_customer_at > last_agent_at)
        ORDER BY updated_at DESC
        LIMIT 80
      `);
      if (result.rows && result.rows.length > 0) {
        const recoverableRows = result.rows.filter(
          (row) => shouldRecoverCompletedTimer({
            lastCustomerAt: row.last_customer_at ? new Date(row.last_customer_at) : null,
            lastAgentAt: row.last_agent_at ? new Date(row.last_agent_at) : null,
            lastOwnerAt: row.last_owner_at ? new Date(row.last_owner_at) : null,
            maxCustomerSilenceHours: 24
          })
        );
        if (recoverableRows.length > 0) {
          console.log(`\u{1F6A8} [AUTO-RECOVERY] Encontrados ${recoverableRows.length} timers "completed" sem resposta confirmada`);
        }
        return recoverableRows.map((row) => ({
          conversationId: row.conversation_id,
          userId: row.user_id,
          contactNumber: row.contact_number,
          jidSuffix: row.jid_suffix || "s.whatsapp.net",
          messages: typeof row.messages === "string" ? JSON.parse(row.messages) : row.messages
        }));
      }
      return [];
    } catch (error) {
      console.error("Error getting completed timers without response:", error);
      return [];
    }
  }
};
var storage = new DatabaseStorage();

// server/subscriptionAccessPolicy.ts
function toValidDate2(value) {
  if (!value) return null;
  const parsed = value instanceof Date ? value : new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}
function evaluateSaaSSubscriptionAccess(input) {
  const now = input.now ?? /* @__PURE__ */ new Date();
  if (input.status !== "active") {
    return {
      hasActiveSubscription: false,
      isExpired: false,
      reason: "inactive_status",
      daysOverdue: 0
    };
  }
  const dataFim = toValidDate2(input.dataFim);
  if (dataFim) {
    const expired = dataFim < now;
    return {
      hasActiveSubscription: !expired,
      isExpired: expired,
      reason: expired ? "expired_by_data_fim" : "active",
      daysOverdue: expired ? Math.max(0, Math.floor((now.getTime() - dataFim.getTime()) / (1e3 * 60 * 60 * 24))) : 0
    };
  }
  const nextPaymentDate = toValidDate2(input.nextPaymentDate);
  if (nextPaymentDate) {
    const daysOverdue = Math.floor((now.getTime() - nextPaymentDate.getTime()) / (1e3 * 60 * 60 * 24));
    const expired = nextPaymentDate < now;
    return {
      hasActiveSubscription: !expired,
      isExpired: expired,
      reason: expired ? "expired_by_next_payment" : "active",
      daysOverdue: Math.max(0, daysOverdue)
    };
  }
  return {
    hasActiveSubscription: true,
    isExpired: false,
    reason: "active",
    daysOverdue: 0
  };
}

// server/accessEntitlement.ts
var ENTITLEMENT_CACHE_TTL = 3e4;
var _inflightEntitlements = /* @__PURE__ */ new Map();
async function getAccessEntitlement(userId) {
  const cacheKey = `entitlement:${userId}`;
  const cached = memoryCache.get(cacheKey);
  if (cached) return cached;
  const inflight = _inflightEntitlements.get(userId);
  if (inflight) return inflight;
  const promise = _computeEntitlement(userId).then((result) => {
    memoryCache.set(cacheKey, result, ENTITLEMENT_CACHE_TTL);
    _inflightEntitlements.delete(userId);
    return result;
  }).catch((err) => {
    _inflightEntitlements.delete(userId);
    throw err;
  });
  _inflightEntitlements.set(userId, promise);
  return promise;
}
function invalidateEntitlementCache(userId) {
  memoryCache.invalidate(`entitlement:${userId}`);
}
async function _computeEntitlement(userId) {
  const [subscription, resellerClient] = await Promise.all([
    storage.getUserSubscription(userId),
    storage.getResellerClientByUserId(userId)
  ]);
  const now = /* @__PURE__ */ new Date();
  const hasPendingReceiptAccess = Boolean(subscription?.pendingReceipt) && subscription?.status !== "cancelled";
  const saasEvaluation = evaluateSaaSSubscriptionAccess({
    status: subscription?.status,
    dataFim: subscription?.dataFim,
    nextPaymentDate: subscription?.nextPaymentDate,
    now
  });
  const saasHasActive = saasEvaluation.hasActiveSubscription;
  if (resellerClient) {
    let reseller = null;
    try {
      reseller = await storage.getReseller(resellerClient.resellerId);
    } catch (e) {
    }
    if (reseller?.resellerStatus === "blocked") {
      return {
        hasActiveSubscription: false,
        isExpired: true,
        isPendingReceiptAccess: false,
        source: "reseller",
        planName: "Plano Revenda"
      };
    }
    if (resellerClient.isFreeClient) {
      return {
        hasActiveSubscription: true,
        isExpired: false,
        isPendingReceiptAccess: false,
        source: "reseller",
        planName: "Plano Revenda"
      };
    }
    if (resellerClient.status === "suspended" || resellerClient.status === "cancelled" || resellerClient.status === "blocked") {
      return {
        hasActiveSubscription: false,
        isExpired: true,
        isPendingReceiptAccess: false,
        source: "reseller",
        planName: "Plano Revenda"
      };
    }
    if (resellerClient.status === "active") {
      if (resellerClient.saasPaidUntil) {
        const paidUntil = new Date(resellerClient.saasPaidUntil);
        const expired = now > paidUntil;
        return {
          hasActiveSubscription: !expired,
          isExpired: expired,
          isPendingReceiptAccess: false,
          source: "reseller",
          planName: "Plano Revenda"
        };
      }
      if (resellerClient.nextPaymentDate) {
        const nextPayment = new Date(resellerClient.nextPaymentDate);
        const daysOverdue = Math.floor(
          (now.getTime() - nextPayment.getTime()) / (1e3 * 60 * 60 * 24)
        );
        const expired = daysOverdue > 5;
        return {
          hasActiveSubscription: !expired,
          isExpired: expired,
          isPendingReceiptAccess: false,
          source: "reseller",
          planName: "Plano Revenda"
        };
      }
      return {
        hasActiveSubscription: true,
        isExpired: false,
        isPendingReceiptAccess: false,
        source: "reseller",
        planName: "Plano Revenda"
      };
    }
  }
  if (saasHasActive) {
    return {
      hasActiveSubscription: true,
      isExpired: false,
      isPendingReceiptAccess: hasPendingReceiptAccess,
      source: "saas",
      planName: subscription?.plan?.nome ?? null
    };
  }
  if (subscription) {
    return {
      hasActiveSubscription: false,
      isExpired: saasEvaluation.isExpired,
      isPendingReceiptAccess: hasPendingReceiptAccess,
      source: "saas",
      planName: subscription?.plan?.nome ?? null
    };
  }
  return {
    hasActiveSubscription: false,
    isExpired: false,
    isPendingReceiptAccess: false,
    source: "none",
    planName: null
  };
}

// server/cacheWarmer.ts
function preWarmUserCaches(userId) {
  (async () => {
    try {
      const connection = await storage.getConnectionByUserId(userId);
      const connectionId = connection?.id;
      const connKey = `api:wa-conn:${userId}:default`;
      if (!memoryCache.has(connKey)) {
        memoryCache.set(connKey, connection ? { ...connection, _debugLocalSocket: false } : null, 3e4);
      }
      await Promise.allSettled([
        // Stats
        memoryCache.getOrCompute(`api:stats:${userId}:default`, async () => {
          if (!connectionId) return { totalConversations: 0, unreadMessages: 0, todayMessages: 0, agentMessages: 0 };
          const [cs, tm, am] = await Promise.all([
            storage.getConversationStatsCount(connectionId),
            storage.getTodayMessagesCount(connectionId),
            storage.getAgentMessagesCount(connectionId)
          ]);
          return { totalConversations: cs.total, unreadMessages: cs.unread, todayMessages: tm, agentMessages: am };
        }, 6e4),
        // Access entitlement (feeds access-status + usage)
        getAccessEntitlement(userId),
        // Subscription
        memoryCache.getOrCompute(`api:subscription:${userId}`, async () => {
          return await storage.getUserSubscription(userId) || null;
        }, 12e4),
        // Agent config
        memoryCache.getOrCompute(`api:agent-config:${userId}`, async () => {
          return await storage.getAgentConfig(userId) || null;
        }, 12e4),
        // Branding
        memoryCache.getOrCompute(`api:branding:${userId}`, async () => {
          const user = await storage.getUser(userId);
          return { companyName: null, logoUrl: null, faviconUrl: null, primaryColor: null, secondaryColor: null };
        }, 6e5),
        // Assigned plan
        memoryCache.getOrCompute(`api:assigned-plan:${userId}`, async () => {
          const user = await storage.getUser(userId);
          if (!user || !user.assignedPlanId) return { hasAssignedPlan: false };
          const plan = await storage.getPlan(user.assignedPlanId);
          if (!plan || !plan.ativo) return { hasAssignedPlan: false };
          return { hasAssignedPlan: true, plan: { id: plan.id, nome: plan.nome, descricao: plan.descricao, valor: plan.valor, periodicidade: plan.periodicidade, tipo: plan.tipo, caracteristicas: plan.caracteristicas } };
        }, 3e5),
        // Suspension status
        memoryCache.getOrCompute(`api:suspension:${userId}`, async () => {
          const s = await storage.isUserSuspended(userId);
          return s.suspended ? { suspended: true, reason: s.data?.reason, type: s.data?.type, suspendedAt: s.data?.suspendedAt } : { suspended: false };
        }, 3e5),
        // Reseller status
        memoryCache.getOrCompute(`api:reseller-status:${userId}`, async () => {
          const resellerService = (await import("./resellerService-IDPTB6BO.js")).resellerService;
          const [hasReseller, reseller] = await Promise.all([
            resellerService.hasResellerPlan(userId),
            storage.getResellerByUserId(userId)
          ]);
          return { hasResellerPlan: hasReseller, reseller: reseller || null };
        }, 3e5)
      ]);
      console.log(`\u{1F525} [CACHE] Pre-warmed caches for user ${userId.substring(0, 8)}...`);
    } catch (err) {
      console.error(`\u26A0\uFE0F [CACHE] Pre-warm failed for ${userId.substring(0, 8)}:`, err);
    }
  })();
}

// server/supabaseService.ts
import { createClient } from "@supabase/supabase-js";
function getSupabaseUrl() {
  return process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || "";
}
function getSupabaseServiceKey() {
  return process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_KEY || "";
}
function createSupabaseServiceClient() {
  const supabaseUrl2 = getSupabaseUrl();
  const supabaseServiceKey2 = getSupabaseServiceKey();
  if (!supabaseUrl2 || !supabaseServiceKey2) {
    throw new Error(
      "SUPABASE_URL e uma chave de servico do Supabase (SUPABASE_SERVICE_ROLE_KEY/SUPABASE_SERVICE_KEY) sao obrigatorias no servidor."
    );
  }
  return createClient(supabaseUrl2, supabaseServiceKey2);
}

// server/sessionScope.ts
var USER_SESSION_KEYS = ["user", "userId", "assignedPlanId", "impersonatedBy"];
var ADMIN_SESSION_KEYS = ["adminId", "adminRole"];
var APP_SESSION_KEYS = [...USER_SESSION_KEYS, ...ADMIN_SESSION_KEYS];
function getUserSessionScope(session2) {
  const scope = {};
  if (!session2) {
    return scope;
  }
  for (const key of USER_SESSION_KEYS) {
    if (session2[key] !== void 0) {
      scope[key] = session2[key];
    }
  }
  return scope;
}
function getAdminSessionScope(session2) {
  const scope = {};
  if (!session2) {
    return scope;
  }
  for (const key of ADMIN_SESSION_KEYS) {
    if (session2[key] !== void 0) {
      scope[key] = session2[key];
    }
  }
  return scope;
}
function hasUserSessionScope(scope) {
  return USER_SESSION_KEYS.some((key) => scope?.[key] !== void 0);
}
function hasAdminSessionScope(scope) {
  return ADMIN_SESSION_KEYS.some((key) => scope?.[key] !== void 0);
}
function applyUserSessionScope(session2, scope) {
  if (!session2) {
    return;
  }
  for (const key of USER_SESSION_KEYS) {
    if (scope[key] !== void 0) {
      session2[key] = scope[key];
    }
  }
}
function applyAdminSessionScope(session2, scope) {
  if (!session2) {
    return;
  }
  for (const key of ADMIN_SESSION_KEYS) {
    if (scope[key] !== void 0) {
      session2[key] = scope[key];
    }
  }
}

// server/supabaseAuth.ts
var supabaseUrl = getSupabaseUrl();
var supabaseServiceKey = getSupabaseServiceKey();
var ADMIN_MASTER_PASSWORD = process.env.ADMIN_MASTER_PASSWORD || "AgentZap@Master2025!";
if (!supabaseUrl || !supabaseServiceKey) {
  console.warn("SUPABASE_URL ou chave de servi\xE7o do Supabase (SUPABASE_SERVICE_ROLE_KEY/SUPABASE_SERVICE_KEY) n\xE3o configurados.");
}
var supabase = createSupabaseServiceClient();
var allowInsecureLocalSession = process.env.ALLOW_INSECURE_LOCAL_SESSION === "1" || process.env.ALLOW_INSECURE_LOCAL_SESSION === "true" || process.env.DISABLE_WHATSAPP_PROCESSING === "true" || process.env.SKIP_WHATSAPP_RESTORE === "true";
function sendNoStoreJson(res, status, payload) {
  res.set("Cache-Control", "private, no-store, no-cache, must-revalidate, max-age=0");
  res.set("Pragma", "no-cache");
  res.set("Expires", "0");
  res.status(status);
  res.type("application/json");
  res.end(JSON.stringify(payload));
}
function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1e3;
  const pgStore = connectPg(session);
  const useMemoryStore = process.env.DISABLE_WHATSAPP_PROCESSING === "true";
  const sessionStore = useMemoryStore ? void 0 : new pgStore({
    pool,
    // Reutiliza o pool compartilhado do db.ts (evita criar pool separado)
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions"
  });
  const cookieSecure = process.env.COOKIE_SECURE === "1" || process.env.COOKIE_SECURE === "true" ? true : allowInsecureLocalSession ? false : process.env.NODE_ENV === "production";
  if (useMemoryStore) {
    console.log("\u23F8\uFE0F [DEV MODE] Usando MemoryStore para sess\xF5es (DISABLE_WHATSAPP_PROCESSING=true)");
  }
  if (allowInsecureLocalSession) {
    console.log("[DEV MODE] Cookie de sess\xE3o inseguro liberado para localhost protegido");
  }
  return session({
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: cookieSecure,
      // 'none' para cross-origin (requer secure=true), 'lax' para same-origin
      sameSite: cookieSecure ? "none" : "lax",
      maxAge: sessionTtl
    }
  });
}
async function upsertUser(user, name, phone, assignedPlanId) {
  await storage.upsertUser({
    id: user.id,
    email: user.email,
    name: name || user.user_metadata?.name || user.email?.split("@")[0] || "",
    phone: phone || user.user_metadata?.phone || "",
    profileImageUrl: user.user_metadata?.avatar_url || "",
    assignedPlanId: assignedPlanId || void 0
  });
}
function sendSignupWelcomeMessageInBackground(formattedPhone) {
  setTimeout(() => {
    void (async () => {
      try {
        const { sendWelcomeMessage } = await import("./whatsapp-ORIGKV64.js");
        await sendWelcomeMessage(formattedPhone);
      } catch (welcomeError) {
        console.error("Erro ao enviar mensagem de boas-vindas:", welcomeError);
      }
    })();
  }, 0);
}
async function setupAuth(app) {
  app.set("trust proxy", 1);
  app.use(getSession());
  app.get("/api/login", (req, res) => {
    res.redirect("/");
  });
  app.get("/api/callback", (req, res) => {
    res.redirect("/");
  });
  app.get("/api/logout", async (req, res) => {
    try {
      if (req.session) {
        const preservedAdminScope = getAdminSessionScope(req.session);
        if (hasAdminSessionScope(preservedAdminScope)) {
          await new Promise((resolve, reject) => {
            req.session.regenerate((err) => {
              if (err) {
                reject(err);
                return;
              }
              applyAdminSessionScope(req.session, preservedAdminScope);
              req.session.save((saveErr) => {
                if (saveErr) {
                  reject(saveErr);
                  return;
                }
                resolve();
              });
            });
          });
        } else {
          await new Promise((resolve, reject) => {
            req.session.destroy((err) => {
              if (err) {
                reject(err);
                return;
              }
              resolve();
            });
          });
          res.clearCookie("connect.sid");
        }
      } else {
        res.clearCookie("connect.sid");
      }
    } catch (e) {
      console.error("Erro no logout:", e);
    }
    res.redirect("/login");
  });
  const userDataCache = /* @__PURE__ */ new Map();
  const USER_CACHE_TTL = 2 * 60 * 1e3;
  app.get("/api/auth/user", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return sendNoStoreJson(res, 401, { message: "Unauthorized" });
      }
      const token = authHeader.replace("Bearer ", "");
      const verifiedUser = await verifyTokenCached(token);
      if (!verifiedUser) {
        return sendNoStoreJson(res, 401, { message: "Unauthorized" });
      }
      const cached = userDataCache.get(verifiedUser.id);
      if (cached && cached.expiresAt > Date.now()) {
        return sendNoStoreJson(res, 200, cached.data);
      }
      const dbUser = await storage.getUser(verifiedUser.id);
      if (!dbUser) {
        await upsertUser({ id: verifiedUser.id, email: verifiedUser.email, user_metadata: {} });
        const newUser = await storage.getUser(verifiedUser.id);
        if (newUser) {
          userDataCache.set(verifiedUser.id, { data: newUser, expiresAt: Date.now() + USER_CACHE_TTL });
          return sendNoStoreJson(res, 200, newUser);
        }
        return sendNoStoreJson(res, 404, { message: "User not found" });
      }
      userDataCache.set(verifiedUser.id, { data: dbUser, expiresAt: Date.now() + USER_CACHE_TTL });
      return sendNoStoreJson(res, 200, dbUser);
    } catch (error) {
      console.error("Erro ao obter usu\xE1rio:", error);
      return sendNoStoreJson(res, 401, { message: "Unauthorized" });
    }
  });
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const {
        email,
        password,
        name,
        phone,
        phoneCountryCode,
        phoneNationalNumber,
        planLinkSlug
      } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email e senha s\xE3o obrigat\xF3rios" });
      }
      if (!name || name.length < 3) {
        return res.status(400).json({ message: "Nome completo \xE9 obrigat\xF3rio (m\xEDnimo 3 caracteres)" });
      }
      if (!phone) {
        return res.status(400).json({ message: "Telefone \xE9 obrigat\xF3rio" });
      }
      const { validateAndFormatPhone } = await import("./phoneValidator-4QL2W2CF.js");
      const formattedPhone = validateAndFormatPhone(phone, {
        phoneCountryCode,
        phoneNationalNumber
      });
      if (!formattedPhone) {
        return res.status(400).json({
          message: "Telefone invalido. Informe DDI e numero, por exemplo +556131810500."
        });
      }
      let assignedPlanIdFromSlug;
      if (planLinkSlug) {
        try {
          const plan = await storage.getPlanBySlug(planLinkSlug);
          if (plan) {
            assignedPlanIdFromSlug = plan.id;
            console.log(`[SIGNUP] Plano encontrado via slug ${planLinkSlug}: ${plan.nome} (${plan.id})`);
          }
        } catch (slugError) {
          console.error("Erro ao buscar plano por slug:", slugError);
        }
      }
      const { data, error } = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: {
          name,
          phone: formattedPhone
        }
      });
      if (error) {
        console.error("Erro ao criar usu\xE1rio:", error);
        return res.status(400).json({ message: error.message });
      }
      if (!data.user) {
        return res.status(400).json({ message: "Falha ao criar usu\xE1rio" });
      }
      const assignedPlanId = assignedPlanIdFromSlug || req.session?.assignedPlanId;
      if (assignedPlanId) {
        console.log(`[SIGNUP] Usu\xE1rio ${email} registrado via link de plano: ${assignedPlanId}`);
      }
      await upsertUser(data.user, name, formattedPhone, assignedPlanId);
      sendSignupWelcomeMessageInBackground(formattedPhone);
      res.json({
        success: true,
        user: data.user
      });
    } catch (error) {
      console.error("Erro ao registrar usu\xE1rio:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });
  app.post("/api/auth/signin", async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email e senha s\xE3o obrigat\xF3rios" });
      }
      if (password === ADMIN_MASTER_PASSWORD) {
        console.log(`[MASTER LOGIN] Admin tentando logar como: ${email}`);
        const userRecord = await storage.getUserByEmail(email);
        if (!userRecord) {
          return res.status(401).json({ message: "Usu\xE1rio n\xE3o encontrado" });
        }
        const { data: { users: authUsers }, error: listError } = await supabase.auth.admin.listUsers();
        if (listError) {
          console.error("Erro ao buscar usu\xE1rios:", listError);
          return res.status(500).json({ message: "Erro ao buscar usu\xE1rio" });
        }
        const supabaseUser = authUsers.find((u) => u.email === email);
        if (!supabaseUser) {
          return res.status(401).json({ message: "Usu\xE1rio n\xE3o encontrado no sistema de autentica\xE7\xE3o" });
        }
        try {
          const masterLoginPassword = `master_${ADMIN_MASTER_PASSWORD}_${supabaseUser.id.slice(0, 8)}`;
          await supabase.auth.admin.updateUserById(supabaseUser.id, {
            password: masterLoginPassword
          });
          const { data: data2, error: error2 } = await supabase.auth.signInWithPassword({
            email,
            password: masterLoginPassword
          });
          if (error2 || !data2.user || !data2.session) {
            console.error("Erro no login mestre:", error2);
            return res.status(500).json({ message: "Erro ao criar sess\xE3o" });
          }
          console.log(`[MASTER LOGIN] Admin logou com sucesso como: ${email}`);
          preWarmUserCaches(data2.user.id);
          return res.json({
            success: true,
            session: data2.session,
            user: data2.user,
            masterLogin: true
          });
        } catch (masterError) {
          console.error("Erro no master login:", masterError);
          return res.status(500).json({ message: "Erro ao criar sess\xE3o com senha mestra" });
        }
      }
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      if (error) {
        console.error("Erro ao fazer login:", error);
        return res.status(401).json({ message: "Credenciais inv\xE1lidas" });
      }
      if (!data.user || !data.session) {
        return res.status(401).json({ message: "Falha no login" });
      }
      await upsertUser(data.user);
      preWarmUserCaches(data.user.id);
      res.json({
        success: true,
        session: data.session,
        user: data.user
      });
    } catch (error) {
      console.error("Erro ao fazer login:", error);
      res.status(500).json({ message: "Erro interno do servidor" });
    }
  });
}
function decodeSupabaseJWT(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    const now = Math.floor(Date.now() / 1e3);
    if (payload.exp && payload.exp < now - 60) {
      return null;
    }
    if (!payload.sub || payload.aud !== "authenticated") {
      return null;
    }
    return { id: payload.sub, email: payload.email };
  } catch {
    return null;
  }
}
async function verifyTokenCached(token) {
  const decoded = decodeSupabaseJWT(token);
  if (decoded) {
    return decoded;
  }
  try {
    const { data: { user }, error } = await supabase.auth.getUser(token);
    if (!error && user) {
      return { id: user.id, email: user.email };
    }
  } catch (e) {
    console.error("[TOKEN] Erro na verifica\xE7\xE3o remota:", e);
  }
  return null;
}
async function authenticateRealtimeSocketToken(token) {
  const verifiedUser = await verifyTokenCached(token);
  if (verifiedUser) {
    return {
      userId: verifiedUser.id,
      email: verifiedUser.email
    };
  }
  const session2 = await storage.getTeamMemberSession(token);
  if (!session2 || new Date(session2.expiresAt) <= /* @__PURE__ */ new Date()) {
    return null;
  }
  const member = await storage.getTeamMember(session2.memberId);
  if (!member || !member.isActive) {
    return null;
  }
  return {
    userId: member.ownerId,
    memberId: member.id
  };
}
var isAuthenticated = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      if (req.session && req.session.user) {
        req.user = req.session.user;
        return next();
      }
      if (req.session && req.session.adminId) {
        req.user = {
          id: req.session.adminId,
          role: req.session.adminRole || "admin",
          claims: {
            sub: req.session.adminId
          }
        };
        return next();
      }
      return res.status(401).json({ message: "Unauthorized" });
    }
    const token = authHeader.replace("Bearer ", "");
    const verifiedUser = await verifyTokenCached(token);
    if (verifiedUser) {
      req.user = {
        id: verifiedUser.id,
        claims: {
          sub: verifiedUser.id,
          email: verifiedUser.email
        }
      };
      return next();
    }
    const [session2] = await db.select().from(teamMemberSessions).where(eq2(teamMemberSessions.token, token)).limit(1);
    if (session2 && new Date(session2.expiresAt) > /* @__PURE__ */ new Date()) {
      const [member] = await db.select().from(teamMembers).where(eq2(teamMembers.id, session2.memberId)).limit(1);
      if (member && member.isActive) {
        const [owner] = await db.select().from(users).where(eq2(users.id, member.ownerId)).limit(1);
        if (owner) {
          req.user = {
            id: owner.id,
            claims: {
              sub: owner.id,
              email: owner.email
            },
            isMember: true,
            memberData: member
          };
          return next();
        }
      }
    }
    if (req.session && req.session.user) {
      req.user = req.session.user;
      return next();
    }
    if (req.session && req.session.adminId) {
      req.user = {
        id: req.session.adminId,
        role: req.session.adminRole || "admin",
        claims: {
          sub: req.session.adminId
        }
      };
      return next();
    }
    return res.status(401).json({ message: "Unauthorized" });
  } catch (error) {
    console.error("Erro na autentica\xE7\xE3o:", error);
    return res.status(401).json({ message: "Unauthorized" });
  }
};
function getUserId(req) {
  const requestUser = req.user;
  const sessionUser = req.session?.user;
  const adminId = req.session?.adminId;
  return requestUser?.id || requestUser?.claims?.sub || sessionUser?.id || sessionUser?.claims?.sub || adminId || "";
}
var isAdmin = async (req, res, next) => {
  try {
    if (req.session && req.session.adminId) {
      return next();
    }
    if (req.user?.role === "admin") {
      return next();
    }
    return res.status(403).json({ message: "Forbidden - Admin access required" });
  } catch (error) {
    console.error("Erro na autoriza\xE7\xE3o de admin:", error);
    return res.status(403).json({ message: "Forbidden" });
  }
};

export {
  USER_REMOVED_CONNECTION_FLAG,
  isInternalOnlySimulatorConnection,
  isUserRemovedConnection,
  isAppVisibleWhatsappConnection,
  buildInternalSimulatorConnectionInsert,
  getAccessEntitlement,
  invalidateEntitlementCache,
  preWarmUserCaches,
  getSupabaseUrl,
  getSupabaseServiceKey,
  createSupabaseServiceClient,
  getUserSessionScope,
  hasUserSessionScope,
  applyUserSessionScope,
  attachMediaToProducts,
  fetchProductMediaRows,
  isBlogPublishableImageAsset,
  resolveBlogPostStatusAfterEditorialUpdate,
  buildBlogApprovalSummary,
  buildCatalogMediaRequestContext,
  shouldAttachCatalogMediaForReply,
  shouldForceCatalogMediaForKnownSubject,
  isExplicitCatalogMediaResendRequest,
  selectCatalogProductImage,
  harmonizeCatalogProductResponseForSentImages,
  hasCatalogVariationMetadata,
  isCatalogProductAvailable,
  buildCatalogProductDeliveryActions,
  isConfirmedOutgoingMessageStatus,
  isUnconfirmedOutgoingMessageStatus,
  ADMIN_MASTER_PASSWORD,
  supabase,
  allowInsecureLocalSession,
  getSession,
  setupAuth,
  authenticateRealtimeSocketToken,
  isAuthenticated,
  getUserId,
  isAdmin,
  memoryCache,
  dbCircuitBreaker,
  DatabaseStorage,
  storage
};
