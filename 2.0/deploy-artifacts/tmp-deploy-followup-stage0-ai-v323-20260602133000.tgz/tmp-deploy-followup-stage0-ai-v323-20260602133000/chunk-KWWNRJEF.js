import {
  connectWhatsApp,
  ensureManagedPhoneConnectionContinuity,
  ensureUserSessionOperational,
  fetchUserGroups,
  getSession,
  hasPersistedAuthForConnection,
  messageQueueService,
  prepareOutgoingMediaForSend,
  redownloadMedia,
  sendMessage,
  sendMessageToGroups,
  sendUserMediaMessage,
  syncGroupConversationHistoryOnDemand
} from "./chunk-JDBD3TU2.js";
import {
  convertBufferToWhatsAppAudio
} from "./chunk-DH4QIP4D.js";
import {
  isOfficialCoexistenceConnection,
  isPersistedWhatsAppConnectionOperational
} from "./chunk-LYL74IEX.js";
import {
  buildPlainTextWhatsAppPayload,
  centralizedMessageSender_default,
  groupMetadataCache,
  normalizeOutboundTextForCustomer
} from "./chunk-GXAKLONY.js";
import {
  storage
} from "./chunk-7SPF5OKO.js";
import {
  buildWhatsAppJidFromPhone,
  normalizeBrazilWhatsAppPhone
} from "./chunk-YB77ZB3P.js";

// server/whatsappConnectionSessionResolver.ts
function resolveConnectionScopedSession(connection, getSession2, options = {}) {
  const sessionByConnection = getSession2(connection.id);
  if (sessionByConnection) {
    return sessionByConnection;
  }
  if (options.allowUserFallback && connection.userId) {
    return getSession2(connection.userId);
  }
  return void 0;
}

// server/whatsappInstanceApiService.ts
var INSTANCE_QR_MAX_AGE_MS = Math.max(
  Number(process.env.WA_INSTANCE_QR_MAX_AGE_MS || 6e4),
  3e4
);
var INSTANCE_STATUS_RECOVERY_OPEN_TIMEOUT_MS = Math.max(
  Number(process.env.WA_INSTANCE_STATUS_RECOVERY_OPEN_TIMEOUT_MS || 45e3),
  1e4
);
var RECOVERABLE_INSTANCE_PROVIDER_STATUSES = /* @__PURE__ */ new Set([
  "",
  "close",
  "closed",
  "disconnected",
  "not_connected",
  "open_timeout",
  "reconnecting",
  "recovering"
]);
var statusRecoveryInflight = /* @__PURE__ */ new Map();
function isRecord(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function getConnectionQrCodeGeneratedAt(sessionData) {
  if (!isRecord(sessionData)) return null;
  const runtimeDiagnostics = sessionData.runtimeDiagnostics;
  if (!isRecord(runtimeDiagnostics)) return null;
  const lastQrCode = runtimeDiagnostics.lastQrCode;
  if (isRecord(lastQrCode) && typeof lastQrCode.at === "string" && lastQrCode.at.trim()) {
    return lastQrCode.at.trim();
  }
  return null;
}
function isFreshConnectionQrCode(qrCode, generatedAt) {
  if (!qrCode || !generatedAt) return false;
  const generatedAtMs = Date.parse(generatedAt);
  if (!Number.isFinite(generatedAtMs)) return false;
  return Date.now() - generatedAtMs < INSTANCE_QR_MAX_AGE_MS;
}
function shouldRecoverDisconnectedInstanceStatus(providerStatus) {
  return RECOVERABLE_INSTANCE_PROVIDER_STATUSES.has(String(providerStatus || "").trim().toLowerCase());
}
async function hasRecoverablePersistedAuth(connection) {
  if (!shouldRecoverDisconnectedInstanceStatus(connection.providerStatus)) return false;
  return hasPersistedAuthForConnection(connection.userId, connection.id).catch(() => false);
}
function scheduleStatusRecovery(connection) {
  const lastAttempt = statusRecoveryInflight.get(connection.id) || 0;
  if (Date.now() - lastAttempt < 3e4) return;
  statusRecoveryInflight.set(connection.id, Date.now());
  void connectWhatsApp(connection.userId, connection.id, {
    source: "status_recovery",
    openTimeoutMs: INSTANCE_STATUS_RECOVERY_OPEN_TIMEOUT_MS
  }).catch((error) => {
    console.warn(
      `[INSTANCE API] Falha ao recuperar status da instancia ${connection.id}:`,
      error?.message || error
    );
  }).finally(() => {
    setTimeout(() => statusRecoveryInflight.delete(connection.id), 3e4).unref?.();
  });
}
function computeLiveInstanceSnapshot(connection, sessionOverride) {
  const session = sessionOverride || resolveConnectionScopedSession(connection, getSession);
  const socketUser = session?.socket?.user;
  const wsReadyState = session?.socket?.ws?.readyState;
  const hasOperationalSocket = !!(socketUser?.id && (wsReadyState === void 0 || wsReadyState === 1));
  const connectedPhone = socketUser?.id ? socketUser.id.split(":")[0] : connection.phoneNumber || null;
  const persistedConnected = isOfficialCoexistenceConnection(connection) ? isPersistedWhatsAppConnectionOperational(connection) : false;
  const isConnected = hasOperationalSocket || persistedConnected;
  return {
    session,
    connectedPhone,
    socketName: socketUser?.name || null,
    socketLid: socketUser?.lid || null,
    hasOperationalSocket,
    isConnected,
    status: isConnected ? "connected" : "disconnected"
  };
}
function normalizeApiDestination(to) {
  const normalized = normalizeBrazilWhatsAppPhone(String(to || ""));
  const digits = String(normalized || "").replace(/\D/g, "");
  if (!digits) {
    throw new Error("Numero de destino invalido");
  }
  return digits;
}
function buildBrazilReachablePhoneCandidates(value) {
  const normalized = normalizeBrazilWhatsAppPhone(value);
  if (!normalized) {
    return [];
  }
  const candidates = /* @__PURE__ */ new Set([normalized]);
  if (normalized.startsWith("55")) {
    if (normalized.length === 13 && normalized[4] === "9") {
      candidates.add(`${normalized.slice(0, 4)}${normalized.slice(5)}`);
    }
    if (normalized.length === 12) {
      candidates.add(`${normalized.slice(0, 4)}9${normalized.slice(4)}`);
    }
  }
  return Array.from(candidates).filter(Boolean);
}
function extractPhoneDigitsFromJid(value) {
  const normalized = String(value || "").split("@")[0]?.split(":")[0] || "";
  const digits = normalized.replace(/\D/g, "");
  return digits || null;
}
function formatContactCardPhone(value) {
  const normalized = normalizeBrazilWhatsAppPhone(value) || String(value || "").replace(/\D/g, "");
  const digits = String(normalized || "").replace(/\D/g, "");
  if (!digits) {
    throw new Error("Numero do contato invalido");
  }
  return {
    waid: digits,
    formatted: digits.startsWith("+") ? digits : `+${digits}`
  };
}
function buildContactCardPayload(params) {
  const { waid, formatted } = formatContactCardPhone(params.phoneNumber);
  const displayName = String(params.displayName || params.phoneNumber || "Contato").trim() || "Contato";
  const vcardLines = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `FN:${displayName}`
  ];
  if (params.organization) {
    vcardLines.push(`ORG:${String(params.organization).trim()};`);
  }
  vcardLines.push(`TEL;type=CELL;type=VOICE;waid=${waid}:${formatted}`);
  if (params.email) {
    vcardLines.push(`EMAIL;type=INTERNET:${String(params.email).trim()}`);
  }
  if (params.url) {
    vcardLines.push(`URL:${String(params.url).trim()}`);
  }
  vcardLines.push("END:VCARD");
  return {
    displayName,
    contacts: {
      displayName,
      contacts: [{ vcard: vcardLines.join("\n") }]
    }
  };
}
function buildLocationPayload(params) {
  const latitude = Number(params.latitude);
  const longitude = Number(params.longitude);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    throw new Error("Latitude/longitude invalidas");
  }
  return {
    location: {
      degreesLatitude: latitude,
      degreesLongitude: longitude,
      name: params.name ? String(params.name).trim() : void 0,
      address: params.address ? String(params.address).trim() : void 0
    }
  };
}
function normalizeButtonsPayload(params) {
  const body = String(params.body || "").trim();
  if (!body) {
    throw new Error("Texto dos botoes e obrigatorio");
  }
  const buttons = Array.isArray(params.buttons) ? params.buttons.map((button, index) => {
    const title = String(button?.reply?.title || button?.title || "").trim();
    const id = String(button?.reply?.id || button?.id || `option_${index + 1}`).trim();
    if (!title) return null;
    return {
      type: "reply",
      reply: { id, title }
    };
  }).filter(Boolean) : [];
  if (buttons.length === 0) {
    throw new Error("Lista de botoes e obrigatoria");
  }
  return {
    body,
    buttons,
    header: params.header?.text ? { type: "text", text: String(params.header.text).trim() } : void 0,
    footer: params.footer?.text ? { text: String(params.footer.text).trim() } : void 0
  };
}
function normalizeListPayload(params) {
  const body = String(params.body || "").trim();
  const buttonText = String(params.buttonText || "").trim();
  if (!body) {
    throw new Error("Texto da lista e obrigatorio");
  }
  if (!buttonText) {
    throw new Error("buttonText e obrigatorio");
  }
  const sections = Array.isArray(params.sections) ? params.sections.map((section, sectionIndex) => {
    const rows = Array.isArray(section?.rows) ? section.rows.map((row, rowIndex) => {
      const title = String(row?.title || "").trim();
      const id = String(row?.id || `row_${sectionIndex + 1}_${rowIndex + 1}`).trim();
      if (!title) return null;
      return {
        id,
        title,
        description: row?.description ? String(row.description).trim() : void 0
      };
    }).filter(Boolean) : [];
    if (rows.length === 0) {
      return null;
    }
    return {
      title: section?.title ? String(section.title).trim() : void 0,
      rows
    };
  }).filter(Boolean) : [];
  if (sections.length === 0) {
    throw new Error("Secoes da lista sao obrigatorias");
  }
  return {
    body,
    buttonText,
    sections,
    header: params.header?.text ? { type: "text", text: String(params.header.text).trim() } : void 0,
    footer: params.footer?.text ? { text: String(params.footer.text).trim() } : void 0
  };
}
function extractJidSuffix(value) {
  return String(value || "").split("@")[1]?.split(":")[0] || "s.whatsapp.net";
}
async function withValidationTimeout(promise, timeoutMs, label) {
  let timeoutHandle = null;
  return new Promise((resolve, reject) => {
    timeoutHandle = setTimeout(() => {
      reject(new Error(`${label} excedeu ${timeoutMs}ms`));
    }, timeoutMs);
    promise.then(
      (value) => {
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
        }
        resolve(value);
      },
      (error) => {
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
        }
        reject(error);
      }
    );
  });
}
async function validateConversationDestination(params) {
  if (!params.validateDestination) {
    return params.conversation;
  }
  const existingJid = String(params.conversation.remoteJid || "");
  if (existingJid.endsWith("@g.us")) {
    return params.conversation;
  }
  const candidates = buildBrazilReachablePhoneCandidates(
    params.to || params.conversation.contactNumber || params.conversation.remoteJid
  );
  if (candidates.length === 0) {
    throw new Error("Numero de destino invalido");
  }
  const snapshot = computeLiveInstanceSnapshot(params.connection);
  const socket = snapshot.session?.socket;
  if (!socket?.onWhatsApp) {
    throw new Error("Sessao WhatsApp indisponivel para validar o destino");
  }
  let lastError = null;
  for (const candidate of candidates) {
    try {
      const results = await withValidationTimeout(
        socket.onWhatsApp(candidate),
        2e4,
        `Validacao WhatsApp ${candidate}`
      );
      const found = Array.isArray(results) ? results.find((item) => item?.exists && item?.jid) : null;
      if (!found?.jid) {
        continue;
      }
      const remoteJid = String(found.jid);
      const contactNumber = extractPhoneDigitsFromJid(remoteJid) || candidate;
      const updates = {};
      if (params.conversation.remoteJid !== remoteJid) {
        updates.remoteJid = remoteJid;
      }
      if (params.conversation.jidSuffix !== "s.whatsapp.net") {
        updates.jidSuffix = "s.whatsapp.net";
      }
      if (params.conversation.contactNumber !== contactNumber) {
        updates.contactNumber = contactNumber;
      }
      if (!params.conversation.contactName && params.contactName) {
        updates.contactName = params.contactName;
      }
      if (Object.keys(updates).length > 0) {
        await storage.updateConversation(params.conversation.id, updates);
        return {
          ...params.conversation,
          ...updates
        };
      }
      return params.conversation;
    } catch (error) {
      lastError = error;
    }
  }
  const errorDetail = lastError instanceof Error ? ` (${lastError.message})` : "";
  throw new Error(`Numero nao encontrado no WhatsApp: ${candidates.join(", ")}${errorDetail}`);
}
async function resolveValidatedDirectDestination(params) {
  const digits = normalizeApiDestination(params.to);
  const fallbackJid = buildWhatsAppJidFromPhone(digits) || `${digits}@s.whatsapp.net`;
  if (!params.validateDestination) {
    return {
      contactNumber: digits,
      remoteJid: fallbackJid,
      jidSuffix: extractJidSuffix(fallbackJid),
      contactName: params.contactName || digits
    };
  }
  const snapshot = computeLiveInstanceSnapshot(params.connection);
  const socket = snapshot.session?.socket;
  if (!socket?.onWhatsApp) {
    throw new Error("Sessao WhatsApp indisponivel para validar o destino");
  }
  const candidates = buildBrazilReachablePhoneCandidates(params.to || digits);
  let lastError = null;
  for (const candidate of candidates) {
    try {
      const results = await withValidationTimeout(
        socket.onWhatsApp(candidate),
        2e4,
        `Validacao WhatsApp ${candidate}`
      );
      const found = Array.isArray(results) ? results.find((item) => item?.exists && item?.jid) : null;
      if (!found?.jid) {
        continue;
      }
      const remoteJid = String(found.jid);
      return {
        contactNumber: extractPhoneDigitsFromJid(remoteJid) || candidate,
        remoteJid,
        jidSuffix: extractJidSuffix(remoteJid),
        contactName: params.contactName || digits
      };
    } catch (error) {
      lastError = error;
    }
  }
  const errorDetail = lastError instanceof Error ? ` (${lastError.message})` : "";
  throw new Error(`Numero nao encontrado no WhatsApp: ${candidates.join(", ")}${errorDetail}`);
}
async function ensureOperationalSocket(connection, source) {
  const snapshot = computeLiveInstanceSnapshot(connection);
  const continuityConnection = await ensureManagedPhoneConnectionContinuity({
    userId: connection.userId,
    connectionId: connection.id,
    runtimePhoneNumber: snapshot.connectedPhone,
    runtimeIsConnected: snapshot.hasOperationalSocket || connection.isConnected === true
  });
  if (!continuityConnection) {
    throw new Error("Esta instancia esta bloqueada porque o numero pertence a outra conta ativa.");
  }
  const session = await ensureUserSessionOperational(connection.userId, continuityConnection.id, {
    waitMs: 1e4,
    source
  });
  if (!session?.socket) {
    throw new Error("WhatsApp nao conectado para esta instancia");
  }
  return {
    connection: continuityConnection,
    socket: session.socket
  };
}
async function resolveConversationForInstance(connectionId, conversationId) {
  const conversation = await storage.getConversation(conversationId);
  if (!conversation || conversation.connectionId !== connectionId) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  return conversation;
}
async function resolveInstanceMessageRecord(connectionId, conversationId, messageId) {
  await resolveConversationForInstance(connectionId, conversationId);
  const byWhatsAppId = await storage.getMessageByConversationAndMessageId(conversationId, messageId);
  if (byWhatsAppId) {
    return byWhatsAppId;
  }
  const byLocalId = await storage.getMessage(messageId);
  if (byLocalId?.conversationId === conversationId) {
    return byLocalId;
  }
  throw new Error("Mensagem nao encontrada para esta conversa");
}
async function resolveWhatsAppDestination(connection, socket, to) {
  const digits = normalizeApiDestination(to);
  const candidates = buildBrazilReachablePhoneCandidates(to || digits);
  let lastError = null;
  for (const candidate of candidates) {
    try {
      const results = await withValidationTimeout(
        socket.onWhatsApp(candidate),
        2e4,
        `Validacao WhatsApp ${candidate}`
      );
      const found = Array.isArray(results) ? results.find((item) => item?.exists && item?.jid) : null;
      if (!found?.jid) {
        continue;
      }
      const remoteJid = String(found.jid);
      return {
        input: digits,
        exists: true,
        contactNumber: extractPhoneDigitsFromJid(remoteJid) || candidate,
        remoteJid,
        jidSuffix: extractJidSuffix(remoteJid)
      };
    } catch (error) {
      lastError = error;
    }
  }
  if (lastError) {
    console.warn("[INSTANCE API] Falha ao validar destino no WhatsApp:", lastError);
  }
  return {
    input: digits,
    exists: false,
    contactNumber: null,
    remoteJid: null,
    jidSuffix: null
  };
}
async function validateInstanceContact(connection, to) {
  const { connection: operationalConnection, socket } = await ensureOperationalSocket(
    connection,
    `validateInstanceContact:${connection.id}`
  );
  return resolveWhatsAppDestination(operationalConnection, socket, to);
}
async function validateInstanceContactsBatch(connection, phoneNumbers) {
  const { connection: operationalConnection, socket } = await ensureOperationalSocket(
    connection,
    `validateInstanceContactsBatch:${connection.id}`
  );
  const uniqueInputs = Array.from(
    new Set(phoneNumbers.map((item) => String(item || "").trim()).filter(Boolean))
  );
  return Promise.all(
    uniqueInputs.map(
      (phoneNumber) => resolveWhatsAppDestination(operationalConnection, socket, phoneNumber)
    )
  );
}
async function getInstanceContactProfilePicture(connection, to, pictureType = "preview") {
  const { connection: operationalConnection, socket } = await ensureOperationalSocket(
    connection,
    `getInstanceContactProfilePicture:${connection.id}`
  );
  const destination = await resolveWhatsAppDestination(operationalConnection, socket, to);
  if (!destination.exists || !destination.remoteJid) {
    return {
      success: false,
      exists: false,
      pictureUrl: null,
      contactNumber: destination.input,
      remoteJid: null
    };
  }
  const pictureUrl = await socket.profilePictureUrl(destination.remoteJid, pictureType).catch(() => null);
  return {
    success: true,
    exists: true,
    pictureUrl: pictureUrl || null,
    contactNumber: destination.contactNumber,
    remoteJid: destination.remoteJid
  };
}
async function updateInstanceContactBlockStatus(connection, to, action) {
  const { connection: operationalConnection, socket } = await ensureOperationalSocket(
    connection,
    `updateInstanceContactBlockStatus:${connection.id}`
  );
  const destination = await resolveWhatsAppDestination(operationalConnection, socket, to);
  if (!destination.exists || !destination.remoteJid) {
    throw new Error("Numero nao encontrado no WhatsApp");
  }
  await socket.updateBlockStatus(destination.remoteJid, action);
  return {
    success: true,
    action,
    contactNumber: destination.contactNumber,
    remoteJid: destination.remoteJid
  };
}
async function sendInstanceContactPresence(connection, to, presence) {
  const { connection: operationalConnection, socket } = await ensureOperationalSocket(
    connection,
    `sendInstanceContactPresence:${connection.id}`
  );
  const destination = await resolveWhatsAppDestination(operationalConnection, socket, to);
  if (!destination.exists || !destination.remoteJid) {
    throw new Error("Numero nao encontrado no WhatsApp");
  }
  await socket.presenceSubscribe(destination.remoteJid).catch(() => void 0);
  await socket.sendPresenceUpdate(presence, destination.remoteJid);
  return {
    success: true,
    presence,
    contactNumber: destination.contactNumber,
    remoteJid: destination.remoteJid
  };
}
function buildInstanceMessageMediaPayload(connection, message, options) {
  const canRedownload = Boolean(message.mediaType) && Boolean(message.mediaMimeType) && Boolean(message.mediaKey) && Boolean(message.directPath);
  return {
    success: true,
    instanceId: connection.id,
    conversationId: message.conversationId,
    messageId: message.messageId,
    localMessageId: message.id,
    mediaType: message.mediaType || null,
    mediaUrl: message.mediaUrl || null,
    mediaMimeType: message.mediaMimeType || null,
    mediaCaption: message.mediaCaption || null,
    canRedownload,
    redownloaded: options?.redownloaded === true
  };
}
async function getInstanceMessageMedia(connection, conversationId, messageId) {
  const message = await resolveInstanceMessageRecord(connection.id, conversationId, messageId);
  if (!message.mediaType && !message.mediaUrl) {
    throw new Error("Mensagem nao possui midia");
  }
  return buildInstanceMessageMediaPayload(connection, message);
}
async function redownloadInstanceMessageMedia(connection, conversationId, messageId) {
  const message = await resolveInstanceMessageRecord(connection.id, conversationId, messageId);
  if (!message.mediaType) {
    throw new Error("Mensagem nao possui midia");
  }
  if (message.mediaUrl) {
    return buildInstanceMessageMediaPayload(connection, message);
  }
  if (!message.mediaKey || !message.directPath || !message.mediaMimeType) {
    throw new Error("Mensagem nao possui metadados suficientes para redownload");
  }
  const result = await redownloadMedia(
    connection.id,
    message.mediaKey,
    message.directPath,
    message.mediaUrlOriginal || void 0,
    message.mediaType,
    message.mediaMimeType
  );
  if (!result.success || !result.mediaUrl) {
    throw new Error(result.error || "Nao foi possivel rebaixar a midia");
  }
  const updatedMessage = await storage.updateMessage(message.id, {
    mediaUrl: result.mediaUrl
  });
  return buildInstanceMessageMediaPayload(connection, updatedMessage, {
    redownloaded: true
  });
}
async function getInstanceMessageQueue(connection) {
  const stats = messageQueueService.getUserStats(connection.userId);
  const queueStatus = messageQueueService.canSendNow(connection.userId);
  return {
    success: true,
    instanceId: connection.id,
    scope: "account_runtime_shared",
    ...stats,
    canSendNow: queueStatus.canSend,
    waitMs: queueStatus.waitMs,
    reason: queueStatus.reason || null
  };
}
async function clearInstanceMessageQueue(connection) {
  const clearedState = messageQueueService.clearUserQueue(connection.userId);
  const queue = await getInstanceMessageQueue(connection);
  return {
    ...queue,
    cleared: clearedState.cleared,
    wasPending: clearedState.wasPending
  };
}
async function sendTextDirectViaInstance(params) {
  const { connection, socket } = await ensureOperationalSocket(
    params.connection,
    `sendTextDirectViaInstance:${params.connection.id}`
  );
  const destination = await resolveValidatedDirectDestination({
    connection,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const text = normalizeOutboundTextForCustomer(params.text);
  const sentMessage = await socket.sendMessage(
    destination.remoteJid,
    buildPlainTextWhatsAppPayload(text)
  );
  return {
    success: true,
    messageId: sentMessage?.key?.id || null,
    remoteJid: destination.remoteJid,
    contactNumber: destination.contactNumber,
    jidSuffix: destination.jidSuffix
  };
}
async function sendMediaDirectViaInstance(params) {
  const { connection, socket } = await ensureOperationalSocket(
    params.connection,
    `sendMediaDirectViaInstance:${params.connection.id}`
  );
  const destination = await resolveValidatedDirectDestination({
    connection,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const defaultMimeType = params.mimetype || (params.type === "image" ? "image/jpeg" : params.type === "audio" ? "audio/ogg; codecs=opus" : params.type === "video" ? "video/mp4" : "application/octet-stream");
  const { buffer: preparedBuffer } = await prepareOutgoingMediaForSend({
    mediaData: params.data,
    mimeType: defaultMimeType,
    ownerId: connection.userId
  });
  let mediaBuffer = preparedBuffer;
  let mediaMimeType = defaultMimeType;
  if (params.type === "audio") {
    const converted = await convertBufferToWhatsAppAudio(preparedBuffer, mediaMimeType);
    mediaBuffer = converted.buffer;
    mediaMimeType = converted.mimeType;
  }
  let messageContent;
  switch (params.type) {
    case "audio":
      messageContent = {
        audio: mediaBuffer,
        mimetype: mediaMimeType,
        ptt: params.ptt !== false,
        seconds: params.seconds ?? void 0
      };
      break;
    case "image":
      messageContent = {
        image: mediaBuffer,
        mimetype: mediaMimeType,
        caption: params.caption || void 0
      };
      break;
    case "video":
      messageContent = {
        video: mediaBuffer,
        mimetype: mediaMimeType,
        caption: params.caption || void 0
      };
      break;
    case "document":
      messageContent = {
        document: mediaBuffer,
        mimetype: mediaMimeType,
        fileName: params.filename || "document",
        caption: params.caption || void 0
      };
      break;
    default:
      throw new Error(`Tipo de midia nao suportado: ${params.type}`);
  }
  const sentMessage = await socket.sendMessage(destination.remoteJid, messageContent);
  return {
    success: true,
    messageId: sentMessage?.key?.id || null,
    remoteJid: destination.remoteJid,
    contactNumber: destination.contactNumber,
    jidSuffix: destination.jidSuffix
  };
}
async function sendContactDirectViaInstance(params) {
  const { connection, socket } = await ensureOperationalSocket(
    params.connection,
    `sendContactDirectViaInstance:${params.connection.id}`
  );
  const destination = await resolveValidatedDirectDestination({
    connection,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const sentMessage = await socket.sendMessage(
    destination.remoteJid,
    buildContactCardPayload({
      phoneNumber: params.phoneNumber,
      displayName: params.displayName,
      organization: params.organization,
      email: params.email,
      url: params.url
    })
  );
  return {
    success: true,
    messageId: sentMessage?.key?.id || null,
    remoteJid: destination.remoteJid,
    contactNumber: destination.contactNumber,
    jidSuffix: destination.jidSuffix
  };
}
async function sendLocationDirectViaInstance(params) {
  const { connection, socket } = await ensureOperationalSocket(
    params.connection,
    `sendLocationDirectViaInstance:${params.connection.id}`
  );
  const destination = await resolveValidatedDirectDestination({
    connection,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const sentMessage = await socket.sendMessage(
    destination.remoteJid,
    buildLocationPayload({
      latitude: params.latitude,
      longitude: params.longitude,
      name: params.name,
      address: params.address
    })
  );
  return {
    success: true,
    messageId: sentMessage?.key?.id || null,
    remoteJid: destination.remoteJid,
    contactNumber: destination.contactNumber,
    jidSuffix: destination.jidSuffix
  };
}
async function sendButtonsDirectViaInstance(params) {
  const { connection, socket } = await ensureOperationalSocket(
    params.connection,
    `sendButtonsDirectViaInstance:${params.connection.id}`
  );
  const destination = await resolveValidatedDirectDestination({
    connection,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const result = await centralizedMessageSender_default.sendButtons(
    connection.userId,
    destination.remoteJid,
    normalizeButtonsPayload(params),
    socket,
    "manual_admin",
    {
      connectionId: connection.id,
      isOwnerInitiated: true
    }
  );
  return {
    success: result.success,
    messageId: result.messageId || null,
    remoteJid: destination.remoteJid,
    contactNumber: destination.contactNumber,
    jidSuffix: destination.jidSuffix,
    error: result.error || null
  };
}
async function sendListDirectViaInstance(params) {
  const { connection, socket } = await ensureOperationalSocket(
    params.connection,
    `sendListDirectViaInstance:${params.connection.id}`
  );
  const destination = await resolveValidatedDirectDestination({
    connection,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const result = await centralizedMessageSender_default.sendList(
    connection.userId,
    destination.remoteJid,
    normalizeListPayload(params),
    socket,
    "manual_admin",
    {
      connectionId: connection.id,
      isOwnerInitiated: true
    }
  );
  return {
    success: result.success,
    messageId: result.messageId || null,
    remoteJid: destination.remoteJid,
    contactNumber: destination.contactNumber,
    jidSuffix: destination.jidSuffix,
    error: result.error || null
  };
}
async function buildLocalInstanceStatus(connection) {
  const snapshot = computeLiveInstanceSnapshot(connection);
  const isConnected = snapshot.isConnected;
  const hasRecoverableAuth = !isConnected && await hasRecoverablePersistedAuth(connection);
  const qrCodeGeneratedAt = getConnectionQrCodeGeneratedAt(connection.sessionData);
  const qrCode = isFreshConnectionQrCode(connection.qrCode, qrCodeGeneratedAt) ? connection.qrCode || null : null;
  if (hasRecoverableAuth && !qrCode) {
    scheduleStatusRecovery(connection);
  }
  return {
    instanceId: connection.id,
    phoneNumber: snapshot.connectedPhone,
    isConnected,
    qrCode,
    qrCodeGeneratedAt: qrCode ? qrCodeGeneratedAt : null,
    provider: connection.provider || null,
    providerStatus: isConnected ? "connected" : hasRecoverableAuth && !qrCode ? "recovering" : connection.providerStatus || snapshot.status
  };
}
async function buildLocalInstanceDevice(connection) {
  const snapshot = computeLiveInstanceSnapshot(connection);
  return {
    instanceId: connection.id,
    connectedPhone: snapshot.connectedPhone,
    name: snapshot.socketName,
    platform: isOfficialCoexistenceConnection(connection) ? "meta_cloud_api" : "baileys",
    lid: snapshot.socketLid,
    profilePictureUrl: null,
    status: snapshot.status,
    isBusiness: null
  };
}
async function listInstanceConversations(connectionId) {
  return storage.getConversationsByConnectionId(connectionId);
}
async function listInstanceMessages(connectionId, conversationId) {
  const conversation = await storage.getConversation(conversationId);
  if (!conversation || conversation.connectionId !== connectionId) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  return storage.getMessagesByConversationId(conversationId);
}
async function syncInstanceGroupHistory(connectionId, conversationId) {
  const conversation = await storage.getConversation(conversationId);
  if (!conversation || conversation.connectionId !== connectionId) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  return syncGroupConversationHistoryOnDemand({
    connectionId,
    conversationId
  });
}
async function listInstanceContacts(connectionId) {
  return storage.getContactsByConnectionId(connectionId);
}
async function listInstanceGroups(connection) {
  return fetchUserGroups(connection.userId, connection.id);
}
function normalizeGroupParticipant(participant) {
  const id = String(participant?.id || "").trim();
  const phoneNumber = extractPhoneDigitsFromJid(id);
  const adminRole = String(participant?.admin || "").trim();
  return {
    id,
    phoneNumber,
    isAdmin: adminRole === "admin" || adminRole === "superadmin",
    isSuperAdmin: adminRole === "superadmin"
  };
}
function normalizeGroupParticipantTarget(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) {
    throw new Error("Participante invalido");
  }
  if (trimmed.includes("@")) {
    return trimmed;
  }
  const digits = normalizeApiDestination(trimmed);
  return buildWhatsAppJidFromPhone(digits) || `${digits}@s.whatsapp.net`;
}
function buildInstanceGroupDetailsPayload(connection, groupId, metadata) {
  const participants = Array.isArray(metadata?.participants) ? metadata.participants.map(normalizeGroupParticipant).filter((participant) => participant.id) : [];
  const admins = participants.filter((participant) => participant.isAdmin).map((participant) => participant.id);
  return {
    success: true,
    instanceId: connection.id,
    groupId,
    name: String(metadata?.subject || "Grupo sem nome"),
    description: metadata?.desc ? String(metadata.desc) : null,
    owner: metadata?.owner ? String(metadata.owner) : null,
    createdAt: Number.isFinite(Number(metadata?.creation)) ? Number(metadata.creation) : null,
    announce: typeof metadata?.announce === "boolean" ? metadata.announce : null,
    restrict: typeof metadata?.restrict === "boolean" ? metadata.restrict : null,
    participantsCount: participants.length || Number(metadata?.size || 0),
    admins,
    participants
  };
}
async function getInstanceGroupDetails(connection, groupId) {
  const normalizedGroupId = String(groupId || "").trim();
  if (!normalizedGroupId.endsWith("@g.us")) {
    throw new Error("groupId invalido");
  }
  const { socket } = await ensureOperationalSocket(
    connection,
    `getInstanceGroupDetails:${connection.id}`
  );
  const cachedMetadata = groupMetadataCache.get(normalizedGroupId);
  const metadata = cachedMetadata ? {
    id: cachedMetadata.id,
    subject: cachedMetadata.subject,
    participants: cachedMetadata.participants?.map((participantId) => ({
      id: participantId,
      admin: cachedMetadata.admins?.includes(participantId) ? "admin" : void 0
    }))
  } : await socket.groupMetadata(normalizedGroupId);
  if (!cachedMetadata) {
    groupMetadataCache.set(normalizedGroupId, {
      id: normalizedGroupId,
      subject: String(metadata?.subject || "Grupo sem nome"),
      participants: Array.isArray(metadata?.participants) ? metadata.participants.map((participant) => String(participant?.id || "")).filter(Boolean) : [],
      admins: Array.isArray(metadata?.participants) ? metadata.participants.filter((participant) => participant?.admin === "admin" || participant?.admin === "superadmin").map((participant) => String(participant?.id || "")).filter(Boolean) : []
    });
  }
  return buildInstanceGroupDetailsPayload(connection, normalizedGroupId, metadata);
}
async function listInstanceGroupParticipants(connection, groupId) {
  const details = await getInstanceGroupDetails(connection, groupId);
  return {
    success: true,
    instanceId: connection.id,
    groupId: details.groupId,
    items: details.participants
  };
}
async function createInstanceGroup(connection, subject, participants) {
  const trimmedSubject = String(subject || "").trim();
  if (!trimmedSubject) {
    throw new Error("subject is required");
  }
  const normalizedParticipants = Array.from(
    new Set(participants.map(normalizeGroupParticipantTarget))
  );
  if (normalizedParticipants.length === 0) {
    throw new Error("participants is required");
  }
  const { socket } = await ensureOperationalSocket(
    connection,
    `createInstanceGroup:${connection.id}`
  );
  const metadata = await socket.groupCreate(trimmedSubject, normalizedParticipants);
  const groupId = String(metadata?.id || "").trim();
  if (!groupId) {
    throw new Error("Nao foi possivel criar o grupo");
  }
  groupMetadataCache.set(groupId, {
    id: groupId,
    subject: String(metadata?.subject || trimmedSubject),
    participants: Array.isArray(metadata?.participants) ? metadata.participants.map((participant) => String(participant?.id || "")).filter(Boolean) : normalizedParticipants,
    admins: Array.isArray(metadata?.participants) ? metadata.participants.filter((participant) => participant?.admin === "admin" || participant?.admin === "superadmin").map((participant) => String(participant?.id || "")).filter(Boolean) : []
  });
  return buildInstanceGroupDetailsPayload(connection, groupId, metadata);
}
async function leaveInstanceGroup(connection, groupId) {
  const details = await getInstanceGroupDetails(connection, groupId);
  const { socket } = await ensureOperationalSocket(
    connection,
    `leaveInstanceGroup:${connection.id}`
  );
  await socket.groupLeave(details.groupId);
  groupMetadataCache.delete(details.groupId);
  return {
    success: true,
    instanceId: connection.id,
    groupId: details.groupId
  };
}
async function updateInstanceGroupSubject(connection, groupId, subject) {
  const details = await getInstanceGroupDetails(connection, groupId);
  const trimmedSubject = String(subject || "").trim();
  if (!trimmedSubject) {
    throw new Error("subject is required");
  }
  const { socket } = await ensureOperationalSocket(
    connection,
    `updateInstanceGroupSubject:${connection.id}`
  );
  await socket.groupUpdateSubject(details.groupId, trimmedSubject);
  groupMetadataCache.delete(details.groupId);
  return getInstanceGroupDetails(connection, details.groupId);
}
async function updateInstanceGroupDescription(connection, groupId, description) {
  const details = await getInstanceGroupDetails(connection, groupId);
  const { socket } = await ensureOperationalSocket(
    connection,
    `updateInstanceGroupDescription:${connection.id}`
  );
  await socket.groupUpdateDescription(details.groupId, String(description || "").trim() || void 0);
  groupMetadataCache.delete(details.groupId);
  return getInstanceGroupDetails(connection, details.groupId);
}
async function updateInstanceGroupParticipants(connection, groupId, participants, action) {
  const details = await getInstanceGroupDetails(connection, groupId);
  const normalizedParticipants = Array.from(
    new Set(participants.map(normalizeGroupParticipantTarget))
  );
  if (normalizedParticipants.length === 0) {
    throw new Error("participants is required");
  }
  const { socket } = await ensureOperationalSocket(
    connection,
    `updateInstanceGroupParticipants:${connection.id}`
  );
  const updates = await socket.groupParticipantsUpdate(details.groupId, normalizedParticipants, action);
  groupMetadataCache.delete(details.groupId);
  return {
    success: true,
    instanceId: connection.id,
    groupId: details.groupId,
    action,
    items: Array.isArray(updates) ? updates.map((item) => ({
      jid: item?.jid ? String(item.jid) : null,
      status: String(item?.status || "unknown")
    })) : []
  };
}
async function getInstanceGroupInviteCode(connection, groupId) {
  const details = await getInstanceGroupDetails(connection, groupId);
  const { socket } = await ensureOperationalSocket(
    connection,
    `getInstanceGroupInviteCode:${connection.id}`
  );
  const inviteCode = await socket.groupInviteCode(details.groupId);
  return {
    success: true,
    instanceId: connection.id,
    groupId: details.groupId,
    inviteCode: inviteCode ? String(inviteCode) : null
  };
}
async function revokeInstanceGroupInviteCode(connection, groupId) {
  const details = await getInstanceGroupDetails(connection, groupId);
  const { socket } = await ensureOperationalSocket(
    connection,
    `revokeInstanceGroupInviteCode:${connection.id}`
  );
  const inviteCode = await socket.groupRevokeInvite(details.groupId);
  return {
    success: true,
    instanceId: connection.id,
    groupId: details.groupId,
    inviteCode: inviteCode ? String(inviteCode) : null
  };
}
async function joinInstanceGroupByInvite(connection, inviteCode) {
  const trimmedCode = String(inviteCode || "").trim();
  if (!trimmedCode) {
    throw new Error("inviteCode is required");
  }
  const { socket } = await ensureOperationalSocket(
    connection,
    `joinInstanceGroupByInvite:${connection.id}`
  );
  const groupId = await socket.groupAcceptInvite(trimmedCode);
  return {
    success: true,
    instanceId: connection.id,
    groupId: groupId ? String(groupId) : null
  };
}
async function ensureConversationForDestination(connection, to, contactName) {
  const digits = normalizeApiDestination(to);
  const snapshot = computeLiveInstanceSnapshot(connection);
  const continuityConnection = await ensureManagedPhoneConnectionContinuity({
    userId: connection.userId,
    connectionId: connection.id,
    runtimePhoneNumber: snapshot.connectedPhone,
    runtimeIsConnected: snapshot.hasOperationalSocket || connection.isConnected === true
  });
  if (!continuityConnection) {
    throw new Error("Esta instancia esta bloqueada porque o numero pertence a outra conta ativa.");
  }
  const targetJid = buildWhatsAppJidFromPhone(digits);
  const existing = await storage.findConversationByIdentity(continuityConnection.id, {
    contactNumber: digits,
    remoteJid: targetJid,
    activeOnly: true
  }) || await storage.findConversationByIdentity(continuityConnection.id, {
    contactNumber: digits,
    remoteJid: targetJid
  });
  if (existing) {
    return existing;
  }
  return storage.createConversation({
    connectionId: continuityConnection.id,
    contactNumber: digits,
    remoteJid: buildWhatsAppJidFromPhone(digits),
    jidSuffix: "s.whatsapp.net",
    contactName: contactName || digits,
    unreadCount: 0,
    hasReplied: false
  });
}
async function sendTextViaInstance(params) {
  let conversation = params.conversationId ? await storage.getConversation(params.conversationId) : await ensureConversationForDestination(params.connection, params.to || "", params.contactName);
  if (!conversation || conversation.connectionId !== params.connection.id) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  conversation = await validateConversationDestination({
    connection: params.connection,
    conversation,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const result = await sendMessage(params.connection.userId, conversation.id, normalizeOutboundTextForCustomer(params.text), {
    source: params.source || (params.isFromAgent ? "agent" : "system"),
    isFromAgent: params.isFromAgent === true,
    acceptQueued: params.acceptQueued === true
  });
  return {
    success: result.success,
    messageId: result.messageId || null,
    conversationId: conversation.id,
    remoteJid: conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber)
  };
}
async function sendMediaViaInstance(params) {
  let conversation = params.conversationId ? await storage.getConversation(params.conversationId) : await ensureConversationForDestination(params.connection, params.to || "", params.contactName);
  if (!conversation || conversation.connectionId !== params.connection.id) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  conversation = await validateConversationDestination({
    connection: params.connection,
    conversation,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const source = params.source || "agent";
  const isOwnerManualSend = source === "owner" && params.isFromAgent !== true;
  const result = await sendUserMediaMessage(params.connection.userId, conversation.id, {
    type: params.type,
    data: params.data,
    mimetype: params.mimetype || (params.type === "image" ? "image/jpeg" : params.type === "audio" ? "audio/ogg; codecs=opus" : params.type === "video" ? "video/mp4" : "application/octet-stream"),
    filename: params.filename || void 0,
    caption: params.caption || void 0,
    ptt: params.ptt,
    seconds: params.seconds ?? void 0
  }, {
    isFromAgent: !isOwnerManualSend,
    yieldQueue: true,
    skipQueueDelay: isOwnerManualSend,
    skipAutoPause: true
  });
  return {
    success: true,
    conversationId: conversation.id,
    messageId: result?.messageId || null,
    remoteJid: conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber)
  };
}
async function sendContactViaInstance(params) {
  let conversation = params.conversationId ? await storage.getConversation(params.conversationId) : await ensureConversationForDestination(params.connection, params.to || "", params.contactName);
  if (!conversation || conversation.connectionId !== params.connection.id) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  conversation = await validateConversationDestination({
    connection: params.connection,
    conversation,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const { socket } = await ensureOperationalSocket(
    params.connection,
    `sendContactViaInstance:${params.connection.id}`
  );
  const sentMessage = await socket.sendMessage(
    conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber),
    buildContactCardPayload({
      phoneNumber: params.phoneNumber,
      displayName: params.displayName,
      organization: params.organization,
      email: params.email,
      url: params.url
    })
  );
  return {
    success: true,
    conversationId: conversation.id,
    messageId: sentMessage?.key?.id || null,
    remoteJid: conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber)
  };
}
async function sendLocationViaInstance(params) {
  let conversation = params.conversationId ? await storage.getConversation(params.conversationId) : await ensureConversationForDestination(params.connection, params.to || "", params.contactName);
  if (!conversation || conversation.connectionId !== params.connection.id) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  conversation = await validateConversationDestination({
    connection: params.connection,
    conversation,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const { socket } = await ensureOperationalSocket(
    params.connection,
    `sendLocationViaInstance:${params.connection.id}`
  );
  const sentMessage = await socket.sendMessage(
    conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber),
    buildLocationPayload({
      latitude: params.latitude,
      longitude: params.longitude,
      name: params.name,
      address: params.address
    })
  );
  return {
    success: true,
    conversationId: conversation.id,
    messageId: sentMessage?.key?.id || null,
    remoteJid: conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber)
  };
}
async function sendButtonsViaInstance(params) {
  let conversation = params.conversationId ? await storage.getConversation(params.conversationId) : await ensureConversationForDestination(params.connection, params.to || "", params.contactName);
  if (!conversation || conversation.connectionId !== params.connection.id) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  conversation = await validateConversationDestination({
    connection: params.connection,
    conversation,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const { socket } = await ensureOperationalSocket(
    params.connection,
    `sendButtonsViaInstance:${params.connection.id}`
  );
  const result = await centralizedMessageSender_default.sendButtons(
    params.connection.userId,
    conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber),
    normalizeButtonsPayload(params),
    socket,
    "manual_admin",
    {
      conversationId: conversation.id,
      connectionId: params.connection.id,
      isOwnerInitiated: true
    }
  );
  return {
    success: result.success,
    conversationId: conversation.id,
    messageId: result.messageId || null,
    remoteJid: conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber),
    error: result.error || null
  };
}
async function sendListViaInstance(params) {
  let conversation = params.conversationId ? await storage.getConversation(params.conversationId) : await ensureConversationForDestination(params.connection, params.to || "", params.contactName);
  if (!conversation || conversation.connectionId !== params.connection.id) {
    throw new Error("Conversa nao encontrada para esta instancia");
  }
  conversation = await validateConversationDestination({
    connection: params.connection,
    conversation,
    to: params.to,
    contactName: params.contactName,
    validateDestination: params.validateDestination
  });
  const { socket } = await ensureOperationalSocket(
    params.connection,
    `sendListViaInstance:${params.connection.id}`
  );
  const result = await centralizedMessageSender_default.sendList(
    params.connection.userId,
    conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber),
    normalizeListPayload(params),
    socket,
    "manual_admin",
    {
      conversationId: conversation.id,
      connectionId: params.connection.id,
      isOwnerInitiated: true
    }
  );
  return {
    success: result.success,
    conversationId: conversation.id,
    messageId: result.messageId || null,
    remoteJid: conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber),
    error: result.error || null
  };
}
async function sendReactionViaInstance(params) {
  const targetMessage = params.conversationId ? await resolveInstanceMessageRecord(params.connection.id, params.conversationId, params.messageId) : await storage.getMessageByMessageId(params.messageId);
  if (!targetMessage) {
    throw new Error("Mensagem alvo nao encontrada");
  }
  const conversation = await resolveConversationForInstance(
    params.connection.id,
    targetMessage.conversationId
  );
  const { connection, socket } = await ensureOperationalSocket(
    params.connection,
    `sendReactionViaInstance:${params.connection.id}`
  );
  const remoteJid = conversation.remoteJid || buildWhatsAppJidFromPhone(conversation.contactNumber);
  const sentMessage = await socket.sendMessage(remoteJid, {
    react: {
      text: String(params.emoji || "").trim(),
      key: {
        id: targetMessage.messageId,
        remoteJid,
        fromMe: targetMessage.fromMe
      }
    }
  });
  return {
    success: true,
    conversationId: conversation.id,
    targetMessageId: targetMessage.messageId,
    messageId: sentMessage?.key?.id || null,
    remoteJid,
    instanceId: connection.id
  };
}
async function sendGroupBulkViaInstance(params) {
  return sendMessageToGroups(params.connection.userId, params.groupIds, params.message, {
    connectionId: params.connection.id,
    delayMin: Number(params.settings?.delayMin || 0) * 1e3,
    delayMax: Number(params.settings?.delayMax || 0) * 1e3,
    useAI: Boolean(params.settings?.useAI)
  });
}

export {
  resolveConnectionScopedSession,
  computeLiveInstanceSnapshot,
  validateInstanceContact,
  validateInstanceContactsBatch,
  getInstanceContactProfilePicture,
  updateInstanceContactBlockStatus,
  sendInstanceContactPresence,
  getInstanceMessageMedia,
  redownloadInstanceMessageMedia,
  getInstanceMessageQueue,
  clearInstanceMessageQueue,
  sendTextDirectViaInstance,
  sendMediaDirectViaInstance,
  sendContactDirectViaInstance,
  sendLocationDirectViaInstance,
  sendButtonsDirectViaInstance,
  sendListDirectViaInstance,
  buildLocalInstanceStatus,
  buildLocalInstanceDevice,
  listInstanceConversations,
  listInstanceMessages,
  syncInstanceGroupHistory,
  listInstanceContacts,
  listInstanceGroups,
  getInstanceGroupDetails,
  listInstanceGroupParticipants,
  createInstanceGroup,
  leaveInstanceGroup,
  updateInstanceGroupSubject,
  updateInstanceGroupDescription,
  updateInstanceGroupParticipants,
  getInstanceGroupInviteCode,
  revokeInstanceGroupInviteCode,
  joinInstanceGroupByInvite,
  sendTextViaInstance,
  sendMediaViaInstance,
  sendContactViaInstance,
  sendLocationViaInstance,
  sendButtonsViaInstance,
  sendListViaInstance,
  sendReactionViaInstance,
  sendGroupBulkViaInstance
};
