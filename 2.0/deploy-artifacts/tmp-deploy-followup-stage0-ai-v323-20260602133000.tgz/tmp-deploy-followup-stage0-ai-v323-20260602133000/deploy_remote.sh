﻿#!/usr/bin/env bash
set -euo pipefail
BASE_IMAGE="agentezap-app:fk-ficha-mfc-context-v321-20260602124000"
NEW_IMAGE="agentezap-app:followup-stage0-ai-v323-20260602133000"
cd /opt/agentezap-single/compose
ACTIVE_IMAGE="$(grep '^AGENTEZAP_APP_IMAGE=' .env.runtime | cut -d= -f2-)"
if [ "$ACTIVE_IMAGE" != "$BASE_IMAGE" ]; then
  echo "Active image changed: $ACTIVE_IMAGE (expected $BASE_IMAGE)" >&2
  exit 20
fi
cd /tmp/followup-stage0-ai-v323-20260602133000
docker build -t "$NEW_IMAGE" .
cd /opt/agentezap-single/compose
./scripts/deploy-service.sh app "$NEW_IMAGE"
echo "$NEW_IMAGE"
