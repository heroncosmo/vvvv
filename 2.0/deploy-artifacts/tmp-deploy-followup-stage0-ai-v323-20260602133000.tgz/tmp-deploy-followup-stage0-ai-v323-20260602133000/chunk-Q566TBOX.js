// server/autoReactivatePolicy.ts
var MIN_PENDING_REPLY_STALE_WINDOW_MINUTES = 60;
function toTimestampMs(value) {
  if (!value) return null;
  if (value instanceof Date) {
    const time2 = value.getTime();
    return Number.isFinite(time2) ? time2 : null;
  }
  const time = new Date(String(value)).getTime();
  return Number.isFinite(time) ? time : null;
}
function getAutoReactivatePendingReplyStaleWindowMinutes(autoReactivateAfterMinutes) {
  const configuredMinutes = Number(autoReactivateAfterMinutes);
  if (!Number.isFinite(configuredMinutes) || configuredMinutes <= 0) {
    return MIN_PENDING_REPLY_STALE_WINDOW_MINUTES;
  }
  return Math.max(MIN_PENDING_REPLY_STALE_WINDOW_MINUTES, configuredMinutes * 2);
}
function shouldSkipStaleAutoReactivateReply(params) {
  const messageAt = toTimestampMs(params.conversationLastMessageAt) ?? toTimestampMs(params.clientLastMessageAt);
  if (!messageAt) return false;
  const now = toTimestampMs(params.now) ?? Date.now();
  const staleWindowMinutes = getAutoReactivatePendingReplyStaleWindowMinutes(
    params.autoReactivateAfterMinutes
  );
  return now - messageAt > staleWindowMinutes * 6e4;
}

// server/planPayloadNormalizer.ts
import { randomBytes } from "crypto";
function hasOwn(input, key) {
  return Object.prototype.hasOwnProperty.call(input, key);
}
function normalizeOptionalString(value) {
  if (typeof value !== "string") {
    return value == null ? null : String(value).trim() || null;
  }
  const normalized = value.trim();
  return normalized.length > 0 ? normalized : null;
}
function normalizeOptionalUppercaseString(value) {
  const normalized = normalizeOptionalString(value);
  return normalized ? normalized.toUpperCase() : null;
}
function normalizeSlugString(value) {
  const normalized = normalizeOptionalString(value);
  if (!normalized) return null;
  const slug = normalized.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 100);
  return slug || null;
}
function normalizeCodeForSlug(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function normalizeCodePrefix(value) {
  const normalized = normalizeOptionalUppercaseString(value)?.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Z0-9]+/g, "").slice(0, 10);
  return normalized || "PLANO";
}
function getExistingCode(plan) {
  return normalizeOptionalUppercaseString(plan.codigoPersonalizado ?? plan.codigo_personalizado);
}
function getExistingSlug(plan) {
  return normalizeSlugString(plan.linkSlug ?? plan.link_slug);
}
function getExistingId(plan) {
  const value = plan?.id;
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function buildIdentifierSets(existingPlans, currentPlan) {
  const currentId = getExistingId(currentPlan);
  const codes = /* @__PURE__ */ new Set();
  const slugs = /* @__PURE__ */ new Set();
  for (const plan of existingPlans) {
    if (currentId && getExistingId(plan) === currentId) {
      continue;
    }
    const code = getExistingCode(plan);
    if (code) codes.add(code);
    const slug = getExistingSlug(plan);
    if (slug) slugs.add(slug);
  }
  return { codes, slugs };
}
function createRandomPlanCode(seedName) {
  const prefix = normalizeCodePrefix(seedName);
  const suffix = randomBytes(3).toString("hex").toUpperCase();
  return `${prefix}-${suffix}`.slice(0, 50);
}
function createPlanLinkSlug(seedName, code) {
  const base = normalizeSlugString(seedName) || "plano";
  const codeSlug = normalizeCodeForSlug(code) || randomBytes(3).toString("hex");
  return `${base}-${codeSlug}`.slice(0, 100).replace(/-+$/g, "");
}
function uniquePlanCode(seedName, existingCodes) {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const code = createRandomPlanCode(seedName);
    if (!existingCodes.has(code)) {
      existingCodes.add(code);
      return code;
    }
  }
  const fallback = `PLANO-${Date.now().toString(36).toUpperCase()}-${randomBytes(2).toString("hex").toUpperCase()}`.slice(0, 50);
  existingCodes.add(fallback);
  return fallback;
}
function uniquePlanSlug(seedName, code, existingSlugs) {
  const baseSlug = createPlanLinkSlug(seedName, code);
  if (!existingSlugs.has(baseSlug)) {
    existingSlugs.add(baseSlug);
    return baseSlug;
  }
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const suffix = randomBytes(2).toString("hex");
    const slug = `${baseSlug.slice(0, Math.max(1, 95 - suffix.length))}-${suffix}`;
    if (!existingSlugs.has(slug)) {
      existingSlugs.add(slug);
      return slug;
    }
  }
  const fallback = `${baseSlug.slice(0, 88)}-${Date.now().toString(36)}`.slice(0, 100);
  existingSlugs.add(fallback);
  return fallback;
}
function normalizePlanPayload(input) {
  const normalized = { ...input };
  if (hasOwn(input, "nome")) {
    normalized.nome = normalizeOptionalString(input.nome) ?? "";
  }
  if (hasOwn(input, "valor")) {
    normalized.valor = normalizeOptionalString(input.valor) ?? "";
  }
  if (hasOwn(input, "descricao")) {
    normalized.descricao = normalizeOptionalString(input.descricao);
  }
  if (hasOwn(input, "badge")) {
    normalized.badge = normalizeOptionalString(input.badge);
  }
  if (hasOwn(input, "ctaTexto")) {
    normalized.ctaTexto = normalizeOptionalString(input.ctaTexto);
  }
  if (hasOwn(input, "valorOriginal")) {
    normalized.valorOriginal = normalizeOptionalString(input.valorOriginal);
  }
  if (hasOwn(input, "valorPrimeiraCobranca")) {
    normalized.valorPrimeiraCobranca = normalizeOptionalString(input.valorPrimeiraCobranca);
  }
  if (hasOwn(input, "codigoPersonalizado")) {
    normalized.codigoPersonalizado = normalizeOptionalUppercaseString(input.codigoPersonalizado);
  }
  if (hasOwn(input, "linkSlug")) {
    normalized.linkSlug = normalizeSlugString(input.linkSlug);
  }
  return normalized;
}
function preparePlanPayload(input, existingPlans = [], options = {}) {
  const normalized = normalizePlanPayload(input);
  const currentPlan = options.currentPlan ?? null;
  const { codes, slugs } = buildIdentifierSets(existingPlans, currentPlan);
  const currentCode = getExistingCode(currentPlan || {});
  const requestedCode = normalizeOptionalUppercaseString(normalized.codigoPersonalizado);
  const code = requestedCode || currentCode || uniquePlanCode(normalized.nome ?? currentPlan?.nome, codes);
  normalized.codigoPersonalizado = code;
  const currentSlug = getExistingSlug(currentPlan || {});
  const requestedSlug = normalizeSlugString(normalized.linkSlug);
  normalized.linkSlug = requestedSlug || currentSlug || uniquePlanSlug(normalized.nome ?? currentPlan?.nome, code, slugs);
  return normalized;
}

export {
  shouldSkipStaleAutoReactivateReply,
  preparePlanPayload
};
