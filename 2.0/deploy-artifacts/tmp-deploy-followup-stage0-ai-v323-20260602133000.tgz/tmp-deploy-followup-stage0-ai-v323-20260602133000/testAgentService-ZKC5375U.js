import {
  expandSimulatorMediaAction,
  getSimulatorChannelGuardResult
} from "./chunk-WPNIUNIZ.js";
import {
  getAgentMediaLibrary,
  testAgentResponse
} from "./chunk-JDBD3TU2.js";
import "./chunk-TWJ5LOMY.js";
import "./chunk-HXFUB6FA.js";
import "./chunk-AL4GIH74.js";
import "./chunk-JE2U3KMF.js";
import "./chunk-SFLSWTY7.js";
import "./chunk-DH4QIP4D.js";
import "./chunk-OX43ECVD.js";
import "./chunk-PH437YKV.js";
import "./chunk-LYL74IEX.js";
import "./chunk-QCEDG5RZ.js";
import "./chunk-GXAKLONY.js";
import "./chunk-R2H3ZHAP.js";
import "./chunk-7SPF5OKO.js";
import "./chunk-YB77ZB3P.js";
import "./chunk-XZFDVJYL.js";
import "./chunk-LIK4OWWG.js";
import {
  repairMojibakeText
} from "./chunk-K6J2PMOD.js";
import "./chunk-M7TXNZTC.js";
import "./chunk-UKCWWGWI.js";
import "./chunk-R6CXRQMB.js";
import "./chunk-JC6URYU5.js";
import "./chunk-KFQGP6VL.js";

// server/testAgentService.ts
function looksLikeTransientFailure(text) {
  const normalized = String(text || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
  if (!normalized) return true;
  return normalized.includes("nao consegui processar") || normalized.includes("ocorreu um erro ao processar") || normalized.includes("houve um erro tecnico");
}
function repairCommonMojibake(text) {
  return repairMojibakeText(text);
}
async function handleTestAgentMessage(params, deps) {
  const { message, token, history, userId, sentMedias, sessionId } = params;
  if (!message || !message.trim()) {
    throw new Error("Mensagem obrigatoria");
  }
  let resolvedUserId = userId;
  if (!resolvedUserId && token && token !== "demo") {
    const tokenInfo = await deps.getTestToken(token);
    if (tokenInfo?.userId) {
      resolvedUserId = tokenInfo.userId;
    }
  }
  if (!resolvedUserId && token && token !== "demo") {
    return {
      response: "Esse link de teste e invalido ou expirou. Peca um novo link para o administrador e tente novamente.",
      mode: "client_agent"
    };
  }
  if (resolvedUserId) {
    const channelGuard = await getSimulatorChannelGuardResult(resolvedUserId);
    if (!channelGuard.channelReady) {
      return {
        response: channelGuard.blockReason || "O canal real do WhatsApp n\xE3o est\xE1 pronto para responder.",
        mode: "client_agent",
        resolvedUserId
      };
    }
    const agentConfig = await deps.getAgentConfig(resolvedUserId);
    if (!agentConfig?.prompt) {
      return {
        response: "Seu agente ainda nao esta configurado para teste. Peca ao administrador para finalizar a configuracao do agente antes de usar este link.",
        mode: "client_agent",
        resolvedUserId
      };
    }
    console.log("\n ");
    console.log(" [TestAgentService] SIMULADOR UNIFICADO - Usando mesmo fluxo do WhatsApp");
    console.log(" ");
    const conversationHistory = history?.map((msg, idx) => ({
      id: `sim-${idx}`,
      chatId: "simulator",
      text: msg.content,
      fromMe: msg.role === "assistant",
      timestamp: new Date(Date.now() - (history.length - idx) * 6e4),
      isFromAgent: msg.role === "assistant"
    })) || [];
    console.log(` [TestAgentService] Histrico: ${conversationHistory.length} msgs, Mdias enviadas: ${sentMedias?.length || 0}`);
    try {
      let result = await testAgentResponse(
        resolvedUserId,
        message,
        void 0,
        // Nao passar customPrompt aqui - usar o do banco
        conversationHistory,
        sentMedias || [],
        "Visitante",
        sessionId || token || resolvedUserId
      );
      let mediaActions = [];
      if (result.mediaActions && result.mediaActions.length > 0) {
        const mediaLibrary = await getAgentMediaLibrary(resolvedUserId);
        for (const rawAction of result.mediaActions) {
          const action = rawAction;
          const expandedActions = expandSimulatorMediaAction(action, mediaLibrary);
          if (expandedActions.length > 0 && action?.media_name) {
            console.log(` [TestAgentService] Mdia encontrada: ${action.media_name}`);
          }
          mediaActions.push(...expandedActions);
        }
      }
      console.log(" \n");
      let responseText = typeof result.text === "string" ? result.text : "";
      const shouldRetry = mediaActions.length === 0 && looksLikeTransientFailure(responseText);
      if (shouldRetry) {
        console.warn(" [TestAgentService] Resposta fraca/transiente detectada, tentando 1 retry");
        result = await testAgentResponse(
          resolvedUserId,
          message,
          void 0,
          conversationHistory,
          sentMedias || [],
          "Visitante",
          sessionId || token || resolvedUserId
        );
        responseText = typeof result.text === "string" ? result.text : "";
      }
      const safeResponse = repairCommonMojibake(responseText);
      if (mediaActions.length === 0 && looksLikeTransientFailure(safeResponse)) {
        return {
          response: "",
          mediaActions,
          deliveryOrderCreated: result.deliveryOrderCreated,
          mode: "client_agent",
          resolvedUserId,
          emptyResponse: true,
          error: "empty_real_response"
        };
      }
      return {
        response: safeResponse,
        mediaActions,
        deliveryOrderCreated: result.deliveryOrderCreated,
        mode: "client_agent",
        resolvedUserId
      };
    } catch (error) {
      console.error(" [TestAgentService] Erro:", error);
      return {
        response: "",
        mode: "client_agent",
        resolvedUserId,
        emptyResponse: true,
        error: "processing_error"
      };
    }
  }
  const fallbackSessionId = token || `test_${Date.now()}`;
  const response = await deps.processAdminMessage(fallbackSessionId, message, void 0, void 0, true);
  if (!response) {
    return {
      response: "",
      mode: "sales_demo",
      emptyResponse: true,
      error: "demo_empty_response"
    };
  }
  return {
    response: repairCommonMojibake(response.text),
    mediaActions: response.mediaActions,
    mode: "sales_demo"
  };
}
export {
  handleTestAgentMessage
};
