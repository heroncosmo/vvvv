import {
  generateAutologinLink
} from "./chunk-HHBRBLFW.js";
import {
  storage
} from "./chunk-7SPF5OKO.js";
import "./chunk-YB77ZB3P.js";
import "./chunk-XZFDVJYL.js";
import "./chunk-LIK4OWWG.js";
import "./chunk-K6J2PMOD.js";
import {
  getLLMClient
} from "./chunk-M7TXNZTC.js";
import "./chunk-UKCWWGWI.js";
import "./chunk-R6CXRQMB.js";
import "./chunk-JC6URYU5.js";
import "./chunk-KFQGP6VL.js";

// server/adminSetupRequestService.ts
var DEFAULT_PLAN = {
  summary: "",
  pains: [],
  objectives: [],
  workflowKind: "normal",
  companyName: "",
  agentNameSuggestion: "Atendente",
  businessDescription: "",
  mainOffer: "",
  desiredBehavior: "",
  modules: [],
  mediaSuggestions: [],
  missingData: [],
  checklist: [],
  usesScheduling: null,
  restaurantOrderMode: null,
  workDays: [],
  workStartTime: null,
  workEndTime: null
};
function extractJsonCandidate(raw) {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return raw.slice(start, end + 1);
}
function normalizeAdminSetupPlan(planLike) {
  const workflow = planLike?.workflowKind === "delivery" || planLike?.workflowKind === "agendamento" ? planLike.workflowKind : "normal";
  const modules = Array.isArray(planLike?.modules) ? planLike.modules.map((item) => String(item || "").trim()).filter(Boolean) : [];
  const mediaSuggestions = Array.isArray(planLike?.mediaSuggestions) ? planLike.mediaSuggestions.map((item) => ({
    name: String(item?.name || "").trim(),
    type: item?.type === "audio" || item?.type === "image" || item?.type === "video" || item?.type === "document" || item?.type === "flow" ? item.type : "text",
    description: String(item?.description || "").trim(),
    whenToUse: String(item?.whenToUse || "").trim()
  })).filter((item) => item.name && item.description).map((item) => ({
    ...item,
    type: item.type === "text" ? "document" : item.type
  })) : [];
  const workDays = Array.isArray(planLike?.workDays) ? planLike.workDays.map((value) => Number(value)).filter((value) => Number.isInteger(value) && value >= 0 && value <= 6) : [];
  return {
    ...DEFAULT_PLAN,
    summary: String(planLike?.summary || "").trim(),
    pains: Array.isArray(planLike?.pains) ? planLike.pains.map((item) => String(item || "").trim()).filter(Boolean) : [],
    objectives: Array.isArray(planLike?.objectives) ? planLike.objectives.map((item) => String(item || "").trim()).filter(Boolean) : [],
    workflowKind: workflow,
    companyName: String(planLike?.companyName || "").trim(),
    agentNameSuggestion: String(planLike?.agentNameSuggestion || "Atendente").trim() || "Atendente",
    businessDescription: String(planLike?.businessDescription || "").trim(),
    mainOffer: String(planLike?.mainOffer || "").trim(),
    desiredBehavior: String(planLike?.desiredBehavior || "").trim(),
    modules,
    mediaSuggestions,
    missingData: Array.isArray(planLike?.missingData) ? planLike.missingData.map((item) => String(item || "").trim()).filter(Boolean) : [],
    checklist: Array.isArray(planLike?.checklist) ? planLike.checklist.map((item) => String(item || "").trim()).filter(Boolean) : [],
    usesScheduling: typeof planLike?.usesScheduling === "boolean" ? planLike.usesScheduling : workflow === "agendamento" ? true : null,
    restaurantOrderMode: planLike?.restaurantOrderMode === "full_order" || planLike?.restaurantOrderMode === "first_contact" ? planLike.restaurantOrderMode : null,
    workDays,
    workStartTime: String(planLike?.workStartTime || "").trim() || null,
    workEndTime: String(planLike?.workEndTime || "").trim() || null
  };
}
function buildRequestStatus(request) {
  if (!request) return "pending";
  return String(request.status || "open");
}
function mapAdminSetupStatusToCustomerReply(request) {
  const status = buildRequestStatus(request);
  if (status === "created") {
    return "Perfeito. Sua configura\xE7\xE3o j\xE1 ficou pronta e est\xE1 em valida\xE7\xE3o final. Assim que eu liberar o acesso, te aviso aqui.";
  }
  if (status === "approved" || status === "executing") {
    return "Estou finalizando a sua configura\xE7\xE3o por aqui. Assim que terminar, eu te atualizo nesta conversa.";
  }
  if (status === "failed") {
    return "Estou revisando um detalhe da sua configura\xE7\xE3o por aqui. Assim que eu corrigir, eu te atualizo nesta conversa.";
  }
  return "Seu pedido de configura\xE7\xE3o assistida j\xE1 est\xE1 aberto. Um humano vai montar isso com voc\xEA por aqui e eu te atualizo nesta conversa.";
}
async function callJsonLlm(messages, maxTokens) {
  try {
    const client = await getLLMClient();
    const response = await client.chat.complete({
      model: "mistral-small-latest",
      messages,
      maxTokens,
      temperature: 0.1
    });
    const raw = String(response.choices?.[0]?.message?.content || "");
    const json = extractJsonCandidate(raw);
    if (!json) return null;
    return JSON.parse(json);
  } catch (error) {
    console.warn("[ADMIN-SETUP] Falha ao interpretar JSON da LLM:", error);
    return null;
  }
}
async function getConversationBundle(conversationId) {
  const conversation = await storage.getAdminConversation(conversationId);
  if (!conversation) {
    throw new Error("CONVERSATION_NOT_FOUND");
  }
  const messages = await storage.getAdminMessages(conversationId);
  return { conversation, messages };
}
function summarizeConversationForLlm(messages) {
  return messages.slice(-80).map((message) => `${message.fromMe ? "ASSISTENTE" : "CLIENTE"}: ${String(message.text || message.mediaCaption || "").trim()}`).filter(Boolean).join("\n");
}
async function persistConversationSetupState(conversationId, requestId, status) {
  const conversation = await storage.getAdminConversation(conversationId);
  if (!conversation) return;
  const nextContextState = {
    ...conversation.contextState || {},
    assistedSetupRequestId: requestId,
    assistedSetupStatus: status,
    assistedSetupLocked: true
  };
  await storage.updateAdminConversation(conversationId, {
    contextState: nextContextState
  });
}
async function classifyAdminConversationMode(params) {
  const cleanMessage = String(params.messageText || "").trim();
  if (!cleanMessage) {
    return {
      mode: "normal_sales",
      confidence: 0,
      reason: "Mensagem vazia",
      requestedHelpLevel: "none"
    };
  }
  const recentHistory = (params.session.conversationHistory || []).slice(-8).map((item) => `${item.role === "assistant" ? "ASSISTENTE" : "CLIENTE"}: ${item.content}`).join("\n");
  const parsed = await callJsonLlm(
    [
      {
        role: "system",
        content: `Voc\xEA classifica o modo de uma conversa comercial da AgenteZap.

Retorne SOMENTE JSON v\xE1lido:
{"mode":"auto_self_serve|assisted_setup|human_support|normal_sales","confidence":0.0,"reason":"...","requestedHelpLevel":"explicit|none"}

Regras:
- "assisted_setup" somente quando o cliente pedir explicitamente para voc\xEAs configurarem por ele, disser que n\xE3o consegue sozinho, ou pedir ajuda humana para montar.
- "auto_self_serve" quando o cliente quiser testar, ver funcionando, criar a conta, receber link, simulador ou acessar o sistema por conta pr\xF3pria.
- "human_support" quando ele pedir falar com humano, liga\xE7\xE3o, call ou suporte humano.
- "normal_sales" nos demais casos.

Nunca use "assisted_setup" s\xF3 porque o cliente est\xE1 com d\xFAvida. Tem que haver pedido expl\xEDcito de ajuda para configurar por ele.`
      },
      {
        role: "user",
        content: `Mensagem atual: ${cleanMessage}

Contexto:
- flowState: ${params.session.flowState || "onboarding"}
- pendingAction: ${params.session.pendingAction?.type || "nenhuma"}
- temContaVinculada: ${params.linkedContext.user ? "sim" : "nao"}
- temAgenteConfigurado: ${params.linkedContext.hasConfiguredAgent ? "sim" : "nao"}

Conversa recente:
${recentHistory || "sem hist\xF3rico"}`
      }
    ],
    180
  );
  if (!parsed) {
    return {
      mode: "normal_sales",
      confidence: 0,
      reason: "Fallback seguro",
      requestedHelpLevel: "none"
    };
  }
  return {
    mode: parsed.mode === "assisted_setup" || parsed.mode === "auto_self_serve" || parsed.mode === "human_support" ? parsed.mode : "normal_sales",
    confidence: Number(parsed.confidence || 0),
    reason: String(parsed.reason || "").trim(),
    requestedHelpLevel: parsed.requestedHelpLevel === "explicit" ? "explicit" : "none"
  };
}
async function openAssistedSetupRequest(params) {
  const existing = await storage.getAdminSetupRequestByConversationId(params.conversationId);
  if (existing) {
    const updated = await storage.updateAdminSetupRequest(existing.id, {
      status: "open",
      requestMode: "assisted_setup",
      analysisStatus: existing.analysisStatus || "pending",
      approvalStatus: existing.approvalStatus || "pending",
      executionStatus: existing.executionStatus || "pending",
      lockedCustomerHandoff: true,
      linkedUserId: params.linkedUserId || existing.linkedUserId || void 0,
      conversationFacts: {
        ...existing.conversationFacts || {},
        openingReason: params.openingReason,
        openingCustomerMessage: params.customerMessage
      }
    });
    await persistConversationSetupState(params.conversationId, updated.id, updated.status);
    return updated;
  }
  const created = await storage.createAdminSetupRequest({
    conversationId: params.conversationId,
    adminId: params.adminId,
    status: "open",
    requestMode: "assisted_setup",
    analysisStatus: "pending",
    approvalStatus: "pending",
    executionStatus: "pending",
    lockedCustomerHandoff: true,
    linkedUserId: params.linkedUserId,
    createdByAi: true,
    conversationFacts: {
      openingReason: params.openingReason,
      openingCustomerMessage: params.customerMessage
    },
    suggestedPlan: {},
    refinedPlan: {},
    executionResult: {}
  });
  await storage.createAdminSetupRequestMessage({
    requestId: created.id,
    role: "assistant",
    messageType: "system",
    content: `Pedido assistido aberto automaticamente. Motivo: ${params.openingReason || "pedido expl\xEDcito do cliente"}.`,
    planSnapshot: {},
    metadata: {
      source: "customer_handoff",
      customerMessage: params.customerMessage
    },
    createdBy: "ai"
  });
  await persistConversationSetupState(params.conversationId, created.id, created.status);
  return created;
}
async function getSetupRequestBundle(conversationId) {
  const request = await storage.getAdminSetupRequestByConversationId(conversationId);
  if (!request) {
    return { request: null, messages: [] };
  }
  const messages = await storage.getAdminSetupRequestMessages(request.id);
  return { request, messages };
}
async function analyzeSetupRequest(params) {
  const { conversation, messages } = await getConversationBundle(params.conversationId);
  const request = await storage.getAdminSetupRequestByConversationId(params.conversationId) || await openAssistedSetupRequest({
    conversationId: params.conversationId,
    adminId: params.adminId,
    linkedUserId: conversation.linkedUserId || void 0,
    openingReason: "An\xE1lise manual iniciada no admin",
    customerMessage: conversation.lastMessageText || ""
  });
  await storage.updateAdminSetupRequest(request.id, {
    status: "analyzing",
    analysisStatus: "running",
    lockedCustomerHandoff: true
  });
  const conversationText = summarizeConversationForLlm(messages);
  const parsed = await callJsonLlm(
    [
      {
        role: "system",
        content: `Voc\xEA analisa uma conversa de venda da AgenteZap e monta um plano inicial de configura\xE7\xE3o assistida.

Retorne SOMENTE JSON v\xE1lido:
{
  "facts": {
    "summary": "string",
    "customerGoal": "string",
    "objections": ["..."],
    "customerAskedForHumanSetup": true
  },
  "plan": {
    "summary": "string",
    "pains": ["..."],
    "objectives": ["..."],
    "workflowKind": "delivery|agendamento|normal",
    "companyName": "string",
    "agentNameSuggestion": "string",
    "businessDescription": "string",
    "mainOffer": "string",
    "desiredBehavior": "string",
    "modules": ["crm","kanban","notificador","delivery","agendamento","fluxos","midias"],
    "mediaSuggestions": [{"name":"string","type":"audio|image|video|document|flow","description":"string","whenToUse":"string"}],
    "missingData": ["..."],
    "checklist": ["..."],
    "usesScheduling": true,
    "restaurantOrderMode": "full_order|first_contact|null",
    "workDays": [1,2,3,4,5],
    "workStartTime": "09:00",
    "workEndTime": "18:00"
  }
}

Use apenas os dados que realmente aparecem na conversa. Se algo estiver faltando, deixe em missingData.`
      },
      {
        role: "user",
        content: `Conversa completa:
${conversationText || "sem mensagens"}

\xDAltima mensagem do cliente: ${conversation.lastMessageText || "sem mensagem"}
Nome do contato: ${conversation.contactName || "n\xE3o informado"}`
      }
    ],
    1800
  );
  const facts = parsed?.facts && typeof parsed.facts === "object" ? parsed.facts : {};
  const plan = normalizeAdminSetupPlan(parsed?.plan || {});
  const updated = await storage.updateAdminSetupRequest(request.id, {
    status: "draft_ready",
    analysisStatus: "done",
    conversationFacts: facts,
    suggestedPlan: plan,
    refinedPlan: plan
  });
  await storage.createAdminSetupRequestMessage({
    requestId: request.id,
    role: "assistant",
    messageType: "analysis",
    content: "An\xE1lise inicial conclu\xEDda e plano sugerido atualizado.",
    planSnapshot: plan,
    metadata: {
      facts
    },
    createdBy: "ai"
  });
  await persistConversationSetupState(params.conversationId, request.id, updated.status);
  return updated;
}
async function chatSetupRequest(params) {
  const bundle = await getSetupRequestBundle(params.conversationId);
  if (!bundle.request) {
    throw new Error("SETUP_REQUEST_NOT_FOUND");
  }
  const request = bundle.request;
  const { messages: conversationMessages } = await getConversationBundle(params.conversationId);
  const conversationText = summarizeConversationForLlm(conversationMessages);
  const priorMessages = bundle.messages.slice(-10).map((item) => `${item.role === "assistant" ? "IA" : "DONO"}: ${item.content}`).join("\n");
  const currentPlan = normalizeAdminSetupPlan(request.refinedPlan || request.suggestedPlan || {});
  const parsed = await callJsonLlm(
    [
      {
        role: "system",
        content: `Voc\xEA ajuda o dono da AgenteZap a refinar um plano de configura\xE7\xE3o assistida.

Retorne SOMENTE JSON v\xE1lido:
{
  "replyText": "resposta curta para o dono",
  "updatedPlan": {
    "summary": "string",
    "pains": ["..."],
    "objectives": ["..."],
    "workflowKind": "delivery|agendamento|normal",
    "companyName": "string",
    "agentNameSuggestion": "string",
    "businessDescription": "string",
    "mainOffer": "string",
    "desiredBehavior": "string",
    "modules": ["..."],
    "mediaSuggestions": [{"name":"string","type":"audio|image|video|document|flow","description":"string","whenToUse":"string"}],
    "missingData": ["..."],
    "checklist": ["..."],
    "usesScheduling": true,
    "restaurantOrderMode": "full_order|first_contact|null",
    "workDays": [1,2,3,4,5],
    "workStartTime": "09:00",
    "workEndTime": "18:00"
  }
}

Atualize o plano apenas com base no pedido do dono e no hist\xF3rico real.`
      },
      {
        role: "user",
        content: `Conversa com o cliente:
${conversationText || "sem mensagens"}

Plano atual:
${JSON.stringify(currentPlan, null, 2)}

Hist\xF3rico dono x IA:
${priorMessages || "sem hist\xF3rico"}

Pedido novo do dono:
${params.message}`
      }
    ],
    2200
  );
  const updatedPlan = normalizeAdminSetupPlan(parsed?.updatedPlan || currentPlan);
  const replyText = String(parsed?.replyText || "Ajustei o plano com base no que voc\xEA pediu.").trim();
  await storage.createAdminSetupRequestMessage({
    requestId: request.id,
    role: "user",
    messageType: "chat",
    content: params.message,
    planSnapshot: currentPlan,
    metadata: {},
    createdBy: params.adminId
  });
  const updated = await storage.updateAdminSetupRequest(request.id, {
    status: "needs_admin_input",
    refinedPlan: updatedPlan
  });
  await storage.createAdminSetupRequestMessage({
    requestId: request.id,
    role: "assistant",
    messageType: "chat",
    content: replyText,
    planSnapshot: updatedPlan,
    metadata: {},
    createdBy: "ai"
  });
  return { request: updated, reply: replyText };
}
async function approveSetupRequest(params) {
  const request = await storage.getAdminSetupRequestByConversationId(params.conversationId);
  if (!request) {
    throw new Error("SETUP_REQUEST_NOT_FOUND");
  }
  const updated = await storage.updateAdminSetupRequest(request.id, {
    status: "approved",
    approvalStatus: "approved",
    approvedByAdmin: params.adminId,
    approvedAt: /* @__PURE__ */ new Date()
  });
  await storage.createAdminSetupRequestMessage({
    requestId: request.id,
    role: "assistant",
    messageType: "approval",
    content: "Plano aprovado para execu\xE7\xE3o autom\xE1tica.",
    planSnapshot: normalizeAdminSetupPlan(updated.refinedPlan || updated.suggestedPlan || {}),
    metadata: {},
    createdBy: params.adminId
  });
  return updated;
}
function mapWorkflowKindToSessionPlan(workflowKind) {
  if (workflowKind === "delivery") {
    return { workflowKind: "delivery", usesScheduling: false };
  }
  if (workflowKind === "agendamento") {
    return { workflowKind: "scheduling", usesScheduling: true };
  }
  return { workflowKind: "generic", usesScheduling: false };
}
async function createExecutionSession(params) {
  const { createClientSession, getClientSession, updateClientSession } = await import("./adminAgentService-S7FDQR3A.js");
  let session = getClientSession(params.phoneNumber);
  if (!session) {
    session = createClientSession(params.phoneNumber);
  }
  const mappedWorkflow = mapWorkflowKindToSessionPlan(params.plan.workflowKind);
  session = updateClientSession(params.phoneNumber, {
    contactName: params.contactName || session.contactName,
    flowState: "onboarding",
    agentConfig: {
      ...session.agentConfig,
      company: params.plan.companyName,
      name: params.plan.agentNameSuggestion || "Atendente",
      role: params.plan.mainOffer || params.plan.businessDescription || "atendente virtual",
      prompt: params.plan.desiredBehavior || params.plan.summary || "Atenda com clareza e objetividade."
    },
    setupProfile: {
      ...session.setupProfile || {},
      questionStage: "ready",
      answeredBusiness: true,
      answeredBehavior: true,
      answeredWorkflow: true,
      businessSummary: params.plan.businessDescription || params.plan.summary,
      desiredAgentBehavior: params.plan.desiredBehavior || params.plan.summary,
      mainOffer: params.plan.mainOffer || void 0,
      workflowKind: mappedWorkflow.workflowKind,
      usesScheduling: mappedWorkflow.usesScheduling,
      restaurantOrderMode: params.plan.workflowKind === "delivery" ? params.plan.restaurantOrderMode || "first_contact" : void 0,
      workDays: params.plan.workDays.length > 0 ? params.plan.workDays : void 0,
      workStartTime: params.plan.workStartTime || void 0,
      workEndTime: params.plan.workEndTime || void 0,
      rawAnswers: {
        q1: params.plan.businessDescription || params.plan.summary,
        q2: params.plan.desiredBehavior || params.plan.summary,
        q3: params.plan.workflowKind === "delivery" ? params.plan.restaurantOrderMode || "first_contact" : params.plan.workflowKind === "agendamento" ? `${params.plan.workStartTime || "09:00"}-${params.plan.workEndTime || "18:00"}` : "atendimento normal"
      }
    }
  });
  return session;
}
async function executeSetupRequestCreation(params) {
  const request = await storage.getAdminSetupRequestByConversationId(params.conversationId);
  if (!request) {
    throw new Error("SETUP_REQUEST_NOT_FOUND");
  }
  const { conversation } = await getConversationBundle(params.conversationId);
  const plan = normalizeAdminSetupPlan(request.refinedPlan || request.suggestedPlan || {});
  const steps = [
    { id: "create_or_reuse_user", status: "pending", detail: "Aguardando" },
    { id: "resolve_business_mode", status: "pending", detail: "Aguardando" },
    { id: "save_prompt_and_config", status: "pending", detail: "Aguardando" },
    { id: "seed_delivery_or_scheduling_if_needed", status: "pending", detail: "Aguardando" },
    { id: "create_test_access", status: "pending", detail: "Aguardando" },
    { id: "validate_result", status: "pending", detail: "Aguardando" }
  ];
  await storage.updateAdminSetupRequest(request.id, {
    status: "executing",
    executionStatus: "running",
    lastError: null
  });
  try {
    const session = await createExecutionSession({
      phoneNumber: conversation.contactNumber,
      plan,
      contactName: conversation.contactName
    });
    steps[0] = { id: "create_or_reuse_user", status: "success", detail: "Sess\xE3o preparada para cria\xE7\xE3o idempotente." };
    steps[1] = {
      id: "resolve_business_mode",
      status: "success",
      detail: `Modo operacional definido como ${plan.workflowKind}.`
    };
    const { createTestAccountWithCredentials, getClientSession, getTestToken } = await import("./adminAgentService-S7FDQR3A.js");
    const createResult = await createTestAccountWithCredentials(session);
    if (!createResult.success || !createResult.email || !createResult.simulatorToken) {
      throw new Error(createResult.error || "CREATE_TEST_ACCOUNT_FAILED");
    }
    steps[2] = { id: "save_prompt_and_config", status: "success", detail: "Prompt e configura\xE7\xE3o do agente salvos." };
    steps[3] = {
      id: "seed_delivery_or_scheduling_if_needed",
      status: "success",
      detail: plan.workflowKind === "normal" ? "Sem seed estrutural extra para modo normal." : `M\xF3dulos estruturais aplicados para ${plan.workflowKind}.`
    };
    steps[4] = { id: "create_test_access", status: "success", detail: "Teste e credenciais gerados." };
    const refreshedSession = getClientSession(conversation.contactNumber);
    const userId = refreshedSession?.userId;
    if (!userId) {
      throw new Error("USER_ID_NOT_RESOLVED");
    }
    const [user, agentConfig, tokenInfo, panelUrl] = await Promise.all([
      storage.getUser(userId),
      storage.getAgentConfig(userId),
      getTestToken(createResult.simulatorToken),
      generateAutologinLink(userId, "/meu-agente-ia")
    ]);
    if (!user || !agentConfig?.prompt || !tokenInfo?.token) {
      throw new Error("VALIDATION_FAILED");
    }
    steps[5] = { id: "validate_result", status: "success", detail: "Conta, prompt, token e auto-login validados." };
    const executionResult = {
      success: true,
      userId,
      email: createResult.email,
      simulatorToken: createResult.simulatorToken,
      simulatorUrl: `https://agentezap.online/test/${createResult.simulatorToken}`,
      panelUrl,
      steps
    };
    const updated = await storage.updateAdminSetupRequest(request.id, {
      status: "created",
      approvalStatus: "approved",
      executionStatus: "done",
      linkedUserId: userId,
      createdTestToken: createResult.simulatorToken,
      createdAutologinToken: panelUrl,
      executionResult,
      completedAt: /* @__PURE__ */ new Date()
    });
    await persistConversationSetupState(params.conversationId, request.id, updated.status);
    return updated;
  } catch (error) {
    const failedStep = steps.find((step) => step.status === "pending");
    if (failedStep) {
      failedStep.status = "failed";
      failedStep.detail = error?.message || "Falha sem detalhe";
    }
    const executionResult = {
      success: false,
      error: String(error?.message || error),
      steps
    };
    const updated = await storage.updateAdminSetupRequest(request.id, {
      status: "failed",
      executionStatus: "failed",
      lastError: String(error?.message || error),
      executionResult
    });
    await persistConversationSetupState(params.conversationId, request.id, updated.status);
    return updated;
  }
}
async function sendSetupRequestResult(params) {
  const request = await storage.getAdminSetupRequestByConversationId(params.conversationId);
  if (!request) {
    throw new Error("SETUP_REQUEST_NOT_FOUND");
  }
  const executionResult = request.executionResult || {};
  if (!executionResult.success || !executionResult.simulatorUrl || !executionResult.panelUrl) {
    throw new Error("SETUP_REQUEST_NOT_READY");
  }
  const { sendAdminConversationMessage } = await import("./whatsapp-ORIGKV64.js");
  const text = `Perfeito. Sua configura\xE7\xE3o ficou pronta.

Teste: ${executionResult.simulatorUrl}

Painel: ${executionResult.panelUrl}

Voc\xEA tamb\xE9m pode ajustar direto no sistema e conhecer CRM, Kanban, conversas, notificador inteligente, fluxos e a conex\xE3o do WhatsApp.`;
  await sendAdminConversationMessage(params.adminId, params.conversationId, text);
  const updated = await storage.updateAdminSetupRequest(request.id, {
    status: "delivered",
    executionResult: {
      ...executionResult,
      sentToCustomerAt: (/* @__PURE__ */ new Date()).toISOString()
    }
  });
  await persistConversationSetupState(params.conversationId, request.id, updated.status);
  return updated;
}
async function getCustomerAssistedSetupStatusByPhone(phoneNumber) {
  const conversation = await storage.getAdminConversationByPhone(String(phoneNumber || "").replace(/\D/g, ""));
  if (!conversation) {
    return { request: null, reply: null };
  }
  const request = await storage.getAdminSetupRequestByConversationId(conversation.id);
  if (!request || request.lockedCustomerHandoff !== true) {
    return { request: null, reply: null };
  }
  return {
    request,
    reply: mapAdminSetupStatusToCustomerReply(request)
  };
}
export {
  analyzeSetupRequest,
  approveSetupRequest,
  chatSetupRequest,
  classifyAdminConversationMode,
  executeSetupRequestCreation,
  getCustomerAssistedSetupStatusByPhone,
  getSetupRequestBundle,
  mapAdminSetupStatusToCustomerReply,
  normalizeAdminSetupPlan,
  openAssistedSetupRequest,
  sendSetupRequestResult
};
