// server/runtimeProfile.ts
function normalizeProfile(value) {
  return String(value || "").trim().toLowerCase();
}
function resolveAppRuntimeProfile() {
  const explicitProfile = normalizeProfile(
    process.env.APP_RUNTIME_PROFILE || process.env.RUNTIME_PROFILE || process.env.APP_ROLE
  );
  if (explicitProfile === "web" || explicitProfile === "web-only" || explicitProfile === "frontend" || explicitProfile === "ui") {
    return "web";
  }
  if (explicitProfile === "worker" || explicitProfile === "jobs" || explicitProfile === "stateful-worker" || explicitProfile === "background") {
    return "worker";
  }
  return "full";
}
function isWebOnlyAppRuntime() {
  return resolveAppRuntimeProfile() === "web";
}
function isWorkerAppRuntime() {
  return resolveAppRuntimeProfile() === "worker";
}
function areStatefulAppServicesEnabled() {
  if (process.env.DISABLE_BACKGROUND_SERVICES === "true") {
    return false;
  }
  if (process.env.DISABLE_BACKGROUND_JOBS === "true") {
    return false;
  }
  if (process.env.DISABLE_WHATSAPP_PROCESSING === "true") {
    return false;
  }
  return !isWebOnlyAppRuntime();
}
function areLocalWhatsAppRuntimeServicesEnabled() {
  if (!areStatefulAppServicesEnabled()) {
    return false;
  }
  if (process.env.DISABLE_LOCAL_WHATSAPP_RUNTIME === "true") {
    return false;
  }
  if (process.env.DISABLE_LEGACY_WHATSAPP_RUNTIME === "true") {
    return false;
  }
  return !isWorkerAppRuntime();
}
function describeAppRuntimeProfile() {
  const profile = resolveAppRuntimeProfile();
  if (profile === "web") return "web-only";
  if (profile === "worker") return "worker";
  return "full";
}

export {
  isWebOnlyAppRuntime,
  isWorkerAppRuntime,
  areStatefulAppServicesEnabled,
  areLocalWhatsAppRuntimeServicesEnabled,
  describeAppRuntimeProfile
};
