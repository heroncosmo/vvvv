import {
  getBrazilTimeParts,
  init_greetingTime
} from "./chunk-LIK4OWWG.js";
import {
  db
} from "./chunk-R6CXRQMB.js";
import {
  adminConversations,
  admins,
  conversations,
  followupConfigs,
  followupLogs,
  systemConfig,
  userFollowupLogs,
  users,
  whatsappConnections
} from "./chunk-JC6URYU5.js";

// server/brazilWallClock.ts
init_greetingTime();
var BRAZIL_UTC_OFFSET = "-03:00";
function buildWallClockDate(parts) {
  return new Date(
    parts.year,
    parts.month - 1,
    parts.day,
    parts.hour,
    parts.minute,
    parts.second,
    0
  );
}
function cloneWallClockDate(value) {
  return new Date(
    value.getFullYear(),
    value.getMonth(),
    value.getDate(),
    value.getHours(),
    value.getMinutes(),
    value.getSeconds(),
    0
  );
}
function normalizeDateTimeInput(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) {
    return "";
  }
  if (!trimmed.includes("T") && trimmed.includes(" ")) {
    return trimmed.replace(" ", "T");
  }
  return trimmed;
}
function hasExplicitTimeZone(value) {
  if (!value) {
    return false;
  }
  if (value.endsWith("Z") || value.endsWith("z")) {
    return true;
  }
  const timeIndex = value.indexOf("T");
  if (timeIndex < 0) {
    return false;
  }
  const tail = value.slice(timeIndex + 1);
  const plusIndex = tail.lastIndexOf("+");
  const minusIndex = tail.lastIndexOf("-");
  const offsetIndex = Math.max(plusIndex, minusIndex);
  if (offsetIndex < 0) {
    return false;
  }
  const offset = tail.slice(offsetIndex);
  return offset.length === 6 && offset[3] === ":";
}
function parseWallClockParts(value) {
  const normalized = normalizeDateTimeInput(value);
  if (!normalized) {
    return null;
  }
  const [datePart = "", timePartRaw = "00:00:00"] = normalized.split("T");
  const [yearRaw = "", monthRaw = "", dayRaw = ""] = datePart.split("-");
  const [hourRaw = "00", minuteRaw = "00", secondRaw = "00"] = timePartRaw.split(":");
  const parts = {
    year: Number(yearRaw),
    month: Number(monthRaw),
    day: Number(dayRaw),
    hour: Number(hourRaw),
    minute: Number(minuteRaw),
    second: Number((secondRaw || "00").slice(0, 2))
  };
  if (Object.values(parts).some((part) => Number.isNaN(part))) {
    return null;
  }
  return parts;
}
function formatDatePart(value) {
  return String(value).padStart(2, "0");
}
function toBrazilWallClockDate(reference = /* @__PURE__ */ new Date()) {
  if (!Number.isFinite(reference.getTime())) {
    return new Date(Number.NaN);
  }
  return buildWallClockDate(getBrazilTimeParts(reference));
}
function getBrazilWallClockNow(reference = /* @__PURE__ */ new Date()) {
  return toBrazilWallClockDate(reference);
}
function parseBrazilWallClockDateTime(value) {
  if (!value) {
    return null;
  }
  if (value instanceof Date) {
    return Number.isFinite(value.getTime()) ? cloneWallClockDate(value) : null;
  }
  const normalized = normalizeDateTimeInput(value);
  if (!normalized) {
    return null;
  }
  if (hasExplicitTimeZone(normalized)) {
    const parsed = new Date(normalized);
    return Number.isFinite(parsed.getTime()) ? toBrazilWallClockDate(parsed) : null;
  }
  const parts = parseWallClockParts(normalized);
  if (!parts) {
    return null;
  }
  return buildWallClockDate(parts);
}
function formatBrazilWallClockDate(value) {
  const parsed = parseBrazilWallClockDateTime(value);
  if (!parsed) {
    return null;
  }
  return [
    parsed.getFullYear().toString().padStart(4, "0"),
    formatDatePart(parsed.getMonth() + 1),
    formatDatePart(parsed.getDate())
  ].join("-");
}
function serializeBrazilWallClockDateTime(value) {
  const parsed = parseBrazilWallClockDateTime(value);
  if (!parsed) {
    return null;
  }
  const date = formatBrazilWallClockDate(parsed);
  if (!date) {
    return null;
  }
  const time = [
    formatDatePart(parsed.getHours()),
    formatDatePart(parsed.getMinutes()),
    formatDatePart(parsed.getSeconds())
  ].join(":");
  return `${date}T${time}${BRAZIL_UTC_OFFSET}`;
}

// server/userFollowUpScheduling.ts
init_greetingTime();
var USER_FOLLOWUP_DEFAULT_INTERVALS = [10, 30, 180, 1440, 2880, 4320, 10080, 21600];
function getIntervals(config) {
  const intervals = config?.intervalsMinutes?.filter((value) => Number.isFinite(value) && value > 0);
  return intervals && intervals.length > 0 ? intervals : USER_FOLLOWUP_DEFAULT_INTERVALS;
}
function getBusinessDays(config) {
  const days = config?.businessDays?.filter((value) => Number.isInteger(value) && value >= 0 && value <= 6);
  return days && days.length > 0 ? days : [1, 2, 3, 4, 5];
}
function parseTime(value, fallback) {
  const source = String(value || fallback).slice(0, 5);
  const [hoursRaw, minutesRaw] = source.split(":");
  const hours = Number(hoursRaw);
  const minutes = Number(minutesRaw);
  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) {
    return parseTime(fallback, fallback);
  }
  return [Math.max(0, Math.min(23, hours)), Math.max(0, Math.min(59, minutes))];
}
function addRandomSeconds(date, randomFn = Math.random) {
  const randomSeconds = Math.floor(randomFn() * 45) + 5;
  return new Date(date.getTime() + randomSeconds * 1e3);
}
function formatDatePart2(value) {
  return String(value).padStart(2, "0");
}
function buildBrazilInstant(parts) {
  const isoDate = [
    String(parts.year).padStart(4, "0"),
    formatDatePart2(parts.month),
    formatDatePart2(parts.day)
  ].join("-");
  const isoTime = [
    formatDatePart2(parts.hour),
    formatDatePart2(parts.minute),
    formatDatePart2(parts.second)
  ].join(":");
  return /* @__PURE__ */ new Date(`${isoDate}T${isoTime}${BRAZIL_UTC_OFFSET}`);
}
function getBrazilCalendarCursor(reference) {
  const parts = getBrazilTimeParts(reference);
  return new Date(Date.UTC(parts.year, parts.month - 1, parts.day, 0, 0, 0, 0));
}
function getCursorParts(cursor) {
  return {
    year: cursor.getUTCFullYear(),
    month: cursor.getUTCMonth() + 1,
    day: cursor.getUTCDate()
  };
}
function isWithinBusinessHours(config, reference = /* @__PURE__ */ new Date()) {
  if (!config?.respectBusinessHours) {
    return true;
  }
  const local = getBrazilTimeParts(reference);
  const businessDays = getBusinessDays(config);
  const localDay = new Date(Date.UTC(local.year, local.month - 1, local.day)).getUTCDay();
  if (!businessDays.includes(localDay)) {
    return false;
  }
  const [startHour, startMinute] = parseTime(config.businessHoursStart, "09:00");
  const [endHour, endMinute] = parseTime(config.businessHoursEnd, "18:00");
  const currentMinutes = local.hour * 60 + local.minute;
  const startMinutes = startHour * 60 + startMinute;
  const endMinutes = endHour * 60 + endMinute;
  return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
}
function getNextBusinessTime(config, reference = /* @__PURE__ */ new Date()) {
  if (!config?.respectBusinessHours) {
    return reference;
  }
  const businessDays = getBusinessDays(config);
  const [startHour, startMinute] = parseTime(config.businessHoursStart, "09:00");
  const local = getBrazilTimeParts(reference);
  const currentMinutes = local.hour * 60 + local.minute;
  const startMinutes = startHour * 60 + startMinute;
  const cursor = getBrazilCalendarCursor(reference);
  const currentDay = cursor.getUTCDay();
  if (!businessDays.includes(currentDay) || currentMinutes >= startMinutes) {
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  while (!businessDays.includes(cursor.getUTCDay())) {
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  const dateParts = getCursorParts(cursor);
  return buildBrazilInstant({
    ...dateParts,
    hour: startHour,
    minute: startMinute,
    second: 0
  });
}
function alignDateToBusinessWindow(candidate, config) {
  if (!config?.respectBusinessHours) {
    return candidate;
  }
  const businessDays = getBusinessDays(config);
  const [startHour, startMinute] = parseTime(config.businessHoursStart, "09:00");
  const [endHour, endMinute] = parseTime(config.businessHoursEnd, "18:00");
  const startMinutes = startHour * 60 + startMinute;
  const endMinutes = endHour * 60 + endMinute;
  const local = getBrazilTimeParts(candidate);
  const currentMinutes = local.hour * 60 + local.minute;
  const cursor = getBrazilCalendarCursor(candidate);
  while (true) {
    const isAllowedDay = businessDays.includes(cursor.getUTCDay());
    const isAllowedTime = currentMinutes >= startMinutes && currentMinutes <= endMinutes;
    if (isAllowedDay && isAllowedTime) {
      return candidate;
    }
    if (!isAllowedDay || currentMinutes > endMinutes) {
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }
    while (!businessDays.includes(cursor.getUTCDay())) {
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }
    const dateParts = getCursorParts(cursor);
    return buildBrazilInstant({
      ...dateParts,
      hour: startHour,
      minute: startMinute,
      second: 0
    });
  }
}
function buildFollowUpStageScheduleDate(params) {
  const { config, stageIndex, now = /* @__PURE__ */ new Date(), randomFn = Math.random } = params;
  const intervals = getIntervals(config);
  let candidate;
  if (stageIndex >= intervals.length) {
    if (!config?.infiniteLoop) {
      return null;
    }
    const minDays = Math.max(1, Number(config.infiniteLoopMinDays) || 15);
    const maxDays = Math.max(minDays, Number(config.infiniteLoopMaxDays) || minDays);
    const randomDays = Math.floor(randomFn() * (maxDays - minDays + 1)) + minDays;
    candidate = new Date(now.getTime() + randomDays * 24 * 60 * 60 * 1e3);
  } else {
    const delayMinutes = intervals[stageIndex] || intervals[0] || USER_FOLLOWUP_DEFAULT_INTERVALS[0];
    candidate = new Date(now.getTime() + delayMinutes * 60 * 1e3);
  }
  return addRandomSeconds(alignDateToBusinessWindow(candidate, config), randomFn);
}
function buildMissingFollowUpScheduleDate(params) {
  const { config, currentStage, baseDate, now = /* @__PURE__ */ new Date(), randomFn = Math.random } = params;
  const intervals = getIntervals(config);
  let candidate;
  if (currentStage >= intervals.length) {
    if (!config?.infiniteLoop) {
      return null;
    }
    const minDays = Math.max(1, Number(config.infiniteLoopMinDays) || 15);
    const maxDays = Math.max(minDays, Number(config.infiniteLoopMaxDays) || minDays);
    const randomDays = Math.floor(randomFn() * (maxDays - minDays + 1)) + minDays;
    candidate = new Date(baseDate.getTime() + randomDays * 24 * 60 * 60 * 1e3);
  } else {
    const delayMinutes = intervals[currentStage] || intervals[0] || USER_FOLLOWUP_DEFAULT_INTERVALS[0];
    candidate = new Date(baseDate.getTime() + delayMinutes * 60 * 1e3);
  }
  if (candidate < now) {
    candidate = new Date(now.getTime() + 60 * 1e3);
  }
  return addRandomSeconds(alignDateToBusinessWindow(candidate, config), randomFn);
}

// server/adminMessagingFeaturePolicy.ts
var ADMIN_DISABLED_AI_BOOLEAN_FIELDS = [
  "paymentReminderAiEnabled",
  "payment_reminder_ai_enabled",
  "overdueReminderAiEnabled",
  "overdue_reminder_ai_enabled",
  "checkinAiEnabled",
  "checkin_ai_enabled",
  "broadcastAiVariation",
  "broadcast_ai_variation",
  "disconnectedAiEnabled",
  "disconnected_ai_enabled",
  "aiVariationEnabled",
  "ai_variation_enabled",
  "welcomeMessageAiEnabled",
  "welcome_message_ai_enabled"
];
var ADMIN_DISABLED_AI_TEXT_FIELDS = [
  "paymentReminderAiPrompt",
  "payment_reminder_ai_prompt",
  "overdueReminderAiPrompt",
  "overdue_reminder_ai_prompt",
  "checkinAiPrompt",
  "checkin_ai_prompt",
  "disconnectedAiPrompt",
  "disconnected_ai_prompt",
  "aiVariationPrompt",
  "ai_variation_prompt",
  "welcomeMessageAiPrompt",
  "welcome_message_ai_prompt"
];
function isAdminAiSendingEnabled() {
  return false;
}
function isAdminLiveAiEnabled() {
  return false;
}
function sanitizeAdminNotificationConfig(raw) {
  if (!raw) {
    return raw;
  }
  const sanitized = { ...raw };
  for (const field of ADMIN_DISABLED_AI_BOOLEAN_FIELDS) {
    sanitized[field] = false;
  }
  for (const field of ADMIN_DISABLED_AI_TEXT_FIELDS) {
    sanitized[field] = "";
  }
  return sanitized;
}
function sanitizeAdminBroadcast(raw) {
  if (!raw) {
    return raw;
  }
  return {
    ...raw,
    aiVariation: false,
    ai_variation: false
  };
}
function sanitizeAdminWhatsappConnection(raw) {
  if (!raw) {
    return raw;
  }
  return {
    ...raw,
    aiEnabled: false,
    ai_enabled: false
  };
}
function sanitizeAdminFollowupConfig(raw) {
  if (!raw) {
    return raw;
  }
  return {
    ...raw,
    enabled: false,
    isEnabled: false,
    followupNonPayersEnabled: false,
    followup_non_payers_enabled: false
  };
}

// server/adminFollowupMigrationService.ts
import { and, eq, inArray, isNotNull, sql } from "drizzle-orm";
var GLOBAL_FOLLOWUP_CONFIG_KEY = "admin_followup_global_config";
var LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG = {
  enabled: true,
  maxAttempts: 8,
  intervalsMinutes: [10, 30, 180, 1440, 4320, 10080, 259200, 432e3],
  finalMinDays: 15,
  finalMaxDays: 30,
  businessHoursStart: "09:00",
  businessHoursEnd: "18:00",
  businessDays: [1, 2, 3, 4, 5],
  respectBusinessHours: true,
  tone: "friendly",
  formalityLevel: 3,
  useEmojis: true,
  importantInfo: [],
  infiniteLoop: true,
  infiniteLoopMinDays: 15,
  infiniteLoopMaxDays: 30
};
function normalizeTimeValue(value, fallback) {
  if (typeof value !== "string" || !value.trim()) return fallback;
  const parts = value.split(":").map((part) => part.trim()).filter(Boolean);
  if (parts.length < 2) return fallback;
  const hour = (parts[0] || "00").padStart(2, "0").slice(0, 2);
  const minute = (parts[1] || "00").padStart(2, "0").slice(0, 2);
  return `${hour}:${minute}`;
}
function normalizeBusinessDays(value, fallback) {
  if (!Array.isArray(value)) return fallback;
  const cleaned = value.map((entry) => Number(entry)).filter((entry) => Number.isInteger(entry) && entry >= 0 && entry <= 6);
  return cleaned.length > 0 ? cleaned : fallback;
}
function normalizeIntervals(value, fallback) {
  if (!Array.isArray(value)) return fallback;
  const cleaned = value.map((entry) => Number(entry)).filter((entry) => Number.isFinite(entry) && entry > 0);
  return cleaned.length > 0 ? cleaned : fallback;
}
function normalizeText(value) {
  return typeof value === "string" ? value.trim() : "";
}
function normalizeDateKey(value) {
  if (!value) return "";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toISOString();
}
function buildLogDedupKey(data) {
  return [
    data.conversationId || "",
    data.contactNumber || "",
    data.status || "",
    String(data.stage ?? ""),
    normalizeDateKey(data.executedAt),
    normalizeText(data.messageContent),
    normalizeText(data.errorReason)
  ].join("|");
}
function normalizeAdminFollowupConfig(raw) {
  const fallback = LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG;
  return {
    enabled: raw?.enabled !== false,
    maxAttempts: Number(raw?.maxAttempts) > 0 ? Number(raw?.maxAttempts) : fallback.maxAttempts,
    intervalsMinutes: normalizeIntervals(raw?.intervalsMinutes, fallback.intervalsMinutes),
    finalMinDays: Number(raw?.finalMinDays) > 0 ? Number(raw?.finalMinDays) : fallback.finalMinDays,
    finalMaxDays: Number(raw?.finalMaxDays) > 0 ? Number(raw?.finalMaxDays) : fallback.finalMaxDays,
    businessHoursStart: normalizeTimeValue(raw?.businessHoursStart, fallback.businessHoursStart),
    businessHoursEnd: normalizeTimeValue(raw?.businessHoursEnd, fallback.businessHoursEnd),
    businessDays: normalizeBusinessDays(raw?.businessDays, fallback.businessDays),
    respectBusinessHours: raw?.respectBusinessHours !== false,
    tone: typeof raw?.tone === "string" && raw.tone.trim() ? raw.tone : fallback.tone,
    formalityLevel: Number(raw?.formalityLevel) > 0 ? Number(raw?.formalityLevel) : fallback.formalityLevel,
    useEmojis: raw?.useEmojis !== false,
    importantInfo: Array.isArray(raw?.importantInfo) ? raw.importantInfo : fallback.importantInfo,
    infiniteLoop: raw?.infiniteLoop !== false,
    infiniteLoopMinDays: Number(raw?.infiniteLoopMinDays) > 0 ? Number(raw?.infiniteLoopMinDays) : fallback.infiniteLoopMinDays,
    infiniteLoopMaxDays: Number(raw?.infiniteLoopMaxDays) > 0 ? Number(raw?.infiniteLoopMaxDays) : fallback.infiniteLoopMaxDays
  };
}
function isLegacyAdminFollowupConfig(raw) {
  if (!raw) return true;
  return JSON.stringify(normalizeAdminFollowupConfig(raw)) === JSON.stringify(LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG);
}
async function getAdminFollowupGlobalConfig() {
  const fallback = sanitizeAdminFollowupConfig({
    id: "global",
    userId: "admin",
    isEnabled: false,
    followupNonPayersEnabled: false,
    ...LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG
  });
  try {
    const row = await db.query.systemConfig.findFirst({
      where: eq(systemConfig.chave, GLOBAL_FOLLOWUP_CONFIG_KEY)
    });
    if (!row?.valor) return fallback;
    const parsed = JSON.parse(row.valor);
    const normalized = normalizeAdminFollowupConfig(parsed);
    return sanitizeAdminFollowupConfig({
      ...fallback,
      ...parsed,
      ...normalized,
      isEnabled: false,
      followupNonPayersEnabled: false
    });
  } catch {
    return fallback;
  }
}
async function saveAdminFollowupGlobalConfig(data) {
  const existing = await db.query.systemConfig.findFirst({
    where: eq(systemConfig.chave, GLOBAL_FOLLOWUP_CONFIG_KEY)
  });
  const current = existing?.valor ? JSON.parse(existing.valor) : {};
  const normalized = normalizeAdminFollowupConfig({ ...current, ...data });
  const merged = sanitizeAdminFollowupConfig({
    id: "global",
    userId: "admin",
    isEnabled: false,
    followupNonPayersEnabled: false,
    ...current,
    ...data,
    ...normalized
  });
  const valor = JSON.stringify(merged);
  if (existing) {
    await db.update(systemConfig).set({ valor, updatedAt: /* @__PURE__ */ new Date() }).where(eq(systemConfig.chave, GLOBAL_FOLLOWUP_CONFIG_KEY));
  } else {
    await db.insert(systemConfig).values({
      chave: GLOBAL_FOLLOWUP_CONFIG_KEY,
      valor
    });
  }
  return merged;
}
function buildAdminFollowupConfigFromUserConfig(userConfig) {
  if (!userConfig) return normalizeAdminFollowupConfig();
  return normalizeAdminFollowupConfig({
    enabled: userConfig.isEnabled !== false,
    maxAttempts: userConfig.maxAttempts,
    intervalsMinutes: userConfig.intervalsMinutes,
    finalMinDays: userConfig.infiniteLoopMinDays,
    finalMaxDays: userConfig.infiniteLoopMaxDays,
    businessHoursStart: userConfig.businessHoursStart,
    businessHoursEnd: userConfig.businessHoursEnd,
    businessDays: userConfig.businessDays,
    respectBusinessHours: userConfig.respectBusinessHours,
    tone: userConfig.tone,
    formalityLevel: userConfig.formalityLevel,
    useEmojis: userConfig.useEmojis,
    importantInfo: userConfig.importantInfo,
    infiniteLoop: userConfig.infiniteLoop,
    infiniteLoopMinDays: userConfig.infiniteLoopMinDays,
    infiniteLoopMaxDays: userConfig.infiniteLoopMaxDays
  });
}
function shouldSourceWin(sourceStage, sourceNext, target) {
  if (!target) return true;
  if (!target.followupActive || !target.nextFollowupAt) return true;
  const targetStage = Number(target.followupStage || 0);
  if (targetStage > sourceStage) return false;
  if (targetStage < sourceStage) return true;
  if (!sourceNext) return false;
  return sourceNext.getTime() < new Date(target.nextFollowupAt).getTime();
}
async function resolveMigrationActors(params) {
  let adminId = params.adminId;
  if (!adminId && params.adminEmail) {
    const admin = await db.query.admins.findFirst({
      where: eq(admins.email, params.adminEmail)
    });
    adminId = admin?.id;
  }
  if (!adminId) {
    throw new Error("Admin de destino nao encontrado");
  }
  let sourceUserId = params.sourceUserId;
  if (!sourceUserId && params.sourceEmail) {
    const user = await db.query.users.findFirst({
      where: eq(users.email, params.sourceEmail)
    });
    sourceUserId = user?.id;
  }
  if (!sourceUserId) {
    throw new Error("Usuario de origem nao encontrado");
  }
  return { adminId, sourceUserId };
}
async function migrateUserFollowupsToAdmin(params) {
  const { adminId, sourceUserId } = await resolveMigrationActors(params);
  const sourceConfig = await db.query.followupConfigs.findFirst({
    where: eq(followupConfigs.userId, sourceUserId)
  });
  const mappedConfig = buildAdminFollowupConfigFromUserConfig(sourceConfig);
  const globalConfig = await saveAdminFollowupGlobalConfig({
    ...mappedConfig,
    isEnabled: sourceConfig?.isEnabled !== false
  });
  const sourceConversations = await db.select({
    id: conversations.id,
    contactNumber: conversations.contactNumber,
    contactName: conversations.contactName,
    remoteJid: conversations.remoteJid,
    followupStage: conversations.followupStage,
    nextFollowupAt: conversations.nextFollowupAt,
    lastMessageText: conversations.lastMessageText,
    lastMessageTime: conversations.lastMessageTime
  }).from(conversations).innerJoin(whatsappConnections, eq(whatsappConnections.id, conversations.connectionId)).where(and(
    eq(whatsappConnections.userId, sourceUserId),
    eq(conversations.followupActive, true),
    isNotNull(conversations.nextFollowupAt)
  ));
  const targetConversations = await db.query.adminConversations.findMany({
    where: eq(adminConversations.adminId, adminId)
  });
  const targetMap = new Map(targetConversations.map((conv) => [conv.contactNumber, conv]));
  let created = 0;
  let updated = 0;
  let keptTarget = 0;
  let disabledSource = 0;
  for (const source of sourceConversations) {
    const sourceStage = Number(source.followupStage || 0);
    const sourceNext = source.nextFollowupAt ? new Date(source.nextFollowupAt) : null;
    const existingTarget = targetMap.get(source.contactNumber) || null;
    if (!existingTarget) {
      const [createdConversation] = await db.insert(adminConversations).values({
        adminId,
        contactNumber: source.contactNumber,
        remoteJid: source.remoteJid,
        contactName: source.contactName,
        lastMessageText: source.lastMessageText,
        lastMessageTime: source.lastMessageTime,
        unreadCount: 0,
        isAgentEnabled: true,
        followupActive: true,
        followupStage: sourceStage,
        nextFollowupAt: sourceNext,
        followupConfig: mappedConfig,
        contextState: {
          followupMigration: {
            sourceUserId,
            sourceConversationId: source.id,
            migratedAt: (/* @__PURE__ */ new Date()).toISOString(),
            sourceStage,
            sourceNextFollowupAt: sourceNext?.toISOString() || null
          }
        }
      }).returning();
      targetMap.set(source.contactNumber, createdConversation);
      created += 1;
    } else if (shouldSourceWin(sourceStage, sourceNext, existingTarget)) {
      const currentState = existingTarget.contextState || {};
      const [updatedConversation] = await db.update(adminConversations).set({
        remoteJid: existingTarget.remoteJid || source.remoteJid,
        contactName: existingTarget.contactName || source.contactName,
        lastMessageText: source.lastMessageText || existingTarget.lastMessageText,
        lastMessageTime: source.lastMessageTime || existingTarget.lastMessageTime,
        followupActive: true,
        followupStage: sourceStage,
        nextFollowupAt: sourceNext,
        followupConfig: mappedConfig,
        contextState: {
          ...currentState,
          followupMigration: {
            sourceUserId,
            sourceConversationId: source.id,
            migratedAt: (/* @__PURE__ */ new Date()).toISOString(),
            sourceStage,
            sourceNextFollowupAt: sourceNext?.toISOString() || null
          }
        },
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq(adminConversations.id, existingTarget.id)).returning();
      targetMap.set(source.contactNumber, updatedConversation);
      updated += 1;
    } else {
      keptTarget += 1;
    }
    await db.update(conversations).set({
      followupActive: false,
      nextFollowupAt: null,
      followupDisabledReason: `Migrado para admin ${adminId} em ${(/* @__PURE__ */ new Date()).toISOString()}`,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(conversations.id, source.id));
    disabledSource += 1;
  }
  return {
    sourceUserId,
    adminId,
    sourceConfigApplied: mappedConfig,
    globalConfigSaved: globalConfig,
    scanned: sourceConversations.length,
    created,
    updated,
    keptTarget,
    disabledSource
  };
}
async function migrateUserFollowupLogsToAdmin(params) {
  const { adminId, sourceUserId } = await resolveMigrationActors(params);
  const globalConfig = await getAdminFollowupGlobalConfig();
  const targetConversations = await db.query.adminConversations.findMany({
    where: eq(adminConversations.adminId, adminId)
  });
  const targetByPhone = /* @__PURE__ */ new Map();
  const targetBySourceConversationId = /* @__PURE__ */ new Map();
  for (const conversation of targetConversations) {
    if (conversation.contactNumber && !targetByPhone.has(conversation.contactNumber)) {
      targetByPhone.set(conversation.contactNumber, conversation);
    }
    const sourceConversationId = conversation.contextState?.followupMigration?.sourceConversationId;
    if (sourceConversationId && !targetBySourceConversationId.has(sourceConversationId)) {
      targetBySourceConversationId.set(sourceConversationId, conversation);
    }
  }
  const targetConversationIds = targetConversations.map((conversation) => conversation.id);
  const existingLogs = targetConversationIds.length > 0 ? await db.query.followupLogs.findMany({
    where: inArray(followupLogs.conversationId, targetConversationIds)
  }) : [];
  const existingKeys = new Set(
    existingLogs.map(
      (entry) => buildLogDedupKey({
        conversationId: entry.conversationId,
        contactNumber: entry.contactNumber,
        status: entry.status,
        stage: entry.stage,
        executedAt: entry.executedAt,
        messageContent: entry.messageContent,
        errorReason: entry.errorReason
      })
    )
  );
  const sourceLogs = await db.query.userFollowupLogs.findMany({
    where: eq(userFollowupLogs.userId, sourceUserId),
    orderBy: (table, { asc }) => [asc(table.executedAt), asc(table.id)]
  });
  const sourceConversationIds = Array.from(
    new Set(sourceLogs.map((entry) => entry.conversationId).filter((entry) => Boolean(entry)))
  );
  const sourceConversations = sourceConversationIds.length > 0 ? await db.select({
    id: conversations.id,
    contactNumber: conversations.contactNumber,
    contactName: conversations.contactName,
    remoteJid: conversations.remoteJid,
    followupActive: conversations.followupActive,
    followupStage: conversations.followupStage,
    nextFollowupAt: conversations.nextFollowupAt,
    lastMessageText: conversations.lastMessageText,
    lastMessageTime: conversations.lastMessageTime
  }).from(conversations).innerJoin(whatsappConnections, eq(whatsappConnections.id, conversations.connectionId)).where(and(
    eq(whatsappConnections.userId, sourceUserId),
    inArray(conversations.id, sourceConversationIds)
  )) : [];
  const sourceConversationById = new Map(sourceConversations.map((entry) => [entry.id, entry]));
  const sourceConversationByPhone = /* @__PURE__ */ new Map();
  for (const entry of sourceConversations) {
    if (entry.contactNumber && !sourceConversationByPhone.has(entry.contactNumber)) {
      sourceConversationByPhone.set(entry.contactNumber, entry);
    }
  }
  let migrated = 0;
  let skippedExisting = 0;
  let skippedWithoutTarget = 0;
  let createdFromHistory = 0;
  for (const sourceLog of sourceLogs) {
    let targetConversation = (sourceLog.conversationId ? targetBySourceConversationId.get(sourceLog.conversationId) : null) || targetByPhone.get(sourceLog.contactNumber);
    if (!targetConversation) {
      const sourceConversation = (sourceLog.conversationId ? sourceConversationById.get(sourceLog.conversationId) : null) || sourceConversationByPhone.get(sourceLog.contactNumber);
      if (!sourceConversation) {
        skippedWithoutTarget += 1;
        continue;
      }
      const [createdConversation] = await db.insert(adminConversations).values({
        adminId,
        contactNumber: sourceConversation.contactNumber,
        remoteJid: sourceConversation.remoteJid,
        contactName: sourceConversation.contactName,
        lastMessageText: sourceConversation.lastMessageText || sourceLog.messageContent,
        lastMessageTime: sourceConversation.lastMessageTime || sourceLog.executedAt,
        unreadCount: 0,
        isAgentEnabled: true,
        followupActive: Boolean(sourceConversation.followupActive && sourceConversation.nextFollowupAt),
        followupStage: Number(sourceConversation.followupStage || sourceLog.stage || 0),
        nextFollowupAt: sourceConversation.nextFollowupAt,
        followupConfig: normalizeAdminFollowupConfig(globalConfig),
        contextState: {
          followupMigration: {
            sourceUserId,
            sourceConversationId: sourceConversation.id,
            migratedAt: (/* @__PURE__ */ new Date()).toISOString(),
            sourceStage: Number(sourceConversation.followupStage || sourceLog.stage || 0),
            sourceNextFollowupAt: sourceConversation.nextFollowupAt?.toISOString?.() || null,
            historyOnly: true
          }
        }
      }).returning();
      targetConversation = createdConversation;
      targetByPhone.set(createdConversation.contactNumber, createdConversation);
      targetBySourceConversationId.set(sourceConversation.id, createdConversation);
      createdFromHistory += 1;
    }
    const aiDecisionReason = sourceLog.aiDecision && typeof sourceLog.aiDecision === "object" ? normalizeText(sourceLog.aiDecision.reason) : "";
    const errorReason = normalizeText(sourceLog.errorReason) || aiDecisionReason || void 0;
    const stage = Number(sourceLog.stage || 0);
    const effectiveConfig = normalizeAdminFollowupConfig(targetConversation.followupConfig || null);
    const followupType = stage >= effectiveConfig.intervalsMinutes.length ? "final" : "regular";
    const dedupKey = buildLogDedupKey({
      conversationId: targetConversation.id,
      contactNumber: sourceLog.contactNumber,
      status: sourceLog.status,
      stage,
      executedAt: sourceLog.executedAt,
      messageContent: sourceLog.messageContent,
      errorReason
    });
    if (existingKeys.has(dedupKey)) {
      skippedExisting += 1;
      continue;
    }
    await db.insert(followupLogs).values({
      conversationId: targetConversation.id,
      contactNumber: sourceLog.contactNumber,
      status: sourceLog.status,
      messageContent: sourceLog.messageContent,
      executedAt: sourceLog.executedAt,
      errorReason,
      paymentStatus: targetConversation.paymentStatus || "pending",
      followupType,
      stage
    });
    existingKeys.add(dedupKey);
    migrated += 1;
  }
  return {
    sourceUserId,
    adminId,
    scanned: sourceLogs.length,
    migrated,
    skippedExisting,
    skippedWithoutTarget,
    createdFromHistory
  };
}
async function repairAdminFailedFollowupRetries(params) {
  let adminId = params.adminId;
  if (!adminId && params.adminEmail) {
    const admin = await db.query.admins.findFirst({
      where: eq(admins.email, params.adminEmail)
    });
    adminId = admin?.id;
  }
  if (!adminId) {
    throw new Error("Admin de destino nao encontrado");
  }
  const globalConfig = await getAdminFollowupGlobalConfig();
  const failedRows = await db.execute(sql`
    with latest_log as (
      select distinct on (l.conversation_id)
        l.id,
        l.conversation_id,
        l.status,
        l.executed_at
      from followup_logs l
      inner join admin_conversations c on c.id = l.conversation_id
      where c.admin_id = ${adminId}
      order by l.conversation_id, l.executed_at desc, l.id desc
    )
    select c.id, c.followup_stage, c.followup_config
    from latest_log
    inner join admin_conversations c on c.id = latest_log.conversation_id
    where latest_log.status = 'failed'
      and c.followup_active = true
      and c.next_followup_at is null
  `);
  let repaired = 0;
  let nextAtBase = Date.now();
  for (const row of failedRows.rows) {
    const stage = Number(row.followup_stage || 0);
    const effectiveConfig = normalizeAdminFollowupConfig({
      ...globalConfig,
      ...row.followup_config || {}
    });
    const delayMinutes = effectiveConfig.intervalsMinutes[Math.min(stage, effectiveConfig.intervalsMinutes.length - 1)] || 10;
    nextAtBase += 60 * 1e3;
    const scheduledFor = new Date(nextAtBase + delayMinutes * 60 * 1e3);
    await db.update(adminConversations).set({
      nextFollowupAt: scheduledFor,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminConversations.id, row.id));
    repaired += 1;
  }
  return {
    adminId,
    repaired
  };
}

// server/adminConversationAutomationState.ts
function isAdminConversationFollowupManuallyPaused(conversation) {
  return conversation?.contextState?.manualFollowupPause === true;
}
function shouldAutoRescheduleAdminFollowup(params) {
  if (params.allowManualResume) return true;
  if (isAdminConversationFollowupManuallyPaused(params.conversation)) return false;
  if (!params.forceRestart && params.hasScheduledFollowup) return false;
  return true;
}

export {
  BRAZIL_UTC_OFFSET,
  toBrazilWallClockDate,
  getBrazilWallClockNow,
  parseBrazilWallClockDateTime,
  formatBrazilWallClockDate,
  serializeBrazilWallClockDateTime,
  USER_FOLLOWUP_DEFAULT_INTERVALS,
  addRandomSeconds,
  isWithinBusinessHours,
  getNextBusinessTime,
  alignDateToBusinessWindow,
  buildFollowUpStageScheduleDate,
  buildMissingFollowUpScheduleDate,
  isAdminAiSendingEnabled,
  isAdminLiveAiEnabled,
  sanitizeAdminNotificationConfig,
  sanitizeAdminBroadcast,
  sanitizeAdminWhatsappConnection,
  sanitizeAdminFollowupConfig,
  LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG,
  normalizeAdminFollowupConfig,
  isLegacyAdminFollowupConfig,
  getAdminFollowupGlobalConfig,
  migrateUserFollowupsToAdmin,
  migrateUserFollowupLogsToAdmin,
  repairAdminFailedFollowupRetries,
  isAdminConversationFollowupManuallyPaused,
  shouldAutoRescheduleAdminFollowup
};
