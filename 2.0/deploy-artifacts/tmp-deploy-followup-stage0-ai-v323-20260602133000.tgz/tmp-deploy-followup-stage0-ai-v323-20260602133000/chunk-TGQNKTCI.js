import {
  applyBroadcastTemplate
} from "./chunk-KUPD522F.js";
import {
  applyAIVariation
} from "./chunk-HDEH5N4C.js";
import {
  ensureUserSessionOperational,
  getSession,
  prepareOutgoingMediaForSend,
  sendMessage,
  sendUserMediaMessage
} from "./chunk-JDBD3TU2.js";
import {
  isOfficialCoexistenceConnection,
  isWhatsAppGatewayRuntime,
  resolveWhatsAppConnectionOwner,
  sendGatewayInstanceGroupBulk,
  sendGatewayInstanceMedia,
  sendGatewayInstanceText
} from "./chunk-LYL74IEX.js";
import {
  generatePixQRCode
} from "./chunk-ZHXPYC3F.js";
import {
  buildGatewayTextSendBody
} from "./chunk-GXAKLONY.js";
import {
  storage
} from "./chunk-7SPF5OKO.js";
import {
  db,
  pool
} from "./chunk-R6CXRQMB.js";
import {
  broadcastCampaigns,
  users,
  whatsappConnections
} from "./chunk-JC6URYU5.js";

// server/ownerNotificationWorkspaceService.ts
import crypto from "crypto";
import { desc as desc2, eq as eq3, sql as sql3 } from "drizzle-orm";

// server/broadcastService.ts
import { and, asc, desc, eq, inArray, like, sql } from "drizzle-orm";
var BROADCAST_MIN_DELAY_MS = 6e4;
var BROADCAST_MAX_DELAY_MS = 3e5;
var BROADCAST_BATCH_SIZE = 10;
var BROADCAST_BATCH_PAUSE_MIN_MS = 9e5;
var BROADCAST_BATCH_PAUSE_MAX_MS = 12e5;
var BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES = 10;
var BROADCAST_INBOUND_GATE_WINDOW_MS = 60 * 60 * 1e3;
var BROADCAST_INBOUND_GATE_RECHECK_MS = 6e4;
var BROADCAST_BUSINESS_HOURS_START_HOUR = 8;
var BROADCAST_BUSINESS_HOURS_END_HOUR = 20;
var BROADCAST_BRAZIL_UTC_OFFSET_HOURS = -3;
var LEGACY_BROADCAST_MEDIA_MAINTENANCE_INTERVAL_MS = 6 * 60 * 60 * 1e3;
var SOCKET_WAIT_TIMEOUT_MS = 3e5;
var SOCKET_POLL_INTERVAL_MS = 3e4;
var CANCELLATION_CHECK_INTERVAL_MS = 1e3;
var BRAZIL_UTC_OFFSET = "-03:00";
var ACTIVE_BROADCAST_STATUSES = ["pending", "running", "scheduled"];
var BROADCAST_UNSTARTED_RECOVERY_MAX_AGE_MS = 2 * 60 * 60 * 1e3;
var BROADCAST_STALE_UNSTARTED_CANCELLATION_MESSAGE = "Envio cancelado por seguran\xE7a: esta campanha ficou aguardando in\xEDcio por mais de 2 horas. Crie um novo envio para confirmar o conte\xFAdo atual.";
var activeBroadcastTasks = /* @__PURE__ */ new Map();
var activeBroadcastCancels = /* @__PURE__ */ new Map();
var broadcastServiceDeps = {
  ensureUserSessionOperational
};
function isConnectionMarkedActiveForBroadcast(connection) {
  const providerStatus = String(connection.providerStatus || "").trim().toLowerCase();
  return !!connection.isConnected || providerStatus === "connected";
}
async function resolveBaileysBroadcastSocket(userId, connectionId, source = "broadcast:dispatch") {
  const session = await broadcastServiceDeps.ensureUserSessionOperational(userId, connectionId, {
    waitMs: 1e4,
    source
  });
  return session?.socket || null;
}
function clampDelayMin(delayMinMs) {
  return Math.max(BROADCAST_MIN_DELAY_MS, Number(delayMinMs || 0));
}
function clampDelayMax(delayMaxMs, delayMinMs) {
  const min = clampDelayMin(delayMinMs);
  return Math.max(BROADCAST_MAX_DELAY_MS, Number(delayMaxMs || 0), min);
}
function normalizeBroadcastConnectionMode(mode) {
  return mode === "rotate" ? "rotate" : "single";
}
function normalizeConnectionId(value) {
  return String(value || "").trim();
}
function normalizeConnectionIdList(connectionIds) {
  const seen = /* @__PURE__ */ new Set();
  const normalized = [];
  for (const rawConnectionId of Array.isArray(connectionIds) ? connectionIds : []) {
    const connectionId = normalizeConnectionId(rawConnectionId);
    if (!connectionId || seen.has(connectionId)) {
      continue;
    }
    seen.add(connectionId);
    normalized.push(connectionId);
  }
  return normalized;
}
function normalizeBooleanOption(value, fallback) {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (["true", "1", "yes", "sim", "on"].includes(normalized)) return true;
    if (["false", "0", "no", "nao", "off"].includes(normalized)) return false;
  }
  return fallback;
}
function normalizeHourOption(value, fallback, min = 0, max = 24) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.round(parsed)));
}
function parseDateMs(value) {
  if (!value) return null;
  const ms = new Date(String(value)).getTime();
  return Number.isFinite(ms) ? ms : null;
}
function getValidIsoDate(value) {
  const ms = parseDateMs(value);
  return ms ? new Date(ms).toISOString() : null;
}
function getBrazilWallClockDate(date) {
  return new Date(date.getTime() + BROADCAST_BRAZIL_UTC_OFFSET_HOURS * 60 * 60 * 1e3);
}
function buildUtcDateFromBrazilWallClock(year, monthIndex, day, hour) {
  return new Date(Date.UTC(year, monthIndex, day, hour - BROADCAST_BRAZIL_UTC_OFFSET_HOURS, 0, 0, 0));
}
function normalizeBroadcastInboundGate(metadata) {
  const raw = metadata.inboundGate && typeof metadata.inboundGate === "object" && !Array.isArray(metadata.inboundGate) ? metadata.inboundGate : {};
  const rawConnections = raw.connections && typeof raw.connections === "object" && !Array.isArray(raw.connections) ? raw.connections : {};
  return {
    version: 1,
    requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES,
    windowMs: BROADCAST_INBOUND_GATE_WINDOW_MS,
    recheckMs: BROADCAST_INBOUND_GATE_RECHECK_MS,
    connections: { ...rawConnections }
  };
}
function normalizeBroadcastSafetyConfig(metadata) {
  const raw = metadata.broadcastSafety && typeof metadata.broadcastSafety === "object" && !Array.isArray(metadata.broadcastSafety) ? metadata.broadcastSafety : {};
  const startHour = normalizeHourOption(raw.businessHoursStartHour ?? raw.startHour ?? metadata.businessHoursStartHour, BROADCAST_BUSINESS_HOURS_START_HOUR, 0, 23);
  const endHour = normalizeHourOption(raw.businessHoursEndHour ?? raw.endHour ?? metadata.businessHoursEndHour, BROADCAST_BUSINESS_HOURS_END_HOUR, 1, 24);
  return {
    version: 1,
    inboundGateEnabled: normalizeBooleanOption(raw.inboundGateEnabled ?? metadata.inboundGateEnabled, true),
    businessHoursEnabled: normalizeBooleanOption(raw.businessHoursEnabled ?? metadata.businessHoursEnabled, true),
    businessHoursStartHour: startHour,
    businessHoursEndHour: Math.max(startHour + 1, endHour),
    businessHoursTimeZone: "America/Sao_Paulo"
  };
}
function withBroadcastSafetyDefaults(metadata = {}) {
  return {
    ...metadata,
    broadcastSafety: normalizeBroadcastSafetyConfig(metadata)
  };
}
function resolveBroadcastBusinessHoursDecision(metadata, now = /* @__PURE__ */ new Date()) {
  const safety = normalizeBroadcastSafetyConfig(metadata);
  const nowIso = now.toISOString();
  if (!safety.businessHoursEnabled) {
    return {
      canSend: true,
      metadata: {
        ...metadata,
        broadcastSafety: safety,
        businessHoursLastDecision: {
          at: nowIso,
          reason: "disabled",
          timeZone: safety.businessHoursTimeZone
        }
      },
      nextDueAt: null,
      reason: "disabled",
      safety
    };
  }
  const brazilNow = getBrazilWallClockDate(now);
  const hour = brazilNow.getUTCHours();
  const insideWindow = hour >= safety.businessHoursStartHour && hour < safety.businessHoursEndHour;
  if (insideWindow) {
    return {
      canSend: true,
      metadata: {
        ...metadata,
        broadcastSafety: safety,
        businessHoursLastDecision: {
          at: nowIso,
          reason: "inside_business_hours",
          currentHour: hour,
          startHour: safety.businessHoursStartHour,
          endHour: safety.businessHoursEndHour,
          timeZone: safety.businessHoursTimeZone
        }
      },
      nextDueAt: null,
      reason: "inside_business_hours",
      safety
    };
  }
  const year = brazilNow.getUTCFullYear();
  const month = brazilNow.getUTCMonth();
  const day = brazilNow.getUTCDate();
  const nextStart = hour < safety.businessHoursStartHour ? buildUtcDateFromBrazilWallClock(year, month, day, safety.businessHoursStartHour) : buildUtcDateFromBrazilWallClock(year, month, day + 1, safety.businessHoursStartHour);
  const nextDueAt = nextStart.toISOString();
  return {
    canSend: false,
    metadata: {
      ...metadata,
      broadcastSafety: safety,
      businessHoursLastDecision: {
        at: nowIso,
        reason: "outside_business_hours",
        currentHour: hour,
        startHour: safety.businessHoursStartHour,
        endHour: safety.businessHoursEndHour,
        timeZone: safety.businessHoursTimeZone,
        nextDueAt
      }
    },
    nextDueAt,
    reason: "outside_business_hours",
    safety
  };
}
function readRotationConnectionIds(metadataJson) {
  const metadata = metadataJson || {};
  return normalizeConnectionIdList(
    Array.isArray(metadata.rotationConnectionIds) ? metadata.rotationConnectionIds.map((connectionId) => String(connectionId || "")) : []
  );
}
function isRotationalBroadcastCampaign(campaign) {
  const metadata = campaign.metadataJson || {};
  return metadata.connectionMode === "rotate" && readRotationConnectionIds(metadata).length > 1;
}
async function countInboundMessagesForConnectionSince(connectionId, sinceIso) {
  const result = await db.execute(sql`
    SELECT COUNT(*)::int AS count
    FROM messages m
    INNER JOIN conversations c ON c.id = m.conversation_id
    WHERE c.connection_id = ${connectionId}
      AND m.from_me = false
      AND m.timestamp >= ${sinceIso}::timestamptz
  `);
  return Number(result.rows[0]?.count || 0);
}
function getCampaignConnectionCandidates(campaign, contact, index, preferredConnectionId) {
  const metadata = campaign.metadataJson || {};
  const rotationConnectionIds = readRotationConnectionIds(metadata);
  const selectedRotationConnectionId = isRotationalBroadcastCampaign(campaign) ? selectBroadcastConnectionIdForContact(rotationConnectionIds, campaign.connectionId, index) : null;
  return Array.from(
    new Set(
      [
        normalizeConnectionId(preferredConnectionId),
        normalizeConnectionId(contact.connectionId),
        normalizeConnectionId(selectedRotationConnectionId),
        normalizeConnectionId(campaign.connectionId)
      ].filter(Boolean)
    )
  );
}
async function resolveBroadcastInboundGate(campaign, contact, index, metadata, preferredConnectionId) {
  const candidates = getCampaignConnectionCandidates(campaign, contact, index, preferredConnectionId);
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();
  const safety = normalizeBroadcastSafetyConfig(metadata);
  const inboundGate = normalizeBroadcastInboundGate(metadata);
  const checkedConnections = [];
  if (!safety.inboundGateEnabled) {
    const connectionId = candidates[0] || null;
    return {
      canSend: true,
      connectionId,
      metadata: {
        ...metadata,
        broadcastSafety: safety,
        inboundGate,
        inboundGateLastDecision: {
          at: nowIso,
          reason: "disabled",
          connectionId,
          requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES
        }
      },
      nextDueAt: null,
      reason: "disabled",
      inboundCount: 0,
      requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES,
      windowStartedAt: null,
      checkedConnections
    };
  }
  if (candidates.length === 0) {
    return {
      canSend: true,
      connectionId: null,
      metadata: {
        ...metadata,
        broadcastSafety: safety,
        inboundGate,
        inboundGateLastDecision: {
          at: nowIso,
          reason: "no_connection_candidate",
          requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES
        }
      },
      nextDueAt: null,
      reason: "no_connection_candidate",
      inboundCount: 0,
      requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES,
      windowStartedAt: null,
      checkedConnections
    };
  }
  let bestWaitUntilMs = nowMs + BROADCAST_INBOUND_GATE_RECHECK_MS;
  for (const connectionId of candidates) {
    const rawState = inboundGate.connections[connectionId] && typeof inboundGate.connections[connectionId] === "object" ? inboundGate.connections[connectionId] : {};
    const windowStartedAt = getValidIsoDate(rawState.windowStartedAt) || getValidIsoDate(rawState.lastResetAt) || nowIso;
    const windowStartedMs = parseDateMs(windowStartedAt) || nowMs;
    const waitUntilMs = windowStartedMs + BROADCAST_INBOUND_GATE_WINDOW_MS;
    const inboundCount = await countInboundMessagesForConnectionSince(connectionId, windowStartedAt);
    const forcedAfterTimeout = inboundCount < BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES && waitUntilMs <= nowMs;
    const eligible = inboundCount >= BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES || forcedAfterTimeout;
    const waitUntil = new Date(waitUntilMs).toISOString();
    inboundGate.connections[connectionId] = {
      ...rawState,
      windowStartedAt,
      lastCheckedAt: nowIso,
      lastInboundCount: inboundCount,
      waitUntil
    };
    checkedConnections.push({
      connectionId,
      inboundCount,
      windowStartedAt,
      waitUntil,
      eligible,
      forcedAfterTimeout
    });
    if (eligible) {
      return {
        canSend: true,
        connectionId,
        metadata: {
          ...metadata,
          inboundGate,
          inboundGateLastDecision: {
            at: nowIso,
            reason: forcedAfterTimeout ? "timeout_send_one" : "inbound_threshold_met",
            connectionId,
            inboundCount,
            requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES,
            windowStartedAt,
            waitUntil,
            checkedConnections
          }
        },
        nextDueAt: null,
        reason: forcedAfterTimeout ? "timeout_send_one" : "inbound_threshold_met",
        inboundCount,
        requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES,
        windowStartedAt,
        forcedAfterTimeout,
        checkedConnections
      };
    }
    bestWaitUntilMs = Math.min(bestWaitUntilMs, waitUntilMs);
  }
  const nextCheckMs = Math.max(nowMs + 5e3, Math.min(nowMs + BROADCAST_INBOUND_GATE_RECHECK_MS, bestWaitUntilMs));
  const nextDueAt = new Date(nextCheckMs).toISOString();
  const bestConnection = [...checkedConnections].sort((left, right) => right.inboundCount - left.inboundCount)[0] || null;
  return {
    canSend: false,
    connectionId: null,
    metadata: {
      ...metadata,
      inboundGate,
      inboundGateLastDecision: {
        at: nowIso,
        reason: "waiting_inbound_messages",
        requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES,
        nextDueAt,
        bestConnection,
        checkedConnections
      }
    },
    nextDueAt,
    reason: "waiting_inbound_messages",
    inboundCount: bestConnection?.inboundCount || 0,
    requiredMessages: BROADCAST_INBOUND_GATE_REQUIRED_MESSAGES,
    windowStartedAt: bestConnection?.windowStartedAt || null,
    checkedConnections
  };
}
function markBroadcastInboundGateAfterSend(metadata, connectionId, gateDecision) {
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const inboundGate = normalizeBroadcastInboundGate(metadata);
  if (connectionId) {
    const previousState = inboundGate.connections[connectionId] && typeof inboundGate.connections[connectionId] === "object" ? inboundGate.connections[connectionId] : {};
    inboundGate.connections[connectionId] = {
      ...previousState,
      windowStartedAt: nowIso,
      lastResetAt: nowIso,
      lastSentAt: nowIso,
      lastInboundCountBeforeSend: gateDecision.inboundCount,
      lastSendWasTimeoutFallback: gateDecision.forcedAfterTimeout === true,
      sentCountInGate: Number(previousState.sentCountInGate || 0) + 1
    };
  }
  return {
    ...metadata,
    inboundGate,
    inboundGateLastDecision: {
      at: nowIso,
      reason: "sent_and_window_reset",
      connectionId: connectionId || null,
      previousReason: gateDecision.reason,
      inboundCount: gateDecision.inboundCount,
      requiredMessages: gateDecision.requiredMessages,
      forcedAfterTimeout: gateDecision.forcedAfterTimeout === true
    }
  };
}
function summarizeBroadcastInboundGate(gateDecision) {
  return {
    reason: gateDecision.reason,
    connectionId: gateDecision.connectionId,
    inboundCount: gateDecision.inboundCount,
    requiredMessages: gateDecision.requiredMessages,
    windowStartedAt: gateDecision.windowStartedAt,
    forcedAfterTimeout: gateDecision.forcedAfterTimeout === true
  };
}
function selectBroadcastConnectionIdForContact(rotationConnectionIds, fallbackConnectionId, contactIndex = 0) {
  const normalizedRotationIds = normalizeConnectionIdList(rotationConnectionIds);
  if (normalizedRotationIds.length > 1) {
    const safeIndex = Math.max(0, Math.floor(Number(contactIndex) || 0));
    return normalizedRotationIds[safeIndex % normalizedRotationIds.length];
  }
  return normalizeConnectionId(fallbackConnectionId) || null;
}
async function resolveBroadcastConnectionSelection(userId, payload, baseMetadata) {
  const requestedMode = normalizeBroadcastConnectionMode(payload.connectionMode);
  const requestedConnectionId = normalizeConnectionId(payload.connectionId);
  if (requestedMode === "rotate") {
    const requestedRotationIds = normalizeConnectionIdList(payload.rotationConnectionIds);
    if (requestedRotationIds.length < 2) {
      throw new Error("Selecione pelo menos duas conexoes conectadas para o modo rotacional");
    }
    const availableConnections = await db.select({
      id: whatsappConnections.id,
      isConnected: whatsappConnections.isConnected,
      providerStatus: whatsappConnections.providerStatus
    }).from(whatsappConnections).where(
      and(
        eq(whatsappConnections.userId, userId),
        inArray(whatsappConnections.id, requestedRotationIds)
      )
    ).orderBy(desc(whatsappConnections.updatedAt));
    const activeById = new Set(
      availableConnections.filter((connection) => isConnectionMarkedActiveForBroadcast(connection)).map((connection) => connection.id)
    );
    const rotationConnectionIds = requestedRotationIds.filter((connectionId) => activeById.has(connectionId));
    if (rotationConnectionIds.length < 2) {
      throw new Error("O modo rotacional precisa de pelo menos duas conexoes conectadas");
    }
    return {
      connectionId: rotationConnectionIds[0],
      metadataJson: {
        ...baseMetadata,
        connectionMode: "rotate",
        rotationConnectionIds,
        rotationStrategy: "round_robin"
      }
    };
  }
  if (payload.strictConnectionSelection && requestedConnectionId) {
    const [selectedConnection] = await db.select({
      id: whatsappConnections.id,
      isConnected: whatsappConnections.isConnected,
      providerStatus: whatsappConnections.providerStatus
    }).from(whatsappConnections).where(
      and(
        eq(whatsappConnections.id, requestedConnectionId),
        eq(whatsappConnections.userId, userId)
      )
    ).limit(1);
    if (!selectedConnection || !isConnectionMarkedActiveForBroadcast(selectedConnection)) {
      throw new Error("A conexao escolhida nao esta conectada ou nao pertence a este cliente");
    }
  }
  return {
    connectionId: requestedConnectionId || null,
    metadataJson: {
      ...baseMetadata,
      connectionMode: "single",
      rotationConnectionIds: [],
      rotationStrategy: null
    }
  };
}
function applyTemplate(template, name) {
  return applyBroadcastTemplate(template, name);
}
function formatPhoneToJid(phone) {
  const cleanPhone = String(phone || "").replace(/\D/g, "");
  if (!cleanPhone) {
    throw new Error("Numero de telefone invalido");
  }
  let formattedPhone = cleanPhone;
  if (cleanPhone.length === 10 || cleanPhone.length === 11) {
    formattedPhone = `55${cleanPhone}`;
  }
  return `${formattedPhone}@s.whatsapp.net`;
}
function isGroupBroadcastCampaign(campaign) {
  return String(campaign.campaignType || "").trim().toLowerCase() === "group_broadcast";
}
function isGroupBroadcastContact(contact) {
  return Boolean(contact.groupId) || String(contact.phone || "").includes("@g.us");
}
function formatGroupBroadcastJid(contact) {
  const rawGroupId = String(contact.groupId || contact.phone || "").trim();
  if (!rawGroupId) {
    throw new Error("Grupo da campanha nao encontrado");
  }
  return rawGroupId.includes("@g.us") ? rawGroupId : `${rawGroupId}@g.us`;
}
function normalizePhone(phone) {
  const cleanPhone = String(phone || "").replace(/\D/g, "");
  if (!cleanPhone) {
    throw new Error("Numero de telefone invalido");
  }
  if (cleanPhone.length === 10 || cleanPhone.length === 11) {
    return `55${cleanPhone}`;
  }
  return cleanPhone;
}
function buildBroadcastPhoneCandidates(phone) {
  const normalizedPhone = normalizePhone(phone);
  const candidates = /* @__PURE__ */ new Set([normalizedPhone]);
  if (normalizedPhone.startsWith("55")) {
    const localPhone = normalizedPhone.slice(2);
    candidates.add(localPhone);
    if (normalizedPhone.length === 13 && normalizedPhone[4] === "9") {
      candidates.add(`${normalizedPhone.slice(0, 4)}${normalizedPhone.slice(5)}`);
    }
    if (normalizedPhone.length === 12) {
      candidates.add(`${normalizedPhone.slice(0, 4)}9${normalizedPhone.slice(4)}`);
    }
  }
  return Array.from(candidates).filter(Boolean);
}
async function resolveReachableBroadcastJid(socket, phone) {
  if (!socket?.onWhatsApp) {
    return formatPhoneToJid(phone);
  }
  const candidates = buildBroadcastPhoneCandidates(phone);
  for (const candidate of candidates) {
    const [result] = await withBroadcastTimeout(
      socket.onWhatsApp(candidate),
      2e4,
      `Validacao WhatsApp ${candidate}`
    );
    if (result?.exists && result?.jid) {
      return result.jid;
    }
  }
  throw new Error(`Numero nao encontrado no WhatsApp: ${normalizePhone(phone)}`);
}
async function withBroadcastTimeout(promise, timeoutMs, label) {
  let timeoutHandle = null;
  return new Promise((resolve, reject) => {
    timeoutHandle = setTimeout(() => {
      reject(new Error(`${label} excedeu ${timeoutMs}ms`));
    }, timeoutMs);
    promise.then(
      (value) => {
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
        }
        resolve(value);
      },
      (error) => {
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
        }
        reject(error);
      }
    );
  });
}
function dedupeCampaignContacts(contacts) {
  const unique = /* @__PURE__ */ new Map();
  for (const contact of contacts) {
    const normalizedPhone = normalizePhone(contact.phone);
    const existing = unique.get(normalizedPhone);
    const normalizedName = String(contact.name || "").trim();
    if (!existing) {
      unique.set(normalizedPhone, {
        ...contact,
        phone: normalizedPhone,
        name: normalizedName || "Cliente"
      });
      continue;
    }
    if ((!existing.name || existing.name === "Cliente") && normalizedName) {
      unique.set(normalizedPhone, {
        ...existing,
        name: normalizedName
      });
    }
  }
  return Array.from(unique.values());
}
function getJidSuffix(jid) {
  return jid.split("@")[1]?.split(":")[0] || "s.whatsapp.net";
}
function getMediaFallbackText(mediaType) {
  switch (mediaType) {
    case "image":
      return "[Imagem enviada]";
    case "video":
      return "[Video enviado]";
    case "audio":
      return "[Audio enviado]";
    case "document":
      return "[Documento enviado]";
    default:
      return "[Mensagem enviada]";
  }
}
function getPersistedMessageText(messageText, mediaType) {
  const trimmed = messageText.trim();
  if (trimmed) {
    return trimmed;
  }
  return getMediaFallbackText(mediaType);
}
function getConversationPreviewText(messageText, mediaType) {
  const trimmed = messageText.trim();
  if (trimmed) {
    return trimmed;
  }
  return mediaType ? getMediaFallbackText(mediaType).replace("enviado", "").trim() : "[Mensagem]";
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function cloneScheduledDate(value) {
  return new Date(value.getTime());
}
function normalizeScheduledAtInput(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) {
    return "";
  }
  if (!trimmed.includes("T") && trimmed.includes(" ")) {
    return trimmed.replace(" ", "T");
  }
  return trimmed;
}
function hasExplicitTimeZone(value) {
  if (!value) {
    return false;
  }
  if (value.endsWith("Z") || value.endsWith("z")) {
    return true;
  }
  const timeIndex = value.indexOf("T");
  if (timeIndex < 0) {
    return false;
  }
  const tail = value.slice(timeIndex + 1);
  const plusIndex = tail.lastIndexOf("+");
  const minusIndex = tail.lastIndexOf("-");
  const offsetIndex = Math.max(plusIndex, minusIndex);
  if (offsetIndex < 0) {
    return false;
  }
  const offset = tail.slice(offsetIndex);
  return offset.length === 6 && offset[3] === ":";
}
function parseBroadcastScheduledAt(value) {
  if (!value) {
    return null;
  }
  if (value instanceof Date) {
    return Number.isFinite(value.getTime()) ? cloneScheduledDate(value) : null;
  }
  const normalized = normalizeScheduledAtInput(value);
  if (!normalized) {
    return null;
  }
  let candidate = normalized;
  const timeIndex = candidate.indexOf("T");
  if (timeIndex >= 0) {
    const tail = candidate.slice(timeIndex + 1);
    const segments = tail.split(":");
    if (segments.length === 2) {
      candidate = `${candidate}:00`;
    }
  }
  if (!hasExplicitTimeZone(candidate) && candidate.includes("T")) {
    candidate = `${candidate}${BRAZIL_UTC_OFFSET}`;
  }
  const parsed = new Date(candidate);
  return Number.isFinite(parsed.getTime()) ? parsed : null;
}
function isBroadcastScheduledForFuture(scheduledAt, reference = /* @__PURE__ */ new Date()) {
  const scheduled = parseBroadcastScheduledAt(scheduledAt);
  return Boolean(scheduled && scheduled.getTime() > reference.getTime());
}
function shouldCancelStaleUnstartedBroadcastCampaign(campaign, reference = /* @__PURE__ */ new Date()) {
  if (!["pending", "running"].includes(String(campaign.status || ""))) {
    return false;
  }
  if (campaign.scheduledAt || Number(campaign.sentCount || 0) > 0 || Number(campaign.failedCount || 0) > 0) {
    return false;
  }
  if (Array.isArray(campaign.resultsJson) && campaign.resultsJson.length > 0) {
    return false;
  }
  const metadata = campaign.metadataJson && typeof campaign.metadataJson === "object" && !Array.isArray(campaign.metadataJson) ? campaign.metadataJson : {};
  if (parseDateMs(metadata.nextDueAt)) {
    return false;
  }
  const createdAtMs = parseDateMs(campaign.createdAt);
  return Boolean(createdAtMs && reference.getTime() - createdAtMs > BROADCAST_UNSTARTED_RECOVERY_MAX_AGE_MS);
}
function buildCampaignEntityKey(contactId, phone) {
  const trimmedId = String(contactId || "").trim();
  if (trimmedId) {
    return `id:${trimmedId}`;
  }
  const trimmedPhone = String(phone || "").trim();
  if (!trimmedPhone) {
    return null;
  }
  try {
    return `phone:${normalizePhone(trimmedPhone)}`;
  } catch {
    return `phone:${trimmedPhone}`;
  }
}
function buildBroadcastResumeState(contacts, persistedResults) {
  const safeResults = Array.isArray(persistedResults) ? [...persistedResults] : [];
  const processedKeys = /* @__PURE__ */ new Set();
  let sentCount = 0;
  let failedCount = 0;
  for (const result of safeResults) {
    const key = buildCampaignEntityKey(result.contactId, result.phone);
    if (key) {
      processedKeys.add(key);
    }
    if (result.status === "sent") {
      sentCount += 1;
      continue;
    }
    if (result.status === "failed") {
      failedCount += 1;
    }
  }
  const pendingContacts = contacts.map((contact, index) => ({
    ...contact,
    sequenceIndex: typeof contact.sequenceIndex === "number" ? contact.sequenceIndex : index
  })).filter((contact) => {
    const key = buildCampaignEntityKey(contact.id, contact.phone);
    return key ? !processedKeys.has(key) : true;
  });
  return {
    results: safeResults,
    sentCount,
    failedCount,
    pendingContacts
  };
}
function getBroadcastCancelState(campaignId) {
  const existing = activeBroadcastCancels.get(campaignId);
  if (existing) {
    return existing;
  }
  const state = { requested: false };
  activeBroadcastCancels.set(campaignId, state);
  return state;
}
function requestBroadcastCancellation(campaignId) {
  getBroadcastCancelState(campaignId).requested = true;
}
function isBroadcastCancellationRequested(campaignId) {
  return activeBroadcastCancels.get(campaignId)?.requested === true;
}
async function waitForCampaignDelay(campaignId, durationMs) {
  let remaining = Math.max(0, Math.floor(durationMs));
  while (remaining > 0) {
    if (isBroadcastCancellationRequested(campaignId)) {
      return false;
    }
    const chunk = Math.min(CANCELLATION_CHECK_INTERVAL_MS, remaining);
    await sleep(chunk);
    remaining -= chunk;
  }
  return !isBroadcastCancellationRequested(campaignId);
}
async function sleepRange(campaignId, minMs, maxMs) {
  const delay = minMs >= maxMs ? minMs : Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
  return waitForCampaignDelay(campaignId, delay);
}
function parseDataUrl(dataUrl) {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) {
    return null;
  }
  return {
    mimeType: match[1],
    buffer: Buffer.from(match[2], "base64")
  };
}
function guessMimeTypeFromUrl(url, mediaType) {
  const lowerUrl = url.toLowerCase();
  if (mediaType === "image") {
    if (lowerUrl.endsWith(".png")) return "image/png";
    if (lowerUrl.endsWith(".webp")) return "image/webp";
    return "image/jpeg";
  }
  if (mediaType === "video") {
    if (lowerUrl.endsWith(".webm")) return "video/webm";
    if (lowerUrl.endsWith(".mov")) return "video/quicktime";
    return "video/mp4";
  }
  if (mediaType === "audio") {
    if (lowerUrl.endsWith(".mp3")) return "audio/mpeg";
    if (lowerUrl.endsWith(".wav")) return "audio/wav";
    if (lowerUrl.endsWith(".m4a")) return "audio/mp4";
    return "audio/ogg; codecs=opus";
  }
  if (lowerUrl.endsWith(".pdf")) return "application/pdf";
  if (lowerUrl.endsWith(".doc")) return "application/msword";
  if (lowerUrl.endsWith(".docx")) {
    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  }
  if (lowerUrl.endsWith(".xlsx")) {
    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  }
  return "application/octet-stream";
}
function normalizeMediaType(mediaType) {
  if (mediaType === "image" || mediaType === "video" || mediaType === "audio" || mediaType === "document") {
    return mediaType;
  }
  return null;
}
function isRemoteMediaUrl(mediaUrl) {
  return mediaUrl.startsWith("http://") || mediaUrl.startsWith("https://");
}
async function persistBroadcastMediaUrlIfNeeded(params) {
  const normalizedMediaType = normalizeMediaType(params.mediaType);
  const trimmedMediaUrl = String(params.mediaUrl || "").trim();
  if (!trimmedMediaUrl || !normalizedMediaType) {
    return {
      mediaType: normalizedMediaType,
      mediaUrl: trimmedMediaUrl || null
    };
  }
  if (isRemoteMediaUrl(trimmedMediaUrl)) {
    return {
      mediaType: normalizedMediaType,
      mediaUrl: trimmedMediaUrl
    };
  }
  const parsedDataUrl = parseDataUrl(trimmedMediaUrl);
  const mimeType = parsedDataUrl?.mimeType || guessMimeTypeFromUrl(trimmedMediaUrl, normalizedMediaType);
  const { persistedMediaUrl } = await prepareOutgoingMediaForSend({
    mediaData: trimmedMediaUrl,
    mimeType,
    ownerId: params.userId
  });
  return {
    mediaType: normalizedMediaType,
    mediaUrl: String(persistedMediaUrl || trimmedMediaUrl).trim() || null
  };
}
async function prepareCampaignMediaSource(params) {
  const normalized = await persistBroadcastMediaUrlIfNeeded(params);
  if (!normalized.mediaUrl || !normalized.mediaType) {
    return null;
  }
  const resolved = await resolveMediaSource(normalized.mediaUrl, normalized.mediaType);
  return {
    mediaType: normalized.mediaType,
    mediaUrl: normalized.mediaUrl,
    mimeType: resolved.mimeType,
    buffer: resolved.buffer
  };
}
function buildMessageContentFromPreparedMedia(messageText, preparedMedia) {
  if (!preparedMedia) {
    return { text: messageText };
  }
  const caption = messageText.trim() || void 0;
  switch (preparedMedia.mediaType) {
    case "image":
      return {
        image: preparedMedia.buffer,
        mimetype: preparedMedia.mimeType || "image/jpeg",
        caption
      };
    case "video":
      return {
        video: preparedMedia.buffer,
        mimetype: preparedMedia.mimeType || "video/mp4",
        caption
      };
    case "audio":
      return {
        audio: preparedMedia.buffer,
        mimetype: preparedMedia.mimeType || "audio/ogg; codecs=opus",
        ptt: false
      };
    case "document":
      return {
        document: preparedMedia.buffer,
        mimetype: preparedMedia.mimeType || "application/octet-stream",
        fileName: `broadcast-${Date.now()}`,
        caption
      };
  }
}
async function resolveMediaSource(mediaUrl, mediaType) {
  const parsed = parseDataUrl(mediaUrl);
  if (parsed) {
    return parsed;
  }
  if (/^https?:\/\//i.test(mediaUrl)) {
    const response = await fetch(mediaUrl);
    if (!response.ok) {
      throw new Error(`Falha ao baixar midia: HTTP ${response.status}`);
    }
    const arrayBuffer = await response.arrayBuffer();
    return {
      mimeType: response.headers.get("content-type") || guessMimeTypeFromUrl(mediaUrl, mediaType),
      buffer: Buffer.from(arrayBuffer)
    };
  }
  return {
    mimeType: guessMimeTypeFromUrl(mediaUrl, mediaType),
    buffer: Buffer.from(mediaUrl, "base64")
  };
}
function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function preserveInitialCase(source, replacement) {
  return /^[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ]/.test(source) ? replacement.charAt(0).toLocaleUpperCase("pt-BR") + replacement.slice(1) : replacement;
}
function applyAiVariation(message, index) {
  const synonyms = {
    "ol\xE1": ["oi", "bom dia", "boa tarde"],
    "ola": ["oi", "bom dia", "boa tarde"],
    "oi": ["ol\xE1", "bom dia", "boa tarde"],
    "tudo bem": ["tudo certo", "como vai", "espero que esteja bem"],
    "obrigado": ["agrade\xE7o", "muito obrigado", "valeu"],
    "obrigada": ["agrade\xE7o", "muito obrigada", "valeu"],
    "gostaria": ["queria", "posso", "vim"],
    "pode": ["consegue", "poderia", "daria para"],
    "produto": ["item", "op\xE7\xE3o", "oferta"],
    "produtos": ["itens", "op\xE7\xF5es", "ofertas"],
    "servi\xE7o": ["atendimento", "solu\xE7\xE3o", "suporte"],
    "servico": ["atendimento", "solu\xE7\xE3o", "suporte"],
    "desconto": ["condi\xE7\xE3o especial", "oferta especial", "vantagem"],
    "promo\xE7\xE3o": ["condi\xE7\xE3o especial", "oferta", "oportunidade"],
    "promocao": ["condi\xE7\xE3o especial", "oferta", "oportunidade"]
  };
  const prefixes = ["", "", "Ol\xE1, ", "Tudo bem? ", "Passando para avisar: "];
  const suffixes = ["", ".", "!", " Fico \xE0 disposi\xE7\xE3o.", " Posso te ajudar?"];
  let varied = message.trim();
  let replacements = 0;
  const maxReplacements = 1 + index % 2;
  for (const [source, targets] of Object.entries(synonyms)) {
    if (replacements >= maxReplacements) {
      break;
    }
    const regex = new RegExp(`(^|[^\\p{L}\\p{N}_])(${escapeRegExp(source)})(?=$|[^\\p{L}\\p{N}_])`, "iu");
    if (regex.test(varied)) {
      const replacement = targets[index % targets.length];
      varied = varied.replace(regex, (_match, prefix2, matched) => `${prefix2}${preserveInitialCase(matched, replacement)}`);
      replacements += 1;
    }
  }
  const prefix = prefixes[index % prefixes.length];
  const suffix = suffixes[(index + 1) % suffixes.length];
  if (prefix && !/^(olá|ola|oi|bom dia|boa tarde|boa noite|tudo bem)/i.test(varied)) {
    varied = `${prefix}${varied}`;
  }
  if (suffix && !/[.!?]$/.test(varied.trim())) {
    varied = `${varied}${suffix}`;
  }
  return varied;
}
async function resolveActiveConnection(userId, preferredConnectionId, options) {
  const availableConnections = await db.select().from(whatsappConnections).where(eq(whatsappConnections.userId, userId)).orderBy(desc(whatsappConnections.updatedAt)).limit(20);
  const activeConnections = availableConnections.filter(
    (connection) => isConnectionMarkedActiveForBroadcast(connection)
  );
  if (preferredConnectionId) {
    const specificConnection = activeConnections.find((connection) => connection.id === preferredConnectionId) || null;
    if (specificConnection) {
      return specificConnection;
    }
    if (options?.strictPreferred) {
      return null;
    }
  }
  const primaryConnected = activeConnections.find((connection) => connection.isPrimary) || null;
  if (primaryConnected) {
    return primaryConnected;
  }
  return activeConnections[0] || null;
}
async function resolveSocket(userId, preferredConnectionId, options) {
  const connection = await resolveActiveConnection(userId, preferredConnectionId, options);
  if (!connection) {
    return { connection: null, connectionId: null, socket: null, useConversationApi: false };
  }
  const owner = await resolveWhatsAppConnectionOwner(connection);
  const useConversationApi = isOfficialCoexistenceConnection(connection) || !isWhatsAppGatewayRuntime() && owner === "gateway";
  if (useConversationApi) {
    return {
      connection,
      connectionId: connection.id,
      socket: null,
      useConversationApi: true
    };
  }
  let session = getSession(connection.id);
  if (!session?.socket) {
    const recoveredSocket = await resolveBaileysBroadcastSocket(
      userId,
      connection.id,
      `broadcast:${connection.id}`
    );
    return {
      connection,
      connectionId: connection.id,
      socket: recoveredSocket,
      useConversationApi: false
    };
  }
  return {
    connection,
    connectionId: connection.id,
    socket: session?.socket || null,
    useConversationApi: false
  };
}
async function waitForSocket(campaignId, userId, preferredConnectionId, options) {
  const startedAt = Date.now();
  while (Date.now() - startedAt < SOCKET_WAIT_TIMEOUT_MS) {
    if (isBroadcastCancellationRequested(campaignId)) {
      return { connectionId: null, socket: null };
    }
    const resolved = await resolveSocket(userId, preferredConnectionId, options);
    if (resolved.useConversationApi || resolved.socket) {
      return resolved;
    }
    const keepWaiting = await waitForCampaignDelay(campaignId, SOCKET_POLL_INTERVAL_MS);
    if (!keepWaiting) {
      return { connectionId: null, socket: null };
    }
  }
  return { connection: null, connectionId: null, socket: null, useConversationApi: false };
}
async function ensureBroadcastConversation(connectionId, contact, jid) {
  const normalizedPhone = normalizePhone(contact.phone);
  const existingConversation = await storage.findConversationByIdentity(connectionId, {
    contactNumber: normalizedPhone,
    remoteJid: jid,
    activeOnly: true
  });
  if (existingConversation) {
    return existingConversation;
  }
  return storage.createConversation({
    connectionId,
    contactNumber: normalizedPhone,
    remoteJid: jid,
    jidSuffix: getJidSuffix(jid),
    contactName: contact.name || normalizedPhone,
    contactAvatar: null,
    lastMessageText: "",
    lastMessageTime: /* @__PURE__ */ new Date(),
    lastMessageFromMe: true,
    unreadCount: 0,
    hasReplied: true
  });
}
async function dispatchBroadcastViaConversationApi(params) {
  const owner = await resolveWhatsAppConnectionOwner(params.connection);
  const shouldUseGatewayDirectSend = !isOfficialCoexistenceConnection(params.connection) && owner === "gateway" && !isWhatsAppGatewayRuntime();
  const isGroupContact = isGroupBroadcastContact(params.contact);
  if (shouldUseGatewayDirectSend) {
    const gatewayTarget = isGroupContact ? params.jid : params.contact.phone;
    if (params.mediaUrl && params.mediaType) {
      const result3 = await sendGatewayInstanceMedia(params.connection.id, {
        type: params.mediaType,
        data: params.mediaUrl,
        mimetype: guessMimeTypeFromUrl(params.mediaUrl, params.mediaType),
        filename: params.mediaType === "document" ? `broadcast-${Date.now()}` : void 0,
        caption: params.messageText.trim() || void 0,
        to: gatewayTarget,
        contactName: isGroupContact ? void 0 : params.contact.name || void 0,
        validateDestination: isGroupContact ? void 0 : true,
        directByNumber: isGroupContact ? void 0 : true
      });
      return {
        conversationId: null,
        messageId: result3?.messageId || null,
        remoteJid: result3?.remoteJid || params.jid,
        historyPersisted: false
      };
    }
    if (isGroupContact) {
      const result3 = await sendGatewayInstanceGroupBulk(params.connection.id, {
        groupIds: [params.jid],
        message: params.messageText,
        settings: { delayMin: 0, delayMax: 0, useAI: false }
      });
      if (Number(result3?.sent || 0) <= 0) {
        const errorDetail = Array.isArray(result3?.errors) ? result3.errors[0] : null;
        throw new Error(String(errorDetail || "Falha ao enviar para o grupo"));
      }
      return {
        conversationId: null,
        messageId: null,
        remoteJid: params.jid,
        historyPersisted: false
      };
    }
    const result2 = await sendGatewayInstanceText(params.connection.id, buildGatewayTextSendBody({
      text: params.messageText,
      to: gatewayTarget,
      contactName: params.contact.name || void 0,
      validateDestination: true,
      directByNumber: true
    }));
    return {
      conversationId: null,
      messageId: result2?.messageId || null,
      remoteJid: result2?.remoteJid || params.jid,
      historyPersisted: false
    };
  }
  const conversation = await ensureBroadcastConversation(params.connection.id, params.contact, params.jid);
  if (params.mediaUrl && params.mediaType) {
    const normalizedMediaType = params.mediaType;
    const parsedMedia = parseDataUrl(params.mediaUrl);
    const result2 = await sendUserMediaMessage(params.userId, conversation.id, {
      type: normalizedMediaType,
      data: params.mediaUrl,
      mimetype: parsedMedia?.mimeType || guessMimeTypeFromUrl(params.mediaUrl, normalizedMediaType),
      filename: normalizedMediaType === "document" ? `broadcast-${Date.now()}` : void 0,
      caption: params.messageText.trim() || void 0,
      ptt: false
    }, {
      isFromAgent: true,
      skipAutoPause: true,
      validateDestination: true
    });
    return {
      conversationId: result2?.conversationId || conversation.id,
      messageId: result2?.messageId || null,
      remoteJid: result2?.remoteJid || params.jid,
      historyPersisted: true
    };
  }
  const result = await sendMessage(params.userId, conversation.id, params.messageText, {
    source: "system",
    validateDestination: true
  });
  return {
    conversationId: conversation.id,
    messageId: result?.messageId || null,
    remoteJid: result?.remoteJid || params.jid,
    historyPersisted: true
  };
}
async function persistBroadcastHistory(params) {
  if (!params.campaignConnectionId) {
    throw new Error("ConnectionId indisponivel para persistir historico do broadcast");
  }
  const normalizedPhone = normalizePhone(params.contact.phone);
  const previewText = getConversationPreviewText(params.messageText, params.mediaType);
  const persistedText = getPersistedMessageText(params.messageText, params.mediaType);
  const jidSuffix = getJidSuffix(params.jid);
  let conversation = await storage.findConversationByIdentity(params.campaignConnectionId, {
    contactNumber: normalizedPhone,
    remoteJid: params.jid,
    activeOnly: true
  });
  if (!conversation) {
    conversation = await storage.createConversation({
      connectionId: params.campaignConnectionId,
      contactNumber: normalizedPhone,
      remoteJid: params.jid,
      jidSuffix,
      contactName: params.contact.name || normalizedPhone,
      contactAvatar: null,
      lastMessageText: previewText,
      lastMessageTime: params.sentAt,
      lastMessageFromMe: true,
      unreadCount: 0,
      hasReplied: true
    });
  }
  const existingMessage = await storage.getMessageByMessageId(params.messageId);
  if (!existingMessage) {
    await storage.createMessage({
      conversationId: conversation.id,
      messageId: params.messageId,
      fromMe: true,
      text: persistedText,
      timestamp: params.sentAt,
      status: "sent",
      isFromAgent: false,
      mediaType: params.mediaType || null,
      mediaUrl: params.mediaUrl || null,
      mediaCaption: params.mediaType ? params.messageText.trim() || null : null
    });
  }
  await storage.updateConversation(conversation.id, {
    remoteJid: params.jid,
    jidSuffix,
    contactName: params.contact.name || conversation.contactName || normalizedPhone,
    lastMessageText: previewText,
    lastMessageTime: params.sentAt,
    lastMessageFromMe: true,
    unreadCount: 0,
    hasReplied: true
  });
}
async function simulateBroadcastTyping(socket, jid, messageText) {
  if (!socket?.sendPresenceUpdate) {
    return;
  }
  const typingDurationMs = Math.min(8e3, Math.max(2e3, String(messageText || "").length * 45));
  try {
    await socket.presenceSubscribe?.(jid);
    await socket.sendPresenceUpdate("composing", jid);
    await sleep(typingDurationMs);
    await socket.sendPresenceUpdate("paused", jid);
  } catch (error) {
    console.warn("[BROADCAST] Falha ao simular digitando antes do envio:", error);
  }
}
async function isCampaignCancelled(campaignId) {
  if (isBroadcastCancellationRequested(campaignId)) {
    return true;
  }
  const [campaign] = await db.select({ status: broadcastCampaigns.status }).from(broadcastCampaigns).where(eq(broadcastCampaigns.id, campaignId)).limit(1);
  return campaign?.status === "cancelled";
}
async function persistProgress(campaignId, values) {
  await db.update(broadcastCampaigns).set({
    ...values,
    updatedAt: /* @__PURE__ */ new Date()
  }).where(eq(broadcastCampaigns.id, campaignId));
}
function resolvePreparedMessage(campaign, contact) {
  if (campaign.campaignType !== "referral_outreach") {
    return null;
  }
  const metadata = campaign.metadataJson || {};
  const preparedMessages = metadata.preparedMessages || {};
  const direct = contact.id ? preparedMessages[contact.id] : null;
  return String(direct?.message || "").trim() || null;
}
async function createAndRunCampaign(userId, payload) {
  const normalizedDelayMinMs = clampDelayMin(payload.delayMinMs);
  const normalizedDelayMaxMs = clampDelayMax(payload.delayMaxMs, payload.delayMinMs);
  const uniqueContacts = dedupeCampaignContacts(payload.contacts || []);
  const scheduledAt = parseBroadcastScheduledAt(payload.scheduledAt);
  const shouldScheduleForFuture = isBroadcastScheduledForFuture(scheduledAt);
  const normalizedMedia = await persistBroadcastMediaUrlIfNeeded({
    userId,
    mediaUrl: payload.mediaUrl,
    mediaType: payload.mediaType
  });
  if (uniqueContacts.length === 0) {
    throw new Error("Nenhum contato valido para a campanha");
  }
  const baseMetadata = withBroadcastSafetyDefaults(payload.metadataJson || {});
  const connectionSelection = await resolveBroadcastConnectionSelection(
    userId,
    payload,
    baseMetadata
  );
  const [insertedCampaign] = await db.insert(broadcastCampaigns).values({
    userId,
    connectionId: connectionSelection.connectionId,
    name: payload.name || `Campanha ${(/* @__PURE__ */ new Date()).toLocaleString("pt-BR")}`,
    status: shouldScheduleForFuture ? "scheduled" : "pending",
    messageTemplate: payload.messageTemplate,
    mediaUrl: normalizedMedia.mediaUrl,
    mediaType: normalizedMedia.mediaType,
    totalContacts: uniqueContacts.length,
    sentCount: 0,
    failedCount: 0,
    campaignType: payload.campaignType || "broadcast",
    useAi: Boolean(payload.useAi),
    delayMinMs: normalizedDelayMinMs,
    delayMaxMs: normalizedDelayMaxMs,
    batchSize: BROADCAST_BATCH_SIZE,
    batchPauseMs: BROADCAST_BATCH_PAUSE_MAX_MS,
    contactsJson: uniqueContacts.map((contact, index) => ({
      id: contact.id || `${Date.now()}-${Math.random()}`,
      phone: contact.phone,
      name: contact.name || "Cliente",
      sequenceIndex: index
    })),
    resultsJson: [],
    metadataJson: connectionSelection.metadataJson,
    scheduledAt
  }).returning({ id: broadcastCampaigns.id });
  const campaignId = insertedCampaign.id;
  if (!shouldScheduleForFuture) {
    void startBroadcastCampaignRun(campaignId, "create");
  }
  return {
    campaignId,
    total: uniqueContacts.length,
    scheduled: shouldScheduleForFuture,
    status: shouldScheduleForFuture ? "scheduled" : "pending"
  };
}
async function executeCampaign(campaignId) {
  const [campaign] = await db.select().from(broadcastCampaigns).where(eq(broadcastCampaigns.id, campaignId)).limit(1);
  if (!campaign) {
    return;
  }
  if (campaign.status === "cancelled") {
    return;
  }
  const contacts = Array.isArray(campaign.contactsJson) ? [...campaign.contactsJson] : [];
  const resumeState = buildBroadcastResumeState(
    contacts,
    Array.isArray(campaign.resultsJson) ? campaign.resultsJson : []
  );
  const results = [...resumeState.results];
  let sentCount = resumeState.sentCount;
  let failedCount = resumeState.failedCount;
  const pendingContacts = resumeState.pendingContacts;
  const rotationConnectionIds = readRotationConnectionIds(campaign.metadataJson);
  const isRotationalCampaign = isRotationalBroadcastCampaign(campaign);
  const isGroupCampaign = isGroupBroadcastCampaign(campaign);
  let metadata = withBroadcastSafetyDefaults(campaign.metadataJson || {});
  if (shouldCancelStaleUnstartedBroadcastCampaign(campaign)) {
    await persistProgress(campaignId, {
      status: "cancelled",
      completedAt: /* @__PURE__ */ new Date(),
      errorMessage: BROADCAST_STALE_UNSTARTED_CANCELLATION_MESSAGE,
      metadataJson: {
        ...metadata,
        nextDueAt: null,
        recoverySafetyCancellation: {
          reason: "stale_unstarted_campaign",
          at: (/* @__PURE__ */ new Date()).toISOString(),
          maxAgeMs: BROADCAST_UNSTARTED_RECOVERY_MAX_AGE_MS
        }
      }
    });
    return;
  }
  if (isBroadcastScheduledForFuture(campaign.scheduledAt)) {
    await persistProgress(campaignId, {
      status: "scheduled",
      startedAt: null,
      completedAt: null,
      metadataJson: metadata
    });
    return;
  }
  const nextDueAtMs = parseDateMs(metadata.nextDueAt);
  if (nextDueAtMs && nextDueAtMs > Date.now()) {
    await persistProgress(campaignId, {
      status: "running",
      startedAt: campaign.startedAt || /* @__PURE__ */ new Date(),
      completedAt: null,
      metadataJson: metadata
    });
    return;
  }
  const preparedCampaignMedia = await prepareCampaignMediaSource({
    userId: campaign.userId,
    mediaUrl: campaign.mediaUrl,
    mediaType: campaign.mediaType
  });
  if (preparedCampaignMedia?.mediaUrl !== (campaign.mediaUrl || null) || preparedCampaignMedia?.mediaType !== normalizeMediaType(campaign.mediaType)) {
    await persistProgress(campaignId, {
      mediaUrl: preparedCampaignMedia?.mediaUrl || null,
      mediaType: preparedCampaignMedia?.mediaType || null
    });
    campaign.mediaUrl = preparedCampaignMedia?.mediaUrl || null;
    campaign.mediaType = preparedCampaignMedia?.mediaType || null;
  } else if (!preparedCampaignMedia && normalizeMediaType(campaign.mediaType) !== campaign.mediaType) {
    campaign.mediaType = normalizeMediaType(campaign.mediaType);
  }
  await persistProgress(campaignId, {
    status: "running",
    startedAt: campaign.startedAt || /* @__PURE__ */ new Date(),
    sentCount,
    failedCount,
    resultsJson: results,
    metadataJson: metadata,
    completedAt: null,
    errorMessage: null
  });
  for (let index = 0; index < pendingContacts.length; index += 1) {
    if (await isCampaignCancelled(campaignId)) {
      await persistProgress(campaignId, {
        completedAt: /* @__PURE__ */ new Date()
      });
      return;
    }
    const contact = pendingContacts[index];
    const contactSequenceIndex = typeof contact.sequenceIndex === "number" ? contact.sequenceIndex : index;
    const contactConnectionId = normalizeConnectionId(contact.connectionId);
    const targetConnectionId = contactConnectionId || (isRotationalCampaign ? selectBroadcastConnectionIdForContact(rotationConnectionIds, campaign.connectionId, contactSequenceIndex) : campaign.connectionId);
    let resolved = await resolveSocket(campaign.userId, targetConnectionId, {
      strictPreferred: isRotationalCampaign || Boolean(contactConnectionId)
    });
    if (!resolved.socket) {
      resolved = await waitForSocket(campaignId, campaign.userId, targetConnectionId, {
        strictPreferred: isRotationalCampaign || Boolean(contactConnectionId)
      });
    }
    if (await isCampaignCancelled(campaignId)) {
      await persistProgress(campaignId, {
        completedAt: /* @__PURE__ */ new Date()
      });
      return;
    }
    if (!isRotationalCampaign && resolved.connectionId && resolved.connectionId !== campaign.connectionId) {
      await persistProgress(campaignId, {
        connectionId: resolved.connectionId
      });
      campaign.connectionId = resolved.connectionId;
    }
    if (!resolved.useConversationApi && !resolved.socket) {
      failedCount += 1;
      results.push({
        contactId: contact.id,
        phone: contact.phone,
        name: contact.name || "Cliente",
        status: "failed",
        error: "Socket indisponivel apos aguardar reconexao por 5 minutos"
      });
      await persistProgress(campaignId, {
        failedCount,
        resultsJson: results
      });
    } else {
      const businessHoursDecision = resolveBroadcastBusinessHoursDecision(metadata, /* @__PURE__ */ new Date());
      if (!businessHoursDecision.canSend) {
        metadata = {
          ...businessHoursDecision.metadata,
          nextDueAt: businessHoursDecision.nextDueAt
        };
        await persistProgress(campaignId, {
          status: "running",
          startedAt: campaign.startedAt || /* @__PURE__ */ new Date(),
          completedAt: null,
          metadataJson: metadata
        });
        return;
      }
      metadata = {
        ...businessHoursDecision.metadata,
        nextDueAt: null
      };
      const gateConnectionId = resolved.connectionId || targetConnectionId || campaign.connectionId || null;
      const gateDecision = await resolveBroadcastInboundGate(campaign, contact, contactSequenceIndex, metadata, gateConnectionId);
      if (!gateDecision.canSend) {
        metadata = {
          ...gateDecision.metadata,
          nextDueAt: gateDecision.nextDueAt
        };
        await persistProgress(campaignId, {
          status: "running",
          startedAt: campaign.startedAt || /* @__PURE__ */ new Date(),
          completedAt: null,
          metadataJson: metadata
        });
        return;
      }
      metadata = {
        ...gateDecision.metadata,
        nextDueAt: null
      };
      try {
        let jid = isGroupCampaign || isGroupBroadcastContact(contact) ? formatGroupBroadcastJid(contact) : formatPhoneToJid(contact.phone);
        let messageText = resolvePreparedMessage(campaign, contact) || applyTemplate(campaign.messageTemplate, contact.name);
        if (campaign.useAi && campaign.campaignType !== "referral_outreach") {
          messageText = applyAiVariation(messageText, contactSequenceIndex);
        }
        const sentAt = /* @__PURE__ */ new Date();
        let messageId = `broadcast_${campaignId}_${contactSequenceIndex}_${sentAt.getTime()}`;
        if (resolved.useConversationApi && resolved.connection) {
          const dispatched = await dispatchBroadcastViaConversationApi({
            userId: campaign.userId,
            connection: resolved.connection,
            contact,
            jid,
            messageText,
            mediaUrl: campaign.mediaUrl,
            mediaType: campaign.mediaType
          });
          if (dispatched.messageId) {
            messageId = dispatched.messageId;
          }
          if (dispatched.remoteJid) {
            jid = dispatched.remoteJid;
          }
          metadata = markBroadcastInboundGateAfterSend(metadata, dispatched.connectionId || gateDecision.connectionId, gateDecision);
          if (dispatched.historyPersisted !== true) {
            await persistBroadcastHistory({
              campaignConnectionId: resolved.connectionId || campaign.connectionId,
              contact,
              jid,
              messageId,
              messageText,
              sentAt,
              mediaUrl: campaign.mediaUrl,
              mediaType: campaign.mediaType
            }).catch((error) => {
              console.warn("[BROADCAST] Falha ao persistir historico da mensagem enviada:", error);
            });
          }
        } else if (resolved.socket) {
          if (!isGroupCampaign && !isGroupBroadcastContact(contact)) {
            jid = await resolveReachableBroadcastJid(resolved.socket, contact.phone);
          }
          const messageContent = buildMessageContentFromPreparedMedia(messageText, preparedCampaignMedia);
          await simulateBroadcastTyping(resolved.socket, jid, messageText);
          const sentMessage = await resolved.socket.sendMessage(jid, messageContent);
          messageId = sentMessage?.key?.id || messageId;
          metadata = markBroadcastInboundGateAfterSend(metadata, resolved.connectionId || gateDecision.connectionId, gateDecision);
          await persistBroadcastHistory({
            campaignConnectionId: resolved.connectionId || campaign.connectionId,
            contact,
            jid,
            messageId,
            messageText,
            sentAt,
            mediaUrl: campaign.mediaUrl,
            mediaType: campaign.mediaType
          }).catch((error) => {
            console.warn("[BROADCAST] Falha ao persistir historico da mensagem enviada:", error);
          });
        }
        sentCount += 1;
        results.push({
          contactId: contact.id,
          phone: contact.phone,
          name: contact.name || "Cliente",
          status: "sent",
          sentAt: sentAt.toISOString(),
          message: messageText,
          messageId,
          remoteJid: jid,
          connectionId: resolved.connectionId || gateDecision.connectionId,
          inboundGate: summarizeBroadcastInboundGate(gateDecision)
        });
        await persistProgress(campaignId, {
          connectionId: !isRotationalCampaign ? resolved.connectionId || campaign.connectionId : campaign.connectionId,
          sentCount,
          failedCount,
          resultsJson: results,
          metadataJson: metadata
        });
      } catch (error) {
        const failedAt = /* @__PURE__ */ new Date();
        failedCount += 1;
        results.push({
          contactId: contact.id,
          phone: contact.phone,
          name: contact.name || "Cliente",
          status: "failed",
          error: error instanceof Error ? error.message : "Erro desconhecido",
          sentAt: failedAt.toISOString(),
          message: resolvePreparedMessage(campaign, contact) || applyTemplate(campaign.messageTemplate, contact.name),
          connectionId: gateDecision.connectionId,
          inboundGate: summarizeBroadcastInboundGate(gateDecision)
        });
        await persistProgress(campaignId, {
          connectionId: !isRotationalCampaign ? resolved.connectionId || campaign.connectionId : campaign.connectionId,
          sentCount,
          failedCount,
          resultsJson: results,
          metadataJson: metadata
        });
      }
    }
    const isLastContact = index === pendingContacts.length - 1;
    if (isLastContact) {
      continue;
    }
    const processedCount = sentCount + failedCount;
    if (processedCount % BROADCAST_BATCH_SIZE === 0) {
      const keepRunning2 = await sleepRange(
        campaignId,
        BROADCAST_BATCH_PAUSE_MIN_MS,
        Math.max(Number(campaign.batchPauseMs || 0), BROADCAST_BATCH_PAUSE_MAX_MS)
      );
      if (!keepRunning2) {
        await persistProgress(campaignId, {
          completedAt: /* @__PURE__ */ new Date()
        });
        return;
      }
      continue;
    }
    const keepRunning = await sleepRange(campaignId, campaign.delayMinMs, campaign.delayMaxMs);
    if (!keepRunning) {
      await persistProgress(campaignId, {
        completedAt: /* @__PURE__ */ new Date()
      });
      return;
    }
  }
  if (await isCampaignCancelled(campaignId)) {
    await persistProgress(campaignId, {
      completedAt: /* @__PURE__ */ new Date()
    });
    return;
  }
  await persistProgress(campaignId, {
    status: "completed",
    sentCount,
    failedCount,
    resultsJson: results,
    metadataJson: { ...metadata, nextDueAt: null },
    completedAt: /* @__PURE__ */ new Date(),
    errorMessage: null
  });
}
async function getCampaignStatus(campaignId, userId) {
  const [campaign] = await db.select().from(broadcastCampaigns).where(and(eq(broadcastCampaigns.id, campaignId), eq(broadcastCampaigns.userId, userId))).limit(1);
  return campaign || null;
}
async function cancelCampaign(campaignId, userId) {
  requestBroadcastCancellation(campaignId);
  const cancelled = await db.update(broadcastCampaigns).set({
    status: "cancelled",
    completedAt: /* @__PURE__ */ new Date(),
    updatedAt: /* @__PURE__ */ new Date()
  }).where(and(eq(broadcastCampaigns.id, campaignId), eq(broadcastCampaigns.userId, userId))).returning({ id: broadcastCampaigns.id });
  return cancelled.length > 0;
}
async function resumePendingBroadcastCampaigns(trigger) {
  const campaigns = await db.select({
    id: broadcastCampaigns.id,
    status: broadcastCampaigns.status,
    scheduledAt: broadcastCampaigns.scheduledAt
  }).from(broadcastCampaigns).where(inArray(broadcastCampaigns.status, [...ACTIVE_BROADCAST_STATUSES])).orderBy(asc(broadcastCampaigns.createdAt)).limit(100);
  let started = 0;
  let scheduled = 0;
  for (const campaign of campaigns) {
    const isScheduledForFuture = isBroadcastScheduledForFuture(campaign.scheduledAt);
    if (isScheduledForFuture) {
      if (campaign.status !== "scheduled") {
        await persistProgress(campaign.id, {
          status: "scheduled",
          startedAt: null,
          completedAt: null
        });
      }
      scheduled += 1;
      continue;
    }
    startBroadcastCampaignRun(campaign.id, trigger);
    started += 1;
  }
  return {
    candidates: campaigns.length,
    started,
    scheduled
  };
}
function startBroadcastCampaignRun(campaignId, trigger = "manual") {
  const activeTask = activeBroadcastTasks.get(campaignId);
  if (activeTask) {
    return activeTask;
  }
  getBroadcastCancelState(campaignId).requested = false;
  const task = executeCampaign(campaignId).catch(async (error) => {
    console.error(`[BROADCAST ${campaignId}] Runner abortado. trigger=${trigger}`, error);
    await persistProgress(campaignId, {
      status: "error",
      errorMessage: error instanceof Error ? error.message : String(error),
      completedAt: /* @__PURE__ */ new Date()
    }).catch(() => void 0);
  }).finally(() => {
    activeBroadcastTasks.delete(campaignId);
    activeBroadcastCancels.delete(campaignId);
  });
  activeBroadcastTasks.set(campaignId, task);
  return task;
}
async function runBroadcastCampaignRecoveryOnce() {
  return resumePendingBroadcastCampaigns("manual");
}

// server/ownerWorkspaceRegistry.ts
import { eq as eq2, inArray as inArray2, sql as sql2 } from "drizzle-orm";
var OWNER_WORKSPACE_EMAILS = ["rodrigo4@gmail.com"];
function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}
function parseCount(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}
function canAccessOwnerWorkspaceEmail(email) {
  const normalized = normalizeEmail(email);
  return normalized.length > 0 && OWNER_WORKSPACE_EMAILS.includes(normalized);
}
async function getOwnerWorkspaceUserById(userId) {
  const [user] = await db.select({
    id: users.id,
    email: users.email,
    name: users.name,
    role: users.role
  }).from(users).where(eq2(users.id, userId)).limit(1);
  return user || null;
}
async function getPrimaryOwnerWorkspaceUser() {
  const [user] = await db.select({
    id: users.id,
    email: users.email,
    name: users.name,
    role: users.role
  }).from(users).where(inArray2(users.email, OWNER_WORKSPACE_EMAILS)).limit(1);
  return user || null;
}
async function getOwnerWorkspaceUsers() {
  return db.select({
    id: users.id,
    email: users.email,
    name: users.name,
    role: users.role
  }).from(users).where(inArray2(users.email, OWNER_WORKSPACE_EMAILS));
}
async function canUserAccessOwnerWorkspace(userId) {
  const user = await getOwnerWorkspaceUserById(userId);
  return canAccessOwnerWorkspaceEmail(user?.email);
}
async function getLegacyAdminMatchForOwnerEmail(email) {
  const normalized = normalizeEmail(email);
  if (!normalized) {
    return null;
  }
  const result = await db.execute(sql2`
    SELECT
      a.id,
      a.email,
      a.role,
      CASE WHEN LOWER(a.email) = ${normalized} THEN TRUE ELSE FALSE END AS same_email,
      EXISTS(
        SELECT 1
        FROM admin_notification_config anc
        WHERE anc.admin_id = a.id
      ) AS has_config,
      (
        SELECT COUNT(*)::int
        FROM admin_notification_logs anl
        WHERE anl.admin_id = a.id
      ) AS logs_count,
      (
        SELECT COUNT(*)::int
        FROM scheduled_notifications sn
        WHERE sn.admin_id = a.id
      ) AS scheduled_count,
      (
        SELECT COUNT(*)::int
        FROM admin_broadcasts ab
        WHERE ab.admin_id = a.id
      ) AS broadcasts_count,
      a.created_at
    FROM admins a
    WHERE LOWER(a.email) = ${normalized}
       OR a.role = 'owner'
  `);
  const candidates = (result.rows || []).map((row) => {
    const logsCount = parseCount(row.logs_count);
    const scheduledCount = parseCount(row.scheduled_count);
    const broadcastsCount = parseCount(row.broadcasts_count);
    const hasConfig = Boolean(row.has_config);
    const dataSignals = [
      hasConfig,
      logsCount > 0,
      scheduledCount > 0,
      broadcastsCount > 0
    ].filter(Boolean).length;
    return {
      id: String(row.id),
      email: String(row.email || ""),
      role: String(row.role || "admin"),
      sameEmail: Boolean(row.same_email),
      hasConfig,
      logsCount,
      scheduledCount,
      broadcastsCount,
      totalRecords: logsCount + scheduledCount + broadcastsCount + (hasConfig ? 1 : 0),
      dataSignals,
      createdAt: row.created_at ? new Date(row.created_at) : null
    };
  }).sort((left, right) => {
    if (right.dataSignals !== left.dataSignals) {
      return right.dataSignals - left.dataSignals;
    }
    if (right.totalRecords !== left.totalRecords) {
      return right.totalRecords - left.totalRecords;
    }
    if (left.sameEmail !== right.sameEmail) {
      return left.sameEmail ? -1 : 1;
    }
    if (left.role === "owner" !== (right.role === "owner")) {
      return left.role === "owner" ? -1 : 1;
    }
    const leftCreatedAt = left.createdAt?.getTime() ?? Number.MAX_SAFE_INTEGER;
    const rightCreatedAt = right.createdAt?.getTime() ?? Number.MAX_SAFE_INTEGER;
    return leftCreatedAt - rightCreatedAt;
  });
  const best = candidates[0];
  if (!best) {
    return null;
  }
  return {
    id: best.id,
    email: best.email,
    role: best.role,
    sameEmail: best.sameEmail,
    hasConfig: best.hasConfig,
    logsCount: best.logsCount,
    scheduledCount: best.scheduledCount,
    broadcastsCount: best.broadcastsCount,
    totalRecords: best.totalRecords,
    dataSignals: best.dataSignals
  };
}

// server/ownerNotificationWorkspaceService.ts
var OWNER_NOTIFICATION_INTERVAL_MS = 5 * 60 * 1e3;
var OWNER_AUTO_REORGANIZE_INTERVAL_MS = 2 * 60 * 60 * 1e3;
var OWNER_HORIZON_DAYS = 14;
var OWNER_STALE_DISCONNECTED_NOTIFICATION_MS = 6 * 60 * 60 * 1e3;
var OWNER_STALE_OVERDUE_NOTIFICATION_MS = 45 * 24 * 60 * 60 * 1e3;
var OWNER_QUEUE_BATCH_SIZE = 10;
var OWNER_QUEUE_BATCH_PAUSE_MIN_SECONDS = 15 * 60;
var OWNER_QUEUE_BATCH_PAUSE_MAX_SECONDS = 20 * 60;
var OWNER_ALLOWED_EMAIL = "rodrigo4@gmail.com";
var FREE_TRIAL_MESSAGE_LIMIT = 25;
var ownerSchedulerInterval = null;
var lastOwnerAutoReorganize = /* @__PURE__ */ new Map();
var readyOwners = /* @__PURE__ */ new Set();
var migrationLocks = /* @__PURE__ */ new Map();
function getDefaultConfig() {
  return {
    paymentReminderEnabled: true,
    paymentReminderDaysBefore: [7, 3, 1],
    paymentReminderMessageTemplate: "Ola {cliente_nome}!\n\nSeu plano vence em {dias_restantes} dia(s), em {data_vencimento}.\nValor: R$ {valor}\n\nPix copia e cola:\n{{pix_copia_cola}}\n\nDepois de pagar, envie o comprovante por aqui para validarmos.",
    paymentReminderAiEnabled: false,
    paymentReminderAiPrompt: "",
    overdueReminderEnabled: true,
    overdueReminderDaysAfter: [1, 3, 7, 14],
    overdueReminderMessageTemplate: "Ola {cliente_nome}!\n\nSeu plano venceu em {data_vencimento}.\nValor: R$ {valor}\n\nPix copia e cola:\n{{pix_copia_cola}}\n\nSe ja pagou, envie o comprovante por aqui para validarmos.",
    overdueReminderAiEnabled: false,
    overdueReminderAiPrompt: "",
    periodicCheckinEnabled: true,
    periodicCheckinMinDays: 7,
    periodicCheckinMaxDays: 15,
    periodicCheckinMessageTemplate: "Ola {cliente_nome}.\n\nPassando para saber se o AgenteZap esta funcionando corretamente e se voce precisa de algum ajuste.",
    checkinAiEnabled: false,
    checkinAiPrompt: "",
    broadcastEnabled: true,
    broadcastAntibotVariation: true,
    broadcastAiVariation: false,
    broadcastMinIntervalSeconds: 60,
    broadcastMaxIntervalSeconds: 90,
    disconnectedAlertEnabled: true,
    disconnectedAlertHours: 2,
    disconnectedAlertMessageTemplate: "Ola {cliente_nome}.\n\nNotei que seu WhatsApp ficou desconectado no AgenteZap. Quer ajuda para reconectar e deixar o atendimento ativo novamente?",
    disconnectedAiEnabled: false,
    disconnectedAiPrompt: "",
    aiVariationEnabled: false,
    aiVariationPrompt: "",
    businessHoursStart: "09:00",
    businessHoursEnd: "18:00",
    businessDays: [1, 2, 3, 4, 5],
    respectBusinessHours: true,
    welcomeMessageEnabled: true,
    welcomeMessageVariations: [
      "Ola {{name}}. Aqui e o Rodrigo, do AgenteZap. Vi que voce criou sua conta e estou por aqui para ajudar no que precisar.",
      "Oi {{name}}. Bem-vindo ao AgenteZap. Se quiser tirar duvida, configurar algo ou entender a plataforma, pode me chamar por aqui.",
      "Ola {{name}}. Que bom ter voce no AgenteZap. Vou te acompanhar por aqui para deixar seu atendimento funcionando bem."
    ],
    welcomeMessageAiEnabled: false,
    welcomeMessageAiPrompt: "",
    trialLimitReachedEnabled: true,
    trialLimitReachedMessageTemplate: "Ola {cliente_nome}!\n\nSeu limite de 25 mensagens do teste gratuito acabou.\n\nSe quiser continuar com mensagens ilimitadas e manter seu atendimento ativo, voce pode assinar um de nossos planos.\n\nComo foi sua experiencia ate aqui?",
    trialLimitReachedAiEnabled: false,
    trialLimitReachedAiPrompt: ""
  };
}
function normalizeEmail2(value) {
  return String(value || "").trim().toLowerCase();
}
function normalizePhone2(phone) {
  const digits = String(phone || "").replace(/\D/g, "");
  if (!digits) return "";
  if (digits.length === 10 || digits.length === 11) {
    return `55${digits}`;
  }
  return digits;
}
function hashToOffset(seed, max) {
  if (max <= 0) return 0;
  const hash = crypto.createHash("sha1").update(seed).digest("hex").slice(0, 8);
  return parseInt(hash, 16) % max;
}
function parseJsonField(value, fallback) {
  if (!value) return fallback;
  if (typeof value === "object") return value;
  try {
    return JSON.parse(String(value));
  } catch {
    return fallback;
  }
}
function parseNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}
function parseDate(value) {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}
function latestDate(...values) {
  let latest = null;
  for (const value of values) {
    const date = parseDate(value);
    if (date && (!latest || date.getTime() > latest.getTime())) {
      latest = date;
    }
  }
  return latest;
}
function buildPgIntArray(values) {
  const safeValues = values.map((value) => Number(value)).filter((value) => Number.isInteger(value));
  return `ARRAY[${safeValues.join(",")}]::integer[]`;
}
function escapeSqlText(value) {
  return String(value).replace(/'/g, "''");
}
function buildPgTextArray(values) {
  const safeValues = values.map((value) => String(value || "").trim()).filter(Boolean).map((value) => `'${escapeSqlText(value)}'`);
  return safeValues.length > 0 ? `ARRAY[${safeValues.join(",")}]::text[]` : "ARRAY[]::text[]";
}
function mapConfigRowToCamel(row) {
  const defaults = getDefaultConfig();
  if (!row) return defaults;
  const trialLimitReachedMessageTemplate = typeof row.trial_limit_reached_message_template === "string" && row.trial_limit_reached_message_template.trim().length > 0 ? row.trial_limit_reached_message_template : defaults.trialLimitReachedMessageTemplate;
  return {
    paymentReminderEnabled: row.payment_reminder_enabled ?? defaults.paymentReminderEnabled,
    paymentReminderDaysBefore: row.payment_reminder_days_before ?? defaults.paymentReminderDaysBefore,
    paymentReminderMessageTemplate: row.payment_reminder_message_template ?? defaults.paymentReminderMessageTemplate,
    paymentReminderAiEnabled: row.payment_reminder_ai_enabled ?? defaults.paymentReminderAiEnabled,
    paymentReminderAiPrompt: row.payment_reminder_ai_prompt ?? defaults.paymentReminderAiPrompt,
    overdueReminderEnabled: row.overdue_reminder_enabled ?? defaults.overdueReminderEnabled,
    overdueReminderDaysAfter: row.overdue_reminder_days_after ?? defaults.overdueReminderDaysAfter,
    overdueReminderMessageTemplate: row.overdue_reminder_message_template ?? defaults.overdueReminderMessageTemplate,
    overdueReminderAiEnabled: row.overdue_reminder_ai_enabled ?? defaults.overdueReminderAiEnabled,
    overdueReminderAiPrompt: row.overdue_reminder_ai_prompt ?? defaults.overdueReminderAiPrompt,
    periodicCheckinEnabled: row.periodic_checkin_enabled ?? defaults.periodicCheckinEnabled,
    periodicCheckinMinDays: row.periodic_checkin_min_days ?? defaults.periodicCheckinMinDays,
    periodicCheckinMaxDays: row.periodic_checkin_max_days ?? defaults.periodicCheckinMaxDays,
    periodicCheckinMessageTemplate: row.periodic_checkin_message_template ?? defaults.periodicCheckinMessageTemplate,
    checkinAiEnabled: row.checkin_ai_enabled ?? defaults.checkinAiEnabled,
    checkinAiPrompt: row.checkin_ai_prompt ?? defaults.checkinAiPrompt,
    broadcastEnabled: row.broadcast_enabled ?? defaults.broadcastEnabled,
    broadcastAntibotVariation: row.broadcast_antibot_variation ?? defaults.broadcastAntibotVariation,
    broadcastAiVariation: row.broadcast_ai_variation ?? defaults.broadcastAiVariation,
    broadcastMinIntervalSeconds: Math.max(row.broadcast_min_interval_seconds ?? defaults.broadcastMinIntervalSeconds, 60),
    broadcastMaxIntervalSeconds: Math.max(row.broadcast_max_interval_seconds ?? defaults.broadcastMaxIntervalSeconds, 60),
    disconnectedAlertEnabled: row.disconnected_alert_enabled ?? defaults.disconnectedAlertEnabled,
    disconnectedAlertHours: row.disconnected_alert_hours ?? defaults.disconnectedAlertHours,
    disconnectedAlertMessageTemplate: row.disconnected_alert_message_template ?? defaults.disconnectedAlertMessageTemplate,
    disconnectedAiEnabled: row.disconnected_ai_enabled ?? defaults.disconnectedAiEnabled,
    disconnectedAiPrompt: row.disconnected_ai_prompt ?? defaults.disconnectedAiPrompt,
    aiVariationEnabled: row.ai_variation_enabled ?? defaults.aiVariationEnabled,
    aiVariationPrompt: row.ai_variation_prompt ?? defaults.aiVariationPrompt,
    businessHoursStart: row.business_hours_start ?? defaults.businessHoursStart,
    businessHoursEnd: row.business_hours_end ?? defaults.businessHoursEnd,
    businessDays: row.business_days ?? defaults.businessDays,
    respectBusinessHours: row.respect_business_hours ?? defaults.respectBusinessHours,
    welcomeMessageEnabled: row.welcome_message_enabled ?? defaults.welcomeMessageEnabled,
    welcomeMessageVariations: row.welcome_message_variations ?? defaults.welcomeMessageVariations,
    welcomeMessageAiEnabled: row.welcome_message_ai_enabled ?? defaults.welcomeMessageAiEnabled,
    welcomeMessageAiPrompt: row.welcome_message_ai_prompt ?? defaults.welcomeMessageAiPrompt,
    trialLimitReachedEnabled: row.trial_limit_reached_enabled ?? defaults.trialLimitReachedEnabled,
    trialLimitReachedMessageTemplate,
    trialLimitReachedAiEnabled: row.trial_limit_reached_ai_enabled ?? defaults.trialLimitReachedAiEnabled,
    trialLimitReachedAiPrompt: row.trial_limit_reached_ai_prompt ?? defaults.trialLimitReachedAiPrompt
  };
}
async function ensureOwnerWorkspaceTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS owner_notification_config (
      owner_user_id TEXT PRIMARY KEY,
      legacy_admin_id TEXT,
      payment_reminder_enabled BOOLEAN NOT NULL DEFAULT true,
      payment_reminder_days_before INTEGER[] NOT NULL DEFAULT ARRAY[7,3,1],
      payment_reminder_message_template TEXT NOT NULL DEFAULT '',
      payment_reminder_ai_enabled BOOLEAN NOT NULL DEFAULT false,
      payment_reminder_ai_prompt TEXT NOT NULL DEFAULT '',
      overdue_reminder_enabled BOOLEAN NOT NULL DEFAULT true,
      overdue_reminder_days_after INTEGER[] NOT NULL DEFAULT ARRAY[1,3,7,14],
      overdue_reminder_message_template TEXT NOT NULL DEFAULT '',
      overdue_reminder_ai_enabled BOOLEAN NOT NULL DEFAULT false,
      overdue_reminder_ai_prompt TEXT NOT NULL DEFAULT '',
      periodic_checkin_enabled BOOLEAN NOT NULL DEFAULT true,
      periodic_checkin_min_days INTEGER NOT NULL DEFAULT 7,
      periodic_checkin_max_days INTEGER NOT NULL DEFAULT 15,
      periodic_checkin_message_template TEXT NOT NULL DEFAULT '',
      checkin_ai_enabled BOOLEAN NOT NULL DEFAULT false,
      checkin_ai_prompt TEXT NOT NULL DEFAULT '',
      broadcast_enabled BOOLEAN NOT NULL DEFAULT true,
      broadcast_antibot_variation BOOLEAN NOT NULL DEFAULT true,
      broadcast_ai_variation BOOLEAN NOT NULL DEFAULT false,
      broadcast_min_interval_seconds INTEGER NOT NULL DEFAULT 60,
      broadcast_max_interval_seconds INTEGER NOT NULL DEFAULT 90,
      disconnected_alert_enabled BOOLEAN NOT NULL DEFAULT true,
      disconnected_alert_hours INTEGER NOT NULL DEFAULT 2,
      disconnected_alert_message_template TEXT NOT NULL DEFAULT '',
      disconnected_ai_enabled BOOLEAN NOT NULL DEFAULT false,
      disconnected_ai_prompt TEXT NOT NULL DEFAULT '',
      ai_variation_enabled BOOLEAN NOT NULL DEFAULT false,
      ai_variation_prompt TEXT NOT NULL DEFAULT '',
      business_hours_start TEXT NOT NULL DEFAULT '09:00',
      business_hours_end TEXT NOT NULL DEFAULT '18:00',
      business_days INTEGER[] NOT NULL DEFAULT ARRAY[1,2,3,4,5],
      respect_business_hours BOOLEAN NOT NULL DEFAULT true,
      welcome_message_enabled BOOLEAN NOT NULL DEFAULT true,
      welcome_message_variations TEXT[] NOT NULL DEFAULT ARRAY[]::text[],
      welcome_message_ai_enabled BOOLEAN NOT NULL DEFAULT false,
      welcome_message_ai_prompt TEXT NOT NULL DEFAULT '',
      trial_limit_reached_enabled BOOLEAN NOT NULL DEFAULT true,
      trial_limit_reached_message_template TEXT NOT NULL DEFAULT '',
      trial_limit_reached_ai_enabled BOOLEAN NOT NULL DEFAULT false,
      trial_limit_reached_ai_prompt TEXT NOT NULL DEFAULT '',
      legacy_admin_migrated_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS owner_notification_logs (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL,
      legacy_admin_id TEXT,
      user_id TEXT,
      notification_type TEXT NOT NULL,
      recipient_phone TEXT NOT NULL,
      recipient_name TEXT,
      message_original TEXT,
      message_sent TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
      error_message TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      sent_at TIMESTAMPTZ
    );

    CREATE TABLE IF NOT EXISTS owner_scheduled_notifications (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL,
      legacy_admin_id TEXT,
      user_id TEXT,
      notification_type TEXT NOT NULL,
      recipient_phone TEXT NOT NULL,
      recipient_name TEXT,
      message_template TEXT NOT NULL,
      ai_prompt TEXT,
      scheduled_for TIMESTAMPTZ NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      ai_enabled BOOLEAN NOT NULL DEFAULT false,
      metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
      final_message TEXT,
      conversation_context TEXT,
      error_message TEXT,
      retry_count INTEGER NOT NULL DEFAULT 0,
      sent_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS owner_broadcast_archives (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL,
      legacy_admin_id TEXT,
      legacy_broadcast_id TEXT,
      name TEXT NOT NULL,
      message_template TEXT,
      target_type TEXT,
      target_filter JSONB NOT NULL DEFAULT '{}'::jsonb,
      ai_variation BOOLEAN NOT NULL DEFAULT false,
      antibot_enabled BOOLEAN NOT NULL DEFAULT true,
      status TEXT NOT NULL DEFAULT 'completed',
      scheduled_at TIMESTAMPTZ,
      total_recipients INTEGER NOT NULL DEFAULT 0,
      sent_count INTEGER NOT NULL DEFAULT 0,
      failed_count INTEGER NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      started_at TIMESTAMPTZ,
      completed_at TIMESTAMPTZ,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS owner_broadcast_archive_messages (
      id TEXT PRIMARY KEY,
      archive_id TEXT NOT NULL,
      owner_user_id TEXT NOT NULL,
      legacy_admin_id TEXT,
      user_id TEXT,
      recipient_phone TEXT NOT NULL,
      recipient_name TEXT,
      message_original TEXT,
      message_sent TEXT,
      ai_varied BOOLEAN NOT NULL DEFAULT false,
      status TEXT NOT NULL DEFAULT 'sent',
      error_message TEXT,
      sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE INDEX IF NOT EXISTS idx_owner_notification_logs_owner_created
      ON owner_notification_logs(owner_user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_owner_scheduled_notifications_owner_status_date
      ON owner_scheduled_notifications(owner_user_id, status, scheduled_for ASC);
    CREATE INDEX IF NOT EXISTS idx_owner_broadcast_archives_owner_created
      ON owner_broadcast_archives(owner_user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_owner_broadcast_archive_messages_archive
      ON owner_broadcast_archive_messages(archive_id, sent_at DESC);

    ALTER TABLE owner_notification_config
      ADD COLUMN IF NOT EXISTS trial_limit_reached_enabled BOOLEAN NOT NULL DEFAULT true,
      ADD COLUMN IF NOT EXISTS trial_limit_reached_message_template TEXT NOT NULL DEFAULT '',
      ADD COLUMN IF NOT EXISTS trial_limit_reached_ai_enabled BOOLEAN NOT NULL DEFAULT false,
      ADD COLUMN IF NOT EXISTS trial_limit_reached_ai_prompt TEXT NOT NULL DEFAULT '';
  `);
  await pool.query(
    `
      UPDATE owner_notification_config
      SET trial_limit_reached_message_template = $1
      WHERE COALESCE(BTRIM(trial_limit_reached_message_template), '') = ''
    `,
    [getDefaultConfig().trialLimitReachedMessageTemplate]
  );
}
async function getOwnerConfigRow(ownerUserId) {
  const result = await db.execute(sql3`
    SELECT * FROM owner_notification_config
    WHERE owner_user_id = ${ownerUserId}
    LIMIT 1
  `);
  return result.rows?.[0] || null;
}
async function seedOwnerDefaultConfig(ownerUserId, legacyAdminId) {
  const defaults = getDefaultConfig();
  await db.execute(sql3`
    INSERT INTO owner_notification_config (
      owner_user_id,
      legacy_admin_id,
      payment_reminder_enabled,
      payment_reminder_days_before,
      payment_reminder_message_template,
      payment_reminder_ai_enabled,
      payment_reminder_ai_prompt,
      overdue_reminder_enabled,
      overdue_reminder_days_after,
      overdue_reminder_message_template,
      overdue_reminder_ai_enabled,
      overdue_reminder_ai_prompt,
      periodic_checkin_enabled,
      periodic_checkin_min_days,
      periodic_checkin_max_days,
      periodic_checkin_message_template,
      checkin_ai_enabled,
      checkin_ai_prompt,
      broadcast_enabled,
      broadcast_antibot_variation,
      broadcast_ai_variation,
      broadcast_min_interval_seconds,
      broadcast_max_interval_seconds,
      disconnected_alert_enabled,
      disconnected_alert_hours,
      disconnected_alert_message_template,
      disconnected_ai_enabled,
      disconnected_ai_prompt,
      ai_variation_enabled,
      ai_variation_prompt,
      business_hours_start,
      business_hours_end,
      business_days,
      respect_business_hours,
      welcome_message_enabled,
      welcome_message_variations,
      welcome_message_ai_enabled,
      welcome_message_ai_prompt,
      trial_limit_reached_enabled,
      trial_limit_reached_message_template,
      trial_limit_reached_ai_enabled,
      trial_limit_reached_ai_prompt
    ) VALUES (
      ${ownerUserId},
      ${legacyAdminId},
      ${defaults.paymentReminderEnabled},
      ${sql3.raw(buildPgIntArray(defaults.paymentReminderDaysBefore))},
      ${defaults.paymentReminderMessageTemplate},
      ${defaults.paymentReminderAiEnabled},
      ${defaults.paymentReminderAiPrompt},
      ${defaults.overdueReminderEnabled},
      ${sql3.raw(buildPgIntArray(defaults.overdueReminderDaysAfter))},
      ${defaults.overdueReminderMessageTemplate},
      ${defaults.overdueReminderAiEnabled},
      ${defaults.overdueReminderAiPrompt},
      ${defaults.periodicCheckinEnabled},
      ${defaults.periodicCheckinMinDays},
      ${defaults.periodicCheckinMaxDays},
      ${defaults.periodicCheckinMessageTemplate},
      ${defaults.checkinAiEnabled},
      ${defaults.checkinAiPrompt},
      ${defaults.broadcastEnabled},
      ${defaults.broadcastAntibotVariation},
      ${defaults.broadcastAiVariation},
      ${defaults.broadcastMinIntervalSeconds},
      ${defaults.broadcastMaxIntervalSeconds},
      ${defaults.disconnectedAlertEnabled},
      ${defaults.disconnectedAlertHours},
      ${defaults.disconnectedAlertMessageTemplate},
      ${defaults.disconnectedAiEnabled},
      ${defaults.disconnectedAiPrompt},
      ${defaults.aiVariationEnabled},
      ${defaults.aiVariationPrompt},
      ${defaults.businessHoursStart},
      ${defaults.businessHoursEnd},
      ${sql3.raw(buildPgIntArray(defaults.businessDays))},
      ${defaults.respectBusinessHours},
      ${defaults.welcomeMessageEnabled},
      ${sql3.raw(buildPgTextArray(defaults.welcomeMessageVariations))},
      ${defaults.welcomeMessageAiEnabled},
      ${defaults.welcomeMessageAiPrompt},
      ${defaults.trialLimitReachedEnabled},
      ${defaults.trialLimitReachedMessageTemplate},
      ${defaults.trialLimitReachedAiEnabled},
      ${defaults.trialLimitReachedAiPrompt}
    )
    ON CONFLICT (owner_user_id) DO NOTHING
  `);
}
function shouldReconcileOwnerLegacyAdmin(configRow, resolvedLegacyAdminId, legacyAdminConfigUpdatedAt) {
  const currentLegacyAdminId = typeof configRow?.legacy_admin_id === "string" && configRow.legacy_admin_id.trim().length > 0 ? configRow.legacy_admin_id.trim() : null;
  if (!configRow?.legacy_admin_migrated_at) {
    return true;
  }
  if (!resolvedLegacyAdminId) {
    return false;
  }
  if (currentLegacyAdminId !== resolvedLegacyAdminId) {
    return true;
  }
  if (!legacyAdminConfigUpdatedAt) {
    return false;
  }
  const migratedAt = parseDate(configRow?.legacy_admin_migrated_at);
  if (!migratedAt) {
    return true;
  }
  return legacyAdminConfigUpdatedAt.getTime() > migratedAt.getTime();
}
async function getLegacyAdminConfigUpdatedAt(legacyAdminId) {
  const result = await db.execute(sql3`
    SELECT updated_at
    FROM admin_notification_config
    WHERE admin_id = ${legacyAdminId}
    LIMIT 1
  `);
  return parseDate(result.rows?.[0]?.updated_at ?? null);
}
async function syncOwnerWorkspaceFromLegacyAdmin(ownerUserId, legacyAdminId) {
  const defaults = getDefaultConfig();
  await db.execute(sql3`
    INSERT INTO owner_notification_config (
      owner_user_id,
      legacy_admin_id,
      payment_reminder_enabled,
      payment_reminder_days_before,
      payment_reminder_message_template,
      payment_reminder_ai_enabled,
      payment_reminder_ai_prompt,
      overdue_reminder_enabled,
      overdue_reminder_days_after,
      overdue_reminder_message_template,
      overdue_reminder_ai_enabled,
      overdue_reminder_ai_prompt,
      periodic_checkin_enabled,
      periodic_checkin_min_days,
      periodic_checkin_max_days,
      periodic_checkin_message_template,
      checkin_ai_enabled,
      checkin_ai_prompt,
      broadcast_enabled,
      broadcast_antibot_variation,
      broadcast_ai_variation,
      broadcast_min_interval_seconds,
      broadcast_max_interval_seconds,
      disconnected_alert_enabled,
      disconnected_alert_hours,
      disconnected_alert_message_template,
      disconnected_ai_enabled,
      disconnected_ai_prompt,
      ai_variation_enabled,
      ai_variation_prompt,
      business_hours_start,
      business_hours_end,
      business_days,
      respect_business_hours,
      welcome_message_enabled,
      welcome_message_variations,
      welcome_message_ai_enabled,
      welcome_message_ai_prompt,
      trial_limit_reached_enabled,
      trial_limit_reached_message_template,
      trial_limit_reached_ai_enabled,
      trial_limit_reached_ai_prompt,
      legacy_admin_migrated_at,
      updated_at
    )
    SELECT
      ${ownerUserId},
      ${legacyAdminId},
      anc.payment_reminder_enabled,
      anc.payment_reminder_days_before,
      anc.payment_reminder_message_template,
      anc.payment_reminder_ai_enabled,
      anc.payment_reminder_ai_prompt,
      anc.overdue_reminder_enabled,
      anc.overdue_reminder_days_after,
      anc.overdue_reminder_message_template,
      anc.overdue_reminder_ai_enabled,
      anc.overdue_reminder_ai_prompt,
      anc.periodic_checkin_enabled,
      anc.periodic_checkin_min_days,
      anc.periodic_checkin_max_days,
      anc.periodic_checkin_message_template,
      anc.checkin_ai_enabled,
      anc.checkin_ai_prompt,
      anc.broadcast_enabled,
      anc.broadcast_antibot_variation,
      anc.broadcast_ai_variation,
      anc.broadcast_min_interval_seconds,
      anc.broadcast_max_interval_seconds,
      anc.disconnected_alert_enabled,
      anc.disconnected_alert_hours,
      anc.disconnected_alert_message_template,
      anc.disconnected_ai_enabled,
      anc.disconnected_ai_prompt,
      anc.ai_variation_enabled,
      anc.ai_variation_prompt,
      anc.business_hours_start,
      anc.business_hours_end,
      anc.business_days,
      anc.respect_business_hours,
      anc.welcome_message_enabled,
      anc.welcome_message_variations,
      anc.welcome_message_ai_enabled,
      anc.welcome_message_ai_prompt,
      ${defaults.trialLimitReachedEnabled},
      ${defaults.trialLimitReachedMessageTemplate},
      ${defaults.trialLimitReachedAiEnabled},
      ${defaults.trialLimitReachedAiPrompt},
      NOW(),
      NOW()
    FROM admin_notification_config anc
    WHERE anc.admin_id = ${legacyAdminId}
    ON CONFLICT (owner_user_id) DO UPDATE SET
      legacy_admin_id = EXCLUDED.legacy_admin_id,
      payment_reminder_enabled = EXCLUDED.payment_reminder_enabled,
      payment_reminder_days_before = EXCLUDED.payment_reminder_days_before,
      payment_reminder_message_template = EXCLUDED.payment_reminder_message_template,
      payment_reminder_ai_enabled = EXCLUDED.payment_reminder_ai_enabled,
      payment_reminder_ai_prompt = EXCLUDED.payment_reminder_ai_prompt,
      overdue_reminder_enabled = EXCLUDED.overdue_reminder_enabled,
      overdue_reminder_days_after = EXCLUDED.overdue_reminder_days_after,
      overdue_reminder_message_template = EXCLUDED.overdue_reminder_message_template,
      overdue_reminder_ai_enabled = EXCLUDED.overdue_reminder_ai_enabled,
      overdue_reminder_ai_prompt = EXCLUDED.overdue_reminder_ai_prompt,
      periodic_checkin_enabled = EXCLUDED.periodic_checkin_enabled,
      periodic_checkin_min_days = EXCLUDED.periodic_checkin_min_days,
      periodic_checkin_max_days = EXCLUDED.periodic_checkin_max_days,
      periodic_checkin_message_template = EXCLUDED.periodic_checkin_message_template,
      checkin_ai_enabled = EXCLUDED.checkin_ai_enabled,
      checkin_ai_prompt = EXCLUDED.checkin_ai_prompt,
      broadcast_enabled = EXCLUDED.broadcast_enabled,
      broadcast_antibot_variation = EXCLUDED.broadcast_antibot_variation,
      broadcast_ai_variation = EXCLUDED.broadcast_ai_variation,
      broadcast_min_interval_seconds = EXCLUDED.broadcast_min_interval_seconds,
      broadcast_max_interval_seconds = EXCLUDED.broadcast_max_interval_seconds,
      disconnected_alert_enabled = EXCLUDED.disconnected_alert_enabled,
      disconnected_alert_hours = EXCLUDED.disconnected_alert_hours,
      disconnected_alert_message_template = EXCLUDED.disconnected_alert_message_template,
      disconnected_ai_enabled = EXCLUDED.disconnected_ai_enabled,
      disconnected_ai_prompt = EXCLUDED.disconnected_ai_prompt,
      ai_variation_enabled = EXCLUDED.ai_variation_enabled,
      ai_variation_prompt = EXCLUDED.ai_variation_prompt,
      business_hours_start = EXCLUDED.business_hours_start,
      business_hours_end = EXCLUDED.business_hours_end,
      business_days = EXCLUDED.business_days,
      respect_business_hours = EXCLUDED.respect_business_hours,
      welcome_message_enabled = EXCLUDED.welcome_message_enabled,
      welcome_message_variations = EXCLUDED.welcome_message_variations,
      welcome_message_ai_enabled = EXCLUDED.welcome_message_ai_enabled,
      welcome_message_ai_prompt = EXCLUDED.welcome_message_ai_prompt,
      legacy_admin_migrated_at = NOW(),
      updated_at = NOW()
  `);
  await db.execute(sql3`
    INSERT INTO owner_notification_logs (
      id,
      owner_user_id,
      legacy_admin_id,
      user_id,
      notification_type,
      recipient_phone,
      recipient_name,
      message_original,
      message_sent,
      status,
      metadata,
      error_message,
      created_at,
      sent_at
    )
    SELECT
      anl.id,
      ${ownerUserId},
      ${legacyAdminId},
      anl.user_id,
      anl.notification_type,
      anl.recipient_phone,
      anl.recipient_name,
      anl.message_original,
      anl.message_sent,
      anl.status,
      COALESCE(anl.metadata, '{}'::jsonb),
      anl.error_message,
      COALESCE(anl.created_at, NOW()),
      anl.sent_at
    FROM admin_notification_logs anl
    WHERE anl.admin_id = ${legacyAdminId}
    ON CONFLICT (id) DO NOTHING
  `);
  await db.execute(sql3`
    INSERT INTO owner_scheduled_notifications (
      id,
      owner_user_id,
      legacy_admin_id,
      user_id,
      notification_type,
      recipient_phone,
      recipient_name,
      message_template,
      ai_prompt,
      scheduled_for,
      status,
      ai_enabled,
      metadata,
      final_message,
      conversation_context,
      error_message,
      retry_count,
      sent_at,
      created_at,
      updated_at
    )
    SELECT
      sn.id,
      ${ownerUserId},
      ${legacyAdminId},
      sn.user_id,
      sn.notification_type,
      sn.recipient_phone,
      sn.recipient_name,
      sn.message_template,
      sn.ai_prompt,
      sn.scheduled_for,
      sn.status,
      COALESCE(sn.ai_enabled, false),
      COALESCE(sn.metadata, '{}'::jsonb),
      sn.final_message,
      sn.conversation_context,
      sn.error_message,
      COALESCE(sn.retry_count, 0),
      sn.sent_at,
      COALESCE(sn.created_at, NOW()),
      COALESCE(sn.updated_at, NOW())
    FROM scheduled_notifications sn
    WHERE sn.admin_id = ${legacyAdminId}
    ON CONFLICT (id) DO NOTHING
  `);
  await db.execute(sql3`
    INSERT INTO owner_broadcast_archives (
      id,
      owner_user_id,
      legacy_admin_id,
      legacy_broadcast_id,
      name,
      message_template,
      target_type,
      target_filter,
      ai_variation,
      antibot_enabled,
      status,
      scheduled_at,
      total_recipients,
      sent_count,
      failed_count,
      created_at,
      started_at,
      completed_at,
      updated_at
    )
    SELECT
      ab.id,
      ${ownerUserId},
      ${legacyAdminId},
      ab.id,
      COALESCE(ab.name, 'Broadcast legado'),
      ab.message_template,
      ab.target_type,
      COALESCE(ab.target_filter, '{}'::jsonb),
      COALESCE(ab.ai_variation, false),
      COALESCE(ab.antibot_enabled, true),
      COALESCE(ab.status, 'completed'),
      ab.scheduled_at,
      COALESCE(ab.total_recipients, 0),
      COALESCE(ab.sent_count, 0),
      COALESCE(ab.failed_count, 0),
      COALESCE(ab.created_at, NOW()),
      ab.started_at,
      ab.completed_at,
      COALESCE(ab.updated_at, NOW())
    FROM admin_broadcasts ab
    WHERE ab.admin_id = ${legacyAdminId}
    ON CONFLICT (id) DO NOTHING
  `);
  await db.execute(sql3`
    INSERT INTO owner_broadcast_archive_messages (
      id,
      archive_id,
      owner_user_id,
      legacy_admin_id,
      user_id,
      recipient_phone,
      recipient_name,
      message_original,
      message_sent,
      ai_varied,
      status,
      error_message,
      sent_at
    )
    SELECT
      abm.id,
      abm.broadcast_id,
      ${ownerUserId},
      ${legacyAdminId},
      abm.user_id,
      abm.recipient_phone,
      abm.recipient_name,
      abm.message_original,
      abm.message_sent,
      COALESCE(abm.ai_varied, false),
      COALESCE(abm.status, 'sent'),
      abm.error_message,
      COALESCE(abm.sent_at, NOW())
    FROM admin_broadcast_messages abm
    WHERE abm.admin_id = ${legacyAdminId}
    ON CONFLICT (id) DO NOTHING
  `);
}
async function migrateLegacyAdminData(ownerUserId) {
  if (readyOwners.has(ownerUserId)) {
    return;
  }
  let lock = migrationLocks.get(ownerUserId);
  if (!lock) {
    lock = (async () => {
      await ensureOwnerWorkspaceTables();
      const ownerUser = await getOwnerWorkspaceUserById(ownerUserId);
      const legacyAdminMatch = await getLegacyAdminMatchForOwnerEmail(ownerUser?.email);
      const legacyAdminId = legacyAdminMatch?.id || null;
      const legacyAdminConfigUpdatedAt = legacyAdminId ? await getLegacyAdminConfigUpdatedAt(legacyAdminId) : null;
      let configRow = await getOwnerConfigRow(ownerUserId);
      if (!configRow) {
        await seedOwnerDefaultConfig(ownerUserId, legacyAdminId);
        configRow = await getOwnerConfigRow(ownerUserId);
      }
      if (!shouldReconcileOwnerLegacyAdmin(configRow, legacyAdminId, legacyAdminConfigUpdatedAt)) {
        readyOwners.add(ownerUserId);
        return;
      }
      if (legacyAdminId) {
        await syncOwnerWorkspaceFromLegacyAdmin(ownerUserId, legacyAdminId);
      }
      await db.execute(sql3`
        UPDATE owner_notification_config
        SET
          legacy_admin_id = COALESCE(${legacyAdminId}, legacy_admin_id),
          legacy_admin_migrated_at = NOW(),
          updated_at = NOW()
        WHERE owner_user_id = ${ownerUserId}
      `);
      readyOwners.add(ownerUserId);
    })().finally(() => {
      migrationLocks.delete(ownerUserId);
    });
    migrationLocks.set(ownerUserId, lock);
  }
  await lock;
}
async function ensureOwnerWorkspaceReady(ownerUserId) {
  await ensureOwnerWorkspaceTables();
  const allowed = await canUserAccessOwnerWorkspace(ownerUserId);
  if (!allowed) {
    throw new Error("Acesso negado ao workspace do administrador");
  }
  await migrateLegacyAdminData(ownerUserId);
}
async function syncOwnerWorkspaceForLegacyAdmin(legacyAdminId) {
  await ensureOwnerWorkspaceTables();
  const owners = await getOwnerWorkspaceUsers();
  let syncedOwners = 0;
  for (const owner of owners) {
    if (!owner?.id) continue;
    const match = await getLegacyAdminMatchForOwnerEmail(owner.email);
    if (match?.id !== legacyAdminId) {
      continue;
    }
    await syncOwnerWorkspaceFromLegacyAdmin(owner.id, legacyAdminId);
    await db.execute(sql3`
      UPDATE owner_notification_config
      SET
        legacy_admin_id = ${legacyAdminId},
        legacy_admin_migrated_at = NOW(),
        updated_at = NOW()
      WHERE owner_user_id = ${owner.id}
    `);
    readyOwners.add(owner.id);
    syncedOwners += 1;
  }
  return syncedOwners;
}
async function getManagedUsers(ownerUserId) {
  const result = await db.execute(sql3`
    SELECT
      u.id,
      u.phone,
      u.name,
      u.email,
      u.role,
      s.id AS subscription_id,
      s.status AS subscription_status,
      s.cancelled_at,
      s.data_inicio,
      s.data_fim,
      s.next_payment_date,
      s.coupon_price,
      p.valor AS plan_valor,
      p.nome AS plan_nome,
      COALESCE(wc.is_connected_effective, false) AS whatsapp_connected,
      wc.phone_number AS connection_phone_number,
      wc.updated_at AS connection_updated_at,
      EXISTS(
        SELECT 1
        FROM subscriptions sub_history
        WHERE sub_history.user_id = u.id
      ) AS has_subscription_history,
      EXISTS(
        SELECT 1
        FROM reseller_clients rc
        WHERE rc.user_id = u.id
      ) AS has_reseller_access,
      COALESCE(msg.agent_messages_count, 0) AS agent_messages_count
    FROM users u
    LEFT JOIN LATERAL (
      SELECT *
      FROM subscriptions sub
      WHERE sub.user_id = u.id
      ORDER BY sub.created_at DESC
      LIMIT 1
    ) s ON true
    LEFT JOIN LATERAL (
      SELECT
        c.id,
        CASE
          WHEN c.provider = 'baileys'
            AND COALESCE(NULLIF(c.connection_method, ''), 'qr') <> 'coexistence'
            AND COALESCE(NULLIF(c.provider_status, ''), 'inactive') = 'connected'
          THEN true
          ELSE COALESCE(c.is_connected, false)
        END AS is_connected_effective,
        c.phone_number,
        c.updated_at
      FROM whatsapp_connections c
      WHERE c.user_id = u.id
      ORDER BY c.created_at DESC
      LIMIT 1
    ) wc ON true
    LEFT JOIN plans p ON p.id = s.plan_id
    LEFT JOIN LATERAL (
      SELECT COUNT(*)::int AS agent_messages_count
      FROM messages m
      JOIN conversations conv ON conv.id = m.conversation_id
      WHERE conv.connection_id = wc.id
        AND m.is_from_agent = true
    ) msg ON true
    WHERE u.id <> ${ownerUserId}
      AND COALESCE(u.role, '') NOT IN ('owner', 'admin')
    ORDER BY u.created_at DESC
  `);
  return result.rows || [];
}
function isTrialLimitReachedCandidate(user) {
  return !Boolean(user.has_subscription_history) && !Boolean(user.has_reseller_access) && parseNumber(user.agent_messages_count, 0) >= FREE_TRIAL_MESSAGE_LIMIT;
}
function setTimeOnDate(base, hhmm, minuteOffset = 0) {
  const [hours, minutes] = String(hhmm || "09:00").split(":").map((value) => parseInt(value, 10) || 0);
  const date = new Date(base);
  date.setHours(hours, minutes + minuteOffset, 0, 0);
  return date;
}
function advanceToNextBusinessDay(date, businessDays) {
  const next = new Date(date);
  for (let index = 0; index < 14; index += 1) {
    if (businessDays.includes(next.getDay())) {
      return next;
    }
    next.setDate(next.getDate() + 1);
    next.setHours(9, 0, 0, 0);
  }
  return next;
}
function coerceToBusinessSlot(rawDate, config, seed) {
  const minuteOffset = hashToOffset(seed, 90);
  const businessDays = Array.isArray(config.businessDays) && config.businessDays.length > 0 ? config.businessDays : [1, 2, 3, 4, 5];
  let date = new Date(rawDate);
  if (!config.respectBusinessHours) {
    date.setSeconds(0, 0);
    return new Date(date.getTime() + minuteOffset * 60 * 1e3);
  }
  date = advanceToNextBusinessDay(date, businessDays);
  const start = setTimeOnDate(date, config.businessHoursStart || "09:00");
  const end = setTimeOnDate(date, config.businessHoursEnd || "18:00");
  if (date < start) {
    return setTimeOnDate(date, config.businessHoursStart || "09:00", minuteOffset);
  }
  if (date > end) {
    const nextDay = new Date(date);
    nextDay.setDate(nextDay.getDate() + 1);
    const businessDay = advanceToNextBusinessDay(nextDay, businessDays);
    return setTimeOnDate(businessDay, config.businessHoursStart || "09:00", minuteOffset);
  }
  date.setMinutes(date.getMinutes() + minuteOffset);
  if (date > end) {
    const nextDay = new Date(date);
    nextDay.setDate(nextDay.getDate() + 1);
    const businessDay = advanceToNextBusinessDay(nextDay, businessDays);
    return setTimeOnDate(businessDay, config.businessHoursStart || "09:00", minuteOffset);
  }
  date.setSeconds(0, 0);
  return date;
}
function formatDatePtBr(dateValue) {
  const date = parseDate(dateValue);
  return date ? date.toLocaleDateString("pt-BR") : "";
}
function parseBillingAmount(value, fallback = 0) {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : fallback;
  }
  const raw = String(value ?? "").trim();
  if (!raw) return fallback;
  const normalized = raw.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}(?:\D|$))/g, "").replace(",", ".");
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : fallback;
}
function formatAmountForMessage(value) {
  const amount = parseBillingAmount(value, Number.NaN);
  if (!Number.isFinite(amount)) {
    return String(value ?? "");
  }
  return amount.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
function firstPositiveBillingAmount(...values) {
  for (const value of values) {
    const amount = parseBillingAmount(value, Number.NaN);
    if (Number.isFinite(amount) && amount > 0) {
      return amount;
    }
  }
  return 0;
}
function getManagedUserBillingAmount(user) {
  return firstPositiveBillingAmount(user.coupon_price, user.plan_valor);
}
function getBillingSnapshotAmount(snapshot, metadata) {
  return firstPositiveBillingAmount(
    snapshot?.coupon_price,
    metadata.valor,
    metadata.amount,
    snapshot?.plan_valor
  );
}
function getManagedUserDueDate(user) {
  return latestDate(user.next_payment_date, user.data_fim);
}
function isManagedUserCurrentlyActive(user, now = /* @__PURE__ */ new Date()) {
  if (user.subscription_status !== "active") {
    return false;
  }
  const dueDate = getManagedUserDueDate(user);
  return !dueDate || dueDate.getTime() >= now.getTime();
}
function isManagedUserBillingOverdue(user, now = /* @__PURE__ */ new Date()) {
  const dueDate = getManagedUserDueDate(user);
  return Boolean(dueDate && dueDate.getTime() < now.getTime() && user.has_subscription_history);
}
function isManagedUserCancellationRequested(user) {
  return Boolean(parseDate(user.cancelled_at));
}
function shouldUseOwnerLogForDedupe(status) {
  return status === "sent" || status === "skipped_active_plan" || status === "skipped_stale";
}
function isWithinOwnerHorizon(date, horizonEnd) {
  return date.getTime() <= horizonEnd.getTime();
}
function rebaseMissedOwnerNotification(rawScheduledFor, config, seed, catchupIndex, now = /* @__PURE__ */ new Date()) {
  if (rawScheduledFor.getTime() >= now.getTime()) {
    return rawScheduledFor;
  }
  const base = new Date(now.getTime() + Math.max(0, catchupIndex) * 2 * 60 * 1e3);
  return coerceToBusinessSlot(base, config, `${seed}:catchup:${catchupIndex}`);
}
function buildMessageFromTemplate(template, recipientName, metadata) {
  const valor = metadata.valorFormatado ?? metadata.valor_formatado ?? metadata.valor;
  const pixCode = metadata.pix_copia_cola ?? metadata.pixCopiaCola ?? metadata.pixCode ?? metadata.codigoPix ?? metadata.codigo_pix ?? "";
  const replacements = {
    cliente_nome: recipientName || "Cliente",
    nome: recipientName || "Cliente",
    name: recipientName || "Cliente",
    dias_restantes: String(metadata.daysBefore ?? metadata.daysUntilExpiration ?? ""),
    dias_atraso: String(metadata.daysAfter ?? metadata.daysOverdue ?? ""),
    data_vencimento: formatDatePtBr(metadata.dueDate),
    valor: valor === void 0 || valor === null || valor === "" ? "" : formatAmountForMessage(valor),
    plano: String(metadata.planName ?? metadata.plan_nome ?? metadata.plano ?? ""),
    pix_copia_cola: String(pixCode || ""),
    codigo_pix: String(pixCode || ""),
    link_pagamento: String(metadata.link_pagamento ?? metadata.paymentLink ?? "https://agentezap.online/plans")
  };
  let output = String(template || "");
  for (const [key, value] of Object.entries(replacements)) {
    output = output.split(`{{${key}}}`).join(value);
    output = output.split(`{${key}}`).join(value);
  }
  return output;
}
function buildNotificationKey(userId, type, metadata) {
  const markerParts = [];
  const primaryMarker = metadata.daysBefore ?? metadata.daysAfter ?? metadata.hoursDisconnected ?? metadata.seed ?? metadata.messageLimit ?? metadata.kind ?? "";
  if (primaryMarker !== "") {
    markerParts.push(String(primaryMarker));
  }
  const cycleMarker = metadata.billingCycleDate ?? metadata.dueDate ?? metadata.checkinCycleDate ?? metadata.disconnectedSince ?? metadata.connectionUpdatedAt ?? "";
  if (cycleMarker !== "") {
    markerParts.push(String(cycleMarker).slice(0, 10));
  }
  return `${userId}:${type}:${markerParts.join(":")}`;
}
function isBillingNotificationType(type) {
  return type === "payment_reminder" || type === "overdue_reminder";
}
function getStaleOwnerNotificationSkipReason(row, notificationType, metadata) {
  const scheduledFor = parseDate(row.scheduled_for);
  if ((notificationType === "disconnected" || notificationType === "disconnected_alert") && scheduledFor && scheduledFor.getTime() < Date.now() - OWNER_STALE_DISCONNECTED_NOTIFICATION_MS) {
    return "Envio bloqueado: alerta de desconexao ficou antigo.";
  }
  if (notificationType === "overdue_reminder") {
    const dueDate = parseDate(metadata.dueDate);
    if (dueDate && dueDate.getTime() < Date.now() - OWNER_STALE_OVERDUE_NOTIFICATION_MS) {
      return "Envio bloqueado: cobranca antiga fora da agenda atual.";
    }
  }
  return null;
}
function getMetadataText(metadata, keys) {
  for (const key of keys) {
    const value = metadata[key];
    if (value !== void 0 && value !== null && String(value).trim()) {
      return String(value).trim();
    }
  }
  return "";
}
async function getBillingSubscriptionSnapshot(row, metadata) {
  const metadataSubscriptionId = getMetadataText(metadata, ["subscriptionId", "subscription_id"]);
  const rowUserId = row.user_id || null;
  if (metadataSubscriptionId) {
    const result2 = await db.execute(sql3`
      SELECT
        s.id,
        s.user_id,
        s.status,
        s.data_fim,
        s.next_payment_date,
        s.coupon_price,
        p.nome AS plan_nome,
        p.valor AS plan_valor
      FROM subscriptions s
      LEFT JOIN plans p ON p.id = s.plan_id
      WHERE s.id = ${metadataSubscriptionId}
        AND (${rowUserId}::text IS NULL OR s.user_id = ${rowUserId})
      LIMIT 1
    `);
    return result2.rows?.[0] || null;
  }
  if (!row.user_id) return null;
  const result = await db.execute(sql3`
    SELECT
      s.id,
      s.user_id,
      s.status,
      s.data_fim,
      s.next_payment_date,
      s.coupon_price,
      p.nome AS plan_nome,
      p.valor AS plan_valor
    FROM subscriptions s
    LEFT JOIN plans p ON p.id = s.plan_id
    WHERE s.user_id = ${row.user_id}
    ORDER BY s.created_at DESC
    LIMIT 1
  `);
  return result.rows?.[0] || null;
}
async function getBillingNotificationSkipReason(row, notificationType, metadata) {
  if (notificationType === "overdue_reminder") {
    return await hasActiveSubscriptionForUser(row.user_id) || await hasActiveSubscriptionForRecipientPhone(row.recipient_phone) ? "Envio bloqueado: cliente ja possui assinatura ativa." : null;
  }
  if (notificationType !== "payment_reminder") {
    return null;
  }
  const snapshot = await getBillingSubscriptionSnapshot(row, metadata);
  if (!snapshot?.id) {
    return await hasActiveSubscriptionForUser(row.user_id) ? "Envio bloqueado: lembrete antigo sem assinatura de referencia." : "Envio bloqueado: assinatura de cobranca nao encontrada.";
  }
  if (String(snapshot.status || "") !== "active") {
    return "Envio bloqueado: plano de cobranca nao esta ativo.";
  }
  const snapshotDueDate = latestDate(snapshot.next_payment_date, snapshot.data_fim);
  const metadataDueDate = parseDate(metadata.dueDate);
  if (notificationType === "payment_reminder" && snapshotDueDate && metadataDueDate && metadataDueDate.getTime() < snapshotDueDate.getTime() - 24 * 60 * 60 * 1e3) {
    return "Envio bloqueado: lembrete antigo de ciclo ja renovado.";
  }
  const dueDate = snapshotDueDate || metadataDueDate;
  if (dueDate && dueDate.getTime() < Date.now() - 24 * 60 * 60 * 1e3) {
    return "Envio bloqueado: lembrete antes do vencimento ficou antigo.";
  }
  return null;
}
async function enrichBillingNotificationMetadata(row, notificationType, metadata) {
  if (!isBillingNotificationType(notificationType)) {
    return metadata;
  }
  const existingPixCode = getMetadataText(metadata, [
    "pix_copia_cola",
    "pixCopiaCola",
    "pixCode",
    "codigoPix",
    "codigo_pix"
  ]);
  if (existingPixCode) {
    return metadata;
  }
  const snapshot = await getBillingSubscriptionSnapshot(row, metadata);
  const subscriptionId = getMetadataText(metadata, ["subscriptionId", "subscription_id"]) || String(snapshot?.id || "");
  const planName = getMetadataText(metadata, ["planName", "plan_nome", "plano"]) || String(snapshot?.plan_nome || "Plano AgenteZap");
  const amount = getBillingSnapshotAmount(snapshot, metadata);
  if (!subscriptionId || !Number.isFinite(amount) || amount <= 0) {
    return metadata;
  }
  const { pixCode } = await generatePixQRCode({
    planNome: planName,
    valor: amount,
    subscriptionId
  });
  return {
    ...metadata,
    subscriptionId,
    subscription_id: subscriptionId,
    planName,
    plan_nome: planName,
    plano: planName,
    valor: amount.toFixed(2),
    valorFormatado: formatAmountForMessage(amount),
    pix_copia_cola: pixCode,
    pixCopiaCola: pixCode,
    pixCode,
    codigoPix: pixCode,
    codigo_pix: pixCode,
    link_pagamento: metadata.link_pagamento ?? metadata.paymentLink ?? "https://agentezap.online/plans",
    pixSource: "plans_manual_pix",
    pixGeneratedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function isOwnerNotificationModuleEnabled(type, config) {
  switch (type) {
    case "payment_reminder":
      return config.paymentReminderEnabled !== false;
    case "overdue_reminder":
      return config.overdueReminderEnabled !== false;
    case "checkin":
    case "periodic_checkin":
      return config.periodicCheckinEnabled !== false;
    case "disconnected":
    case "disconnected_alert":
      return config.disconnectedAlertEnabled !== false;
    case "trial_limit_reached":
      return config.trialLimitReachedEnabled !== false;
    default:
      return true;
  }
}
async function hasActiveSubscriptionForUser(userId) {
  if (!userId) return false;
  const result = await db.execute(sql3`
    SELECT 1
    FROM subscriptions
    WHERE user_id = ${userId}
      AND status = 'active'
      AND (
        (next_payment_date IS NULL AND data_fim IS NULL)
        OR GREATEST(
          COALESCE(next_payment_date, '-infinity'::timestamp),
          COALESCE(data_fim, '-infinity'::timestamp)
        ) >= NOW()
      )
    LIMIT 1
  `);
  return (result.rows || []).length > 0;
}
async function hasActiveSubscriptionForRecipientPhone(phone) {
  const phoneKey = normalizePhone2(phone).slice(-11);
  if (phoneKey.length < 10) return false;
  const result = await db.execute(sql3`
    SELECT 1
    FROM users u
    JOIN subscriptions s ON s.user_id = u.id
    WHERE RIGHT(regexp_replace(COALESCE(u.phone, ''), '\\D', '', 'g'), 11) = ${phoneKey}
      AND s.status = 'active'
      AND (
        (s.next_payment_date IS NULL AND s.data_fim IS NULL)
        OR GREATEST(
          COALESCE(s.next_payment_date, '-infinity'::timestamp),
          COALESCE(s.data_fim, '-infinity'::timestamp)
        ) >= NOW()
      )
    LIMIT 1
  `);
  return (result.rows || []).length > 0;
}
async function createOwnerNotificationLog(input) {
  await db.execute(sql3`
    INSERT INTO owner_notification_logs (
      id,
      owner_user_id,
      user_id,
      notification_type,
      recipient_phone,
      recipient_name,
      message_original,
      message_sent,
      status,
      metadata,
      error_message,
      created_at,
      sent_at
    ) VALUES (
      ${crypto.randomUUID()},
      ${input.ownerUserId},
      ${input.userId || null},
      ${input.notificationType},
      ${input.recipientPhone},
      ${input.recipientName},
      ${input.messageOriginal},
      ${input.messageSent},
      ${input.status},
      ${JSON.stringify(input.metadata || {})}::jsonb,
      ${input.errorMessage || null},
      NOW(),
      NOW()
    )
  `);
}
async function ensureOwnerConversation(ownerUserId, phone, name) {
  const connection = await storage.getUserActiveConnection(ownerUserId);
  if (!connection?.id) {
    throw new Error("A conex\xE3o principal do propriet\xE1rio n\xE3o est\xE1 conectada");
  }
  const normalizedPhone = normalizePhone2(phone);
  if (!normalizedPhone) {
    throw new Error("Telefone do destinat\xE1rio inv\xE1lido");
  }
  let conversation = await storage.getActiveConversationByContactNumber(connection.id, normalizedPhone);
  if (!conversation) {
    conversation = await storage.createConversation({
      connectionId: connection.id,
      contactNumber: normalizedPhone,
      remoteJid: `${normalizedPhone}@s.whatsapp.net`,
      jidSuffix: "s.whatsapp.net",
      contactName: name || normalizedPhone,
      contactAvatar: null,
      lastMessageText: null,
      lastMessageTime: /* @__PURE__ */ new Date(),
      lastMessageFromMe: true,
      unreadCount: 0,
      hasReplied: true
    });
  }
  return conversation;
}
async function resolveOwnerRecipientName(ownerUserId, phone) {
  const normalizedPhone = normalizePhone2(phone);
  const connection = await storage.getUserActiveConnection(ownerUserId);
  if (connection?.id && normalizedPhone) {
    const activeConversation = await storage.getActiveConversationByContactNumber(connection.id, normalizedPhone);
    const existingConversation = activeConversation || await storage.getConversationByContactNumber(connection.id, normalizedPhone);
    const conversationName = String(existingConversation?.contactName || "").trim();
    if (conversationName) {
      return conversationName;
    }
  }
  if (normalizedPhone) {
    const user = await storage.getUserByPhone(normalizedPhone);
    const userName = String(user?.name || "").trim();
    if (userName) {
      return userName;
    }
  }
  return "Cliente";
}
async function isOwnerNotificationRecipientExcluded(ownerUserId, phone) {
  const normalizedPhone = normalizePhone2(phone);
  if (!normalizedPhone) {
    return false;
  }
  try {
    if (await storage.isNumberExcluded(ownerUserId, normalizedPhone)) {
      return true;
    }
    return await storage.isNumberExcludedFromFollowup(ownerUserId, normalizedPhone);
  } catch (error) {
    console.warn("[OWNER-NOTIFICATIONS] Falha ao verificar lista de exclusao:", error);
    return false;
  }
}
async function sendOwnerNotificationRow(ownerUserId, row, options) {
  const config = await getOwnerWorkspaceConfig(ownerUserId);
  const recipientName = String(row.recipient_name || "Cliente").trim() || "Cliente";
  let metadata = parseJsonField(row.metadata, {});
  const notificationType = String(row.notification_type || "");
  let originalMessage = buildMessageFromTemplate(row.message_template, recipientName, metadata);
  const skip = async (status, reason) => {
    await db.execute(sql3`
      UPDATE owner_scheduled_notifications
      SET
        status = ${status},
        final_message = ${originalMessage},
        error_message = ${reason},
        sent_at = NULL,
        updated_at = NOW()
      WHERE id = ${row.id}
    `);
    await createOwnerNotificationLog({
      ownerUserId,
      userId: row.user_id,
      notificationType,
      recipientPhone: row.recipient_phone,
      recipientName,
      messageOriginal: originalMessage,
      messageSent: "",
      status,
      metadata,
      errorMessage: reason
    });
    return {
      success: false,
      finalMessage: "",
      requeued: false,
      nextAttemptAt: null,
      message: reason
    };
  };
  if (!isOwnerNotificationModuleEnabled(notificationType, config)) {
    return skip("skipped_disabled", "Envio bloqueado: modulo desativado no painel.");
  }
  const staleReason = getStaleOwnerNotificationSkipReason(row, notificationType, metadata);
  if (staleReason) {
    return skip("skipped_stale", staleReason);
  }
  if (await isOwnerNotificationRecipientExcluded(ownerUserId, row.recipient_phone)) {
    return skip("skipped_excluded", "Numero na lista de exclusao. Envio automatico bloqueado.");
  }
  if (isBillingNotificationType(notificationType)) {
    const skipReason = await getBillingNotificationSkipReason(row, notificationType, metadata);
    if (skipReason) {
      return skip("skipped_active_plan", skipReason);
    }
    const nextMetadata = await enrichBillingNotificationMetadata(row, notificationType, metadata);
    if (JSON.stringify(nextMetadata) !== JSON.stringify(metadata)) {
      metadata = nextMetadata;
      originalMessage = buildMessageFromTemplate(row.message_template, recipientName, metadata);
      await db.execute(sql3`
        UPDATE owner_scheduled_notifications
        SET metadata = ${JSON.stringify(metadata)}::jsonb, updated_at = NOW()
        WHERE id = ${row.id}
      `);
    }
  }
  let finalMessage = options?.regenerate ? originalMessage : String(row.final_message || originalMessage).trim() || originalMessage;
  finalMessage = buildMessageFromTemplate(finalMessage, recipientName, metadata).trim() || originalMessage;
  if ((row.ai_enabled ?? false) && (options?.regenerate || !row.final_message)) {
    const customPrompt = String(row.ai_prompt || config.aiVariationPrompt || "").trim();
    if (customPrompt) {
      finalMessage = await applyAIVariation(finalMessage, customPrompt, recipientName);
      finalMessage = buildMessageFromTemplate(finalMessage, recipientName, metadata);
    }
  }
  const conversation = await ensureOwnerConversation(ownerUserId, row.recipient_phone, recipientName);
  const result = await sendMessage(ownerUserId, conversation.id, finalMessage, { source: "system" });
  const delivery = buildOwnerDeliveryDecision(row, {
    success: result.success === true && !result.blocked,
    blocked: result.blocked === true,
    deferred: result.deferred === true,
    retryAfterMs: result.retryAfterMs,
    reason: result.reason || "Falha ao enviar mensagem"
  });
  const success = delivery.status === "sent";
  const errorMessage = delivery.errorMessage;
  await db.execute(sql3`
    UPDATE owner_scheduled_notifications
    SET
      status = ${delivery.status},
      final_message = ${finalMessage},
      error_message = ${errorMessage},
      retry_count = ${delivery.retryCount},
      scheduled_for = ${delivery.nextAttemptAt || row.scheduled_for},
      sent_at = ${delivery.sentAt},
      updated_at = NOW()
    WHERE id = ${row.id}
  `);
  await createOwnerNotificationLog({
    ownerUserId,
    userId: row.user_id,
    notificationType: row.notification_type,
    recipientPhone: row.recipient_phone,
    recipientName,
    messageOriginal: originalMessage,
    messageSent: finalMessage,
    status: delivery.logStatus,
    metadata,
    errorMessage: delivery.errorMessage
  });
  return {
    success,
    finalMessage,
    requeued: delivery.status === "pending",
    nextAttemptAt: delivery.nextAttemptAt,
    message: success ? "Notificacao enviada com sucesso" : errorMessage || "Falha ao enviar"
  };
}
function computeOwnerRetryDelayMs(retryCount, requestedRetryAfterMs) {
  if (Number.isFinite(requestedRetryAfterMs) && Number(requestedRetryAfterMs) > 0) {
    return Math.min(Math.max(Number(requestedRetryAfterMs), OWNER_RETRY_BASE_DELAY_MS), OWNER_RETRY_MAX_DELAY_MS);
  }
  const safeRetryCount = Math.max(0, Math.floor(retryCount));
  const delayStepsMs = [
    5 * 60 * 1e3,
    10 * 60 * 1e3,
    20 * 60 * 1e3,
    30 * 60 * 1e3,
    45 * 60 * 1e3,
    60 * 60 * 1e3
  ];
  return delayStepsMs[Math.min(safeRetryCount, delayStepsMs.length - 1)];
}
function buildOwnerDeliveryDecision(row, outcome) {
  const retryCount = Math.max(0, Number(row.retry_count || 0));
  const normalizedReason = String(outcome.reason || "").trim();
  if (outcome.success) {
    return {
      status: "sent",
      logStatus: "sent",
      errorMessage: null,
      retryCount,
      sentAt: /* @__PURE__ */ new Date(),
      nextAttemptAt: null
    };
  }
  if (outcome.blocked && normalizedReason === "Mensagem duplicada recente") {
    return {
      status: "sent",
      logStatus: "sent",
      errorMessage: null,
      retryCount,
      sentAt: /* @__PURE__ */ new Date(),
      nextAttemptAt: null
    };
  }
  const nextRetryCount = retryCount + 1;
  const retryDelayMs = computeOwnerRetryDelayMs(nextRetryCount, outcome.retryAfterMs);
  return {
    status: "pending",
    logStatus: "failed",
    errorMessage: normalizedReason || "Falha ao enviar mensagem",
    retryCount: nextRetryCount,
    sentAt: null,
    nextAttemptAt: new Date(Date.now() + retryDelayMs)
  };
}
async function recoverOwnerFailedNotifications(ownerUserId) {
  const failedResult = await db.execute(sql3`
    SELECT *
    FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND status = 'failed'
    ORDER BY updated_at ASC
    LIMIT 200
  `);
  const failedRows = failedResult.rows || [];
  for (const row of failedRows) {
    const retryCount = Math.max(1, Number(row.retry_count || 0));
    const retryDelayMs = computeOwnerRetryDelayMs(retryCount, null);
    await db.execute(sql3`
      UPDATE owner_scheduled_notifications
      SET
        status = 'pending',
        retry_count = ${retryCount},
        scheduled_for = ${new Date(Date.now() + retryDelayMs)},
        updated_at = NOW()
      WHERE id = ${row.id}
    `);
  }
  return failedRows.length;
}
async function sleepRange2(minSeconds, maxSeconds) {
  const safeMin = Math.max(1, Math.floor(minSeconds));
  const safeMax = Math.max(safeMin, Math.floor(maxSeconds));
  const duration = safeMin === safeMax ? safeMin : Math.floor(Math.random() * (safeMax - safeMin + 1)) + safeMin;
  await new Promise((resolve) => setTimeout(resolve, duration * 1e3));
}
async function insertScheduledNotification(input) {
  await db.execute(sql3`
    INSERT INTO owner_scheduled_notifications (
      id,
      owner_user_id,
      user_id,
      notification_type,
      recipient_phone,
      recipient_name,
      message_template,
      ai_prompt,
      scheduled_for,
      status,
      ai_enabled,
      metadata,
      created_at,
      updated_at
    ) VALUES (
      ${crypto.randomUUID()},
      ${input.ownerUserId},
      ${input.userId},
      ${input.type},
      ${input.phone},
      ${input.name},
      ${input.template},
      ${input.aiPrompt},
      ${input.scheduledFor},
      'pending',
      ${input.aiEnabled},
      ${JSON.stringify(input.metadata)}::jsonb,
      NOW(),
      NOW()
    )
  `);
}
async function getOwnerWorkspaceConfig(ownerUserId) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const row = await getOwnerConfigRow(ownerUserId);
  return mapConfigRowToCamel(row);
}
async function updateOwnerWorkspaceConfig(ownerUserId, updates) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const currentRow = await getOwnerConfigRow(ownerUserId);
  const current = mapConfigRowToCamel(currentRow);
  const legacyAdminId = typeof currentRow?.legacy_admin_id === "string" && currentRow.legacy_admin_id.trim().length > 0 ? currentRow.legacy_admin_id.trim() : null;
  const next = {
    ...current,
    ...updates,
    paymentReminderDaysBefore: Array.isArray(updates.paymentReminderDaysBefore) ? updates.paymentReminderDaysBefore.map((value) => Number(value)).filter(Number.isFinite) : current.paymentReminderDaysBefore,
    overdueReminderDaysAfter: Array.isArray(updates.overdueReminderDaysAfter) ? updates.overdueReminderDaysAfter.map((value) => Number(value)).filter(Number.isFinite) : current.overdueReminderDaysAfter,
    businessDays: Array.isArray(updates.businessDays) ? updates.businessDays.map((value) => Number(value)).filter(Number.isFinite) : current.businessDays,
    welcomeMessageVariations: Array.isArray(updates.welcomeMessageVariations) ? updates.welcomeMessageVariations.map((value) => String(value || "").trim()).filter(Boolean) : current.welcomeMessageVariations
  };
  await db.execute(sql3`
    UPDATE owner_notification_config
    SET
      payment_reminder_enabled = ${next.paymentReminderEnabled},
      payment_reminder_days_before = ${sql3.raw(buildPgIntArray(next.paymentReminderDaysBefore))},
      payment_reminder_message_template = ${next.paymentReminderMessageTemplate},
      payment_reminder_ai_enabled = ${next.paymentReminderAiEnabled},
      payment_reminder_ai_prompt = ${next.paymentReminderAiPrompt},
      overdue_reminder_enabled = ${next.overdueReminderEnabled},
      overdue_reminder_days_after = ${sql3.raw(buildPgIntArray(next.overdueReminderDaysAfter))},
      overdue_reminder_message_template = ${next.overdueReminderMessageTemplate},
      overdue_reminder_ai_enabled = ${next.overdueReminderAiEnabled},
      overdue_reminder_ai_prompt = ${next.overdueReminderAiPrompt},
      periodic_checkin_enabled = ${next.periodicCheckinEnabled},
      periodic_checkin_min_days = ${next.periodicCheckinMinDays},
      periodic_checkin_max_days = ${next.periodicCheckinMaxDays},
      periodic_checkin_message_template = ${next.periodicCheckinMessageTemplate},
      checkin_ai_enabled = ${next.checkinAiEnabled},
      checkin_ai_prompt = ${next.checkinAiPrompt},
      broadcast_enabled = ${next.broadcastEnabled},
      broadcast_antibot_variation = ${next.broadcastAntibotVariation},
      broadcast_ai_variation = ${next.broadcastAiVariation},
      broadcast_min_interval_seconds = ${Math.max(next.broadcastMinIntervalSeconds, 60)},
      broadcast_max_interval_seconds = ${Math.max(next.broadcastMaxIntervalSeconds, 60)},
      disconnected_alert_enabled = ${next.disconnectedAlertEnabled},
      disconnected_alert_hours = ${next.disconnectedAlertHours},
      disconnected_alert_message_template = ${next.disconnectedAlertMessageTemplate},
      disconnected_ai_enabled = ${next.disconnectedAiEnabled},
      disconnected_ai_prompt = ${next.disconnectedAiPrompt},
      ai_variation_enabled = ${next.aiVariationEnabled},
      ai_variation_prompt = ${next.aiVariationPrompt},
      business_hours_start = ${next.businessHoursStart},
      business_hours_end = ${next.businessHoursEnd},
      business_days = ${sql3.raw(buildPgIntArray(next.businessDays))},
      respect_business_hours = ${next.respectBusinessHours},
      welcome_message_enabled = ${next.welcomeMessageEnabled},
      welcome_message_variations = ${sql3.raw(buildPgTextArray(next.welcomeMessageVariations))},
      welcome_message_ai_enabled = ${next.welcomeMessageAiEnabled},
      welcome_message_ai_prompt = ${next.welcomeMessageAiPrompt},
      trial_limit_reached_enabled = ${next.trialLimitReachedEnabled},
      trial_limit_reached_message_template = ${next.trialLimitReachedMessageTemplate},
      trial_limit_reached_ai_enabled = ${next.trialLimitReachedAiEnabled},
      trial_limit_reached_ai_prompt = ${next.trialLimitReachedAiPrompt},
      updated_at = NOW()
    WHERE owner_user_id = ${ownerUserId}
  `);
  if (legacyAdminId && storage.updateAdminNotificationConfig) {
    await storage.updateAdminNotificationConfig(legacyAdminId, next);
  }
  const disabledTypesByModule = [
    {
      enabled: next.paymentReminderEnabled,
      types: ["payment_reminder"],
      reason: "Cancelado automaticamente: m\xF3dulo de pagamento desativado"
    },
    {
      enabled: next.overdueReminderEnabled,
      types: ["overdue_reminder"],
      reason: "Cancelado automaticamente: m\xF3dulo de cobran\xE7a desativado"
    },
    {
      enabled: next.periodicCheckinEnabled,
      types: ["checkin", "periodic_checkin"],
      reason: "Cancelado automaticamente: m\xF3dulo de check-in desativado"
    },
    {
      enabled: next.disconnectedAlertEnabled,
      types: ["disconnected", "disconnected_alert"],
      reason: "Cancelado automaticamente: m\xF3dulo de desconectado desativado"
    },
    {
      enabled: next.trialLimitReachedEnabled,
      types: ["trial_limit_reached"],
      reason: "Cancelado automaticamente: modulo de limite de teste desativado"
    }
  ];
  for (const moduleConfig of disabledTypesByModule) {
    if (moduleConfig.enabled) continue;
    for (const type of moduleConfig.types) {
      await db.execute(sql3`
        UPDATE owner_scheduled_notifications
        SET
          status = 'cancelled',
          error_message = COALESCE(NULLIF(error_message, ''), ${moduleConfig.reason}),
          updated_at = NOW()
        WHERE owner_user_id = ${ownerUserId}
          AND notification_type = ${type}
          AND status IN ('pending', 'processing')
      `);
    }
  }
}
async function getOwnerWorkspaceStats(ownerUserId) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const users2 = await getManagedUsers(ownerUserId);
  const now = /* @__PURE__ */ new Date();
  const total = users2.length;
  const withPlan = users2.filter((user) => isManagedUserCurrentlyActive(user, now)).length;
  const withoutPlan = total - withPlan;
  const disconnected = users2.filter((user) => !user.whatsapp_connected).length;
  const trialLimitReached = users2.filter(isTrialLimitReachedCandidate).length;
  const overduePayments = users2.filter((user) => isManagedUserBillingOverdue(user, now)).length;
  return { total, withPlan, withoutPlan, disconnected, overduePayments, trialLimitReached };
}
async function getOwnerWorkspaceHistory(ownerUserId, filters) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const page = Math.max(1, Number(filters.page || 1));
  const pageSize = Math.max(1, Math.min(100, Number(filters.pageSize || 20)));
  const offset = (page - 1) * pageSize;
  const whereParts = [sql3`owner_user_id = ${ownerUserId}`];
  if (filters.type && filters.type !== "all") {
    whereParts.push(sql3`notification_type = ${filters.type}`);
  }
  if (filters.status && filters.status !== "all") {
    whereParts.push(sql3`status = ${filters.status}`);
  }
  const whereClause = sql3.join(whereParts, sql3` AND `);
  const totalResult = await db.execute(sql3`
    SELECT COUNT(*) AS total
    FROM owner_notification_logs
    WHERE ${whereClause}
  `);
  const rows = await db.execute(sql3`
    SELECT *
    FROM owner_notification_logs
    WHERE ${whereClause}
    ORDER BY created_at DESC
    LIMIT ${pageSize}
    OFFSET ${offset}
  `);
  const total = parseNumber(totalResult.rows?.[0]?.total, 0);
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  return {
    logs: rows.rows || [],
    pagination: {
      page,
      limit: pageSize,
      pageSize,
      total,
      totalPages
    }
  };
}
async function getOwnerWorkspaceScheduled(ownerUserId, startDate, endDate) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const hasExplicitDateRange = Boolean(startDate || endDate);
  const startKey = startDate || endDate || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const endKey = endDate || startDate || new Date(Date.now() + OWNER_HORIZON_DAYS * 24 * 60 * 60 * 1e3).toISOString().slice(0, 10);
  const result = hasExplicitDateRange ? await db.execute(sql3`
        SELECT osn.*, u.name AS user_name, u.email AS user_email
        FROM owner_scheduled_notifications osn
        LEFT JOIN users u ON u.id = osn.user_id
        WHERE osn.owner_user_id = ${ownerUserId}
          AND DATE(osn.scheduled_for AT TIME ZONE 'America/Sao_Paulo') >= ${startKey}::date
          AND DATE(osn.scheduled_for AT TIME ZONE 'America/Sao_Paulo') <= ${endKey}::date
        ORDER BY osn.scheduled_for ASC
      `) : await db.execute(sql3`
        SELECT osn.*, u.name AS user_name, u.email AS user_email
        FROM owner_scheduled_notifications osn
        LEFT JOIN users u ON u.id = osn.user_id
        WHERE osn.owner_user_id = ${ownerUserId}
          AND osn.scheduled_for >= NOW()
          AND DATE(osn.scheduled_for AT TIME ZONE 'America/Sao_Paulo') <= ${endKey}::date
        ORDER BY osn.scheduled_for ASC
      `);
  return result.rows || [];
}
async function getOwnerWorkspaceCalendar(ownerUserId, month, year) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const start = new Date(year, month - 1, 1, 0, 0, 0, 0);
  const end = new Date(year, month, 0, 23, 59, 59, 999);
  const result = await db.execute(sql3`
    SELECT
      DATE(scheduled_for AT TIME ZONE 'America/Sao_Paulo') AS day,
      status,
      notification_type,
      COUNT(*) AS total
    FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND scheduled_for >= ${start}
      AND scheduled_for <= ${end}
    GROUP BY 1, 2, 3
    ORDER BY 1 ASC
  `);
  const calendar = {};
  for (const row of result.rows) {
    const rawDay = row.day;
    const dayKey = rawDay instanceof Date ? rawDay.toISOString().slice(0, 10) : String(rawDay || "").slice(0, 10);
    if (!calendar[dayKey]) {
      calendar[dayKey] = { total: 0, pending: 0, sent: 0, failed: 0, byType: {} };
    }
    const total = parseNumber(row.total, 0);
    calendar[dayKey].total += total;
    if (row.status === "pending" || row.status === "processing") {
      calendar[dayKey].pending += total;
    } else if (row.status === "sent") {
      calendar[dayKey].sent += total;
    } else if (row.status === "failed") {
      calendar[dayKey].failed += total;
    }
    calendar[dayKey].byType[String(row.notification_type)] = (calendar[dayKey].byType[String(row.notification_type)] || 0) + total;
  }
  return calendar;
}
async function reorganizeOwnerWorkspaceAgenda(ownerUserId) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const config = await getOwnerWorkspaceConfig(ownerUserId);
  const managedUsers = await getManagedUsers(ownerUserId);
  const now = /* @__PURE__ */ new Date();
  const horizonEnd = new Date(now.getTime() + OWNER_HORIZON_DAYS * 24 * 60 * 60 * 1e3);
  let catchupIndex = 0;
  await db.execute(sql3`
    DELETE FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND status IN ('pending', 'processing')
  `);
  const sentResult = await db.execute(sql3`
    SELECT user_id, notification_type, metadata, status, created_at
    FROM owner_notification_logs
    WHERE owner_user_id = ${ownerUserId}
      AND created_at >= NOW() - INTERVAL '45 days'
  `);
  const lastCheckinSent = /* @__PURE__ */ new Map();
  const sentKeys = /* @__PURE__ */ new Set();
  for (const row of sentResult.rows) {
    const metadata = parseJsonField(row.metadata, {});
    if (row.user_id && shouldUseOwnerLogForDedupe(String(row.status || ""))) {
      sentKeys.add(buildNotificationKey(String(row.user_id), String(row.notification_type), metadata));
    }
    if (row.user_id && (row.notification_type === "checkin" || row.notification_type === "periodic_checkin")) {
      const createdAt = parseDate(row.created_at);
      if (createdAt) {
        const current = lastCheckinSent.get(String(row.user_id));
        if (!current || createdAt > current) {
          lastCheckinSent.set(String(row.user_id), createdAt);
        }
      }
    }
  }
  let created = 0;
  const activeBillingPhones = new Set(
    managedUsers.filter((user) => isManagedUserCurrentlyActive(user, now)).map((user) => normalizePhone2(user.phone)).filter(Boolean)
  );
  for (const user of managedUsers) {
    const phone = normalizePhone2(user.phone);
    if (!phone) continue;
    const recipientName = String(user.name || user.email || phone).trim() || "Cliente";
    const dueDate = getManagedUserDueDate(user);
    const hasActivePlan = isManagedUserCurrentlyActive(user, now);
    const hasActivePlanForSamePhone = activeBillingPhones.has(phone);
    const hasOverdueBilling = isManagedUserBillingOverdue(user, now);
    const cancellationRequested = isManagedUserCancellationRequested(user);
    if (!cancellationRequested && hasActivePlan && config.paymentReminderEnabled && dueDate) {
      let insertedFuturePayment = false;
      const missedPaymentCandidates = [];
      const billingAmount = getManagedUserBillingAmount(user);
      const billingAmountText = billingAmount > 0 ? billingAmount.toFixed(2) : "";
      const billingAmountFormatted = billingAmount > 0 ? formatAmountForMessage(billingAmount) : "";
      for (const daysBefore of [...config.paymentReminderDaysBefore].sort((a, b) => b - a)) {
        const candidate = new Date(dueDate);
        candidate.setDate(candidate.getDate() - daysBefore);
        const scheduledFor = coerceToBusinessSlot(candidate, config, `${user.id}:payment:${daysBefore}`);
        const metadata = {
          daysBefore,
          dueDate: dueDate.toISOString(),
          billingCycleDate: dueDate.toISOString().slice(0, 10),
          valor: billingAmountText,
          valorFormatado: billingAmountFormatted,
          couponPrice: user.coupon_price ?? "",
          planBaseValor: user.plan_valor ?? "",
          planName: user.plan_nome ?? "",
          subscriptionId: user.subscription_id ?? "",
          subscriptionStatus: user.subscription_status ?? "",
          billingKind: "active_renewal"
        };
        const key = buildNotificationKey(user.id, "payment_reminder", metadata);
        if (sentKeys.has(key)) {
          continue;
        }
        if (scheduledFor.getTime() < now.getTime()) {
          missedPaymentCandidates.push({ daysBefore, scheduledFor, metadata, key });
          continue;
        }
        if (!isWithinOwnerHorizon(scheduledFor, horizonEnd)) continue;
        await insertScheduledNotification({
          ownerUserId,
          userId: user.id,
          type: "payment_reminder",
          phone,
          name: recipientName,
          template: config.paymentReminderMessageTemplate,
          aiPrompt: config.paymentReminderAiPrompt,
          aiEnabled: config.paymentReminderAiEnabled,
          metadata,
          scheduledFor
        });
        created += 1;
        insertedFuturePayment = true;
        sentKeys.add(key);
      }
      if (!insertedFuturePayment && missedPaymentCandidates.length > 0) {
        const selected = missedPaymentCandidates.sort((a, b) => a.daysBefore - b.daysBefore)[0];
        const scheduledFor = rebaseMissedOwnerNotification(
          selected.scheduledFor,
          config,
          `${user.id}:payment:${selected.daysBefore}`,
          catchupIndex++,
          now
        );
        if (isWithinOwnerHorizon(scheduledFor, horizonEnd)) {
          await insertScheduledNotification({
            ownerUserId,
            userId: user.id,
            type: "payment_reminder",
            phone,
            name: recipientName,
            template: config.paymentReminderMessageTemplate,
            aiPrompt: config.paymentReminderAiPrompt,
            aiEnabled: config.paymentReminderAiEnabled,
            metadata: {
              ...selected.metadata,
              catchup: true,
              originalScheduledFor: selected.scheduledFor.toISOString()
            },
            scheduledFor
          });
          created += 1;
          sentKeys.add(selected.key);
        }
      }
    }
    if (!cancellationRequested && !hasActivePlanForSamePhone && hasOverdueBilling && config.overdueReminderEnabled && dueDate) {
      const isRecentOverdue = dueDate.getTime() >= now.getTime() - OWNER_STALE_OVERDUE_NOTIFICATION_MS;
      let insertedFutureOverdue = false;
      const missedOverdueCandidates = [];
      const billingAmount = getManagedUserBillingAmount(user);
      const billingAmountText = billingAmount > 0 ? billingAmount.toFixed(2) : "";
      const billingAmountFormatted = billingAmount > 0 ? formatAmountForMessage(billingAmount) : "";
      for (const daysAfter of [...config.overdueReminderDaysAfter].sort((a, b) => a - b)) {
        const candidate = new Date(dueDate);
        candidate.setDate(candidate.getDate() + daysAfter);
        const scheduledFor = coerceToBusinessSlot(candidate, config, `${user.id}:overdue:${daysAfter}`);
        const metadata = {
          daysAfter,
          dueDate: dueDate.toISOString(),
          billingCycleDate: dueDate.toISOString().slice(0, 10),
          valor: billingAmountText,
          valorFormatado: billingAmountFormatted,
          couponPrice: user.coupon_price ?? "",
          planBaseValor: user.plan_valor ?? "",
          planName: user.plan_nome ?? "",
          subscriptionId: user.subscription_id ?? "",
          subscriptionStatus: user.subscription_status ?? "",
          billingKind: user.subscription_status === "active" ? "active_overdue" : "overdue"
        };
        const key = buildNotificationKey(user.id, "overdue_reminder", metadata);
        if (sentKeys.has(key)) {
          continue;
        }
        if (scheduledFor.getTime() < now.getTime()) {
          if (isRecentOverdue) {
            missedOverdueCandidates.push({ daysAfter, scheduledFor, metadata, key });
          }
          continue;
        }
        if (!isWithinOwnerHorizon(scheduledFor, horizonEnd)) continue;
        await insertScheduledNotification({
          ownerUserId,
          userId: user.id,
          type: "overdue_reminder",
          phone,
          name: recipientName,
          template: config.overdueReminderMessageTemplate,
          aiPrompt: config.overdueReminderAiPrompt,
          aiEnabled: config.overdueReminderAiEnabled,
          metadata,
          scheduledFor
        });
        created += 1;
        insertedFutureOverdue = true;
        sentKeys.add(key);
      }
      if (!insertedFutureOverdue && missedOverdueCandidates.length > 0) {
        const selected = missedOverdueCandidates.sort((a, b) => b.daysAfter - a.daysAfter)[0];
        const scheduledFor = rebaseMissedOwnerNotification(
          selected.scheduledFor,
          config,
          `${user.id}:overdue:${selected.daysAfter}`,
          catchupIndex++,
          now
        );
        if (isWithinOwnerHorizon(scheduledFor, horizonEnd)) {
          await insertScheduledNotification({
            ownerUserId,
            userId: user.id,
            type: "overdue_reminder",
            phone,
            name: recipientName,
            template: config.overdueReminderMessageTemplate,
            aiPrompt: config.overdueReminderAiPrompt,
            aiEnabled: config.overdueReminderAiEnabled,
            metadata: {
              ...selected.metadata,
              catchup: true,
              originalScheduledFor: selected.scheduledFor.toISOString()
            },
            scheduledFor
          });
          created += 1;
          sentKeys.add(selected.key);
        }
      }
    }
    if (!cancellationRequested && config.trialLimitReachedEnabled && isTrialLimitReachedCandidate(user)) {
      const metadata = {
        kind: "trial_limit_reached",
        messageLimit: FREE_TRIAL_MESSAGE_LIMIT
      };
      const key = buildNotificationKey(user.id, "trial_limit_reached", metadata);
      const rawScheduledFor = coerceToBusinessSlot(now, config, `${user.id}:trial-limit`);
      const scheduledFor = rebaseMissedOwnerNotification(
        rawScheduledFor,
        config,
        `${user.id}:trial-limit`,
        catchupIndex++,
        now
      );
      if (isWithinOwnerHorizon(scheduledFor, horizonEnd) && !sentKeys.has(key)) {
        await insertScheduledNotification({
          ownerUserId,
          userId: user.id,
          type: "trial_limit_reached",
          phone,
          name: recipientName,
          template: config.trialLimitReachedMessageTemplate,
          aiPrompt: config.trialLimitReachedAiPrompt,
          aiEnabled: config.trialLimitReachedAiEnabled,
          metadata,
          scheduledFor
        });
        created += 1;
        sentKeys.add(key);
      }
    }
    if (!cancellationRequested && config.periodicCheckinEnabled) {
      const lastSent = lastCheckinSent.get(user.id);
      const baseDate = lastSent ? new Date(lastSent) : /* @__PURE__ */ new Date();
      const intervalDays = config.periodicCheckinMinDays + hashToOffset(user.id, Math.max(1, config.periodicCheckinMaxDays - config.periodicCheckinMinDays + 1));
      const candidate = new Date(baseDate);
      candidate.setDate(candidate.getDate() + intervalDays);
      const rawScheduledFor = coerceToBusinessSlot(candidate, config, `${user.id}:checkin:${intervalDays}`);
      const scheduledFor = rebaseMissedOwnerNotification(
        rawScheduledFor,
        config,
        `${user.id}:checkin:${intervalDays}`,
        catchupIndex++,
        now
      );
      const metadata = {
        seed: intervalDays,
        checkinCycleDate: scheduledFor.toISOString().slice(0, 10),
        ...rawScheduledFor.getTime() < now.getTime() ? { catchup: true, originalScheduledFor: rawScheduledFor.toISOString() } : {}
      };
      const key = buildNotificationKey(user.id, "periodic_checkin", metadata);
      if (isWithinOwnerHorizon(scheduledFor, horizonEnd) && !sentKeys.has(key)) {
        await insertScheduledNotification({
          ownerUserId,
          userId: user.id,
          type: "periodic_checkin",
          phone,
          name: recipientName,
          template: config.periodicCheckinMessageTemplate,
          aiPrompt: config.checkinAiPrompt,
          aiEnabled: config.checkinAiEnabled,
          metadata,
          scheduledFor
        });
        created += 1;
        sentKeys.add(key);
      }
    }
    if (!cancellationRequested && config.disconnectedAlertEnabled && !user.whatsapp_connected && user.connection_phone_number && user.connection_updated_at) {
      const disconnectedAt = parseDate(user.connection_updated_at);
      if (disconnectedAt) {
        const candidate = new Date(disconnectedAt);
        candidate.setHours(candidate.getHours() + config.disconnectedAlertHours);
        const rawScheduledFor = coerceToBusinessSlot(candidate, config, `${user.id}:disconnected`);
        if (rawScheduledFor.getTime() < now.getTime() - OWNER_STALE_DISCONNECTED_NOTIFICATION_MS) {
          continue;
        }
        const scheduledFor = rebaseMissedOwnerNotification(
          rawScheduledFor,
          config,
          `${user.id}:disconnected`,
          catchupIndex++,
          now
        );
        const metadata = {
          hoursDisconnected: config.disconnectedAlertHours,
          disconnectedSince: disconnectedAt.toISOString(),
          ...rawScheduledFor.getTime() < now.getTime() ? { catchup: true, originalScheduledFor: rawScheduledFor.toISOString() } : {}
        };
        const key = buildNotificationKey(user.id, "disconnected", metadata);
        if (isWithinOwnerHorizon(scheduledFor, horizonEnd) && !sentKeys.has(key)) {
          await insertScheduledNotification({
            ownerUserId,
            userId: user.id,
            type: "disconnected",
            phone,
            name: recipientName,
            template: config.disconnectedAlertMessageTemplate,
            aiPrompt: config.disconnectedAiPrompt,
            aiEnabled: config.disconnectedAiEnabled,
            metadata,
            scheduledFor
          });
          created += 1;
          sentKeys.add(key);
        }
      }
    }
  }
  lastOwnerAutoReorganize.set(ownerUserId, Date.now());
  return { success: true, created };
}
async function deleteOwnerScheduledNotification(ownerUserId, id) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  await db.execute(sql3`
    DELETE FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND id = ${id}
  `);
}
async function sendOwnerScheduledNotification(ownerUserId, id) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const result = await db.execute(sql3`
    SELECT *
    FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND id = ${id}
    LIMIT 1
  `);
  const row = result.rows?.[0] || void 0;
  if (!row) {
    throw new Error("Notifica\xE7\xE3o agendada n\xE3o encontrada");
  }
  return sendOwnerNotificationRow(ownerUserId, row, { regenerate: true });
}
async function resendOwnerScheduledNotification(ownerUserId, id, regenerate) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const result = await db.execute(sql3`
    SELECT *
    FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND id = ${id}
    LIMIT 1
  `);
  const row = result.rows?.[0] || void 0;
  if (!row) {
    throw new Error("Notifica\xE7\xE3o n\xE3o encontrada");
  }
  return sendOwnerNotificationRow(ownerUserId, row, { regenerate });
}
async function processOwnerWorkspaceQueue(ownerUserId, limit = 50) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const config = await getOwnerWorkspaceConfig(ownerUserId);
  await recoverOwnerFailedNotifications(ownerUserId);
  const result = await db.execute(sql3`
    WITH due AS (
      SELECT id
      FROM owner_scheduled_notifications
      WHERE owner_user_id = ${ownerUserId}
        AND status = 'pending'
        AND scheduled_for <= NOW()
      ORDER BY scheduled_for ASC
      LIMIT ${limit}
    )
    UPDATE owner_scheduled_notifications osn
    SET status = 'processing', updated_at = NOW()
    FROM due
    WHERE osn.id = due.id
    RETURNING osn.*
  `);
  const rows = result.rows || [];
  let processed = 0;
  let failed = 0;
  let requeued = 0;
  for (let index = 0; index < rows.length; index += 1) {
    try {
      const sent = await sendOwnerNotificationRow(ownerUserId, rows[index]);
      if (sent.success) {
        processed += 1;
      } else {
        requeued += 1;
      }
    } catch (error) {
      requeued += 1;
      const recovery = buildOwnerDeliveryDecision(rows[index], {
        success: false,
        reason: error?.message || "Erro ao processar a fila"
      });
      await db.execute(sql3`
        UPDATE owner_scheduled_notifications
        SET
          status = ${recovery.status},
          error_message = ${recovery.errorMessage},
          retry_count = ${recovery.retryCount},
          scheduled_for = ${recovery.nextAttemptAt || rows[index].scheduled_for},
          updated_at = NOW()
        WHERE id = ${rows[index].id}
      `);
      await createOwnerNotificationLog({
        ownerUserId,
        userId: rows[index].user_id,
        notificationType: rows[index].notification_type,
        recipientPhone: rows[index].recipient_phone,
        recipientName: String(rows[index].recipient_name || "Cliente").trim() || "Cliente",
        messageOriginal: rows[index].message_template,
        messageSent: rows[index].final_message || rows[index].message_template,
        status: "failed",
        metadata: parseJsonField(rows[index].metadata, {}),
        errorMessage: recovery.errorMessage
      });
    }
    const isLast = index === rows.length - 1;
    if (!isLast && config.broadcastAntibotVariation) {
      const processedInBatch = index + 1;
      if (processedInBatch % OWNER_QUEUE_BATCH_SIZE === 0) {
        await sleepRange2(OWNER_QUEUE_BATCH_PAUSE_MIN_SECONDS, OWNER_QUEUE_BATCH_PAUSE_MAX_SECONDS);
        continue;
      }
      await sleepRange2(config.broadcastMinIntervalSeconds, config.broadcastMaxIntervalSeconds);
    }
  }
  return {
    success: true,
    total: rows.length,
    processed,
    failed,
    requeued,
    minDelay: config.broadcastMinIntervalSeconds,
    maxDelay: config.broadcastMaxIntervalSeconds,
    batchSize: OWNER_QUEUE_BATCH_SIZE,
    batchPauseMinSeconds: OWNER_QUEUE_BATCH_PAUSE_MIN_SECONDS,
    batchPauseMaxSeconds: OWNER_QUEUE_BATCH_PAUSE_MAX_SECONDS
  };
}
async function getOwnerWorkspaceQueueStatus(ownerUserId) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const breakdownResult = await db.execute(sql3`
    SELECT status, notification_type, COUNT(*) AS count
    FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
    GROUP BY status, notification_type
  `);
  const pendingNowResult = await db.execute(sql3`
    SELECT COUNT(*) AS count
    FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND status = 'pending'
      AND scheduled_for <= NOW()
  `);
  const nextResult = await db.execute(sql3`
    SELECT *
    FROM owner_scheduled_notifications
    WHERE owner_user_id = ${ownerUserId}
      AND status = 'pending'
    ORDER BY scheduled_for ASC
    LIMIT 5
  `);
  return {
    breakdown: breakdownResult.rows || [],
    pendingNow: parseNumber(pendingNowResult.rows?.[0]?.count, 0),
    nextInQueue: nextResult.rows || []
  };
}
function mapCampaignStatus(status) {
  switch (status) {
    case "pending":
      return "scheduled";
    case "running":
      return "sending";
    case "completed":
      return "completed";
    case "cancelled":
      return "cancelled";
    case "error":
      return "cancelled";
    default:
      return "scheduled";
  }
}
async function listOwnerWorkspaceBroadcasts(ownerUserId) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const campaignRows = await db.select().from(broadcastCampaigns).where(eq3(broadcastCampaigns.userId, ownerUserId)).orderBy(desc2(broadcastCampaigns.createdAt));
  const archiveRows = await db.execute(sql3`
    SELECT *
    FROM owner_broadcast_archives
    WHERE owner_user_id = ${ownerUserId}
    ORDER BY created_at DESC
  `);
  const campaigns = campaignRows.map((row) => ({
    id: row.id,
    name: row.name,
    messageTemplate: row.messageTemplate,
    targetType: String(row.metadataJson?.targetType || "all"),
    targetFilter: row.metadataJson || {},
    aiVariation: Boolean(row.useAi),
    antibotEnabled: true,
    status: mapCampaignStatus(String(row.status)),
    scheduledAt: row.scheduledAt,
    totalRecipients: row.totalContacts ?? 0,
    sentCount: row.sentCount ?? 0,
    failedCount: row.failedCount ?? 0,
    createdAt: row.createdAt,
    source: "owner"
  }));
  const archives = (archiveRows.rows || []).map((row) => ({
    id: row.id,
    name: row.name,
    messageTemplate: row.message_template,
    targetType: row.target_type || "all",
    targetFilter: parseJsonField(row.target_filter, {}),
    aiVariation: Boolean(row.ai_variation),
    antibotEnabled: row.antibot_enabled !== false,
    status: row.status || "completed",
    scheduledAt: row.scheduled_at,
    totalRecipients: parseNumber(row.total_recipients, 0),
    sentCount: parseNumber(row.sent_count, 0),
    failedCount: parseNumber(row.failed_count, 0),
    createdAt: row.created_at,
    source: "legacy_admin_archive"
  }));
  return [...campaigns, ...archives].sort((a, b) => {
    const timeA = parseDate(a.createdAt)?.getTime() || 0;
    const timeB = parseDate(b.createdAt)?.getTime() || 0;
    return timeB - timeA;
  });
}
async function buildOwnerBroadcastRecipients(ownerUserId, targetType) {
  const users2 = await getManagedUsers(ownerUserId);
  const filtered = users2.filter((user) => {
    if (!normalizePhone2(user.phone)) return false;
    if (targetType === "with_plan") return isManagedUserCurrentlyActive(user);
    if (targetType === "without_plan") return !isManagedUserCurrentlyActive(user);
    return true;
  });
  return filtered.map((user) => ({
    id: user.id,
    phone: normalizePhone2(user.phone),
    name: user.name || user.email || "Cliente"
  }));
}
async function createAndStartOwnerBroadcast(ownerUserId, payload) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const config = await getOwnerWorkspaceConfig(ownerUserId);
  const connection = await storage.getUserActiveConnection(ownerUserId);
  if (!connection?.id) {
    throw new Error("A conex\xE3o principal do propriet\xE1rio n\xE3o est\xE1 conectada");
  }
  const contacts = await buildOwnerBroadcastRecipients(ownerUserId, payload.targetType);
  const result = await createAndRunCampaign(ownerUserId, {
    contacts,
    connectionId: connection.id,
    messageTemplate: payload.messageTemplate,
    name: payload.name,
    useAi: payload.aiVariation === true && config.broadcastAiVariation === true,
    delayMinMs: config.broadcastMinIntervalSeconds * 1e3,
    delayMaxMs: config.broadcastMaxIntervalSeconds * 1e3,
    scheduledAt: payload.scheduledAt || null,
    campaignType: "owner_workspace_broadcast",
    metadataJson: {
      origin: "owner_workspace",
      targetType: payload.targetType,
      antibotEnabled: payload.antibotEnabled !== false
    }
  });
  return {
    success: true,
    id: result.campaignId,
    scheduled: result.scheduled,
    total: result.total,
    status: result.status
  };
}
async function cancelOwnerBroadcast(ownerUserId, broadcastId) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const campaign = await getCampaignStatus(broadcastId, ownerUserId);
  if (campaign) {
    return cancelCampaign(broadcastId, ownerUserId);
  }
  await db.execute(sql3`
    UPDATE owner_broadcast_archives
    SET
      status = 'cancelled',
      updated_at = NOW(),
      completed_at = COALESCE(completed_at, NOW())
    WHERE owner_user_id = ${ownerUserId}
      AND id = ${broadcastId}
  `);
  return true;
}
async function getOwnerBroadcastMessages(ownerUserId, broadcastId) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const campaign = await getCampaignStatus(broadcastId, ownerUserId);
  if (campaign) {
    const results = Array.isArray(campaign.resultsJson) ? campaign.resultsJson : [];
    return results.map((row) => ({
      id: row.contactId || `${broadcastId}:${row.phone}`,
      recipient_name: row.name || "Cliente",
      recipient_phone: row.phone,
      message_original: row.message,
      message_sent: row.message,
      status: row.status,
      error_message: row.error || null,
      sent_at: row.sentAt || null
    }));
  }
  const archiveRows = await db.execute(sql3`
    SELECT *
    FROM owner_broadcast_archive_messages
    WHERE owner_user_id = ${ownerUserId}
      AND archive_id = ${broadcastId}
    ORDER BY sent_at DESC
  `);
  return archiveRows.rows || [];
}
async function sendOwnerWorkspaceWelcomeMessage(ownerUserId, userPhone) {
  await ensureOwnerWorkspaceReady(ownerUserId);
  const config = await getOwnerWorkspaceConfig(ownerUserId);
  if (!config.welcomeMessageEnabled || config.welcomeMessageVariations.length === 0) {
    return false;
  }
  const connection = await storage.getUserActiveConnection(ownerUserId);
  if (!connection?.id) {
    return false;
  }
  const randomIndex = Math.floor(Math.random() * config.welcomeMessageVariations.length);
  const recipientName = await resolveOwnerRecipientName(ownerUserId, userPhone);
  let message = buildMessageFromTemplate(
    config.welcomeMessageVariations[randomIndex] || "",
    recipientName,
    {}
  ).trim();
  if (config.welcomeMessageAiEnabled && config.welcomeMessageAiPrompt) {
    try {
      message = await applyAIVariation(message, config.welcomeMessageAiPrompt, recipientName);
      message = buildMessageFromTemplate(message, recipientName, {}).trim();
    } catch (error) {
      console.error("[OWNER WORKSPACE] Falha ao variar boas-vindas com IA:", error);
    }
  }
  const conversation = await ensureOwnerConversation(ownerUserId, userPhone, recipientName);
  const result = await sendMessage(ownerUserId, conversation.id, message, { source: "system" });
  return result.success === true && !result.blocked;
}
async function sendPrimaryOwnerWorkspaceWelcomeMessage(userPhone) {
  const ownerUser = await getPrimaryOwnerWorkspaceUser();
  if (!ownerUser?.id || normalizeEmail2(ownerUser.email) !== OWNER_ALLOWED_EMAIL) {
    return false;
  }
  return sendOwnerWorkspaceWelcomeMessage(ownerUser.id, userPhone);
}
async function processAllOwnerWorkspaces() {
  const owners = await getOwnerWorkspaceUsers();
  for (const owner of owners) {
    if (!owner?.id) continue;
    try {
      await ensureOwnerWorkspaceReady(owner.id);
      const lastRun = lastOwnerAutoReorganize.get(owner.id) || 0;
      if (Date.now() - lastRun >= OWNER_AUTO_REORGANIZE_INTERVAL_MS) {
        await reorganizeOwnerWorkspaceAgenda(owner.id);
      }
      await processOwnerWorkspaceQueue(owner.id, 50);
    } catch (error) {
      console.error(`[OWNER WORKSPACE] Falha ao processar scheduler do owner ${owner.id}:`, error);
    }
  }
}
function startOwnerWorkspaceScheduler() {
  if (ownerSchedulerInterval) {
    return;
  }
  void processAllOwnerWorkspaces().catch((error) => {
    console.error("[OWNER WORKSPACE] Falha no processamento inicial:", error);
  });
  ownerSchedulerInterval = setInterval(() => {
    void processAllOwnerWorkspaces().catch((error) => {
      console.error("[OWNER WORKSPACE] Falha no loop do scheduler:", error);
    });
  }, OWNER_NOTIFICATION_INTERVAL_MS);
}
function stopOwnerWorkspaceScheduler() {
  if (!ownerSchedulerInterval) {
    return;
  }
  clearInterval(ownerSchedulerInterval);
  ownerSchedulerInterval = null;
}

export {
  createAndRunCampaign,
  getCampaignStatus,
  cancelCampaign,
  startBroadcastCampaignRun,
  runBroadcastCampaignRecoveryOnce,
  canUserAccessOwnerWorkspace,
  ensureOwnerWorkspaceReady,
  syncOwnerWorkspaceForLegacyAdmin,
  getOwnerWorkspaceConfig,
  updateOwnerWorkspaceConfig,
  getOwnerWorkspaceStats,
  getOwnerWorkspaceHistory,
  getOwnerWorkspaceScheduled,
  getOwnerWorkspaceCalendar,
  reorganizeOwnerWorkspaceAgenda,
  deleteOwnerScheduledNotification,
  sendOwnerScheduledNotification,
  resendOwnerScheduledNotification,
  processOwnerWorkspaceQueue,
  getOwnerWorkspaceQueueStatus,
  listOwnerWorkspaceBroadcasts,
  createAndStartOwnerBroadcast,
  cancelOwnerBroadcast,
  getOwnerBroadcastMessages,
  sendOwnerWorkspaceWelcomeMessage,
  sendPrimaryOwnerWorkspaceWelcomeMessage,
  processAllOwnerWorkspaces,
  startOwnerWorkspaceScheduler,
  stopOwnerWorkspaceScheduler
};
