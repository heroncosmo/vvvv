import {
  LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG,
  getAdminFollowupGlobalConfig,
  isLegacyAdminFollowupConfig,
  normalizeAdminFollowupConfig,
  shouldAutoRescheduleAdminFollowup
} from "./chunk-XZFDVJYL.js";
import {
  getLLMClient
} from "./chunk-M7TXNZTC.js";
import {
  db
} from "./chunk-R6CXRQMB.js";
import {
  adminConversations,
  adminMessages,
  admins,
  conversations,
  followupLogs,
  users,
  whatsappConnections
} from "./chunk-JC6URYU5.js";

// server/followUpService.ts
import { eq as eq2, and as and2, lte, isNull } from "drizzle-orm";

// server/followupPriorityService.ts
import { and, desc, eq, sql } from "drizzle-orm";
var FOLLOWUP_PRIORITY_EMAIL = "rodrigo4@gmail.com";
var cachedPriorityUserId;
var cachedPriorityAdminId;
function normalizePriorityPhoneDigits(value) {
  if (!value) return "";
  let normalized = "";
  for (const char of value) {
    if (char >= "0" && char <= "9") {
      normalized += char;
    }
  }
  return normalized;
}
async function getFollowupPriorityUserId() {
  if (cachedPriorityUserId !== void 0) {
    return cachedPriorityUserId;
  }
  const [user] = await db.select({ id: users.id }).from(users).where(eq(users.email, FOLLOWUP_PRIORITY_EMAIL)).limit(1);
  cachedPriorityUserId = user?.id ?? null;
  return cachedPriorityUserId;
}
async function getFollowupPriorityAdminId() {
  if (cachedPriorityAdminId !== void 0) {
    return cachedPriorityAdminId;
  }
  const [admin] = await db.select({ id: admins.id }).from(admins).where(eq(admins.email, FOLLOWUP_PRIORITY_EMAIL)).limit(1);
  cachedPriorityAdminId = admin?.id ?? null;
  return cachedPriorityAdminId;
}
function buildAdminPriorityConflictReason(keepConversationId) {
  return `priority_followup_claimed:${FOLLOWUP_PRIORITY_EMAIL}:admin:${keepConversationId}`;
}
function buildUserPriorityConflictReason(keepConversationId) {
  return `priority_followup_claimed:${FOLLOWUP_PRIORITY_EMAIL}:user:${keepConversationId}`;
}
function rankPriorityUserConversation(conversation, connection) {
  return Number(conversation.followupActive === true) * 1e6 + (conversation.nextFollowupAt ? 1e4 : 0) + Math.max(0, Number(conversation.followupStage || 0)) * 100 + Number(connection?.isConnected === true) * 10 + new Date(
    conversation.lastMessageTime || conversation.updatedAt || conversation.createdAt || /* @__PURE__ */ new Date(0)
  ).getTime();
}
async function listPriorityUserConversations(limit = 5e3, options) {
  const priorityUserId = await getFollowupPriorityUserId();
  if (!priorityUserId) {
    return [];
  }
  const rows = await db.select({
    conversation: conversations,
    connection: whatsappConnections
  }).from(conversations).innerJoin(whatsappConnections, eq(whatsappConnections.id, conversations.connectionId)).where(
    and(
      eq(whatsappConnections.userId, priorityUserId),
      options?.activeOnly ? eq(conversations.followupActive, true) : sql`true`
    )
  ).orderBy(desc(conversations.lastMessageTime), desc(conversations.createdAt)).limit(limit);
  return rows.map((row) => ({
    ...row.conversation,
    connection: row.connection
  }));
}
async function mapPriorityUserConversationsByContact(limit = 5e3, options) {
  const conversationsByPhone = /* @__PURE__ */ new Map();
  const candidates = await listPriorityUserConversations(limit, options);
  for (const candidate of candidates) {
    const normalizedPhone = normalizePriorityPhoneDigits(candidate.contactNumber);
    if (!normalizedPhone) {
      continue;
    }
    const currentBest = conversationsByPhone.get(normalizedPhone);
    if (!currentBest) {
      conversationsByPhone.set(normalizedPhone, candidate);
      continue;
    }
    if (rankPriorityUserConversation(candidate, candidate.connection) > rankPriorityUserConversation(currentBest, currentBest.connection)) {
      conversationsByPhone.set(normalizedPhone, candidate);
    }
  }
  return conversationsByPhone;
}
async function findPriorityUserConversationByContact(contactNumber, excludeConversationId, options) {
  const priorityUserId = await getFollowupPriorityUserId();
  if (!priorityUserId) {
    return null;
  }
  const normalizedTarget = normalizePriorityPhoneDigits(contactNumber);
  if (!normalizedTarget) {
    return null;
  }
  const exactCandidates = await db.query.conversations.findMany({
    where: eq(conversations.contactNumber, contactNumber),
    with: {
      connection: true
    },
    orderBy: (table, { desc: orderDesc }) => [orderDesc(table.lastMessageTime), orderDesc(table.createdAt)],
    limit: 200
  });
  const exactMatches = exactCandidates.filter((candidate) => {
    if (candidate.connection?.userId !== priorityUserId) {
      return false;
    }
    if (excludeConversationId && candidate.id === excludeConversationId) {
      return false;
    }
    if (options?.activeOnly && candidate.followupActive !== true) {
      return false;
    }
    return normalizePriorityPhoneDigits(candidate.contactNumber) === normalizedTarget;
  });
  if (exactMatches.length > 0) {
    exactMatches.sort((left, right) => {
      return rankPriorityUserConversation(right, right.connection) - rankPriorityUserConversation(left, left.connection);
    });
    return exactMatches[0];
  }
  const candidates = await listPriorityUserConversations(5e4, options);
  const matches = candidates.filter((candidate) => {
    if (excludeConversationId && candidate.id === excludeConversationId) {
      return false;
    }
    return normalizePriorityPhoneDigits(candidate.contactNumber) === normalizedTarget;
  });
  if (matches.length === 0) {
    return null;
  }
  matches.sort((left, right) => {
    return rankPriorityUserConversation(right, right.connection) - rankPriorityUserConversation(left, left.connection);
  });
  return matches[0];
}
async function findActiveAdminFollowupsByContact(contactNumber, excludeConversationId) {
  const normalizedTarget = normalizePriorityPhoneDigits(contactNumber);
  if (!normalizedTarget) {
    return [];
  }
  const candidates = await db.query.adminConversations.findMany({
    where: eq(adminConversations.followupActive, true),
    orderBy: (table, { desc: orderDesc }) => [orderDesc(table.lastMessageTime), orderDesc(table.createdAt)],
    limit: 5e3
  });
  return candidates.filter((candidate) => {
    if (excludeConversationId && candidate.id === excludeConversationId) {
      return false;
    }
    return normalizePriorityPhoneDigits(candidate.contactNumber) === normalizedTarget;
  });
}
async function disableAdminFollowupsForPriorityUser(contactNumber, keepConversationId, excludeConversationId) {
  const reason = buildUserPriorityConflictReason(keepConversationId);
  const conflicts = await findActiveAdminFollowupsByContact(contactNumber, excludeConversationId);
  let disabled = 0;
  for (const conflict of conflicts) {
    await db.update(adminConversations).set({
      followupActive: false,
      nextFollowupAt: null,
      followupDisabledReason: reason,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(adminConversations.id, conflict.id));
    disabled += 1;
  }
  return { disabled, reason };
}

// server/followUpService.ts
function getEffectiveConversationConfig(conversation, globalConfig) {
  const normalizedGlobal = normalizeAdminFollowupConfig(globalConfig);
  const currentConversationConfig = conversation.followupConfig || null;
  if (!currentConversationConfig || isLegacyAdminFollowupConfig(currentConversationConfig)) {
    return normalizedGlobal;
  }
  return normalizeAdminFollowupConfig({
    ...normalizedGlobal,
    ...currentConversationConfig
  });
}
var SAO_PAULO_UTC_OFFSET_MINUTES = -3 * 60;
function getSaoPauloParts(reference) {
  const localMs = reference.getTime() + SAO_PAULO_UTC_OFFSET_MINUTES * 60 * 1e3;
  const localDate = new Date(localMs);
  return {
    year: localDate.getUTCFullYear(),
    month: localDate.getUTCMonth(),
    day: localDate.getUTCDate(),
    weekday: localDate.getUTCDay(),
    hours: localDate.getUTCHours(),
    minutes: localDate.getUTCMinutes()
  };
}
function buildUtcFromSaoPauloParts(year, month, day, hours, minutes) {
  return new Date(
    Date.UTC(year, month, day, hours, minutes) - SAO_PAULO_UTC_OFFSET_MINUTES * 60 * 1e3
  );
}
function getMinutesOfDay(timeValue, fallbackHours, fallbackMinutes) {
  if (!timeValue || typeof timeValue !== "string") {
    return fallbackHours * 60 + fallbackMinutes;
  }
  const [rawHours, rawMinutes] = timeValue.split(":");
  const hours = Number(rawHours);
  const minutes = Number(rawMinutes);
  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) {
    return fallbackHours * 60 + fallbackMinutes;
  }
  return Math.max(0, Math.min(23, hours)) * 60 + Math.max(0, Math.min(59, minutes));
}
function isWithinBusinessHours(config, reference = /* @__PURE__ */ new Date()) {
  const normalized = normalizeAdminFollowupConfig(config);
  if (normalized.respectBusinessHours === false) return true;
  const parts = getSaoPauloParts(reference);
  const currentMinutes = parts.hours * 60 + parts.minutes;
  const businessStart = getMinutesOfDay(normalized.businessHoursStart, 9, 0);
  const businessEnd = getMinutesOfDay(normalized.businessHoursEnd, 18, 0);
  return normalized.businessDays.includes(parts.weekday) && currentMinutes >= businessStart && currentMinutes < businessEnd;
}
function getNextBusinessTime(config, reference = /* @__PURE__ */ new Date()) {
  const normalized = normalizeAdminFollowupConfig(config);
  if (normalized.respectBusinessHours === false) return reference;
  const businessStart = getMinutesOfDay(normalized.businessHoursStart, 9, 0);
  for (let dayOffset = 0; dayOffset < 8; dayOffset += 1) {
    const candidateUtc = new Date(reference.getTime() + dayOffset * 24 * 60 * 60 * 1e3);
    const candidateParts = getSaoPauloParts(candidateUtc);
    if (!normalized.businessDays.includes(candidateParts.weekday)) {
      continue;
    }
    if (dayOffset === 0) {
      const currentMinutes = candidateParts.hours * 60 + candidateParts.minutes;
      if (currentMinutes < businessStart) {
        return buildUtcFromSaoPauloParts(
          candidateParts.year,
          candidateParts.month,
          candidateParts.day,
          Math.floor(businessStart / 60),
          businessStart % 60
        );
      }
      if (isWithinBusinessHours(normalized, reference)) {
        return reference;
      }
    }
    return buildUtcFromSaoPauloParts(
      candidateParts.year,
      candidateParts.month,
      candidateParts.day,
      Math.floor(businessStart / 60),
      businessStart % 60
    );
  }
  return reference;
}
function alignToBusinessHours(candidate, config) {
  if (isWithinBusinessHours(config, candidate)) {
    return candidate;
  }
  return getNextBusinessTime(config, candidate);
}
function isValidDate(value) {
  return value instanceof Date && Number.isFinite(value.getTime());
}
function buildDelayDateFromNow(delayMinutes) {
  if (!Number.isFinite(delayMinutes) || delayMinutes <= 0) {
    return null;
  }
  const candidate = new Date(Date.now() + delayMinutes * 60 * 1e3);
  return isValidDate(candidate) ? candidate : null;
}
function normalizePhoneDigits(value) {
  return normalizePriorityPhoneDigits(value);
}
function extractFirstJsonObject(rawContent) {
  if (!rawContent || typeof rawContent !== "string") {
    return null;
  }
  const content = rawContent.trim();
  const start = content.indexOf("{");
  if (start < 0) {
    return null;
  }
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < content.length; index += 1) {
    const char = content[index];
    if (inString) {
      if (escaped) {
        escaped = false;
        continue;
      }
      if (char === "\\") {
        escaped = true;
        continue;
      }
      if (char === '"') {
        inString = false;
      }
      continue;
    }
    if (char === '"') {
      inString = true;
      continue;
    }
    if (char === "{") {
      depth += 1;
      continue;
    }
    if (char === "}") {
      depth -= 1;
      if (depth === 0) {
        return content.slice(start, index + 1);
      }
    }
  }
  return null;
}
var FollowUpService = class {
  constructor() {
    this.checkInterval = null;
    this.isRunning = false;
    // Prevent overlapping cycles (timer overlap can spam leads)
    this.isProcessingCycle = false;
    this.onFollowUpReady = null;
    this.onScheduledContactReady = null;
  }
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    console.log("\u{1F680} [FOLLOW-UP] Servi\xE7o iniciado");
    this.checkInterval = setInterval(() => this.processFollowUps(), 5 * 60 * 1e3);
    setTimeout(async () => {
      await this.repairMissingSchedules();
      await this.processFollowUps();
    }, 30 * 1e3);
  }
  stop() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    this.isRunning = false;
    console.log("\u{1F6D1} [FOLLOW-UP] Servi\xE7o parado");
  }
  registerFollowUpCallback(callback) {
    this.onFollowUpReady = callback;
    console.log("\u{1F4F2} [FOLLOW-UP] Callback registrado");
  }
  registerScheduledContactCallback(callback) {
    this.onScheduledContactReady = callback;
    console.log("\u{1F4F2} [AGENDAMENTO] Callback registrado");
  }
  async getPriorityAdminId() {
    return getFollowupPriorityAdminId();
  }
  async setPriorityBlocked(conversationId, blockedReason) {
    await db.update(adminConversations).set({
      followupActive: false,
      nextFollowupAt: null,
      followupDisabledReason: blockedReason,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq2(adminConversations.id, conversationId));
  }
  rankPriorityOwner(conversation) {
    return (conversation.nextFollowupAt ? 1e4 : 0) + Math.max(0, Number(conversation.followupStage || 0)) * 100 + new Date(
      conversation.lastMessageTime || conversation.updatedAt || conversation.createdAt || /* @__PURE__ */ new Date(0)
    ).getTime();
  }
  async getActiveFollowupConflicts(contactNumber, excludeConversationId) {
    const normalizedTarget = normalizePhoneDigits(contactNumber);
    if (!normalizedTarget) {
      return [];
    }
    const candidates = await db.query.adminConversations.findMany({
      where: eq2(adminConversations.followupActive, true),
      orderBy: (table, { desc: desc2 }) => [desc2(table.lastMessageTime), desc2(table.createdAt)],
      limit: 5e3
    });
    return candidates.filter((candidate) => {
      if (excludeConversationId && candidate.id === excludeConversationId) {
        return false;
      }
      return normalizePhoneDigits(candidate.contactNumber) === normalizedTarget;
    });
  }
  async enforcePriorityForConversation(conversation) {
    const priorityUserConversation = await findPriorityUserConversationByContact(conversation.contactNumber);
    if (priorityUserConversation) {
      const blockedReason = buildUserPriorityConflictReason(priorityUserConversation.id);
      await this.setPriorityBlocked(conversation.id, blockedReason);
      return {
        allowed: false,
        keepConversationId: priorityUserConversation.id,
        blockedReason,
        ownerType: "user"
      };
    }
    const priorityAdminId = await this.getPriorityAdminId();
    if (!priorityAdminId) {
      return { allowed: true };
    }
    const conflicts = await this.getActiveFollowupConflicts(conversation.contactNumber, conversation.id);
    if (conflicts.length === 0) {
      return { allowed: true };
    }
    const priorityConflicts = conflicts.filter((candidate) => candidate.adminId === priorityAdminId);
    if (conversation.adminId !== priorityAdminId) {
      const keepConversation = priorityConflicts.sort((left, right) => this.rankPriorityOwner(right) - this.rankPriorityOwner(left))[0];
      if (keepConversation) {
        const blockedReason = buildAdminPriorityConflictReason(keepConversation.id);
        await this.setPriorityBlocked(conversation.id, blockedReason);
        return { allowed: false, keepConversationId: keepConversation.id, blockedReason, ownerType: "admin" };
      }
      return { allowed: true };
    }
    for (const conflict of conflicts) {
      if (conflict.adminId === priorityAdminId) {
        continue;
      }
      await this.setPriorityBlocked(conflict.id, buildAdminPriorityConflictReason(conversation.id));
    }
    return { allowed: true };
  }
  async findPreferredConversationByPhone(phoneNumber) {
    const normalizedTarget = normalizePhoneDigits(phoneNumber);
    if (!normalizedTarget) {
      return null;
    }
    const priorityAdminId = await this.getPriorityAdminId();
    const candidates = await db.query.adminConversations.findMany({
      orderBy: (table, { desc: desc2 }) => [desc2(table.lastMessageTime), desc2(table.createdAt)],
      limit: 5e3
    });
    const matches = candidates.filter((candidate) => normalizePhoneDigits(candidate.contactNumber) === normalizedTarget);
    if (matches.length === 0) {
      return null;
    }
    matches.sort((left, right) => {
      const priorityDelta = Number(right.adminId === priorityAdminId) - Number(left.adminId === priorityAdminId);
      if (priorityDelta !== 0) {
        return priorityDelta;
      }
      return this.rankPriorityOwner(right) - this.rankPriorityOwner(left);
    });
    return matches[0];
  }
  async reconcilePriorityConflicts(limit = 5e3, adminId) {
    const conversations2 = await db.query.adminConversations.findMany({
      where: eq2(adminConversations.followupActive, true),
      orderBy: (table, { desc: desc2 }) => [desc2(table.lastMessageTime), desc2(table.createdAt)],
      limit
    });
    const priorityUserConversationsByPhone = await mapPriorityUserConversationsByContact(
      Math.max(limit, 5e3),
      { activeOnly: true }
    );
    let disabledDuplicates = 0;
    const eligibleAdminConversations = [];
    for (const conversation of conversations2) {
      const normalizedPhone = normalizePhoneDigits(conversation.contactNumber);
      const priorityUserConversation = normalizedPhone ? priorityUserConversationsByPhone.get(normalizedPhone) ?? null : null;
      if (priorityUserConversation) {
        await this.setPriorityBlocked(
          conversation.id,
          buildUserPriorityConflictReason(priorityUserConversation.id)
        );
        disabledDuplicates += 1;
        continue;
      }
      eligibleAdminConversations.push(conversation);
    }
    const priorityAdminId = await this.getPriorityAdminId();
    if (!priorityAdminId) {
      return { disabledDuplicates };
    }
    const grouped = /* @__PURE__ */ new Map();
    for (const conversation of eligibleAdminConversations) {
      if (adminId && conversation.adminId !== adminId && conversation.adminId !== priorityAdminId) {
        continue;
      }
      const key = normalizePhoneDigits(conversation.contactNumber);
      if (!key) {
        continue;
      }
      const group = grouped.get(key) || [];
      group.push(conversation);
      grouped.set(key, group);
    }
    for (const group of grouped.values()) {
      const priorityGroup = group.filter((conversation) => conversation.adminId === priorityAdminId);
      if (priorityGroup.length === 0) {
        continue;
      }
      priorityGroup.sort((left, right) => this.rankPriorityOwner(right) - this.rankPriorityOwner(left));
      const keepConversationId = priorityGroup[0]?.id;
      if (!keepConversationId) {
        continue;
      }
      for (const conversation of group) {
        if (conversation.id === keepConversationId) {
          continue;
        }
        await this.setPriorityBlocked(conversation.id, buildAdminPriorityConflictReason(keepConversationId));
        disabledDuplicates += 1;
      }
    }
    return { disabledDuplicates };
  }
  /**
   * Processa conversas pendentes de follow-up
   */
  async processFollowUps() {
    if (this.isProcessingCycle) {
      console.log("\u23ED\uFE0F [FOLLOW-UP] Verifica\xE7\xE3o anterior ainda em execu\xE7\xE3o, pulando ciclo para evitar duplicatas");
      return;
    }
    this.isProcessingCycle = true;
    try {
      const globalConfig = await getAdminFollowupGlobalConfig();
      if (!globalConfig.isEnabled) {
        console.log("\u{1F6D1} [FOLLOW-UP] Follow-up global DESATIVADO na config do admin. Pulando ciclo.");
        return;
      }
      await this.reconcilePriorityConflicts();
      const now = /* @__PURE__ */ new Date();
      const pendingConversations = await db.query.adminConversations.findMany({
        where: and2(
          eq2(adminConversations.followupActive, true),
          lte(adminConversations.nextFollowupAt, now)
        )
      });
      if (pendingConversations.length > 0) {
        console.log(`\u{1F50D} [FOLLOW-UP] Encontradas ${pendingConversations.length} conversas para processar`);
      }
      for (const conv of pendingConversations) {
        await this.executeFollowUp(conv);
      }
    } catch (error) {
      console.error("\u274C [FOLLOW-UP] Erro ao processar follow-ups:", error);
    } finally {
      this.isProcessingCycle = false;
    }
  }
  /**
   * Executa a lógica de follow-up para uma conversa específica
   */
  async executeFollowUp(conversation) {
    console.log(`\u{1F449} [FOLLOW-UP] Processando ${conversation.contactNumber} (Est\xE1gio ${conversation.followupStage})`);
    try {
      const globalConfig = await getAdminFollowupGlobalConfig();
      const effectiveConfig = getEffectiveConversationConfig(conversation, globalConfig);
      const followupForNonPayers = conversation.followupForNonPayers ?? true;
      const paymentStatus = conversation.paymentStatus ?? "pending";
      if (paymentStatus === "paid") {
        console.log(`\u{1F6D1} [FOLLOW-UP] Client already paid. Skipping.`);
        await this.logFollowUp(conversation.id, conversation.contactNumber, "skipped", "Client already paid", void 0, "paid", "paid", conversation.followupStage || 0);
        await this.disableFollowUp(conversation.id, "Cliente j\xE1 pagou");
        return;
      }
      if (!globalConfig.followupNonPayersEnabled && paymentStatus === "unpaid") {
        console.log(`\u{1F6D1} [FOLLOW-UP] Follow-up para n\xE3o pagantes DESATIVADO globalmente. Pulando ${conversation.contactNumber}`);
        await this.logFollowUp(conversation.id, conversation.contactNumber, "skipped", "Follow-up n\xE3o pagantes desativado", void 0, paymentStatus, "non_payer", conversation.followupStage || 0);
        await this.scheduleNextFollowUp(conversation, 24 * 60);
        return;
      }
      if (!followupForNonPayers && (paymentStatus === "unpaid" || paymentStatus === "pending")) {
        console.log(`\u{1F6D1} [FOLLOW-UP] Follow-up para n\xE3o pagantes desativado nesta conversa. Pulando ${conversation.contactNumber}`);
        await this.logFollowUp(conversation.id, conversation.contactNumber, "skipped", "Follow-up n\xE3o pagantes desativado nesta conversa", void 0, paymentStatus, "non_payer", conversation.followupStage || 0);
        return;
      }
      try {
        const recent = await db.query.followupLogs.findFirst({
          where: and2(
            eq2(followupLogs.conversationId, conversation.id),
            eq2(followupLogs.status, "sent")
          ),
          orderBy: (logs, { desc: desc2 }) => [desc2(logs.executedAt)]
        });
        if (recent?.executedAt) {
          const ageMs = Date.now() - new Date(recent.executedAt).getTime();
          const cooldownMs = 7 * 60 * 1e3;
          if (Number.isFinite(ageMs) && ageMs >= 0 && ageMs < cooldownMs) {
            console.log(`??? [FOLLOW-UP] Cooldown ativo (${Math.round(ageMs / 1e3)}s) para ${conversation.contactNumber}, evitando spam`);
            await this.scheduleNextFollowUp(conversation, 30);
            return;
          }
        }
      } catch (cooldownErr) {
        console.warn("?? [FOLLOW-UP] Falha ao checar cooldown, continuando:", cooldownErr);
      }
      if (!conversation.followupActive) {
        console.log(`\u{1F6D1} [FOLLOW-UP] Follow-up desativado para ${conversation.contactNumber}. Cancelando.`);
        await this.disableFollowUp(conversation.id, "Follow-up desativado manualmente");
        return;
      }
      const priorityDecision = await this.enforcePriorityForConversation(conversation);
      if (!priorityDecision.allowed) {
        console.log(
          `[FOLLOW-UP] Bloqueado por prioridade de ${FOLLOWUP_PRIORITY_EMAIL} (${priorityDecision.ownerType}) para ${conversation.contactNumber}. Conversa vencedora: ${priorityDecision.keepConversationId}`
        );
        return;
      }
      if (!isWithinBusinessHours(effectiveConfig, /* @__PURE__ */ new Date())) {
        const nextBusinessTime = getNextBusinessTime(effectiveConfig, /* @__PURE__ */ new Date());
        console.log(`\xE2\x8F\xB0 [FOLLOW-UP] Fora do hor\xC3\xA1rio configurado para ${conversation.contactNumber}. Reagendando para ${nextBusinessTime.toISOString()}`);
        await db.update(adminConversations).set({ nextFollowupAt: nextBusinessTime, updatedAt: /* @__PURE__ */ new Date() }).where(eq2(adminConversations.id, conversation.id));
        return;
      }
      const decision = await this.analyzeWithAI(conversation);
      if (decision.action === "abort") {
        console.log(`\u{1F6D1} [FOLLOW-UP] Abortado pela IA para ${conversation.contactNumber}: ${decision.reason}`);
        await this.disableFollowUp(conversation.id);
        return;
      }
      if (decision.action === "wait") {
        console.log(`\u23F3 [FOLLOW-UP] IA sugeriu esperar para ${conversation.contactNumber}: ${decision.reason}`);
        await this.scheduleNextFollowUp(conversation, 24 * 60);
        return;
      }
      if (decision.action === "send") {
        if (this.onFollowUpReady) {
          console.log(`\u{1F4E4} [FOLLOW-UP] Disparando callback para ${conversation.contactNumber}`);
          const attempt = (conversation.followupStage || 0) + 1;
          const type = attempt >= effectiveConfig.intervalsMinutes.length ? "final" : "reminder";
          const result = await this.onFollowUpReady(
            conversation.contactNumber,
            decision.context || "Follow-up autom\xE1tico",
            attempt,
            type
          );
          const wasSuccessful = !!(result && typeof result === "object" && result.success);
          try {
            if (result && typeof result === "object") {
              await this.logFollowUp(conversation.id, conversation.contactNumber, result.success ? "sent" : "failed", result.message, result.error, paymentStatus, type, attempt);
            } else {
              await this.logFollowUp(conversation.id, conversation.contactNumber, "sent", "Mensagem enviada (conte\xFAdo n\xE3o capturado)", void 0, paymentStatus, type, attempt);
            }
          } catch (logError) {
            console.error("Erro ao logar follow-up:", logError);
          }
          if (wasSuccessful) {
            await this.scheduleNextFollowUp(conversation);
          } else {
            const retryDelayMinutes = effectiveConfig.intervalsMinutes[Math.max(0, conversation.followupStage || 0)] || effectiveConfig.intervalsMinutes[0] || LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG.intervalsMinutes[0];
            await this.scheduleNextFollowUp(conversation, retryDelayMinutes);
          }
        } else {
          console.warn("\u26A0\uFE0F [FOLLOW-UP] Callback n\xE3o registrado! Mensagem n\xE3o enviada.");
        }
      }
    } catch (error) {
      console.error(`\u274C [FOLLOW-UP] Erro ao executar para ${conversation.contactNumber}:`, error);
    }
  }
  /**
   * Enhanced log function with payment status and follow-up type
   */
  async logFollowUp(conversationId, contactNumber, status, messageContent, errorReason, paymentStatus, followupType, stage) {
    try {
      await db.insert(followupLogs).values({
        conversationId,
        contactNumber,
        status,
        messageContent,
        errorReason,
        paymentStatus,
        followupType,
        stage
      });
    } catch (logError) {
      console.error("Erro ao logar follow-up:", logError);
    }
  }
  /**
   * Usa IA para analisar se deve enviar follow-up
   */
  async analyzeWithAI(conversation) {
    const seededLead = conversation.contextState?.seededLead || null;
    const messages = await db.query.adminMessages.findMany({
      where: eq2(adminMessages.conversationId, conversation.id),
      orderBy: (adminMessages2, { asc: asc2 }) => [asc2(adminMessages2.timestamp)],
      limit: 20
    });
    if (messages.length === 0 && seededLead) {
      return {
        action: "send",
        reason: "Contato criou conta no sistema, mas ainda n\xE3o teve conversa \xFAtil no WhatsApp.",
        context: "O cliente criou conta no AgenteZap, ainda n\xE3o assinou e n\xE3o h\xE1 hist\xF3rico de WhatsApp. Fa\xE7a um primeiro follow-up curto, consultivo e humano, como lead que j\xE1 demonstrou interesse ao criar a conta."
      };
    }
    const lastMessages = messages.map((m) => ({
      role: m.fromMe ? "assistant" : "user",
      content: m.text || (m.mediaType ? `[M\xEDdia: ${m.mediaType}]` : "")
    }));
    const prompt = `
      Analise esta conversa de vendas e decida o pr\xF3ximo passo para o sistema de follow-up autom\xE1tico.
      
      Contexto:
      - O cliente parou de responder.
      - Estamos no est\xE1gio ${conversation.followupStage} de follow-up.
      - Objetivo: Reengajar o cliente para fechar a venda.
      
      Hist\xF3rico recente:
      ${JSON.stringify(lastMessages, null, 2)}
      
      Regras de Decis\xE3o CR\xCDTICAS:
      1. ABORT ('abort'): 
         - Se o cliente J\xC1 FECHOU/CONTRATOU (ex: "j\xE1 paguei", "fechado", "contratado").
         - Se o cliente disse explicitamente "n\xE3o tenho interesse", "pare de mandar mensagem".
      
      2. WAIT ('wait'): 
         - Se o cliente est\xE1 AGUARDANDO UMA RESPOSTA NOSSA (ex: fez uma pergunta e n\xE3o respondemos ainda).
         - Se o cliente disse "vou ver e te aviso", "falo com voc\xEA amanh\xE3".
      
      3. SEND ('send'): 
         - Se o cliente simplesmente parou de responder e faz sentido tentar reengajar.
         - Se o cliente n\xE3o fechou e n\xE3o estamos devendo resposta.
      
      Responda APENAS um JSON:
      {
        "action": "send" | "wait" | "abort",
        "reason": "breve explica\xE7\xE3o",
        "context": "dicas para a mensagem de follow-up (ex: focar em benef\xEDcios, perguntar se ficou d\xFAvida)"
      }
    `;
    const buildTechnicalFallback = (reason) => {
      const lastMessage = messages[messages.length - 1] || null;
      const lastCustomerMessage = [...messages].reverse().find((message) => !message.fromMe) || null;
      if (!lastMessage || lastMessage.fromMe || !lastCustomerMessage) {
        return {
          action: "send",
          reason,
          context: "Retome a conversa com naturalidade, reconhecendo a pausa e oferecendo ajuda objetiva para avancar."
        };
      }
      return {
        action: "wait",
        reason,
        context: "A ultima mensagem foi do cliente. Aguarde ou priorize resposta manual antes de novo follow-up."
      };
    };
    const parseDecision = (rawContent) => {
      const content = typeof rawContent === "string" ? rawContent.trim() : "";
      if (!content) {
        console.warn(`[FOLLOW-UP] Resposta vazia da IA para ${conversation.contactNumber}. Usando fallback tecnico.`);
        return buildTechnicalFallback("Fallback tecnico: resposta vazia da IA");
      }
      const jsonBlock = extractFirstJsonObject(content);
      if (!jsonBlock) {
        console.warn(`[FOLLOW-UP] IA respondeu sem JSON valido para ${conversation.contactNumber}. Usando fallback tecnico.`);
        return buildTechnicalFallback("Fallback tecnico: IA nao retornou JSON valido");
      }
      try {
        const parsed = JSON.parse(jsonBlock);
        const action = parsed?.action;
        if (action !== "send" && action !== "wait" && action !== "abort") {
          console.warn(`[FOLLOW-UP] IA retornou action invalida para ${conversation.contactNumber}: ${String(action)}`);
          return buildTechnicalFallback("Fallback tecnico: acao invalida na resposta da IA");
        }
        return {
          action,
          reason: typeof parsed?.reason === "string" && parsed.reason.trim() ? parsed.reason.trim() : "Decisao automatica do follow-up",
          context: typeof parsed?.context === "string" && parsed.context.trim() ? parsed.context.trim() : void 0
        };
      } catch (error) {
        console.warn(`[FOLLOW-UP] Falha ao interpretar JSON da IA para ${conversation.contactNumber}. Usando fallback tecnico.`, error);
        return buildTechnicalFallback("Fallback tecnico: erro ao interpretar JSON da IA");
      }
    };
    try {
      const mistral = await getLLMClient();
      const response = await mistral.chat.complete({
        messages: [{ role: "user", content: prompt }]
      });
      const content = response.choices?.[0]?.message?.content || "";
      return parseDecision(content);
    } catch (e) {
      console.error("Erro na an\xE1lise de IA:", e);
      return buildTechnicalFallback("Fallback tecnico: erro na analise da IA");
    }
  }
  /**
   * Agenda o próximo follow-up ou finaliza se acabou a sequência
   * Uses configurable periodicity from global admin config and conversation config
   */
  async scheduleNextFollowUp(conversation, customDelayMinutes) {
    const priorityDecision = await this.enforcePriorityForConversation(conversation);
    if (!priorityDecision.allowed) {
      console.log(
        `[FOLLOW-UP] Reagendamento bloqueado por prioridade de ${FOLLOWUP_PRIORITY_EMAIL} (${priorityDecision.ownerType}) para ${conversation.contactNumber}.`
      );
      return;
    }
    const currentStage = conversation.followupStage || 0;
    const nextStage = currentStage + 1;
    const globalConfig = await getAdminFollowupGlobalConfig();
    const convConfig = getEffectiveConversationConfig(conversation, globalConfig);
    const finalMinDays = globalConfig.infiniteLoopMinDays ?? convConfig.finalMinDays ?? 15;
    const finalMaxDays = globalConfig.infiniteLoopMaxDays ?? convConfig.finalMaxDays ?? 30;
    const lastConfiguredStage = Math.max(0, convConfig.intervalsMinutes.length - 1);
    if (typeof customDelayMinutes === "number") {
      const customBaseDate = buildDelayDateFromNow(customDelayMinutes);
      if (!customBaseDate) {
        throw new Error(`[FOLLOW-UP] Delay customizado inv\xE1lido para ${conversation.contactNumber}: ${String(customDelayMinutes)}`);
      }
      const nextDate = alignToBusinessHours(customBaseDate, convConfig);
      if (!isValidDate(nextDate)) {
        throw new Error(`[FOLLOW-UP] Data inv\xE1lida ao reagendar customizado para ${conversation.contactNumber}`);
      }
      await db.update(adminConversations).set({ nextFollowupAt: nextDate, followupDisabledReason: null, updatedAt: /* @__PURE__ */ new Date() }).where(eq2(adminConversations.id, conversation.id));
      return;
    }
    if (nextStage > lastConfiguredStage) {
      const safeMinDays = Math.max(1, Number(finalMinDays) || 15);
      const safeMaxDays = Math.max(safeMinDays, Number(finalMaxDays) || safeMinDays);
      const range = Math.max(0, safeMaxDays - safeMinDays);
      const randomDelay = Math.floor(Math.random() * (range + 1) + safeMinDays);
      const nextDate = alignToBusinessHours(
        new Date(Date.now() + randomDelay * 24 * 60 * 60 * 1e3),
        convConfig
      );
      if (!isValidDate(nextDate)) {
        throw new Error(`[FOLLOW-UP] Data inv\xE1lida ao reagendar loop infinito para ${conversation.contactNumber}`);
      }
      console.log(`\u{1F504} [FOLLOW-UP] Ciclo infinito: Agendando pr\xF3ximo para daqui a ${randomDelay} dias (config: ${safeMinDays}-${safeMaxDays}d)`);
      await db.update(adminConversations).set({
        followupStage: nextStage,
        // Continua incrementando para saber quantas vezes já tentou
        nextFollowupAt: nextDate,
        followupDisabledReason: null,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq2(adminConversations.id, conversation.id));
    } else {
      const delayMinutes = convConfig.intervalsMinutes[nextStage];
      const baseDate = buildDelayDateFromNow(delayMinutes);
      if (!baseDate) {
        throw new Error(`[FOLLOW-UP] Intervalo inv\xE1lido no est\xE1gio ${nextStage} para ${conversation.contactNumber}: ${String(delayMinutes)}`);
      }
      const nextDate = alignToBusinessHours(baseDate, convConfig);
      if (!isValidDate(nextDate)) {
        throw new Error(`[FOLLOW-UP] Data inv\xE1lida ao reagendar est\xE1gio ${nextStage} para ${conversation.contactNumber}`);
      }
      await db.update(adminConversations).set({
        followupStage: nextStage,
        nextFollowupAt: nextDate,
        followupDisabledReason: null,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq2(adminConversations.id, conversation.id));
    }
  }
  /**
   * Desativa o follow-up para uma conversa
   */
  async disableFollowUp(conversationId, reason = "Cancelado manualmente") {
    console.log(`\u{1F6D1} [FOLLOW-UP] Desativando follow-up para conversa ${conversationId}. Motivo: ${reason}`);
    const conversation = await db.query.adminConversations.findFirst({
      where: eq2(adminConversations.id, conversationId)
    });
    if (conversation) {
      await db.update(adminConversations).set({
        followupActive: false,
        nextFollowupAt: null,
        followupStage: 0,
        followupDisabledReason: reason
      }).where(eq2(adminConversations.id, conversationId));
      console.log(`\u2705 [FOLLOW-UP] Sucesso ao desativar follow-up para ${conversation.contactNumber}. Active: ${conversation.followupActive}`);
      await this.logFollowUp(
        conversation.id,
        conversation.contactNumber,
        "cancelled",
        reason,
        void 0,
        conversation.paymentStatus || "pending",
        "cancelled",
        conversation.followupStage || 0
      );
    } else {
      console.warn(`\u26A0\uFE0F [FOLLOW-UP] Falha ao desativar: Conversa ${conversationId} n\xE3o encontrada ou update falhou.`);
    }
  }
  /**
   * Inicia o ciclo de follow-up para uma nova conversa (ou reinicia)
   */
  async scheduleInitialFollowUp(conversationId, options = {}) {
    const existing = await db.query.adminConversations.findFirst({
      where: eq2(adminConversations.id, conversationId)
    });
    const hasScheduledFollowup = Boolean(existing?.followupActive && existing?.nextFollowupAt);
    if (!shouldAutoRescheduleAdminFollowup({
      conversation: existing,
      forceRestart: options.forceRestart,
      allowManualResume: options.allowManualResume,
      hasScheduledFollowup
    })) {
      if (existing?.contextState?.manualFollowupPause === true) {
        console.log(`\u{1F6D1} [FOLLOW-UP] Conversa ${conversationId} com follow-up pausado manualmente. N\xE3o reativando automaticamente.`);
        return;
      }
      console.log(`\u2139\uFE0F [FOLLOW-UP] Follow-up j\xE1 ativo para ${conversationId} (stage=${existing.followupStage}, next=${new Date(existing.nextFollowupAt).toLocaleString()}). N\xC3O resetando.`);
      return;
    }
    if (existing) {
      const priorityDecision = await this.enforcePriorityForConversation(existing);
      if (!priorityDecision.allowed) {
        console.log(
          `[FOLLOW-UP] Ativa\xE7\xE3o bloqueada por prioridade de ${FOLLOWUP_PRIORITY_EMAIL} (${priorityDecision.ownerType}) para a conversa ${conversationId}.`
        );
        return {
          active: false,
          blockedReason: priorityDecision.blockedReason
        };
      }
    }
    const globalConfig = await getAdminFollowupGlobalConfig();
    const effectiveConfig = getEffectiveConversationConfig(
      existing || {
        followupConfig: LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG
      },
      globalConfig
    );
    const delayMinutes = effectiveConfig.intervalsMinutes[0] || LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG.intervalsMinutes[0];
    const nextDate = alignToBusinessHours(
      new Date(Date.now() + delayMinutes * 60 * 1e3),
      effectiveConfig
    );
    await db.update(adminConversations).set({
      followupActive: true,
      followupStage: 0,
      nextFollowupAt: nextDate,
      followupDisabledReason: null,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq2(adminConversations.id, conversationId));
    if (options.forceRestart && existing?.nextFollowupAt) {
      console.log(`[FOLLOW-UP] Ciclo reiniciado para conversa ${conversationId} em ${delayMinutes} min`);
      return { active: true, nextFollowupAt: nextDate };
    }
    console.log(`\u2705 [FOLLOW-UP] Agendado inicial para conversa ${conversationId} em ${delayMinutes} min`);
    return { active: true, nextFollowupAt: nextDate };
  }
  /**
   * Helper para agendar pelo telefone (busca a conversa mais recente)
   */
  async scheduleInitialFollowUpByPhone(phoneNumber, options = {}) {
    const conversation = await this.findPreferredConversationByPhone(phoneNumber);
    if (conversation) {
      await this.scheduleInitialFollowUp(conversation.id, options);
    } else {
      console.warn(`\u26A0\uFE0F [FOLLOW-UP] Conversa n\xE3o encontrada para ${phoneNumber} ao tentar agendar follow-up inicial`);
    }
  }
  /**
   * Agenda follow-up com delay customizado (solicitado pela IA via [FOLLOWUP:tempo="X"])
   * Ignora follow-up já ativo — a IA pediu explicitamente, então respeita o delay.
   */
  async scheduleCustomFollowUpByPhone(phoneNumber, delayMinutes, motivo) {
    const conversation = await this.findPreferredConversationByPhone(phoneNumber);
    if (!conversation) {
      console.warn(`\u26A0\uFE0F [FOLLOW-UP] Conversa n\xE3o encontrada para ${phoneNumber} ao tentar agendar follow-up customizado`);
      return;
    }
    const priorityDecision = await this.enforcePriorityForConversation(conversation);
    if (!priorityDecision.allowed) {
      console.log(
        `[FOLLOW-UP] Agendamento customizado bloqueado por prioridade de ${FOLLOWUP_PRIORITY_EMAIL} (${priorityDecision.ownerType}) para ${phoneNumber}.`
      );
      return {
        active: false,
        blockedReason: priorityDecision.blockedReason
      };
    }
    const globalConfig = await getAdminFollowupGlobalConfig();
    const effectiveConfig = getEffectiveConversationConfig(conversation, globalConfig);
    const nextDate = alignToBusinessHours(
      new Date(Date.now() + delayMinutes * 60 * 1e3),
      effectiveConfig
    );
    await db.update(adminConversations).set({
      followupActive: true,
      followupStage: 0,
      nextFollowupAt: nextDate,
      followupDisabledReason: null,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq2(adminConversations.id, conversation.id));
    console.log(`\u{1F3AF} [FOLLOW-UP] Agendado PROATIVO para ${phoneNumber} em ${delayMinutes}min. Motivo: ${motivo || "IA solicitou"}. Pr\xF3ximo: ${nextDate.toLocaleString()}`);
  }
  /**
   * Cancela follow-up ativo para um telefone (MANUALMENTE)
   */
  async cancelFollowUpByPhone(phoneNumber) {
    const conversation = await this.findPreferredConversationByPhone(phoneNumber);
    if (conversation) {
      await this.disableFollowUp(conversation.id, "Cancelado pelo usu\xE1rio");
      console.log(`\u{1F6D1} [FOLLOW-UP] Cancelado manualmente para ${phoneNumber}`);
    }
  }
  /**
   * Reseta ciclo quando cliente responde
   */
  async resetFollowUpCycle(phoneNumber) {
    const conversation = await this.findPreferredConversationByPhone(phoneNumber);
    if (!conversation) {
      console.warn(`\xE2\u0161\xA0\xEF\xB8\x8F [FOLLOW-UP] Conversa n\xC3\xA3o encontrada para ${phoneNumber} ao tentar resetar ciclo`);
      return;
    }
    const globalConfig = await getAdminFollowupGlobalConfig();
    const effectiveConfig = getEffectiveConversationConfig(conversation, globalConfig);
    const delayMinutes = effectiveConfig.intervalsMinutes[0] || LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG.intervalsMinutes[0];
    const nextDate = alignToBusinessHours(
      new Date(Date.now() + delayMinutes * 60 * 1e3),
      effectiveConfig
    );
    await db.update(adminConversations).set({
      followupActive: true,
      followupStage: 0,
      nextFollowupAt: nextDate,
      followupDisabledReason: null,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq2(adminConversations.id, conversation.id));
    console.log(`\u{1F504} [FOLLOW-UP] Cliente respondeu. Ciclo resetado para ${delayMinutes}min (Est\xE1gio 0) para ${phoneNumber}`);
  }
  // ============================================================================
  // GETTERS PARA O CALENDÁRIO
  // ============================================================================
  /**
   * Busca logs de follow-up
   */
  async getFollowUpLogs(status) {
    const whereClause = status ? eq2(followupLogs.status, status) : void 0;
    return await db.query.followupLogs.findMany({
      where: whereClause,
      orderBy: (followupLogs2, { desc: desc2 }) => [desc2(followupLogs2.executedAt)],
      limit: 100
    });
  }
  /**
   * Retorna eventos para o calendário (follow-ups futuros)
   */
  async getCalendarEvents() {
    const now = /* @__PURE__ */ new Date();
    const activeFollowUps = await db.query.adminConversations.findMany({
      where: and2(
        eq2(adminConversations.followupActive, true),
        // Trazer apenas os futuros ou atrasados (não nulos)
        lte(adminConversations.nextFollowupAt, new Date(now.getTime() + 30 * 24 * 60 * 60 * 1e3))
        // Próximos 30 dias
      )
    });
    const validFollowUps = activeFollowUps.filter((c) => c.followupActive === true);
    return validFollowUps.map((conv) => ({
      id: conv.id,
      // Use ID directly for easier deletion
      phoneNumber: conv.contactNumber,
      type: "followup",
      title: `Follow-up #${(conv.followupStage || 0) + 1}`,
      scheduledAt: conv.nextFollowupAt,
      status: conv.nextFollowupAt && conv.nextFollowupAt < now ? "overdue" : "pending",
      attempt: (conv.followupStage || 0) + 1,
      metadata: {
        conversationId: conv.id,
        stage: conv.followupStage
      }
    }));
  }
  /**
   * Retorna estatísticas para o dashboard
   */
  async getFollowUpStats() {
    const now = /* @__PURE__ */ new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1e3);
    const events = await this.getCalendarEvents();
    const stats = {
      pending: events.filter((e) => e.status === "pending" || e.status === "overdue").length,
      scheduledToday: events.filter(
        (e) => e.scheduledAt && new Date(e.scheduledAt) >= today && new Date(e.scheduledAt) < new Date(today.getTime() + 24 * 60 * 60 * 1e3)
      ).length,
      scheduledThisWeek: events.filter(
        (e) => e.scheduledAt && new Date(e.scheduledAt) >= today && new Date(e.scheduledAt) < nextWeek
      ).length,
      byType: {}
    };
    events.forEach((e) => {
      stats.byType[e.type] = (stats.byType[e.type] || 0) + 1;
    });
    return stats;
  }
  async getConversationSignals(conversationId) {
    const [latestSentLog, latestOutboundMessage] = await Promise.all([
      db.query.followupLogs.findFirst({
        where: and2(
          eq2(followupLogs.conversationId, conversationId),
          eq2(followupLogs.status, "sent")
        ),
        orderBy: (table, { desc: desc2 }) => [desc2(table.executedAt), desc2(table.id)]
      }),
      db.query.adminMessages.findFirst({
        where: and2(
          eq2(adminMessages.conversationId, conversationId),
          eq2(adminMessages.fromMe, true)
        ),
        orderBy: (table, { desc: desc2 }) => [desc2(table.timestamp), desc2(table.id)]
      })
    ]);
    return { latestSentLog, latestOutboundMessage };
  }
  getCandidateFollowupDate(conversation, effectiveConfig, latestSentLog, latestOutboundMessage) {
    const currentStage = Math.max(0, Number(conversation.followupStage || 0));
    const intervalForStage = effectiveConfig.intervalsMinutes[currentStage] || effectiveConfig.intervalsMinutes[effectiveConfig.intervalsMinutes.length - 1] || LEGACY_DEFAULT_ADMIN_FOLLOWUP_CONFIG.intervalsMinutes[0];
    if (latestSentLog?.executedAt) {
      const sentAt = new Date(latestSentLog.executedAt);
      if (currentStage >= effectiveConfig.intervalsMinutes.length) {
        return conversation.nextFollowupAt ? new Date(conversation.nextFollowupAt) : new Date(
          sentAt.getTime() + Math.max(1, effectiveConfig.infiniteLoopMinDays ?? effectiveConfig.finalMinDays ?? 15) * 24 * 60 * 60 * 1e3
        );
      }
      return new Date(sentAt.getTime() + intervalForStage * 60 * 1e3);
    }
    if (latestOutboundMessage?.timestamp) {
      return new Date(new Date(latestOutboundMessage.timestamp).getTime() + intervalForStage * 60 * 1e3);
    }
    const anchor = conversation.lastMessageTime || conversation.createdAt;
    if (anchor) {
      return new Date(new Date(anchor).getTime() + intervalForStage * 60 * 1e3);
    }
    if (conversation.nextFollowupAt) {
      return new Date(conversation.nextFollowupAt);
    }
    return null;
  }
  async normalizeDuplicatePhones(adminId, limit = 5e3) {
    const conversations2 = await db.query.adminConversations.findMany({
      where: and2(
        eq2(adminConversations.adminId, adminId),
        eq2(adminConversations.followupActive, true)
      ),
      orderBy: (table, { desc: desc2 }) => [desc2(table.lastMessageTime), desc2(table.createdAt)],
      limit
    });
    const grouped = /* @__PURE__ */ new Map();
    for (const conversation of conversations2) {
      const key = normalizePhoneDigits(conversation.contactNumber) || conversation.id;
      const group = grouped.get(key) || [];
      group.push(conversation);
      grouped.set(key, group);
    }
    let disabledDuplicates = 0;
    for (const group of grouped.values()) {
      if (group.length <= 1) continue;
      const ranked = [];
      for (const conversation of group) {
        const { latestSentLog, latestOutboundMessage } = await this.getConversationSignals(conversation.id);
        const score = (latestSentLog ? 1e3 : 0) + (latestOutboundMessage ? 500 : 0) + (conversation.nextFollowupAt ? 100 : 0) + Math.min(50, Number(conversation.followupStage || 0));
        const timestamp = new Date(
          conversation.lastMessageTime || conversation.createdAt || conversation.updatedAt || /* @__PURE__ */ new Date(0)
        ).getTime();
        ranked.push({ conversation, score, timestamp });
      }
      ranked.sort((a, b) => b.score - a.score || b.timestamp - a.timestamp);
      const keepConversationId = ranked[0]?.conversation.id;
      for (const entry of ranked.slice(1)) {
        await db.update(adminConversations).set({
          followupActive: false,
          nextFollowupAt: null,
          followupDisabledReason: `duplicate_phone_merged:${keepConversationId}`,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq2(adminConversations.id, entry.conversation.id));
        disabledDuplicates += 1;
      }
    }
    return { disabledDuplicates };
  }
  async reorganizeAllFollowups(adminId, limit = 2e3) {
    try {
      const priorityResult = await this.reconcilePriorityConflicts(Math.max(limit * 3, 3e3), adminId);
      const duplicateResult = await this.normalizeDuplicatePhones(adminId, Math.max(limit * 3, 3e3));
      await this.repairMissingSchedules(limit, adminId);
      const globalConfig = await getAdminFollowupGlobalConfig();
      const conversations2 = await db.query.adminConversations.findMany({
        where: and2(
          eq2(adminConversations.adminId, adminId),
          eq2(adminConversations.followupActive, true)
        ),
        orderBy: (table, { asc: asc2 }) => [asc2(table.nextFollowupAt), asc2(table.lastMessageTime), asc2(table.createdAt)],
        limit
      });
      let reorganized = 0;
      let skipped = 0;
      let offsetMinutes = 1;
      const now = /* @__PURE__ */ new Date();
      for (const conversation of conversations2) {
        const effectiveConfig = getEffectiveConversationConfig(conversation, globalConfig);
        const { latestSentLog, latestOutboundMessage } = await this.getConversationSignals(conversation.id);
        let candidate = this.getCandidateFollowupDate(
          conversation,
          effectiveConfig,
          latestSentLog,
          latestOutboundMessage
        );
        if (!candidate || Number.isNaN(candidate.getTime())) {
          skipped += 1;
          continue;
        }
        if (candidate <= now) {
          candidate = new Date(now.getTime() + offsetMinutes * 60 * 1e3);
          offsetMinutes += 1;
        }
        candidate = alignToBusinessHours(candidate, effectiveConfig);
        await db.update(adminConversations).set({
          nextFollowupAt: candidate,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq2(adminConversations.id, conversation.id));
        reorganized += 1;
      }
      console.log(`\u{1F504} [FOLLOW-UP] Reorganiza\xE7\xE3o conclu\xEDda para admin ${adminId}. reorganized=${reorganized} skipped=${skipped} disabledDuplicates=${duplicateResult.disabledDuplicates} priorityDisabled=${priorityResult.disabledDuplicates}`);
      return {
        reorganized,
        skipped,
        disabledDuplicates: duplicateResult.disabledDuplicates,
        priorityDisabled: priorityResult.disabledDuplicates
      };
    } catch (error) {
      console.error("\u274C [FOLLOW-UP] Erro ao reorganizar follow-ups:", error);
      throw error;
    }
  }
  async repairMissingSchedules(limit = 1e3, adminId) {
    try {
      await this.reconcilePriorityConflicts(Math.max(limit * 3, 3e3), adminId);
      const globalConfig = await getAdminFollowupGlobalConfig();
      const brokenConversations = await db.query.adminConversations.findMany({
        where: adminId ? and2(
          eq2(adminConversations.adminId, adminId),
          eq2(adminConversations.followupActive, true),
          isNull(adminConversations.nextFollowupAt)
        ) : and2(
          eq2(adminConversations.followupActive, true),
          isNull(adminConversations.nextFollowupAt)
        ),
        orderBy: (table, { asc: asc2 }) => [asc2(table.lastMessageTime), asc2(table.createdAt)],
        limit
      });
      if (brokenConversations.length === 0) {
        return;
      }
      let repaired = 0;
      let skippedWithoutOutbound = 0;
      let offsetMinutes = 1;
      const now = /* @__PURE__ */ new Date();
      for (const conversation of brokenConversations) {
        const priorityDecision = await this.enforcePriorityForConversation(conversation);
        if (!priorityDecision.allowed) {
          continue;
        }
        const effectiveConfig = getEffectiveConversationConfig(conversation, globalConfig);
        const { latestSentLog, latestOutboundMessage } = await this.getConversationSignals(conversation.id);
        let nextDate = this.getCandidateFollowupDate(
          conversation,
          effectiveConfig,
          latestSentLog,
          latestOutboundMessage
        );
        if (!nextDate || Number.isNaN(nextDate.getTime())) {
          skippedWithoutOutbound += 1;
          continue;
        }
        if (nextDate <= now) {
          nextDate = new Date(now.getTime() + offsetMinutes * 60 * 1e3);
          offsetMinutes += 1;
        }
        nextDate = alignToBusinessHours(nextDate, effectiveConfig);
        await db.update(adminConversations).set({
          nextFollowupAt: nextDate,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq2(adminConversations.id, conversation.id));
        repaired += 1;
      }
      console.log(`\xF0\u0178\u203A \xEF\xB8\x8F [FOLLOW-UP] Reparo de agenda conclu\xC3\xADdo. scanned=${brokenConversations.length} repaired=${repaired} skippedWithoutOutbound=${skippedWithoutOutbound}`);
    } catch (error) {
      console.error("\xE2\x9D\u0152 [FOLLOW-UP] Erro ao reparar agendas faltantes:", error);
    }
  }
};
var followUpService = new FollowUpService();
function registerFollowUpCallback(callback) {
  followUpService.registerFollowUpCallback(callback);
}
function registerScheduledContactCallback(callback) {
  followUpService.registerScheduledContactCallback(callback);
}
var scheduleAutoFollowUp = function(phoneNumber, delayMinutes, context) {
  console.warn("\u26A0\uFE0F scheduleAutoFollowUp (legacy) chamado - migrar para scheduleInitialFollowUp");
};
var cancelFollowUp = function(phoneNumber) {
  followUpService.cancelFollowUpByPhone(phoneNumber);
};
var scheduleContact = function(phoneNumber, date, reason) {
};
var parseScheduleFromText = function(text) {
  const now = /* @__PURE__ */ new Date();
  const lowerText = text.toLowerCase();
  if (lowerText.includes("amanh\xE3") || lowerText.includes("amanha")) {
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const hourMatch = text.match(/(\d{1,2})\s*(?:h|hora|:)/i);
    if (hourMatch) {
      tomorrow.setHours(parseInt(hourMatch[1]), 0, 0, 0);
    } else {
      tomorrow.setHours(10, 0, 0, 0);
    }
    return tomorrow;
  }
  const weekdays = ["domingo", "segunda", "ter\xE7a", "terca", "quarta", "quinta", "sexta", "s\xE1bado", "sabado"];
  for (let i = 0; i < weekdays.length; i++) {
    if (lowerText.includes(weekdays[i])) {
      const targetDay = i % 7;
      const currentDay = now.getDay();
      let daysToAdd = targetDay - currentDay;
      if (daysToAdd <= 0) daysToAdd += 7;
      const target = new Date(now);
      target.setDate(target.getDate() + daysToAdd);
      const hourMatch = text.match(/(\d{1,2})\s*(?:h|hora|:)/i);
      if (hourMatch) {
        target.setHours(parseInt(hourMatch[1]), 0, 0, 0);
      } else {
        target.setHours(10, 0, 0, 0);
      }
      return target;
    }
  }
  const inXMatch = text.match(/daqui\s*(?:a\s*)?(\d+)\s*(dia|hora|minuto)/i);
  if (inXMatch) {
    const amount = parseInt(inXMatch[1]);
    const unit = inXMatch[2].toLowerCase();
    const target = new Date(now);
    if (unit.startsWith("dia")) {
      target.setDate(target.getDate() + amount);
      target.setHours(10, 0, 0, 0);
    } else if (unit.startsWith("hora")) {
      target.setHours(target.getHours() + amount);
    } else if (unit.startsWith("minuto")) {
      target.setMinutes(target.getMinutes() + amount);
    }
    return target;
  }
  return null;
};
function setMockFollowUpFunctions(mocks) {
  if (mocks.cancelFollowUp) cancelFollowUp = mocks.cancelFollowUp;
  if (mocks.scheduleAutoFollowUp) scheduleAutoFollowUp = mocks.scheduleAutoFollowUp;
  if (mocks.scheduleContact) scheduleContact = mocks.scheduleContact;
  if (mocks.followUpService) followUpService = mocks.followUpService;
}

export {
  FOLLOWUP_PRIORITY_EMAIL,
  normalizePriorityPhoneDigits,
  getFollowupPriorityUserId,
  findPriorityUserConversationByContact,
  disableAdminFollowupsForPriorityUser,
  FollowUpService,
  followUpService,
  registerFollowUpCallback,
  registerScheduledContactCallback,
  scheduleAutoFollowUp,
  cancelFollowUp,
  scheduleContact,
  parseScheduleFromText,
  setMockFollowUpFunctions
};
