// shared/flowVisualBuilder.ts
var VISUAL_FLOW_META_START = "<<FLOW_VISUAL_META>>";
var VISUAL_FLOW_META_END = "<<END_FLOW_VISUAL_META>>";
function ensureString(value) {
  return typeof value === "string" ? value : "";
}
function makeId(prefix) {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}
function normalizeFinalAction(value) {
  const normalized = ensureString(value).trim();
  if (normalized === "continue_ai" || normalized === "end" || normalized === "handoff") {
    return normalized;
  }
  return null;
}
function normalizeTriggerMode(value) {
  const normalized = ensureString(value).trim();
  if (normalized === "first_message" || normalized === "any_message" || normalized === "default") {
    return normalized;
  }
  return "any_message";
}
function defaultTriggerCondition(triggerMode) {
  if (triggerMode === "first_message") {
    return "Use este fluxo apenas no inicio da conversa, quando a primeira mensagem do cliente combinar com a intencao descrita.";
  }
  if (triggerMode === "default") {
    return "Use este fluxo como fallback quando nenhum outro fluxo representar melhor a intencao real do cliente.";
  }
  return "Use este fluxo quando a intencao e o contexto da mensagem combinarem com este objetivo.";
}
function normalizeMediaAction(input) {
  if (!input || typeof input !== "object") return null;
  const action = input;
  const type = ensureString(action.type).trim();
  if (type === "send_text") {
    const text = ensureString(action.text).trim();
    if (!text) return null;
    const normalizedAction = {
      type: "send_text",
      text
    };
    const delaySeconds = Number(action.delay_seconds);
    if (Number.isFinite(delaySeconds)) {
      normalizedAction.delay_seconds = delaySeconds;
    }
    return normalizedAction;
  }
  if (type === "send_media_url") {
    const mediaUrl = ensureString(action.media_url).trim();
    const mediaType = ensureString(action.media_type).trim();
    if (!mediaUrl || !["audio", "image", "video", "document"].includes(mediaType)) {
      return null;
    }
    const normalizedAction = {
      type: "send_media_url",
      media_url: mediaUrl,
      media_type: mediaType
    };
    const mediaName = ensureString(action.media_name).trim();
    const caption = ensureString(action.caption).trim();
    const fileName = ensureString(action.file_name).trim();
    if (mediaName) normalizedAction.media_name = mediaName;
    if (caption) normalizedAction.caption = caption;
    if (fileName) normalizedAction.file_name = fileName;
    const delaySeconds = Number(action.delay_seconds);
    if (Number.isFinite(delaySeconds)) {
      normalizedAction.delay_seconds = delaySeconds;
    }
    return normalizedAction;
  }
  if (type === "send_media") {
    const mediaName = ensureString(action.media_name).trim();
    if (!mediaName) return null;
    const normalizedAction = {
      type: "send_media",
      media_name: mediaName
    };
    const delaySeconds = Number(action.delay_seconds);
    if (Number.isFinite(delaySeconds)) {
      normalizedAction.delay_seconds = delaySeconds;
    }
    return normalizedAction;
  }
  return null;
}
function normalizeBranch(input) {
  if (!input || typeof input !== "object") return null;
  const branch = input;
  const id = ensureString(branch.id).trim();
  if (!id) return null;
  const nextStepIdRaw = ensureString(branch.nextStepId).trim();
  return {
    id,
    label: ensureString(branch.label).trim(),
    condition: ensureString(branch.condition).trim(),
    nextStepId: nextStepIdRaw || null
  };
}
function normalizeStep(input) {
  if (!input || typeof input !== "object") return null;
  const step = input;
  const id = ensureString(step.id).trim();
  const type = ensureString(step.type).trim();
  if (!id || !["message", "question", "media", "handoff", "end"].includes(type)) {
    return null;
  }
  const nextStepIdRaw = ensureString(step.nextStepId).trim();
  const fallbackStepIdRaw = ensureString(step.fallbackStepId).trim();
  const branches = Array.isArray(step.branches) ? step.branches.map(normalizeBranch).filter(Boolean) : [];
  const mediaActions = Array.isArray(step.mediaActions) ? step.mediaActions.map(normalizeMediaAction).filter(Boolean) : [];
  return {
    id,
    type,
    title: ensureString(step.title).trim() || "Etapa",
    message: ensureString(step.message).trim(),
    nextStepId: nextStepIdRaw || null,
    branches,
    mediaActions,
    fallbackStepId: fallbackStepIdRaw || null,
    fallbackMessage: ensureString(step.fallbackMessage).trim(),
    finalAction: normalizeFinalAction(step.finalAction)
  };
}
function createEmptyVisualFlowRoute(overrides = {}) {
  const triggerMode = normalizeTriggerMode(overrides.triggerMode);
  const steps = Array.isArray(overrides.steps) ? overrides.steps.map(normalizeStep).filter(Boolean) : [];
  return {
    id: ensureString(overrides.id).trim() || makeId("flow"),
    name: ensureString(overrides.name).trim() || "Fluxo principal",
    description: ensureString(overrides.description).trim(),
    triggerMode,
    triggerCondition: ensureString(overrides.triggerCondition).trim() || defaultTriggerCondition(triggerMode),
    defaultFinalAction: normalizeFinalAction(overrides.defaultFinalAction) || "continue_ai",
    steps
  };
}
function createLegacyDefaultRoute(params) {
  const steps = Array.isArray(params.steps) ? params.steps.map(normalizeStep).filter(Boolean) : [];
  return createEmptyVisualFlowRoute({
    id: "flow-default",
    name: "Fluxo principal",
    description: "Fluxo importado do formato anterior.",
    triggerMode: "default",
    triggerCondition: defaultTriggerCondition("default"),
    defaultFinalAction: normalizeFinalAction(params.defaultFinalAction) || "continue_ai",
    steps
  });
}
function normalizeRoute(input, index) {
  if (!input || typeof input !== "object") return null;
  const route = input;
  const triggerMode = normalizeTriggerMode(route.triggerMode);
  const steps = Array.isArray(route.steps) ? route.steps.map(normalizeStep).filter(Boolean) : [];
  return createEmptyVisualFlowRoute({
    id: ensureString(route.id).trim() || `flow-${index + 1}`,
    name: ensureString(route.name).trim() || `Fluxo ${index + 1}`,
    description: ensureString(route.description).trim(),
    triggerMode,
    triggerCondition: ensureString(route.triggerCondition).trim() || defaultTriggerCondition(triggerMode),
    defaultFinalAction: normalizeFinalAction(route.defaultFinalAction) || "continue_ai",
    steps
  });
}
function createEmptyVisualFlowDefinition() {
  return {
    version: 1,
    mode: "visual",
    manualNotes: "",
    flows: [
      createEmptyVisualFlowRoute({
        id: "flow-default",
        name: "Fluxo principal",
        triggerMode: "default"
      })
    ]
  };
}
function sanitizeVisualFlowDefinition(input) {
  if (!input || typeof input !== "object") {
    return createEmptyVisualFlowDefinition();
  }
  const raw = input;
  const version = 1;
  const mode = "visual";
  const manualNotes = ensureString(raw.manualNotes);
  const flows = Array.isArray(raw.flows) ? raw.flows.map(normalizeRoute).filter(Boolean) : [];
  if (flows.length > 0) {
    const ensuredDefault = flows.some((flow) => flow.triggerMode === "default") ? flows : flows.map(
      (flow, index) => index === 0 ? { ...flow, triggerMode: "default" } : flow
    );
    return {
      version,
      mode,
      manualNotes,
      flows: ensuredDefault
    };
  }
  const legacyRoute = createLegacyDefaultRoute({
    steps: raw.steps,
    defaultFinalAction: raw.defaultFinalAction
  });
  return {
    version,
    mode,
    manualNotes,
    flows: [legacyRoute]
  };
}
function extractVisualFlowMetadata(rawScript) {
  const script = ensureString(rawScript);
  const startIndex = script.indexOf(VISUAL_FLOW_META_START);
  const endIndex = script.indexOf(VISUAL_FLOW_META_END);
  if (startIndex === -1 || endIndex === -1 || endIndex <= startIndex) {
    return {
      cleanScript: script.trim(),
      definition: null,
      hasMetadata: false
    };
  }
  const jsonStart = startIndex + VISUAL_FLOW_META_START.length;
  const jsonText = script.slice(jsonStart, endIndex).trim();
  const before = script.slice(0, startIndex).trim();
  const after = script.slice(endIndex + VISUAL_FLOW_META_END.length).trim();
  const cleanScript = [before, after].filter(Boolean).join("\n\n").trim();
  try {
    const parsed = JSON.parse(jsonText);
    return {
      cleanScript,
      definition: sanitizeVisualFlowDefinition(parsed),
      hasMetadata: true
    };
  } catch {
    return {
      cleanScript,
      definition: null,
      hasMetadata: true
    };
  }
}
function getDefaultVisualFlowRoute(definition) {
  if (!definition) return null;
  const sanitized = sanitizeVisualFlowDefinition(definition);
  return sanitized.flows.find((flow) => flow.triggerMode === "default") || sanitized.flows[0] || null;
}
function getVisualFlowRouteByStepId(definition, stepId) {
  if (!definition || !stepId) return null;
  const sanitized = sanitizeVisualFlowDefinition(definition);
  return sanitized.flows.find((flow) => flow.steps.some((step) => step.id === stepId)) || null;
}
function buildVisualFlowFingerprint(rawScript) {
  const extracted = extractVisualFlowMetadata(rawScript);
  const canonical = JSON.stringify({
    cleanScript: extracted.cleanScript,
    definition: extracted.definition ? sanitizeVisualFlowDefinition(extracted.definition) : null
  });
  let hash = 5381;
  for (let index = 0; index < canonical.length; index += 1) {
    hash = (hash << 5) + hash ^ canonical.charCodeAt(index);
  }
  return `vf-${(hash >>> 0).toString(36)}`;
}

export {
  extractVisualFlowMetadata,
  getDefaultVisualFlowRoute,
  getVisualFlowRouteByStepId,
  buildVisualFlowFingerprint
};
