import {
  storage
} from "./chunk-7SPF5OKO.js";

// server/pixService.ts
import QRCode from "qrcode";
async function generatePixQRCode(paymentData) {
  try {
    const pixKeyConfig = await storage.getSystemConfig("pix_key");
    const merchantNameConfig = await storage.getSystemConfig("merchant_name");
    const merchantCityConfig = await storage.getSystemConfig("merchant_city");
    const pixKeyRaw = paymentData.pixKeyOverride || pixKeyConfig?.valor || "rodrigoconexao128@gmail.com";
    const merchantNameRaw = merchantNameConfig?.valor || "RODRIGO MACEDO";
    const merchantCityRaw = merchantCityConfig?.valor || "COSMORAMA";
    let pixKey = String(pixKeyRaw).replace(/\s+/g, "").trim();
    const cleanKey = pixKey.replace(/\+55/g, "");
    let onlyDigits = cleanKey.replace(/\D/g, "");
    if (onlyDigits.length >= 10 && onlyDigits.length <= 13) {
      if (onlyDigits.length >= 12 && onlyDigits.startsWith("55")) {
        onlyDigits = onlyDigits.substring(2);
      }
      pixKey = "+55" + onlyDigits;
    }
    const baseId = String(paymentData.subscriptionId || "").replace(/[^A-Za-z0-9]/g, "").toUpperCase();
    const randomSuffix = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g, "").substring(0, 10);
    const txid = (baseId + randomSuffix).substring(0, 25) || "TX" + Date.now().toString().substring(0, 23);
    const valorNum = typeof paymentData.valor === "string" ? parseFloat(String(paymentData.valor).replace(",", ".")) : Number(paymentData.valor || 0);
    const valor = Number.isFinite(valorNum) && valorNum > 0 ? Number(valorNum.toFixed(2)) : 0.01;
    const sanitize = (s, max) => (s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z0-9 ]/g, "").replace(/\s+/g, " ").trim().toUpperCase().slice(0, max);
    const name = sanitize(merchantNameRaw, 25);
    const city = sanitize(merchantCityRaw, 15);
    const message = sanitize(`Pagamento ${paymentData.planNome || ""}`, 50);
    const tlv = (id, value) => id + String(value.length).padStart(2, "0") + value;
    const maids = tlv("00", "br.gov.bcb.pix") + tlv("01", pixKey);
    const merchantAccountInfo = tlv("26", maids);
    const amount = valor.toFixed(2);
    const base = "" + tlv("00", "01") + tlv("01", "11") + merchantAccountInfo + tlv("52", "0000") + tlv("53", "986") + tlv("54", amount) + tlv("58", "BR") + tlv("59", name) + tlv("60", city) + tlv("62", tlv("05", txid));
    const crcInput = base + "6304";
    let crc = 65535;
    for (let i = 0; i < crcInput.length; i++) {
      crc ^= crcInput.charCodeAt(i) << 8;
      for (let j = 0; j < 8; j++) {
        crc = crc & 32768 ? crc << 1 ^ 4129 : crc << 1;
        crc &= 65535;
      }
    }
    const crcHex = crc.toString(16).toUpperCase().padStart(4, "0");
    const payload = crcInput + crcHex;
    console.log("[PIX Generation]", {
      pixKeyRaw,
      pixKeyFormatted: pixKey,
      amount: valor,
      txid,
      payload: payload.substring(0, 100) + "..."
    });
    const pixQrCode = await QRCode.toDataURL(payload, { errorCorrectionLevel: "M", type: "image/png", margin: 1, width: 300 });
    return { pixCode: payload, pixQrCode };
  } catch (error) {
    console.error("Error generating PIX QR Code:", error);
    throw error;
  }
}

export {
  generatePixQRCode
};
