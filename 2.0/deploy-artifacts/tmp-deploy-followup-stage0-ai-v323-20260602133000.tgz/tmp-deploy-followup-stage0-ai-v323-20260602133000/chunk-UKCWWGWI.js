import {
  db
} from "./chunk-R6CXRQMB.js";
import {
  aiAgentConfig,
  systemConfig
} from "./chunk-JC6URYU5.js";

// server/mistralClient.ts
import { Mistral } from "@mistralai/mistralai";

// server/llmConfigResolver.ts
import { eq, inArray } from "drizzle-orm";

// server/llmUserContext.ts
import { AsyncLocalStorage } from "node:async_hooks";
var llmUserContext = new AsyncLocalStorage();
function normalizeUserId(userId) {
  const normalized = String(userId || "").trim();
  return normalized || void 0;
}
function getLLMUserContext() {
  return normalizeUserId(llmUserContext.getStore()?.userId);
}
async function runWithLLMUserContext(userId, fn) {
  const normalizedUserId = normalizeUserId(userId);
  if (!normalizedUserId) {
    return fn();
  }
  if (getLLMUserContext() === normalizedUserId) {
    return fn();
  }
  return llmUserContext.run({ userId: normalizedUserId }, fn);
}

// server/llmConfigResolver.ts
var LLM_CONFIG_CACHE_TTL_MS = 5 * 60 * 1e3;
var GLOBAL_CACHE_KEY = "global";
var GLOBAL_LLM_KEYS = [
  "llm_provider",
  "groq_api_key",
  "groq_model",
  "openrouter_api_key",
  "openrouter_model",
  "openrouter_provider",
  "mistral_api_key",
  "mistral_model",
  "nvidia_api_key",
  "nvidia_model"
];
var llmConfigCache = /* @__PURE__ */ new Map();
function normalizeOptionalText(value) {
  const normalized = String(value ?? "").trim();
  return normalized || void 0;
}
function sanitizeApiKey(value) {
  const raw = String(value ?? "");
  return raw.replaceAll(" ", "").replaceAll("\n", "").replaceAll("\r", "").replaceAll("	", "");
}
function normalizeProvider(value, fallback = "mistral") {
  const normalized = String(value ?? "").trim().toLowerCase();
  if (normalized === "mistral" || normalized === "groq" || normalized === "openrouter" || normalized === "nvidia") {
    return normalized;
  }
  return fallback;
}
function normalizeAgentLLMConfig(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return { mode: "global" };
  }
  const candidate = value;
  const mode = candidate.mode === "custom" ? "custom" : "global";
  return {
    mode,
    provider: candidate.provider ? normalizeProvider(candidate.provider) : void 0,
    mistralApiKey: sanitizeApiKey(candidate.mistralApiKey) || void 0,
    mistralModel: normalizeOptionalText(candidate.mistralModel),
    groqApiKey: sanitizeApiKey(candidate.groqApiKey) || void 0,
    groqModel: normalizeOptionalText(candidate.groqModel),
    openrouterApiKey: sanitizeApiKey(candidate.openrouterApiKey) || void 0,
    openrouterModel: normalizeOptionalText(candidate.openrouterModel),
    openrouterProvider: normalizeOptionalText(candidate.openrouterProvider),
    nvidiaApiKey: sanitizeApiKey(candidate.nvidiaApiKey) || void 0,
    nvidiaModel: normalizeOptionalText(candidate.nvidiaModel)
  };
}
function buildCacheKey(userId) {
  return userId ? `user:${userId}` : GLOBAL_CACHE_KEY;
}
function readCachedConfig(cacheKey) {
  const cached = llmConfigCache.get(cacheKey);
  if (!cached) {
    return null;
  }
  if (Date.now() - cached.timestamp > LLM_CONFIG_CACHE_TTL_MS) {
    llmConfigCache.delete(cacheKey);
    return null;
  }
  return cached.config;
}
function writeCachedConfig(cacheKey, config) {
  llmConfigCache.set(cacheKey, {
    config,
    timestamp: Date.now()
  });
  return config;
}
async function loadGlobalLLMConfig() {
  const rows = await db.select().from(systemConfig).where(inArray(systemConfig.chave, [...GLOBAL_LLM_KEYS]));
  const configMap = new Map(rows.map((row) => [row.chave, row.valor || ""]));
  return {
    provider: normalizeProvider(configMap.get("llm_provider")),
    groqApiKey: sanitizeApiKey(configMap.get("groq_api_key")),
    groqModel: normalizeOptionalText(configMap.get("groq_model")) || "openai/gpt-oss-20b",
    openrouterApiKey: sanitizeApiKey(configMap.get("openrouter_api_key")),
    openrouterModel: normalizeOptionalText(configMap.get("openrouter_model")) || "google/gemma-3-4b-it:free",
    openrouterProvider: normalizeOptionalText(configMap.get("openrouter_provider")) || "auto",
    mistralApiKey: sanitizeApiKey(configMap.get("mistral_api_key")),
    mistralModel: normalizeOptionalText(configMap.get("mistral_model")) || "mistral-medium-latest",
    nvidiaApiKey: sanitizeApiKey(configMap.get("nvidia_api_key")),
    nvidiaModel: normalizeOptionalText(configMap.get("nvidia_model")) || "nvidia/llama-3.3-nemotron-super-49b-v1",
    usesUserOverride: false
  };
}
async function loadAgentLLMConfig(userId) {
  const row = await db.query.aiAgentConfig.findFirst({
    columns: { llmConfig: true },
    where: eq(aiAgentConfig.userId, userId)
  });
  return normalizeAgentLLMConfig(row?.llmConfig);
}
function applyAgentLLMConfigOverride(baseConfig, overrideConfig, userId) {
  if (overrideConfig.mode !== "custom") {
    return {
      ...baseConfig,
      resolvedUserId: userId,
      usesUserOverride: false
    };
  }
  return {
    provider: overrideConfig.provider || baseConfig.provider,
    groqApiKey: overrideConfig.groqApiKey || baseConfig.groqApiKey,
    groqModel: overrideConfig.groqModel || baseConfig.groqModel,
    openrouterApiKey: overrideConfig.openrouterApiKey || baseConfig.openrouterApiKey,
    openrouterModel: overrideConfig.openrouterModel || baseConfig.openrouterModel,
    openrouterProvider: overrideConfig.openrouterProvider || baseConfig.openrouterProvider,
    mistralApiKey: overrideConfig.mistralApiKey || baseConfig.mistralApiKey,
    mistralModel: overrideConfig.mistralModel || baseConfig.mistralModel,
    nvidiaApiKey: overrideConfig.nvidiaApiKey || baseConfig.nvidiaApiKey,
    nvidiaModel: overrideConfig.nvidiaModel || baseConfig.nvidiaModel,
    resolvedUserId: userId,
    usesUserOverride: true
  };
}
async function getResolvedLLMConfig(userId) {
  const effectiveUserId = normalizeOptionalText(userId) || getLLMUserContext();
  const cacheKey = buildCacheKey(effectiveUserId);
  const cached = readCachedConfig(cacheKey);
  if (cached) {
    return cached;
  }
  const globalConfig = await loadGlobalLLMConfig();
  if (!effectiveUserId) {
    return writeCachedConfig(cacheKey, globalConfig);
  }
  const overrideConfig = await loadAgentLLMConfig(effectiveUserId);
  const resolvedConfig = applyAgentLLMConfigOverride(globalConfig, overrideConfig, effectiveUserId);
  return writeCachedConfig(cacheKey, resolvedConfig);
}
function invalidateResolvedLLMConfigCache(userId) {
  if (userId) {
    llmConfigCache.delete(buildCacheKey(userId));
    return;
  }
  llmConfigCache.clear();
}

// server/mistralClient.ts
var AudioTranscriptionError = class extends Error {
  constructor(message, options) {
    super(message, options?.cause ? { cause: options.cause } : void 0);
    this.name = "AudioTranscriptionError";
    this.statusCode = options?.statusCode;
    this.retryable = options?.retryable ?? false;
    this.retryAfterMs = options?.retryAfterMs;
  }
};
function getAudioTranscriptionStatusCode(error) {
  const status = error?.statusCode ?? error?.status ?? error?.response?.status ?? error?.cause?.statusCode ?? error?.cause?.status;
  return typeof status === "number" && Number.isFinite(status) ? status : void 0;
}
function parseRetryAfterHeader(rawValue) {
  if (typeof rawValue === "number" && Number.isFinite(rawValue) && rawValue > 0) {
    return rawValue * 1e3;
  }
  if (typeof rawValue !== "string") {
    return void 0;
  }
  const trimmed = rawValue.trim();
  if (!trimmed) {
    return void 0;
  }
  const seconds = Number(trimmed);
  if (Number.isFinite(seconds) && seconds > 0) {
    return seconds * 1e3;
  }
  const dateMs = Date.parse(trimmed);
  if (Number.isFinite(dateMs)) {
    const diffMs = dateMs - Date.now();
    return diffMs > 0 ? diffMs : void 0;
  }
  return void 0;
}
function getRetryAfterMsFromError(error) {
  const candidates = [
    error?.retryAfterMs,
    error?.retryAfter,
    error?.response?.headers?.get?.("retry-after"),
    error?.response?.headers?.["retry-after"],
    error?.headers?.get?.("retry-after"),
    error?.headers?.["retry-after"],
    error?.cause?.response?.headers?.get?.("retry-after")
  ];
  for (const candidate of candidates) {
    const parsed = parseRetryAfterHeader(candidate);
    if (parsed) {
      return parsed;
    }
  }
  return void 0;
}
function normalizeAudioTranscriptionErrorMessage(error) {
  if (typeof error?.message === "string" && error.message.trim()) {
    return error.message.trim();
  }
  if (typeof error === "string" && error.trim()) {
    return error.trim();
  }
  return "Falha ao transcrever o \xE1udio.";
}
function isRetryableAudioTranscriptionError(error) {
  if (error instanceof AudioTranscriptionError) {
    return error.retryable;
  }
  const statusCode = getAudioTranscriptionStatusCode(error);
  const message = normalizeAudioTranscriptionErrorMessage(error).toLowerCase();
  return statusCode === 408 || statusCode === 425 || statusCode === 429 || statusCode === 500 || statusCode === 502 || statusCode === 503 || statusCode === 504 || statusCode === 520 || statusCode === 521 || statusCode === 522 || statusCode === 523 || statusCode === 524 || message.includes("rate limit") || message.includes("too many requests") || message.includes("temporarily unavailable") || message.includes("temporarily busy") || message.includes("temporariamente indisponivel") || message.includes("temporariamente ocupado") || message.includes("timeout") || message.includes("timed out") || message.includes("connection") || message.includes("overloaded");
}
function getAudioTranscriptionRetryAfterMs(error) {
  if (error instanceof AudioTranscriptionError) {
    return error.retryAfterMs;
  }
  return getRetryAfterMsFromError(error);
}
function resolveAudioTranscriptionHttpStatus(error) {
  if (error instanceof AudioTranscriptionError && typeof error.statusCode === "number") {
    return error.statusCode;
  }
  const statusCode = getAudioTranscriptionStatusCode(error);
  if (typeof statusCode === "number") {
    return statusCode;
  }
  return isRetryableAudioTranscriptionError(error) ? 503 : 500;
}
function formatAudioTranscriptionErrorMessage(error) {
  const rawMessage = normalizeAudioTranscriptionErrorMessage(error);
  if (isRetryableAudioTranscriptionError(error)) {
    return "O provedor de \xE1udio est\xE1 temporariamente ocupado. O sistema tentou novamente sozinho e ainda est\xE1 aguardando uma janela livre.";
  }
  return rawMessage || "Falha ao transcrever o \xE1udio.";
}
function invalidateMistralKeyCache() {
  console.log(`[Mistral] Cache da API key invalidado`);
}
function sanitizeApiKey2(key) {
  return key.trim().replace(/[\r\n\t\s]/g, "");
}
async function resolveApiKey(userId) {
  const config = await getResolvedLLMConfig(userId);
  const fromConfig = sanitizeApiKey2(config.mistralApiKey);
  if (fromConfig.length >= 32) {
    console.log(
      `[Mistral] Using API key from ${config.usesUserOverride ? `USER ${config.resolvedUserId}` : "GLOBAL CONFIG"} (${fromConfig.length} chars)`
    );
    return fromConfig;
  }
  if (process.env.MISTRAL_API_KEY) {
    const envKey = sanitizeApiKey2(process.env.MISTRAL_API_KEY);
    if (envKey.length >= 32) {
      console.log(`[Mistral] Using API key from ENVIRONMENT (${envKey.length} chars)`);
      return envKey;
    }
  }
  if (globalMockClient) return "mock-key";
  throw new Error("Mistral API Key not configured or invalid (must be at least 32 chars)");
}
async function resolveOpenRouterKey(userId) {
  const config = await getResolvedLLMConfig(userId);
  const fromConfig = sanitizeApiKey2(config.openrouterApiKey);
  if (fromConfig.length > 20) {
    console.log(
      `[OpenRouter] Using API key from ${config.usesUserOverride ? `USER ${config.resolvedUserId}` : "GLOBAL CONFIG"} (${fromConfig.length} chars)`
    );
    return fromConfig;
  }
  if (process.env.OPENROUTER_API_KEY && process.env.OPENROUTER_API_KEY.length > 20) {
    const envKey = sanitizeApiKey2(process.env.OPENROUTER_API_KEY);
    console.log(`[OpenRouter] Using API key from ENVIRONMENT (${envKey.length} chars)`);
    return envKey;
  }
  return null;
}
async function analyzeImageWithOpenRouter(imageUrl, prompt, userId) {
  const apiKey = await resolveOpenRouterKey(userId);
  if (!apiKey) {
    return null;
  }
  const candidateModels = [
    "google/gemma-3-4b-it:free",
    "qwen/qwen2.5-vl-72b-instruct:free"
  ];
  for (const model of candidateModels) {
    try {
      console.log(`[OpenRouter] Trying vision fallback with model: ${model}`);
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://agentezap.online",
          "X-Title": "AgenteZap"
        },
        body: JSON.stringify({
          model,
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: prompt },
                {
                  type: "image_url",
                  image_url: {
                    url: imageUrl
                  }
                }
              ]
            }
          ],
          temperature: 0,
          max_tokens: 300
        })
      });
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[OpenRouter] Vision fallback failed on ${model}: ${response.status} - ${errorText}`);
        continue;
      }
      const data = await response.json();
      const content = data?.choices?.[0]?.message?.content;
      if (typeof content === "string" && content.trim().length > 0) {
        console.log(`[OpenRouter] Vision fallback succeeded with model: ${model}`);
        return content.trim();
      }
    } catch (error) {
      console.error(`[OpenRouter] Vision fallback exception on ${model}:`, error);
    }
  }
  return null;
}
var globalMockClient = null;
function setMockMistralClient(mock) {
  globalMockClient = mock;
}
async function getMistralClient(userId) {
  if (globalMockClient) return globalMockClient;
  const apiKey = await resolveApiKey(userId);
  return new Mistral({ apiKey });
}
async function transcribeAudioWithMistral(audioBuffer, options) {
  try {
    const mistral = await getMistralClient(options?.userId);
    const model = options?.model || process.env.MISTRAL_TRANSCRIPTION_MODEL || "voxtral-mini-latest";
    const response = await mistral.audio.transcriptions.complete({
      model,
      file: {
        fileName: options?.fileName || "audio.ogg",
        content: audioBuffer
      },
      language: options?.language ?? void 0
    });
    if (!response || typeof response.text !== "string") {
      return null;
    }
    return response.text.trim();
  } catch (error) {
    console.error("Error transcribing audio with Mistral:", error);
    if (options?.throwOnFailure) {
      throw error;
    }
    return null;
  }
}
async function analyzeImageWithMistral(imageUrl, prompt = "Descreva esta imagem detalhadamente para que eu possa entender o que \xE9 (ex: card\xE1pio, produto, tabela de pre\xE7os, etc).", userId) {
  try {
    if (globalMockClient && globalMockClient.analyzeImageWithMistral) {
      return globalMockClient.analyzeImageWithMistral(imageUrl);
    }
    const mistral = await getMistralClient(userId);
    const model = "pixtral-12b-2409";
    const response = await mistral.chat.complete({
      model,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: prompt },
            { type: "image_url", imageUrl }
          ]
        }
      ]
    });
    if (!response || !response.choices || response.choices.length === 0) {
      return null;
    }
    return response.choices[0].message.content;
  } catch (error) {
    console.error("Error analyzing image with Mistral:", error);
    return await analyzeImageWithOpenRouter(imageUrl, prompt, userId);
  }
}
async function analyzeImageForAdmin(imageUrl) {
  try {
    if (globalMockClient && globalMockClient.analyzeImageForAdmin) {
      return globalMockClient.analyzeImageForAdmin(imageUrl);
    }
    const mistral = await getMistralClient();
    const model = "pixtral-12b-2409";
    const userPrompt = `Por favor, analise a imagem fornecida e responda em JSON com duas chaves: "summary" (uma etiqueta curta, 2-4 palavras, sem pontua\xE7\xE3o, ex: cardapio, foto_produto, logo) e "description" (uma frase curta descrevendo o conte\xFAdo, em portugu\xEAs). Responda apenas o JSON.`;
    const response = await mistral.chat.complete({
      model,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: userPrompt },
            { type: "image_url", imageUrl }
          ]
        }
      ],
      maxTokens: 200,
      temperature: 0
    });
    const raw = response?.choices?.[0]?.message?.content;
    if (!raw || typeof raw !== "string") return null;
    const jsonTextMatch = raw.match(/\{[\s\S]*\}/);
    const jsonText = jsonTextMatch ? jsonTextMatch[0] : raw;
    try {
      const parsed = JSON.parse(jsonText);
      return {
        summary: String(parsed.summary || parsed.tag || "").trim(),
        description: String(parsed.description || parsed.desc || "").trim()
      };
    } catch (e) {
      const description = raw.trim();
      const summary = description.split(/[.,;\n]/)[0].split(" ").slice(0, 3).join("_").toLowerCase();
      return { summary, description };
    }
  } catch (error) {
    console.error("Error analyzing image for admin with Mistral:", error);
    const fallbackRaw = await analyzeImageWithOpenRouter(
      imageUrl,
      `Analise a imagem e responda em JSON com {"summary":"etiqueta_curta","description":"frase curta em portugues"}. Responda apenas o JSON.`
    );
    if (!fallbackRaw) return null;
    const jsonTextMatch = fallbackRaw.match(/\{[\s\S]*\}/);
    const jsonText = jsonTextMatch ? jsonTextMatch[0] : fallbackRaw;
    try {
      const parsed = JSON.parse(jsonText);
      return {
        summary: String(parsed.summary || parsed.tag || "").trim(),
        description: String(parsed.description || parsed.desc || "").trim()
      };
    } catch {
      const description = fallbackRaw.trim();
      const summary = description.split(/[.,;\n]/)[0].split(" ").slice(0, 3).join("_").toLowerCase();
      return { summary, description };
    }
  }
}
async function classifyMediaWithAI(input) {
  const startTime = Date.now();
  try {
    console.log(`
\u{1F916} [MEDIA AI] \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550`);
    console.log(`\u{1F916} [MEDIA AI] Iniciando classifica\xE7\xE3o de m\xEDdia com IA...`);
    const { clientMessage, conversationHistory, mediaLibrary, sentMedias = [] } = input;
    const availableMedia = mediaLibrary.filter((m) => {
      const alreadySent = sentMedias.some((sent) => sent.toUpperCase() === m.name.toUpperCase());
      return !alreadySent && m.isActive !== false;
    });
    if (availableMedia.length === 0) {
      console.log(`\u{1F916} [MEDIA AI] \u274C Nenhuma m\xEDdia dispon\xEDvel`);
      return { shouldSend: false, mediaName: null, confidence: 0, reason: "Nenhuma m\xEDdia dispon\xEDvel" };
    }
    const clientMsgCount = conversationHistory.filter((m) => !m.fromMe).length;
    const isFirstMessage = clientMsgCount <= 1;
    const recentHistory = conversationHistory.slice(-10).map((m) => `${m.fromMe ? "Agente" : "Cliente"}: ${m.text || "(sem texto)"}`).join("\n");
    const mediaListForAI = availableMedia.map((m, i) => `${i + 1}. NOME: "${m.name}" | TIPO: ${m.type} | QUANDO USAR: ${m.whenToUse || "n\xE3o especificado"}`).join("\n");
    const systemPrompt = `Voc\xEA \xE9 um sistema de classifica\xE7\xE3o de m\xEDdia para um chatbot de WhatsApp.
Sua tarefa \xE9 analisar a conversa e decidir SE e QUAL m\xEDdia deve ser enviada ao cliente.

## REGRAS IMPORTANTES:
1. Se for PRIMEIRA MENSAGEM do cliente (sauda\xE7\xE3o como "oi", "ol\xE1", "bom dia"), procure por m\xEDdia de boas-vindas/in\xEDcio
2. Apenas recomende m\xEDdia se for CLARAMENTE RELEVANTE para o contexto
3. N\xC3O recomende m\xEDdia se o cliente estiver fazendo perguntas espec\xEDficas que n\xE3o precisam de m\xEDdia
4. Leia o campo "QUANDO USAR" de cada m\xEDdia para entender quando \xE9 apropriado enviar
5. Se nenhuma m\xEDdia for claramente apropriada, responda com NO_MEDIA
6. Confian\xE7a deve ser entre 0-100 (apenas envie se > 60)

## RESPONDA APENAS EM JSON:
{"decision": "SEND" ou "NO_MEDIA", "mediaName": "NOME_EXATO_DA_MIDIA" ou null, "confidence": 0-100, "reason": "explica\xE7\xE3o breve"}`;
    const userPrompt = `## CONTEXTO:
\xC9 a primeira mensagem do cliente? ${isFirstMessage ? "SIM" : "N\xC3O"}
Mensagem atual do cliente: "${clientMessage}"

## HIST\xD3RICO RECENTE:
${recentHistory || "(primeira intera\xE7\xE3o)"}

## M\xCDDIAS DISPON\xCDVEIS:
${mediaListForAI}

## M\xCDDIAS J\xC1 ENVIADAS (n\xE3o repetir):
${sentMedias.join(", ") || "nenhuma"}

Analise e decida se alguma m\xEDdia deve ser enviada. Responda APENAS o JSON.`;
    const mistral = await getMistralClient();
    const response = await mistral.chat.complete({
      model: "mistral-small-latest",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      maxTokens: 150,
      temperature: 0.1
      // Baixa para decisões mais consistentes
    });
    const elapsedMs = Date.now() - startTime;
    if (!response || !response.choices || response.choices.length === 0) {
      console.log(`\u{1F916} [MEDIA AI] \u274C Sem resposta da API (${elapsedMs}ms)`);
      return { shouldSend: false, mediaName: null, confidence: 0, reason: "Sem resposta da API" };
    }
    const rawResponse = response.choices[0].message.content;
    console.log(`\u{1F916} [MEDIA AI] \u{1F4E5} Resposta bruta (${elapsedMs}ms): ${rawResponse}`);
    const jsonMatch = rawResponse.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.log(`\u{1F916} [MEDIA AI] \u26A0\uFE0F N\xE3o conseguiu extrair JSON`);
      return { shouldSend: false, mediaName: null, confidence: 0, reason: "Resposta n\xE3o \xE9 JSON v\xE1lido" };
    }
    try {
      const parsed = JSON.parse(jsonMatch[0]);
      const result = {
        shouldSend: parsed.decision === "SEND" && parsed.confidence >= 60,
        mediaName: parsed.mediaName || null,
        confidence: parsed.confidence || 0,
        reason: parsed.reason || "Sem raz\xE3o especificada"
      };
      console.log(`\u{1F916} [MEDIA AI] \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550`);
      if (result.shouldSend) {
        console.log(`\u{1F916} [MEDIA AI] \u2705 DECIS\xC3O: ENVIAR "${result.mediaName}"`);
      } else {
        console.log(`\u{1F916} [MEDIA AI] \u274C DECIS\xC3O: N\xC3O ENVIAR`);
      }
      console.log(`\u{1F916} [MEDIA AI] \u{1F4CA} Confian\xE7a: ${result.confidence}%`);
      console.log(`\u{1F916} [MEDIA AI] \u{1F4A1} Raz\xE3o: ${result.reason}`);
      console.log(`\u{1F916} [MEDIA AI] \u23F1\uFE0F Tempo: ${elapsedMs}ms`);
      console.log(`\u{1F916} [MEDIA AI] \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
`);
      return result;
    } catch (parseError) {
      console.log(`\u{1F916} [MEDIA AI] \u26A0\uFE0F Erro ao parsear JSON: ${parseError}`);
      return { shouldSend: false, mediaName: null, confidence: 0, reason: "Erro ao parsear resposta" };
    }
  } catch (error) {
    console.error(`\u{1F916} [MEDIA AI] \u274C ERRO: ${error.message}`);
    return { shouldSend: false, mediaName: null, confidence: 0, reason: `Erro: ${error.message}` };
  }
}
async function generateWithMistral(systemPrompt, userMessage, options) {
  try {
    const mistral = await getMistralClient();
    const model = options?.model || "mistral-small-latest";
    const response = await mistral.chat.complete({
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      maxTokens: options?.maxTokens || 500,
      temperature: options?.temperature ?? 0.7
    });
    if (!response || !response.choices || response.choices.length === 0) {
      throw new Error("No response from Mistral");
    }
    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Error generating text with Mistral:", error);
    throw new Error(`Failed to generate text: ${error.message}`);
  }
}

export {
  runWithLLMUserContext,
  getResolvedLLMConfig,
  invalidateResolvedLLMConfigCache,
  AudioTranscriptionError,
  isRetryableAudioTranscriptionError,
  getAudioTranscriptionRetryAfterMs,
  resolveAudioTranscriptionHttpStatus,
  formatAudioTranscriptionErrorMessage,
  invalidateMistralKeyCache,
  resolveApiKey,
  setMockMistralClient,
  getMistralClient,
  transcribeAudioWithMistral,
  analyzeImageWithMistral,
  analyzeImageForAdmin,
  classifyMediaWithAI,
  generateWithMistral
};
