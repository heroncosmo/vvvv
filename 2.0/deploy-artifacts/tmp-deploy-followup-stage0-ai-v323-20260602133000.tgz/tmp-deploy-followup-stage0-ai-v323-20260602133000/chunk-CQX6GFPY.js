import {
  repairMojibakeText
} from "./chunk-K6J2PMOD.js";

// server/adminAgentGraphState.ts
function createInitialGraphState(phoneNumber, contactName) {
  const now = Date.now();
  return {
    phoneNumber,
    contactName,
    mode: "onboarding",
    onboardingStage: "business",
    capturedSlots: {},
    stickyFacts: {},
    agentConfig: {},
    workflowKind: "generic",
    usesScheduling: false,
    wantsAutoFollowUp: false,
    deliveryStatus: "not_started",
    awaitingPaymentProof: false,
    awaitingPaymentChoice: false,
    uploadedMedia: [],
    conversationHistory: [],
    turnIndex: 0,
    createdAt: now,
    updatedAt: now
  };
}
function fromLegacySession(session) {
  const now = Date.now();
  const profile = session.setupProfile || {};
  const capturedSlots = {};
  if (profile.answeredBusiness && profile.businessSummary) {
    capturedSlots["businessSummary"] = {
      key: "businessSummary",
      value: profile.businessSummary,
      capturedAt: now,
      turnIndex: 0,
      confidence: 1
    };
  }
  if (profile.mainOffer) {
    capturedSlots["mainOffer"] = {
      key: "mainOffer",
      value: profile.mainOffer,
      capturedAt: now,
      turnIndex: 0,
      confidence: 1
    };
  }
  if (profile.answeredBehavior && profile.desiredAgentBehavior) {
    capturedSlots["desiredAgentBehavior"] = {
      key: "desiredAgentBehavior",
      value: profile.desiredAgentBehavior,
      capturedAt: now,
      turnIndex: 0,
      confidence: 1
    };
  }
  if (profile.answeredWorkflow) {
    capturedSlots["workflowPreference"] = {
      key: "workflowPreference",
      value: profile.wantsAutoFollowUp ? "follow_up" : "no_follow_up",
      capturedAt: now,
      turnIndex: 0,
      confidence: 1
    };
  }
  const stickyFacts = {};
  if (profile.businessSummary) {
    stickyFacts["businessSummary"] = {
      key: "businessSummary",
      value: profile.businessSummary,
      source: "user",
      capturedAt: now
    };
  }
  if (session.agentConfig?.company) {
    stickyFacts["company"] = {
      key: "company",
      value: session.agentConfig.company,
      source: "user",
      capturedAt: now
    };
  }
  return {
    phoneNumber: session.phoneNumber,
    contactName: session.contactName,
    linkedUserId: session.userId,
    mode: session.flowState || "onboarding",
    onboardingStage: profile.questionStage || "business",
    capturedSlots,
    stickyFacts,
    agentConfig: session.agentConfig || {},
    workflowKind: profile.workflowKind || "generic",
    usesScheduling: profile.usesScheduling || false,
    wantsAutoFollowUp: profile.wantsAutoFollowUp || false,
    restaurantOrderMode: profile.restaurantOrderMode,
    workDays: profile.workDays,
    workStartTime: profile.workStartTime,
    workEndTime: profile.workEndTime,
    deliveryStatus: "not_started",
    awaitingPaymentProof: session.awaitingPaymentProof || false,
    awaitingPaymentChoice: false,
    pendingMedia: session.pendingMedia,
    uploadedMedia: session.uploadedMedia || [],
    memorySummary: session.memorySummary,
    conversationHistory: (session.conversationHistory || []).map((m) => ({
      role: m.role,
      content: m.content,
      timestamp: m.timestamp instanceof Date ? m.timestamp.getTime() : m.timestamp
    })),
    turnIndex: session.conversationHistory?.length || 0,
    createdAt: now,
    updatedAt: now
  };
}
function isOnboardingComplete(state) {
  const hasBusinessSlot = !!state.capturedSlots["businessSummary"];
  const hasBehaviorSlot = !!state.capturedSlots["desiredAgentBehavior"];
  const hasWorkflowSlot = !!state.capturedSlots["workflowPreference"];
  if (!hasBusinessSlot || !hasBehaviorSlot || !hasWorkflowSlot) return false;
  if (state.usesScheduling || state.workflowKind === "scheduling" || state.workflowKind === "salon") {
    if (!state.workDays?.length || !state.workStartTime || !state.workEndTime) return false;
  }
  return true;
}
function getNextPendingStage(state) {
  if (!state.capturedSlots["businessSummary"]) return "business";
  if (!state.capturedSlots["desiredAgentBehavior"]) return "behavior";
  if (!state.capturedSlots["workflowPreference"]) return "workflow";
  if ((state.usesScheduling || state.workflowKind === "scheduling" || state.workflowKind === "salon") && (!state.workDays?.length || !state.workStartTime || !state.workEndTime)) {
    return "hours";
  }
  return null;
}

// server/adminAgentGraphClassifier.ts
function normalizeForClassification(text) {
  return (text || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s@#.-]/g, " ").replace(/\s+/g, " ").trim();
}
var COMMAND_PATTERNS = [
  { pattern: /^#(limpar|reset|novo)$/i, intent: "command" },
  { pattern: /^#reset-suave$/i, intent: "command" },
  { pattern: /^#(sair|exit|voltar)$/i, intent: "exit_test" },
  { pattern: /^#(status|info)$/i, intent: "command" },
  { pattern: /^#(debug|log)$/i, intent: "command" },
  { pattern: /^#(plano|preco|valor)$/i, intent: "change_plan" }
];
var AFFIRMATIVE_PATTERNS = [
  /\bsim\b/,
  /\bok\b/,
  /\btudo\b/,
  /\bpode\s*ser\b/,
  /\bisso\b/,
  /\bcom\s*certeza\b/,
  /\bclaro\b/,
  /\bexato\b/,
  /\bperfeito\b/,
  /\bcerto\b/,
  /\bconfirm(o|a|ado)?\b/,
  /\bvamos\b/,
  /\bbora\b/,
  /\bfechado\b/,
  /\btop\b/,
  /\bbeleza\b/,
  /\bshow\b/,
  /\bvaleu\b/,
  /\bfechar\b/,
  /\bquero\b/
];
var NEGATIVE_PATTERNS = [
  /\bnao\b/,
  /\bneg(ativo|a)?\b/,
  /\bsem\s+(isso|follow|fup)\b/,
  /\bnao\s+precisa\b/,
  /\bnao\s+quero\b/,
  /\bcancela\b/,
  /\bdesist(o|ir|i)\b/
];
var GREETING_PATTERNS = [
  /^(oi|ola|hey|eae|fala|bom\s*dia|boa\s*(tarde|noite)|salve)\b/,
  /^(hello|hi|yo)\b/
];
var RESUME_PATTERNS = [
  /\b(followp|fup|follow\s*up|follow-up)\b/,
  /\b(continuar|retomar|voltar)\b/,
  /\b(onde\s+parei|onde\s+paramos)\b/,
  /\b(ja\s+mandei|ja\s+enviei|ja\s+respondi)\b/
];
var TEST_PATTERNS = [
  /\b(testar|teste|testa|experimentar|simular)\b/,
  /\b(quero\s+ver|ver\s+como\s+funciona)\b/,
  /\b(modo\s+teste|simulador)\b/
];
var PAYMENT_PATTERNS = [
  /\b(comprovante|pix|pagamento|pag(uei|ar)|transferi|deposito)\b/,
  /\b(recibo|nota|comprov)\b/
];
var SUPPORT_PATTERNS = [
  /\b(ajuda|help|suporte|problema|erro|bug|nao\s+funciona)\b/,
  /\b(como\s+faz|como\s+funciona|como\s+configur)\b/,
  /\b(duvida|pergunta)\b/
];
var SIDE_QUESTION_PATTERNS = [
  /\bqual\s+(o\s+)?(preco|valor|custo)\b/,
  /\bquanto\s+(custa|e|fica)\b/,
  /\b(funcionalidade|recurso|feature)\b/,
  /\bcomo\b.*\b(funciona|configura|faz)\b/,
  /\btem\s+(suporte|garantia|teste)\b/,
  /\bo\s+que\s+(e|significa|faz)\b/,
  /\?$/
];
function extractBusinessInfo(text) {
  const normalized = normalizeForClassification(text);
  const businessPatterns = [
    /(?:sou\s+dono|tenho|minha?\s+(?:empresa|loja|negocio|clinica|escritorio))\s+(?:de?\s+)?(.{5,})/,
    /(?:trabalho\s+com|vendo|ofereco|faco)\s+(.{5,})/,
    /(?:e\s+uma?\s+|somos\s+uma?\s+)(.{5,})/
  ];
  for (const pat of businessPatterns) {
    const match = normalized.match(pat);
    if (match?.[1]) return match[1].trim();
  }
  if (normalized.length > 15 && !normalized.includes("?")) return void 0;
  return void 0;
}
function extractBehaviorInfo(text) {
  const normalized = normalizeForClassification(text);
  const behaviorPatterns = [
    /(?:quero\s+que|preciso\s+que|gostaria\s+que)\s+(?:o\s+(?:agente|bot|robo)\s+)?(.{5,})/,
    /(?:deve\s+ser|precisa\s+ser|tem\s+que\s+ser)\s+(.{5,})/,
    /(?:tom|estilo|personalidade|jeito)\s+(.{5,})/,
    /(?:formal|informal|amigavel|profissional|descontraido)/
  ];
  for (const pat of behaviorPatterns) {
    const match = normalized.match(pat);
    if (match?.[1]) return match[1].trim();
  }
  return void 0;
}
function extractWorkflowInfo(text) {
  const normalized = normalizeForClassification(text);
  if (/\b(follow\s*u?p?|followp|fup)\b/.test(normalized) || /\btudo\b/.test(normalized) || /\bpode\s*ser\b/.test(normalized) || /\bquero\b/.test(normalized) || /\bcom\s*certeza\b/.test(normalized) || /\bclaro\b/.test(normalized) || /\brecuperar\b/.test(normalized) || /\bcontinuar\s+tentando\b/.test(normalized)) {
    return { wantsFollowUp: true };
  }
  if (/\bsem\s+follow\b/.test(normalized) || /\bnao\s+precisa\b/.test(normalized) || /\bsomente\s+venda\b/.test(normalized) || /\bso\s+venda\b/.test(normalized) || /\bapenas\s+venda\b/.test(normalized)) {
    return { wantsFollowUp: false };
  }
  if (/\b(nao|sem|nunca|nenhum)\b/.test(normalized) && /\b(agenda|agendamento|horario|marcar)\b/.test(normalized)) {
    return { wantsFollowUp: false };
  }
  if (/\b(agenda|agendar|agendamento|horario|marcar|consulta)\b/.test(normalized)) {
    return { wantsScheduling: true };
  }
  return void 0;
}
function extractHoursInfo(text) {
  const normalized = normalizeForClassification(text);
  const hasDays = /\b(segunda|terca|quarta|quinta|sexta|sabado|domingo|seg|ter|qua|qui|sex|sab|dom)\b/.test(normalized);
  const hasHours = /\b\d{1,2}[\s:h]\d{0,2}\b/.test(normalized);
  if (hasDays || hasHours) {
    return {
      days: hasDays ? text : void 0,
      hours: hasHours ? text : void 0
    };
  }
  return void 0;
}
function classifyTurn(rawInput, state, mediaType, mediaUrl) {
  const normalized = normalizeForClassification(rawInput);
  const isMedia = !!(mediaType && mediaUrl);
  const result = {
    intent: "unclear",
    confidence: 0.3,
    hasBusinessInfo: false,
    hasBehaviorInfo: false,
    hasWorkflowInfo: false,
    hasHoursInfo: false,
    isAffirmative: false,
    isNegative: false,
    isMediaMessage: isMedia,
    mediaType,
    mediaUrl,
    normalizedInput: normalized,
    originalInput: rawInput,
    extractedSlots: {}
  };
  for (const cmd of COMMAND_PATTERNS) {
    if (cmd.pattern.test(rawInput)) {
      result.intent = cmd.intent;
      result.confidence = 1;
      return result;
    }
  }
  if (isMedia && state.mode !== "test_mode") {
    result.intent = "media_upload";
    result.confidence = 0.9;
    return result;
  }
  if (isMedia && PAYMENT_PATTERNS.some((p) => p.test(normalized))) {
    result.intent = "payment_proof";
    result.confidence = 0.95;
    return result;
  }
  if (!isMedia && PAYMENT_PATTERNS.some((p) => p.test(normalized)) && state.mode === "payment_pending") {
    result.intent = "payment_proof";
    result.confidence = 0.8;
    return result;
  }
  if (RESUME_PATTERNS.some((p) => p.test(normalized))) {
    result.intent = "resume_session";
    result.confidence = 0.85;
    return result;
  }
  const isShortMessage = normalized.split(/\s+/).length <= 5;
  const hasExplicitTestIntent = /\b(modo\s*teste|simulador|quero\s+ver|ver\s+como\s+funciona)\b/.test(normalized);
  if ((isShortMessage || hasExplicitTestIntent) && TEST_PATTERNS.some((p) => p.test(normalized))) {
    result.intent = "test_request";
    result.confidence = 0.85;
    return result;
  }
  result.isAffirmative = AFFIRMATIVE_PATTERNS.some((p) => p.test(normalized));
  result.isNegative = NEGATIVE_PATTERNS.some((p) => p.test(normalized));
  if (state.mode === "onboarding") {
    const businessInfo = extractBusinessInfo(rawInput);
    const behaviorInfo = extractBehaviorInfo(rawInput);
    const workflowInfo = extractWorkflowInfo(rawInput);
    const hoursInfo = extractHoursInfo(rawInput);
    result.hasBusinessInfo = !!businessInfo;
    result.hasBehaviorInfo = !!behaviorInfo;
    result.hasWorkflowInfo = !!workflowInfo;
    result.hasHoursInfo = !!hoursInfo;
    if (businessInfo) result.extractedSlots["businessSummary"] = businessInfo;
    if (behaviorInfo) result.extractedSlots["desiredAgentBehavior"] = behaviorInfo;
    if (workflowInfo) {
      result.extractedSlots["workflowPreference"] = JSON.stringify(workflowInfo);
    }
    if (hoursInfo) {
      result.extractedSlots["hoursInfo"] = JSON.stringify(hoursInfo);
    }
    const isSideQuestion = SIDE_QUESTION_PATTERNS.some((p) => p.test(normalized));
    switch (state.onboardingStage) {
      case "business":
        if (result.hasBusinessInfo || !isSideQuestion && normalized.length > 10 && !normalized.includes("?")) {
          result.intent = "answer_stage";
          result.confidence = result.hasBusinessInfo ? 0.9 : 0.6;
          return result;
        }
        break;
      case "behavior":
        if (result.hasBehaviorInfo || result.isAffirmative || !isSideQuestion && normalized.length > 10 && !normalized.includes("?")) {
          result.intent = "answer_stage";
          result.confidence = result.hasBehaviorInfo ? 0.9 : 0.6;
          return result;
        }
        break;
      case "workflow":
        if (result.hasWorkflowInfo || result.isAffirmative || result.isNegative) {
          result.intent = "answer_stage";
          result.confidence = result.hasWorkflowInfo ? 0.9 : 0.7;
          return result;
        }
        break;
      case "hours":
        if (result.hasHoursInfo || normalized.length > 5 && /\d/.test(normalized)) {
          result.intent = "answer_stage";
          result.confidence = result.hasHoursInfo ? 0.9 : 0.6;
          return result;
        }
        break;
    }
  }
  if (GREETING_PATTERNS.some((p) => p.test(normalized)) && normalized.split(/\s+/).length <= 4) {
    result.intent = "greeting";
    result.confidence = 0.8;
    return result;
  }
  if (result.isAffirmative && normalized.split(/\s+/).length <= 3) {
    result.intent = "confirmation";
    result.confidence = 0.75;
    return result;
  }
  if (result.isNegative && normalized.split(/\s+/).length <= 3) {
    result.intent = "negation";
    result.confidence = 0.75;
    return result;
  }
  if (SIDE_QUESTION_PATTERNS.some((p) => p.test(normalized))) {
    result.intent = "side_question";
    result.confidence = 0.65;
    return result;
  }
  if (SUPPORT_PATTERNS.some((p) => p.test(normalized))) {
    result.intent = "support";
    result.confidence = 0.7;
    return result;
  }
  if (state.mode === "onboarding" && normalized.length > 5) {
    result.intent = "answer_stage";
    result.confidence = 0.4;
    return result;
  }
  result.intent = "unclear";
  result.confidence = 0.3;
  return result;
}

// server/adminAgentGraphPolicy.ts
function evaluatePolicy(state, classification) {
  const { intent, confidence } = classification;
  if (intent === "command") {
    return {
      action: "execute_command",
      reason: `Comando especial detectado: ${classification.originalInput}`,
      shouldAudit: true
    };
  }
  if (intent === "exit_test") {
    return {
      action: "exit_test_mode",
      reason: "Usu\xE1rio solicitou sair do modo teste",
      shouldAudit: true
    };
  }
  if (intent === "payment_proof") {
    return {
      action: "process_payment",
      reason: "Comprovante de pagamento detectado",
      shouldAudit: true
    };
  }
  if (intent === "media_upload" && classification.isMediaMessage) {
    return {
      action: "upload_media",
      reason: "Upload de m\xEDdia detectado",
      shouldAudit: true
    };
  }
  if (intent === "test_request") {
    if (state.mode === "onboarding" && !isOnboardingComplete(state)) {
      return {
        action: "stay_stage",
        pendingSlot: getNextPendingStage(state) || "business",
        reason: "Usu\xE1rio quer testar mas onboarding ainda n\xE3o terminou",
        shouldAudit: true
      };
    }
    return {
      action: "enter_test_mode",
      reason: "Usu\xE1rio solicitou teste do agente",
      shouldAudit: true
    };
  }
  if (intent === "resume_session") {
    const nextStage = getNextPendingStage(state);
    if (nextStage) {
      return {
        action: "stay_stage",
        pendingSlot: nextStage,
        reason: "Sess\xE3o retomada, continuando do est\xE1gio pendente",
        shouldAudit: true
      };
    }
    return {
      action: "generate_response",
      reason: "Sess\xE3o retomada, onboarding j\xE1 completo",
      shouldAudit: false
    };
  }
  if (state.mode === "onboarding") {
    return evaluateOnboardingPolicy(state, classification);
  }
  if (state.mode === "test_mode") {
    return {
      action: "generate_response",
      reason: "Modo teste: encaminhar mensagem ao agente simulado",
      shouldAudit: false
    };
  }
  if (state.mode === "post_test") {
    if (intent === "confirmation") {
      return {
        action: "send_pix",
        reason: "Usu\xE1rio confirmou ap\xF3s teste, enviar PIX",
        shouldAudit: true
      };
    }
    return {
      action: "generate_response",
      reason: "P\xF3s-teste: gerar resposta conversacional",
      shouldAudit: false
    };
  }
  if (state.mode === "payment_pending") {
    return {
      action: "generate_response",
      reason: "Aguardando pagamento: responder sobre status",
      shouldAudit: false
    };
  }
  if (state.mode === "active") {
    if (intent === "prompt_edit") {
      return {
        action: "edit_prompt",
        reason: "Usu\xE1rio quer editar prompt do agente",
        shouldAudit: true
      };
    }
    return {
      action: "generate_response",
      reason: "Conta ativa: responder via LLM",
      shouldAudit: false
    };
  }
  return {
    action: "generate_response",
    reason: "Fallback gen\xE9rico",
    shouldAudit: false
  };
}
function evaluateOnboardingPolicy(state, classification) {
  const { intent, confidence } = classification;
  const currentStage = state.onboardingStage;
  const nextPending = getNextPendingStage(state);
  if (isOnboardingComplete(state)) {
    return {
      action: "create_agent",
      reason: "Todos os slots preenchidos, criar agente automaticamente",
      shouldAudit: true
    };
  }
  if (intent === "side_question") {
    return {
      action: "side_question",
      pendingSlot: currentStage,
      reason: `Pergunta lateral detectada no est\xE1gio ${currentStage}`,
      shouldAudit: true
    };
  }
  if (intent === "greeting" && currentStage === "business") {
    return {
      action: "stay_stage",
      pendingSlot: "business",
      reason: "Sauda\xE7\xE3o inicial, solicitar dados do neg\xF3cio",
      shouldAudit: false
    };
  }
  if (intent === "answer_stage" || intent === "confirmation") {
    if (currentStage === "business" && state.stickyFacts["businessSummary"]) {
      const next = getNextPendingStage(state);
      if (next && next !== "business") {
        return {
          action: "advance_stage",
          nextStage: next,
          reason: "Business j\xE1 respondido (stickyFact), avan\xE7ando para pr\xF3ximo",
          shouldAudit: true
        };
      }
    }
    if (currentStage === "behavior" && state.stickyFacts["desiredAgentBehavior"]) {
      const next = getNextPendingStage(state);
      if (next && next !== "behavior") {
        return {
          action: "advance_stage",
          nextStage: next,
          reason: "Behavior j\xE1 respondido (stickyFact), avan\xE7ando para pr\xF3ximo",
          shouldAudit: true
        };
      }
    }
    switch (currentStage) {
      case "business":
        return {
          action: "advance_stage",
          nextStage: "behavior",
          reason: "Dados do neg\xF3cio recebidos, avan\xE7ar para comportamento",
          shouldAudit: true
        };
      case "behavior":
        return {
          action: "advance_stage",
          nextStage: "workflow",
          reason: "Comportamento definido, avan\xE7ar para workflow",
          shouldAudit: true
        };
      case "workflow":
        const needsHours = wouldNeedHours(state, classification);
        return {
          action: "advance_stage",
          nextStage: needsHours ? "hours" : "ready",
          reason: needsHours ? "Workflow definido, precisa de hor\xE1rios" : "Workflow definido, onboarding completo",
          shouldAudit: true
        };
      case "hours":
        return {
          action: "advance_stage",
          nextStage: "ready",
          reason: "Hor\xE1rios definidos, onboarding completo",
          shouldAudit: true
        };
      case "ready":
        return {
          action: "create_agent",
          reason: "Todos os dados coletados, criar agente",
          shouldAudit: true
        };
    }
  }
  if (intent === "negation" && currentStage === "workflow") {
    return {
      action: "advance_stage",
      nextStage: wouldNeedHours(state, classification) ? "hours" : "ready",
      reason: "Nega\xE7\xE3o no workflow = sem follow-up, avan\xE7ando",
      shouldAudit: true
    };
  }
  return {
    action: "stay_stage",
    pendingSlot: currentStage,
    reason: `N\xE3o foi poss\xEDvel interpretar resposta para est\xE1gio ${currentStage} (confidence: ${confidence.toFixed(2)})`,
    shouldAudit: confidence < 0.5
  };
}
function wouldNeedHours(state, classification) {
  const workflowSlot = classification.extractedSlots?.["workflowPreference"];
  if (workflowSlot) {
    try {
      const parsed = JSON.parse(workflowSlot);
      if (parsed.wantsScheduling) return true;
    } catch {
    }
  }
  if (state.workflowKind === "scheduling" || state.workflowKind === "salon") return true;
  if (state.usesScheduling) return true;
  return false;
}

// server/adminAgentGraphExecutor.ts
var STAGE_QUESTIONS = {
  business: "Vamos comecar! Me conta sobre seu negocio:\n\n- Qual o *nome* da sua empresa/negocio?\n- O que voce *vende ou oferece*?\n- Quem e seu *cliente ideal*?\n\nPode me contar tudo de uma vez, sem problema!",
  behavior: "Otimo! Agora me diz: como voce quer que seu agente se comporte?\n\nEx: _formal_, _descontraido_, _direto ao ponto_, _amigavel_...\n\nOu me conta o que ele deve fazer quando o cliente entrar em contato.",
  workflow: "Perfeito! Sobre o acompanhamento automatico:\n\nVoce quer que o agente faca *follow-up automatico* com clientes que nao responderam?\n\nOu prefere que ele *so atenda* quando o cliente entrar em contato?",
  hours: "Quase la! Me informa os *horarios de funcionamento*:\n\n- Quais *dias* da semana?\n- De que *horas* ate que *horas*?\n\nEx: _Segunda a sexta, 8h as 18h_",
  ready: ""
};
function getStageQuestion(stage) {
  return STAGE_QUESTIONS[stage] || STAGE_QUESTIONS.business;
}
function buildSideQuestionResponse(state, classification) {
  const input = classification.normalizedInput;
  if (/\b(preco|valor|custo|quanto)\b/.test(input)) {
    return `O plano do AgentZap e:

- *Mensal*: R$ 197/mes
- *Anual*: R$ 97/mes (economia de 51%!)

Voce pode assine e testar GRATIS antes de decidir! Acesse: https://agentezap.online/plans

Vamos continuar configurando seu agente? ${getStagePromptHint(state.onboardingStage)}`;
  }
  if (/\b(funcionalidade|recurso|feature|faz o que)\b/.test(input)) {
    return `O AgentZap pode:

- Atender clientes 24/7 no WhatsApp
- Follow-up automatico
- Agendamento inteligente
- Envio de midias (fotos, videos, catalogos)
- Integracoes diversas

Vamos continuar? ${getStagePromptHint(state.onboardingStage)}`;
  }
  if (/\b(como funciona|como faz|como configura)\b/.test(input)) {
    return `E simples! Voce me conta sobre seu negocio, eu crio seu agente, voce testa gratis e se gostar, ativa!

Vamos la? ${getStagePromptHint(state.onboardingStage)}`;
  }
  return `Boa pergunta! Posso te explicar mais depois. Vamos continuar configurando seu agente? ${getStagePromptHint(state.onboardingStage)}`;
}
function getStagePromptHint(stage) {
  switch (stage) {
    case "business":
      return "Me conta sobre seu negocio!";
    case "behavior":
      return "Como voce quer que o agente se comporte?";
    case "workflow":
      return "Quer follow-up automatico?";
    case "hours":
      return "Quais seus horarios de funcionamento?";
    default:
      return "";
  }
}
function captureSlots(state, classification, currentStage) {
  const slots = {};
  const facts = {};
  const now = Date.now();
  const rememberSlot = (key, value, confidence) => {
    if (!value || slots[key]) return;
    slots[key] = {
      key,
      value,
      capturedAt: now,
      turnIndex: state.turnIndex,
      confidence
    };
    facts[key] = {
      key,
      value,
      source: "user",
      capturedAt: now
    };
  };
  if (currentStage === "business") {
    const businessText = classification.extractedSlots?.["businessSummary"] || classification.originalInput;
    if (businessText && businessText.length > 3) {
      rememberSlot("businessSummary", businessText, classification.hasBusinessInfo ? 0.9 : 0.6);
    }
  }
  if (currentStage === "behavior") {
    const behaviorText = classification.extractedSlots?.["desiredAgentBehavior"] || classification.originalInput;
    if (behaviorText && behaviorText.length > 3) {
      rememberSlot("desiredAgentBehavior", behaviorText, classification.hasBehaviorInfo ? 0.9 : 0.6);
    }
  }
  if (currentStage === "workflow") {
    const isAffirmative = classification.isAffirmative;
    const isNegative = classification.isNegative;
    const workflowData = classification.extractedSlots?.["workflowPreference"];
    let value = "unknown";
    if (workflowData) {
      try {
        const parsed = JSON.parse(workflowData);
        if (parsed.wantsFollowUp === true) value = "follow_up";
        else if (parsed.wantsFollowUp === false) value = "no_follow_up";
        else if (parsed.wantsScheduling) value = "scheduling";
      } catch {
        value = isAffirmative ? "follow_up" : isNegative ? "no_follow_up" : "unknown";
      }
    } else if (isAffirmative) {
      value = "follow_up";
    } else if (isNegative) {
      value = "no_follow_up";
    }
    if (value !== "unknown") {
      rememberSlot("workflowPreference", value, classification.hasWorkflowInfo ? 0.9 : 0.7);
    }
  }
  if (currentStage === "hours") {
    const hoursData = classification.extractedSlots?.["hoursInfo"];
    if (hoursData || classification.hasHoursInfo) {
      slots["hoursInfo"] = {
        key: "hoursInfo",
        value: classification.originalInput,
        capturedAt: now,
        turnIndex: state.turnIndex,
        confidence: classification.hasHoursInfo ? 0.9 : 0.5
      };
    }
  }
  const inferredBusiness = classification.extractedSlots?.["businessSummary"];
  if (inferredBusiness && inferredBusiness.length > 3) {
    rememberSlot("businessSummary", inferredBusiness, classification.hasBusinessInfo ? 0.9 : 0.6);
  }
  const inferredBehavior = classification.extractedSlots?.["desiredAgentBehavior"];
  if (inferredBehavior && inferredBehavior.length > 3) {
    rememberSlot("desiredAgentBehavior", inferredBehavior, classification.hasBehaviorInfo ? 0.9 : 0.6);
  }
  const inferredWorkflow = classification.extractedSlots?.["workflowPreference"];
  if (inferredWorkflow && inferredWorkflow.length > 0) {
    rememberSlot("workflowPreference", inferredWorkflow, classification.hasWorkflowInfo ? 0.9 : 0.7);
  }
  return { slots, facts };
}
function executePolicyDecision(state, decision, classification) {
  const result = {
    responseText: "",
    newSlots: {},
    newFacts: {},
    shouldCreateAgent: false,
    llmCallCount: 0
  };
  switch (decision.action) {
    case "advance_stage": {
      const nextStage = decision.nextStage || "business";
      const { slots, facts } = captureSlots(state, classification, state.onboardingStage);
      result.newSlots = slots;
      result.newFacts = facts;
      result.newStage = nextStage;
      if (nextStage === "ready") {
        result.shouldCreateAgent = true;
        result.responseText = "Perfeito! Vou criar seu agente agora...";
      } else {
        result.responseText = getStageQuestion(nextStage);
      }
      break;
    }
    case "stay_stage": {
      const pendingSlot = decision.pendingSlot || state.onboardingStage;
      result.responseText = getStageQuestion(pendingSlot);
      break;
    }
    case "side_question": {
      result.responseText = buildSideQuestionResponse(state, classification);
      break;
    }
    case "create_agent": {
      result.shouldCreateAgent = true;
      const { slots, facts } = captureSlots(state, classification, state.onboardingStage);
      result.newSlots = slots;
      result.newFacts = facts;
      result.responseText = "Perfeito! Criando seu agente de atendimento...";
      break;
    }
    case "enter_test_mode": {
      result.actions = { startTestMode: true };
      result.responseText = "Entrando no modo de teste...";
      break;
    }
    case "exit_test_mode": {
      result.responseText = "Saindo do modo teste...";
      break;
    }
    case "send_pix": {
      result.actions = { sendPix: true };
      result.responseText = "Gerando seu PIX...";
      break;
    }
    case "process_payment": {
      result.responseText = "Analisando comprovante...";
      break;
    }
    case "upload_media": {
      result.responseText = "Processando sua midia...";
      break;
    }
    case "edit_prompt": {
      result.responseText = "Vamos editar as instrucoes do agente...";
      break;
    }
    case "execute_command": {
      result.responseText = "Executando comando...";
      break;
    }
    case "generate_response": {
      result.responseText = "__LLM_REQUIRED__";
      result.llmCallCount = 1;
      break;
    }
    case "noop": {
      result.responseText = "";
      break;
    }
    default: {
      result.responseText = "__LLM_REQUIRED__";
      result.llmCallCount = 1;
    }
  }
  return result;
}

// server/adminAgentOutputSanitizer.ts
var MOJIBAKE_REPAIRS = [
  // V16: Acentuações comuns — agora preservam acentos corretos em UTF-8
  [/vocÃª/gi, "voc\xEA"],
  [/nÃ£o/gi, "n\xE3o"],
  [/jÃ¡/gi, "j\xE1"],
  [/negÃ³cio/gi, "neg\xF3cio"],
  [/dÃºvida/gi, "d\xFAvida"],
  [/preÃ§o/gi, "pre\xE7o"],
  [/informaÃ§Ã£o/gi, "informa\xE7\xE3o"],
  [/configuraÃ§Ã£o/gi, "configura\xE7\xE3o"],
  [/grÃ¡tis/gi, "gr\xE1tis"],
  [/serviÃ§o/gi, "servi\xE7o"],
  [/horÃ¡rio/gi, "hor\xE1rio"],
  [/criaÃ§Ã£o/gi, "cria\xE7\xE3o"],
  [/funÃ§Ã£o/gi, "fun\xE7\xE3o"],
  [/soluÃ§Ã£o/gi, "solu\xE7\xE3o"],
  [/RecepÃ§Ã£o/gi, "Recep\xE7\xE3o"],
  [/situaÃ§Ã£o/gi, "situa\xE7\xE3o"],
  [/condiÃ§Ã£o/gi, "condi\xE7\xE3o"],
  [/operaÃ§Ã£o/gi, "opera\xE7\xE3o"],
  [/relaÃ§Ã£o/gi, "rela\xE7\xE3o"],
  [/proteÃ§Ã£o/gi, "prote\xE7\xE3o"],
  [/educaÃ§Ã£o/gi, "educa\xE7\xE3o"],
  [/comunicaÃ§Ã£o/gi, "comunica\xE7\xE3o"],
  [/organizaÃ§Ã£o/gi, "organiza\xE7\xE3o"],
  [/produÃ§Ã£o/gi, "produ\xE7\xE3o"],
  [/construÃ§Ã£o/gi, "constru\xE7\xE3o"],
  [/instruÃ§Ã£o/gi, "instru\xE7\xE3o"],
  [/descriÃ§Ã£o/gi, "descri\xE7\xE3o"],
  [/sugestÃ£o/gi, "sugest\xE3o"],
  [/questÃ£o/gi, "quest\xE3o"],
  [/exceÃ§Ã£o/gi, "exce\xE7\xE3o"],
  [/aÃ§Ã£o/gi, "a\xE7\xE3o"],
  [/correÃ§Ã£o/gi, "corre\xE7\xE3o"],
  [/direÃ§Ã£o/gi, "dire\xE7\xE3o"],
  [/geraÃ§Ã£o/gi, "gera\xE7\xE3o"],
  [/aplicaÃ§Ã£o/gi, "aplica\xE7\xE3o"],
  [/integraÃ§Ã£o/gi, "integra\xE7\xE3o"],
  [/automaÃ§Ã£o/gi, "automa\xE7\xE3o"],
  [/simulaÃ§Ã£o/gi, "simula\xE7\xE3o"],
  [/verificaÃ§Ã£o/gi, "verifica\xE7\xE3o"],
  [/validaÃ§Ã£o/gi, "valida\xE7\xE3o"],
  [/notificaÃ§Ã£o/gi, "notifica\xE7\xE3o"],
  // Generic diacritical fragments — preservam acentos
  [/Ã£o\b/g, "\xE3o"],
  [/Ã©/g, "\xE9"],
  [/Ã¡/g, "\xE1"],
  [/Ãª/g, "\xEA"],
  [/Ã³/g, "\xF3"],
  [/Ãº/g, "\xFA"],
  [/Ã§/g, "\xE7"],
  [/Ã­/g, "\xED"],
  [/Ã´/g, "\xF4"],
  [/Ãµ/g, "\xF5"],
  [/Ã /g, "\xE0"],
  [/Ã¢/g, "\xE2"]
];
function convertMarkdownToWhatsApp(text) {
  return text.replace(/^#{1,6}\s+(.+)$/gm, "*$1*").replace(/\[(https?:\/\/[^\]]+)\]\(\1\)/gi, "$1").replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/gi, "$1: $2").replace(/\*\*\*(.+?)\*\*\*/g, "*$1*").replace(/\*\*(.+?)\*\*/g, "*$1*").replace(/__(.+?)__/g, "*$1*").replace(/(?<!\w)_(.+?)_(?!\w)/g, "_$1_").replace(/~~(.+?)~~/g, "~$1~").replace(/```[\s\S]*?```/g, "").replace(/`([^`]+)`/g, "$1").replace(/^[-_*]{3,}$/gm, "").replace(/\n{3,}/g, "\n\n").replace(/^([^\n]*https?:\/\/[^\n]+)$/gm, (line) => line.replace(/\*/g, "")).replace(/(https?:\/\/[^\s:]+):\s*\1/gi, "$1").replace(/\*{2,}/g, "*");
}
var FALSE_EXISTING_PATTERNS = [
  /mantive sua conta/i,
  /conta j[aá] existente/i,
  /mantive a conta/i,
  /conta que voc[eê] j[aá] (tinha|tem|possui)/i,
  /usei sua conta anterior/i,
  /aproveitei seu cadastro/i,
  /conta existente.*mante/i,
  /mante.*conta existente/i
];
function detectFalseExisting(text, isExistingAccount) {
  if (isExistingAccount) return false;
  return FALSE_EXISTING_PATTERNS.some((p) => p.test(text));
}
function removeFalseExistingMentions(text) {
  let cleaned = text;
  for (const pattern of FALSE_EXISTING_PATTERNS) {
    cleaned = cleaned.replace(pattern, "");
  }
  return cleaned.replace(/\s{2,}/g, " ").trim();
}
function removeLLMArtefacts(text) {
  return text.replace(/<\/?(?:thinking|reasoning|internal|thought|scratchpad)[^>]*>/gi, "").replace(/^(?:assistant|rodrigo|agente|bot):\s*/gim, "").replace(/\{[^{}]*"(?:action|intent|type)"[^{}]*\}/g, "").replace(/\\n/g, "\n").replace(/\\t/g, " ").replace(/\\"/g, '"').trim();
}
function stripToolCallPayloads(text) {
  let cleaned = text;
  while (true) {
    const toolCallsIndex = cleaned.indexOf('"tool_calls"');
    if (toolCallsIndex === -1) break;
    const objectStart = cleaned.lastIndexOf("{", toolCallsIndex);
    if (objectStart === -1) break;
    let removalStart = objectStart;
    const prefixSlice = cleaned.slice(Math.max(0, objectStart - 16), objectStart);
    const jsonPrefixMatch = prefixSlice.match(/json\s*$/i);
    if (jsonPrefixMatch) {
      removalStart = objectStart - jsonPrefixMatch[0].length;
    }
    let depth = 0;
    let inString = false;
    let escaped = false;
    let objectEnd = -1;
    for (let i = objectStart; i < cleaned.length; i++) {
      const char = cleaned[i];
      if (inString) {
        if (escaped) {
          escaped = false;
          continue;
        }
        if (char === "\\") {
          escaped = true;
          continue;
        }
        if (char === '"') {
          inString = false;
        }
        continue;
      }
      if (char === '"') {
        inString = true;
        continue;
      }
      if (char === "{") {
        depth++;
        continue;
      }
      if (char === "}") {
        depth--;
        if (depth === 0) {
          objectEnd = i;
          break;
        }
      }
    }
    if (objectEnd === -1) break;
    cleaned = `${cleaned.slice(0, removalStart)}${cleaned.slice(objectEnd + 1)}`;
  }
  return cleaned.replace(/^\s*json\s*$/gim, "").trim();
}
function sanitizeOutput(text, options = {}) {
  const {
    isExistingAccount = false,
    maxLength = 4e3,
    convertMarkdown = true,
    removeLLMArtefacts: shouldRemoveLLM = true
  } = options;
  const originalLength = text.length;
  let cleaned = text;
  if (shouldRemoveLLM) {
    cleaned = removeLLMArtefacts(cleaned);
    cleaned = stripToolCallPayloads(cleaned);
  }
  if (convertMarkdown) {
    cleaned = convertMarkdownToWhatsApp(cleaned);
  }
  cleaned = cleaned.replace(/[\u0000-\u0008\u000B-\u001F\u007F]/g, " ").replace(/\uFFFD/g, "").replace(/ï¿½/g, "");
  cleaned = repairMojibakeText(cleaned);
  let hadMojibake = false;
  const beforeMojibake = cleaned;
  for (const [pattern, replacement] of MOJIBAKE_REPAIRS) {
    cleaned = cleaned.replace(pattern, replacement);
  }
  cleaned = repairMojibakeText(cleaned);
  if (cleaned !== beforeMojibake) hadMojibake = true;
  cleaned = cleaned.replace(/[ÃÂ]{2,}/g, " ");
  let hadFalseExisting = false;
  if (!isExistingAccount && detectFalseExisting(cleaned, isExistingAccount)) {
    cleaned = removeFalseExistingMentions(cleaned);
    hadFalseExisting = true;
    console.log("[SANITIZER-V12] Removida men\xE7\xE3o falsa a conta existente");
  }
  cleaned = cleaned.replace(/\n{3,}/g, "\n\n").replace(/[ \t]{2,}/g, " ").replace(/\n[ \t]+/g, "\n").trim();
  if (cleaned.length > maxLength) {
    cleaned = cleaned.slice(0, maxLength - 3) + "...";
  }
  return {
    text: cleaned,
    hadMojibake,
    hadFalseExisting,
    mojibakeResidualScore: 0,
    charsRemoved: originalLength - cleaned.length
  };
}

// server/adminAgentGraphValidator.ts
function validateCredentialConsistency(credentials, state) {
  const checks = [];
  const hasEmail = !!(credentials.email && credentials.email.includes("@"));
  checks.push({
    name: "email_valid",
    passed: hasEmail,
    details: hasEmail ? `Email: ${credentials.email}` : `Email inv\xE1lido ou ausente: ${credentials.email || "(vazio)"}`
  });
  const hasLoginUrl = !!(credentials.loginUrl && credentials.loginUrl.startsWith("http"));
  checks.push({
    name: "login_url_valid",
    passed: hasLoginUrl,
    details: hasLoginUrl ? `LoginUrl: ${credentials.loginUrl}` : `LoginUrl inv\xE1lido: ${credentials.loginUrl || "(vazio)"}`
  });
  if (!credentials.isExistingAccount) {
    const hasPassword = !!(credentials.password && credentials.password.length >= 4);
    checks.push({
      name: "password_present",
      passed: hasPassword,
      details: hasPassword ? "Password presente e v\xE1lido" : `Password ausente ou muito curto`
    });
  }
  const hasLinkedUser = !!state.linkedUserId;
  const flagConsistent = !credentials.isExistingAccount || hasLinkedUser;
  checks.push({
    name: "existing_account_flag",
    passed: flagConsistent,
    details: flagConsistent ? `isExisting=${credentials.isExistingAccount}, linkedUser=${hasLinkedUser}` : `Flag isExistingAccount=true mas sem linkedUserId`
  });
  const hasToken = !!(credentials.simulatorToken && credentials.simulatorToken.length > 10);
  checks.push({
    name: "simulator_token",
    passed: hasToken,
    details: hasToken ? `Token presente (${credentials.simulatorToken?.substring(0, 8)}...)` : "SimulatorToken ausente ou muito curto"
  });
  return checks;
}
function validateDeliveryText(text, credentials) {
  const checks = [];
  const normalizedText = text.toLowerCase();
  const falseExistingPatterns = [
    /mantive.*conta/i,
    /conta.*existente/i,
    /conta.*anterior/i,
    /cadastro.*existente/i
  ];
  const hasFalseExisting = !credentials.isExistingAccount && falseExistingPatterns.some((p) => p.test(text));
  checks.push({
    name: "no_false_existing",
    passed: !hasFalseExisting,
    details: hasFalseExisting ? "ALERTA: Texto menciona 'conta existente' mas isExistingAccount=false" : "OK: Sem men\xE7\xE3o falsa a conta existente"
  });
  const containsEmail = !!(credentials.email && normalizedText.includes(credentials.email.toLowerCase()));
  checks.push({
    name: "contains_email",
    passed: containsEmail,
    details: containsEmail ? `Email ${credentials.email} encontrado no texto` : `Email ${credentials.email || "(vazio)"} N\xC3O encontrado no texto`
  });
  const containsLink = /https?:\/\/[^\s]+/.test(text);
  checks.push({
    name: "contains_login_link",
    passed: containsLink,
    details: containsLink ? "Link de login presente no texto" : "ALERTA: Sem link de login no texto de entrega"
  });
  const mojibakeCount = (text.match(/[ÃÂ]/g) || []).length;
  const hasMojibake = mojibakeCount > 2;
  checks.push({
    name: "no_mojibake",
    passed: !hasMojibake,
    details: hasMojibake ? `ALERTA: ${mojibakeCount} caracteres mojibake residuais` : "OK: Sem mojibake detectado"
  });
  return checks;
}
function validateDelivery(state, deliveryText, credentials) {
  const allChecks = [];
  const errors = [];
  const warnings = [];
  const credChecks = validateCredentialConsistency(credentials, state);
  allChecks.push(...credChecks);
  const textChecks = validateDeliveryText(deliveryText, credentials);
  allChecks.push(...textChecks);
  for (const check of allChecks) {
    if (!check.passed) {
      if (["email_valid", "login_url_valid", "existing_account_flag"].includes(check.name)) {
        errors.push(`[${check.name}] ${check.details}`);
      } else {
        warnings.push(`[${check.name}] ${check.details}`);
      }
    }
  }
  let deliveryStatus = "not_started";
  const passedNames = new Set(allChecks.filter((c) => c.passed).map((c) => c.name));
  if (passedNames.has("email_valid")) deliveryStatus = "account_created";
  if (passedNames.has("email_valid") && passedNames.has("simulator_token")) deliveryStatus = "token_generated";
  if (passedNames.has("contains_login_link") && passedNames.has("contains_email")) deliveryStatus = "credentials_sent";
  if (errors.length === 0 && warnings.length === 0) deliveryStatus = "confirmed";
  return {
    valid: errors.length === 0,
    deliveryStatus,
    checks: allChecks,
    errors,
    warnings,
    timestamp: Date.now()
  };
}

// server/adminAgentTurnAuditor.ts
var auditBuffer = /* @__PURE__ */ new Map();
var MAX_RECORDS_PER_PHONE = 50;
var MAX_PHONES = 500;
var alertBuffer = [];
var MAX_ALERTS = 200;
function detectReAskLoop(records) {
  if (records.length < 3) return null;
  const lastThree = records.slice(-3);
  const allSameStage = lastThree.every(
    (r) => r.newStage === lastThree[0].newStage && r.previousStage === lastThree[0].previousStage
  );
  const allStayDecisions = lastThree.every(
    (r) => r.decision.action === "stay_stage"
  );
  if (allSameStage && allStayDecisions) {
    return {
      type: "re_ask_loop",
      severity: "critical",
      message: `Re-ask loop detectado! Est\xE1gio "${lastThree[0].newStage}" perguntado ${lastThree.length}x consecutivas`,
      turnIndex: lastThree[lastThree.length - 1].turnIndex,
      phoneNumber: lastThree[0].phoneNumber,
      timestamp: Date.now()
    };
  }
  return null;
}
function detectRepeatedMojibake(records) {
  if (records.length < 2) return null;
  const recentMojibake = records.slice(-3).filter((r) => r.hadMojibake);
  if (recentMojibake.length >= 2) {
    return {
      type: "mojibake_repeated",
      severity: "warning",
      message: `Mojibake detectado em ${recentMojibake.length} respostas consecutivas`,
      turnIndex: records[records.length - 1].turnIndex,
      phoneNumber: records[0].phoneNumber,
      timestamp: Date.now()
    };
  }
  return null;
}
function detectStuckStage(records) {
  if (records.length < 5) return null;
  const lastFive = records.slice(-5);
  const allSameStage = lastFive.every((r) => r.newStage === lastFive[0].newStage);
  if (allSameStage) {
    return {
      type: "stuck_stage",
      severity: "warning",
      message: `Est\xE1gio "${lastFive[0].newStage}" sem avan\xE7o h\xE1 ${lastFive.length} turnos`,
      turnIndex: lastFive[lastFive.length - 1].turnIndex,
      phoneNumber: lastFive[0].phoneNumber,
      timestamp: Date.now()
    };
  }
  return null;
}
function auditTurn(state, classification, decision, previousMode, previousStage, responseText, processingTimeMs, llmCalls = 0) {
  const record = {
    turnIndex: state.turnIndex,
    timestamp: Date.now(),
    phoneNumber: state.phoneNumber,
    rawInput: classification.originalInput,
    normalizedInput: classification.normalizedInput,
    mediaType: classification.mediaType,
    classification,
    decision,
    previousMode,
    previousStage,
    newMode: state.mode,
    newStage: state.onboardingStage,
    responseText: responseText.substring(0, 200),
    // Limitar tamanho
    responseLength: responseText.length,
    hadMojibake: false,
    // Será atualizado pelo sanitizer
    hadFalseExisting: false,
    // Será atualizado pelo sanitizer
    processingTimeMs,
    llmCalls
  };
  let phoneRecords = auditBuffer.get(state.phoneNumber);
  if (!phoneRecords) {
    phoneRecords = [];
    auditBuffer.set(state.phoneNumber, phoneRecords);
  }
  phoneRecords.push(record);
  if (phoneRecords.length > MAX_RECORDS_PER_PHONE) {
    phoneRecords.splice(0, phoneRecords.length - MAX_RECORDS_PER_PHONE);
  }
  if (auditBuffer.size > MAX_PHONES) {
    const oldest = Array.from(auditBuffer.entries()).sort((a, b) => {
      const aLast = a[1][a[1].length - 1]?.timestamp || 0;
      const bLast = b[1][b[1].length - 1]?.timestamp || 0;
      return aLast - bLast;
    }).slice(0, auditBuffer.size - MAX_PHONES);
    for (const [phone] of oldest) {
      auditBuffer.delete(phone);
    }
  }
  const alerts = [];
  const reAsk = detectReAskLoop(phoneRecords);
  if (reAsk) alerts.push(reAsk);
  const mojibake = detectRepeatedMojibake(phoneRecords);
  if (mojibake) alerts.push(mojibake);
  const stuck = detectStuckStage(phoneRecords);
  if (stuck) alerts.push(stuck);
  if (processingTimeMs > 15e3) {
    alerts.push({
      type: "slow_response",
      severity: "warning",
      message: `Resposta lenta: ${processingTimeMs}ms`,
      turnIndex: state.turnIndex,
      phoneNumber: state.phoneNumber,
      timestamp: Date.now()
    });
  }
  for (const alert of alerts) {
    alertBuffer.push(alert);
    if (alertBuffer.length > MAX_ALERTS) {
      alertBuffer.shift();
    }
    console.log(`[AUDITOR] \u26A0 ${alert.severity.toUpperCase()}: ${alert.message}`);
  }
  if (decision.shouldAudit) {
    console.log(
      `[AUDITOR] Turn ${state.turnIndex} | ${state.phoneNumber} | ${previousMode}\u2192${state.mode} | ${previousStage}\u2192${state.onboardingStage} | Intent: ${classification.intent} (${classification.confidence.toFixed(2)}) | Action: ${decision.action} | ${processingTimeMs}ms`
    );
  }
  return alerts;
}
function updateLastAuditWithSanitizeResult(phoneNumber, hadMojibake, hadFalseExisting) {
  const records = auditBuffer.get(phoneNumber);
  if (!records || records.length === 0) return;
  const lastRecord = records[records.length - 1];
  lastRecord.hadMojibake = hadMojibake;
  lastRecord.hadFalseExisting = hadFalseExisting;
}

// server/adminAgentGraphPOC.ts
var graphStates = /* @__PURE__ */ new Map();
function getOrCreateGraphState(phoneNumber, contactName) {
  let state = graphStates.get(phoneNumber);
  if (!state) {
    state = createInitialGraphState(phoneNumber, contactName);
    graphStates.set(phoneNumber, state);
  }
  return state;
}
function updateGraphState(phoneNumber, updates) {
  const current = graphStates.get(phoneNumber) || createInitialGraphState(phoneNumber);
  const updated = { ...current, ...updates, updatedAt: Date.now() };
  graphStates.set(phoneNumber, updated);
  return updated;
}
function clearGraphState(phoneNumber) {
  graphStates.delete(phoneNumber);
}
function syncFromLegacySession(session) {
  const state = fromLegacySession(session);
  graphStates.set(state.phoneNumber, state);
  return state;
}
function syncFromLegacySessionIfNew(session) {
  const cleanPhone = String(session.phoneNumber || "").replace(/\D/g, "");
  if (graphStates.has(cleanPhone)) {
    return graphStates.get(cleanPhone);
  }
  return syncFromLegacySession(session);
}
async function processAdminMessageGraph(phoneNumber, messageText, mediaType, mediaUrl, contactName) {
  const startTime = Date.now();
  const cleanPhone = phoneNumber.replace(/\D/g, "");
  let state = getOrCreateGraphState(cleanPhone, contactName);
  const previousMode = state.mode;
  const previousStage = state.onboardingStage;
  const cleanMessage = (messageText || "").trim();
  if (!cleanMessage && !mediaType) {
    return buildEmptyResult(state, startTime);
  }
  const classification = classifyTurn(cleanMessage, state, mediaType, mediaUrl);
  const decision = evaluatePolicy(state, classification);
  const execResult = executePolicyDecision(state, decision, classification);
  if (Object.keys(execResult.newSlots).length > 0) {
    state = updateGraphState(cleanPhone, {
      capturedSlots: { ...state.capturedSlots, ...execResult.newSlots },
      stickyFacts: { ...state.stickyFacts, ...execResult.newFacts }
    });
  }
  if (execResult.newStage) {
    state = updateGraphState(cleanPhone, {
      onboardingStage: execResult.newStage
    });
  }
  const updatedHistory = [
    ...state.conversationHistory,
    { role: "user", content: cleanMessage, timestamp: Date.now() }
  ];
  state = updateGraphState(cleanPhone, {
    conversationHistory: updatedHistory,
    turnIndex: state.turnIndex + 1
  });
  let deliveryValidation;
  if (execResult.shouldCreateAgent && state.testAccountCredentials) {
    deliveryValidation = validateDelivery(
      state,
      execResult.responseText,
      state.testAccountCredentials
    );
  }
  const sanitizeResult = sanitizeOutput(execResult.responseText, {
    isExistingAccount: state.testAccountCredentials?.isExistingAccount,
    maxLength: 4e3,
    convertMarkdown: true,
    removeLLMArtefacts: true
  });
  const processingTimeMs = Date.now() - startTime;
  const alerts = auditTurn(
    state,
    classification,
    decision,
    previousMode,
    previousStage,
    sanitizeResult.text,
    processingTimeMs,
    execResult.llmCallCount
  );
  updateLastAuditWithSanitizeResult(
    cleanPhone,
    sanitizeResult.hadMojibake,
    sanitizeResult.hadFalseExisting
  );
  if (sanitizeResult.text) {
    state = updateGraphState(cleanPhone, {
      conversationHistory: [
        ...state.conversationHistory,
        { role: "assistant", content: sanitizeResult.text, timestamp: Date.now() }
      ]
    });
  }
  return {
    text: sanitizeResult.text,
    actions: execResult.actions,
    mediaActions: execResult.mediaActions,
    shouldCreateAgent: execResult.shouldCreateAgent,
    classification,
    decision,
    sanitizeResult,
    alerts,
    deliveryValidation,
    newState: state,
    processingTimeMs
  };
}
function buildEmptyResult(state, startTime) {
  const emptyClassification = {
    intent: "unclear",
    confidence: 0,
    hasBusinessInfo: false,
    hasBehaviorInfo: false,
    hasWorkflowInfo: false,
    hasHoursInfo: false,
    isAffirmative: false,
    isNegative: false,
    isMediaMessage: false,
    normalizedInput: "",
    originalInput: ""
  };
  const emptyDecision = {
    action: "noop",
    reason: "Mensagem vazia",
    shouldAudit: false
  };
  return {
    text: "",
    shouldCreateAgent: false,
    classification: emptyClassification,
    decision: emptyDecision,
    sanitizeResult: {
      text: "",
      hadMojibake: false,
      hadFalseExisting: false,
      mojibakeResidualScore: 0,
      charsRemoved: 0
    },
    alerts: [],
    newState: state,
    processingTimeMs: Date.now() - startTime
  };
}
function peekGraphState(phoneNumber) {
  return graphStates.get(phoneNumber);
}
function getGraphStateDebugSummary(phoneNumber) {
  const state = graphStates.get(phoneNumber);
  if (!state) return `[${phoneNumber}] Sem estado no grafo`;
  const slotsCollected = Object.keys(state.capturedSlots).join(", ") || "(nenhum)";
  const isComplete = isOnboardingComplete(state);
  const nextPending = getNextPendingStage(state);
  return `[${phoneNumber}] Mode: ${state.mode} | Stage: ${state.onboardingStage} | Slots: [${slotsCollected}] | Complete: ${isComplete} | NextPending: ${nextPending || "none"} | Turns: ${state.turnIndex} | Delivery: ${state.deliveryStatus}`;
}

export {
  getOrCreateGraphState,
  clearGraphState,
  syncFromLegacySession,
  syncFromLegacySessionIfNew,
  processAdminMessageGraph,
  peekGraphState,
  getGraphStateDebugSummary
};
