import {
  supabase
} from "./chunk-7SPF5OKO.js";
import {
  chatComplete
} from "./chunk-M7TXNZTC.js";

// server/calendarDateTime.ts
var DEFAULT_CALENDAR_TIMEZONE = "America/Sao_Paulo";
var timeZoneFormatterCache = /* @__PURE__ */ new Map();
function getTimeZoneFormatter(timeZone) {
  const cached = timeZoneFormatterCache.get(timeZone);
  if (cached) {
    return cached;
  }
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  });
  timeZoneFormatterCache.set(timeZone, formatter);
  return formatter;
}
function readTimeZoneParts(date, timeZone) {
  const formattedParts = getTimeZoneFormatter(timeZone).formatToParts(date);
  const values = {};
  for (const part of formattedParts) {
    if (part.type === "year" || part.type === "month" || part.type === "day" || part.type === "hour" || part.type === "minute" || part.type === "second") {
      values[part.type] = Number(part.value);
    }
  }
  return {
    year: values.year ?? 0,
    month: values.month ?? 0,
    day: values.day ?? 0,
    hour: values.hour ?? 0,
    minute: values.minute ?? 0,
    second: values.second ?? 0
  };
}
function formatCalendarDateTimeParts(parts) {
  return [
    `${String(parts.year).padStart(4, "0")}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}`,
    `${String(parts.hour).padStart(2, "0")}:${String(parts.minute).padStart(2, "0")}:${String(parts.second).padStart(2, "0")}`
  ].join("T");
}
function hasExplicitTimeZone(value) {
  const normalized = String(value || "").trim();
  if (!normalized) {
    return false;
  }
  if (normalized.endsWith("Z") || normalized.endsWith("z")) {
    return true;
  }
  const plusIndex = normalized.lastIndexOf("+");
  const minusIndex = normalized.lastIndexOf("-");
  const offsetIndex = Math.max(plusIndex, minusIndex);
  const timeSeparatorIndex = normalized.indexOf("T");
  if (offsetIndex <= timeSeparatorIndex) {
    return false;
  }
  const offset = normalized.slice(offsetIndex);
  return offset.length === 6 && offset[3] === ":";
}
function parseCalendarDateTimeParts(value) {
  const normalized = String(value || "").trim();
  if (!normalized) {
    return null;
  }
  const [datePart = "", rawTimePart = "00:00:00"] = normalized.split("T");
  const [yearRaw = "", monthRaw = "", dayRaw = ""] = datePart.split("-");
  const [hourRaw = "00", minuteRaw = "00", secondRaw = "00"] = normalizeCalendarTime(rawTimePart).split(":");
  const parts = {
    year: Number(yearRaw),
    month: Number(monthRaw),
    day: Number(dayRaw),
    hour: Number(hourRaw),
    minute: Number(minuteRaw),
    second: Number(secondRaw)
  };
  if (Object.values(parts).some((valuePart) => Number.isNaN(valuePart))) {
    return null;
  }
  return parts;
}
function formatLocalDateTime(date, timeZone = DEFAULT_CALENDAR_TIMEZONE) {
  return formatCalendarDateTimeParts(readTimeZoneParts(date, timeZone));
}
function normalizeCalendarTime(time) {
  const [rawHour = "00", rawMinute = "00", rawSecond = "00"] = String(time || "").split(":");
  const hour = rawHour.padStart(2, "0");
  const minute = rawMinute.padStart(2, "0");
  const second = rawSecond.padStart(2, "0");
  return `${hour}:${minute}:${second}`;
}
function buildCalendarDateTime(date, time) {
  return `${date}T${normalizeCalendarTime(time)}`;
}
function parseCalendarDateTimeWithTimeZone(value, timeZone = DEFAULT_CALENDAR_TIMEZONE) {
  const normalized = String(value || "").trim();
  if (!normalized) {
    return new Date(Number.NaN);
  }
  if (hasExplicitTimeZone(normalized)) {
    return new Date(normalized);
  }
  const parts = parseCalendarDateTimeParts(normalized);
  if (!parts) {
    return new Date(normalized);
  }
  const targetUtcTime = Date.UTC(
    parts.year,
    parts.month - 1,
    parts.day,
    parts.hour,
    parts.minute,
    parts.second
  );
  let candidateUtcTime = targetUtcTime;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const observedParts = readTimeZoneParts(new Date(candidateUtcTime), timeZone);
    const observedUtcTime = Date.UTC(
      observedParts.year,
      observedParts.month - 1,
      observedParts.day,
      observedParts.hour,
      observedParts.minute,
      observedParts.second
    );
    const difference = observedUtcTime - targetUtcTime;
    if (difference === 0) {
      return new Date(candidateUtcTime);
    }
    candidateUtcTime -= difference;
  }
  return new Date(candidateUtcTime);
}
function addMinutesToCalendarDateTime(date, time, minutesToAdd) {
  const result = parseCalendarDateTimeWithTimeZone(buildCalendarDateTime(date, time));
  result.setUTCMinutes(result.getUTCMinutes() + minutesToAdd);
  return formatLocalDateTime(result);
}
function rangesOverlap(start, end, eventStart, eventEnd) {
  return start < eventEnd && end > eventStart;
}

// server/googleCalendarService.ts
var DEFAULT_TIMEZONE = DEFAULT_CALENDAR_TIMEZONE;
var MATON_TOKEN_TYPE = "maton_api_key";
function getMatonGatewayBaseUrl() {
  const raw = (process.env.MATON_GATEWAY_BASE_URL || "https://gateway.maton.ai").trim();
  let normalized = raw;
  while (normalized.endsWith("/")) {
    normalized = normalized.slice(0, -1);
  }
  return normalized;
}
function readEventDateTime(eventDateTime) {
  if (!eventDateTime) {
    return null;
  }
  if (eventDateTime.dateTime) {
    return parseCalendarDateTimeWithTimeZone(eventDateTime.dateTime, eventDateTime.timeZone || DEFAULT_TIMEZONE);
  }
  if (eventDateTime.date) {
    return parseCalendarDateTimeWithTimeZone(
      `${eventDateTime.date}T00:00:00`,
      eventDateTime.timeZone || DEFAULT_TIMEZONE
    );
  }
  return null;
}
function isBusyEvent(event) {
  return event.status !== "cancelled" && event.transparency !== "transparent";
}
function parseStoredMetadata(rawScope) {
  if (!rawScope) {
    return { provider: "maton" };
  }
  try {
    const parsed = JSON.parse(rawScope);
    if (parsed && typeof parsed === "object") {
      return {
        provider: "maton",
        email: typeof parsed.email === "string" ? parsed.email : void 0,
        primaryCalendarId: typeof parsed.primaryCalendarId === "string" ? parsed.primaryCalendarId : void 0,
        validatedAt: typeof parsed.validatedAt === "string" ? parsed.validatedAt : void 0
      };
    }
  } catch {
    return { provider: "maton" };
  }
  return { provider: "maton" };
}
function inferEmailFromCalendars(calendars) {
  const primaryCalendar = calendars.find((calendar) => calendar.primary) || calendars[0];
  if (!primaryCalendar) {
    return void 0;
  }
  if (primaryCalendar.id.includes("@")) {
    return primaryCalendar.id;
  }
  if (primaryCalendar.summary.includes("@")) {
    return primaryCalendar.summary;
  }
  return void 0;
}
function inferPrimaryCalendarId(calendars) {
  return calendars.find((calendar) => calendar.primary)?.id || calendars[0]?.id || "primary";
}
function canWriteCalendar(calendar) {
  return calendar.accessRole === "owner" || calendar.accessRole === "writer";
}
function pickDefaultWritableCalendarId(calendars) {
  return calendars.find((calendar) => calendar.primary && canWriteCalendar(calendar))?.id || calendars.find((calendar) => canWriteCalendar(calendar))?.id || inferPrimaryCalendarId(calendars);
}
function buildStoredMetadata(calendars) {
  return {
    provider: "maton",
    email: inferEmailFromCalendars(calendars),
    primaryCalendarId: inferPrimaryCalendarId(calendars),
    validatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function parseErrorPayload(rawBody) {
  const trimmed = rawBody.trim();
  if (!trimmed) {
    return "";
  }
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed && typeof parsed === "object") {
      if (typeof parsed.error === "string") {
        return parsed.error;
      }
      if (typeof parsed.message === "string") {
        return parsed.message;
      }
      if (parsed.error && typeof parsed.error.message === "string") {
        return parsed.error.message;
      }
    }
  } catch {
    return trimmed;
  }
  return trimmed;
}
async function matonRequest(apiKey, path, init) {
  const headers = new Headers(init?.headers || {});
  headers.set("Authorization", `Bearer ${apiKey}`);
  if (init?.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const response = await fetch(`${getMatonGatewayBaseUrl()}${path}`, {
    ...init,
    headers
  });
  if (!response.ok) {
    const body = await response.text();
    const parsedMessage = parseErrorPayload(body);
    const errorMessage = parsedMessage || response.statusText || "Falha na integra\xE7\xE3o com o Maton.";
    throw new Error(`Maton ${response.status}: ${errorMessage}`);
  }
  if (response.status === 204) {
    return void 0;
  }
  return response.json();
}
async function listMatonCalendarsWithApiKey(apiKey) {
  const payload = await matonRequest(
    apiKey,
    "/google-calendar/calendar/v3/users/me/calendarList"
  );
  return (payload.items || []).map((calendar) => {
    const id = typeof calendar.id === "string" ? calendar.id : "";
    const summary = typeof calendar.summary === "string" ? calendar.summary : "";
    if (!id || !summary) {
      return null;
    }
    return {
      id,
      summary,
      primary: calendar.primary === true,
      accessRole: typeof calendar.accessRole === "string" ? calendar.accessRole : void 0,
      timeZone: typeof calendar.timeZone === "string" ? calendar.timeZone : void 0,
      selected: calendar.selected === true
    };
  }).filter((calendar) => Boolean(calendar));
}
async function getStoredMatonConnection(userId) {
  const { data, error } = await supabase.from("google_calendar_tokens").select("*").eq("user_id", userId).order("updated_at", { ascending: false }).limit(1);
  const row = Array.isArray(data) ? data[0] : null;
  if (error || !row || !row.access_token) {
    return null;
  }
  if (row.token_type && row.token_type !== MATON_TOKEN_TYPE) {
    return null;
  }
  return {
    apiKey: row.access_token,
    metadata: parseStoredMetadata(row.scope)
  };
}
async function storeMatonConnection(userId, apiKey, metadata) {
  const payload = {
    access_token: apiKey,
    refresh_token: null,
    token_type: MATON_TOKEN_TYPE,
    expiry_date: null,
    scope: JSON.stringify(metadata),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  const { data: existingRows, error: existingError } = await supabase.from("google_calendar_tokens").select("id").eq("user_id", userId).limit(1);
  if (existingError) {
    throw new Error("N\xE3o foi poss\xEDvel consultar a chave atual do Maton.");
  }
  if (existingRows && existingRows.length > 0) {
    const { error: error2 } = await supabase.from("google_calendar_tokens").update(payload).eq("user_id", userId);
    if (error2) {
      throw new Error("N\xE3o foi poss\xEDvel salvar a chave do Maton.");
    }
    return;
  }
  const { error } = await supabase.from("google_calendar_tokens").insert({
    user_id: userId,
    ...payload
  });
  if (error) {
    throw new Error("N\xE3o foi poss\xEDvel salvar a chave do Maton.");
  }
}
async function getSelectedCalendarIdFromConfig(userId) {
  const { data } = await supabase.from("scheduling_config").select("google_calendar_id").eq("user_id", userId).order("updated_at", { ascending: false }).limit(1);
  const row = Array.isArray(data) ? data[0] : null;
  return typeof row?.google_calendar_id === "string" && row.google_calendar_id ? row.google_calendar_id : void 0;
}
async function upsertSchedulingCalendarConfig(userId, updates) {
  const payload = {
    ...updates,
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  const { data: existingRows, error: existingError } = await supabase.from("scheduling_config").select("id").eq("user_id", userId).limit(1);
  if (existingError) {
    throw new Error("N\xE3o foi poss\xEDvel consultar a configura\xE7\xE3o da agenda.");
  }
  if (existingRows && existingRows.length > 0) {
    const { error: error2 } = await supabase.from("scheduling_config").update(payload).eq("user_id", userId);
    if (error2) {
      throw new Error("N\xE3o foi poss\xEDvel atualizar a configura\xE7\xE3o da agenda.");
    }
    return;
  }
  const { error } = await supabase.from("scheduling_config").insert({
    user_id: userId,
    ...payload
  });
  if (error) {
    throw new Error("N\xE3o foi poss\xEDvel atualizar a configura\xE7\xE3o da agenda.");
  }
}
async function resolveCalendarId(userId, providedCalendarId, connection) {
  if (providedCalendarId) {
    return providedCalendarId;
  }
  const configuredCalendarId = await getSelectedCalendarIdFromConfig(userId);
  if (configuredCalendarId) {
    return configuredCalendarId;
  }
  return connection?.metadata.primaryCalendarId || "primary";
}
async function listCalendarEventsWithApiKey(apiKey, calendarId, startDate, endDate) {
  const params = new URLSearchParams({
    timeMin: startDate.toISOString(),
    timeMax: endDate.toISOString(),
    singleEvents: "true",
    orderBy: "startTime",
    maxResults: "250"
  });
  const payload = await matonRequest(
    apiKey,
    `/google-calendar/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events?${params.toString()}`
  );
  return payload.items || [];
}
async function getValidatedMatonContext(userId) {
  const connection = await getStoredMatonConnection(userId);
  if (!connection) {
    throw new Error("Maton n\xE3o conectado. Adicione sua chave da API primeiro.");
  }
  const calendars = await listMatonCalendarsWithApiKey(connection.apiKey);
  if (!calendars.length) {
    throw new Error("A chave Maton n\xE3o retornou nenhuma agenda Google dispon\xEDvel.");
  }
  const requestedCalendarId = await getSelectedCalendarIdFromConfig(userId);
  const selectedCalendarId = calendars.some((calendar) => calendar.id === requestedCalendarId) ? requestedCalendarId : inferPrimaryCalendarId(calendars);
  return {
    connection,
    calendars,
    selectedCalendarId
  };
}
function isGoogleCalendarConfigured() {
  return true;
}
function getGoogleAuthUrl() {
  throw new Error("A integra\xE7\xE3o direta via OAuth do Google foi removida. Use a chave da API do Maton.");
}
async function handleGoogleCallback() {
  return {
    success: false,
    error: "A integra\xE7\xE3o direta com Google foi removida. Use sua chave da API do Maton."
  };
}
async function connectMatonCalendar(userId, apiKey, selectedCalendarId) {
  const normalizedApiKey = String(apiKey || "").trim();
  if (!normalizedApiKey) {
    throw new Error("Informe a chave da API do Maton.");
  }
  const calendars = await listMatonCalendarsWithApiKey(normalizedApiKey);
  if (!calendars.length) {
    throw new Error("A chave do Maton n\xE3o retornou nenhuma agenda conectada.");
  }
  const calendarId = selectedCalendarId && calendars.some((calendar) => calendar.id === selectedCalendarId && canWriteCalendar(calendar)) ? selectedCalendarId : pickDefaultWritableCalendarId(calendars);
  if (!canWriteCalendar(calendars.find((calendar) => calendar.id === calendarId) || { id: "", summary: "" })) {
    throw new Error("A chave do Maton n\xE3o possui nenhuma agenda Google com permiss\xE3o de escrita.");
  }
  const metadata = buildStoredMetadata(calendars);
  await storeMatonConnection(userId, normalizedApiKey, metadata);
  await upsertSchedulingCalendarConfig(userId, {
    google_calendar_enabled: true,
    google_calendar_id: calendarId
  });
  return {
    connected: true,
    configured: true,
    provider: "maton",
    providerLabel: "Maton",
    email: metadata.email,
    selectedCalendarId: calendarId,
    calendars,
    checked: true
  };
}
async function updateSelectedCalendar(userId, calendarId) {
  const desiredCalendarId = String(calendarId || "").trim();
  if (!desiredCalendarId) {
    throw new Error("Selecione uma agenda v\xE1lida.");
  }
  const { connection, calendars } = await getValidatedMatonContext(userId);
  if (!calendars.some((calendar) => calendar.id === desiredCalendarId && canWriteCalendar(calendar))) {
    throw new Error("A agenda escolhida n\xE3o est\xE1 dispon\xEDvel na chave Maton informada.");
  }
  await upsertSchedulingCalendarConfig(userId, {
    google_calendar_id: desiredCalendarId
  });
  return {
    connected: true,
    configured: true,
    provider: "maton",
    providerLabel: "Maton",
    email: connection.metadata.email || inferEmailFromCalendars(calendars),
    selectedCalendarId: desiredCalendarId,
    calendars,
    checked: true
  };
}
async function isGoogleCalendarConnected(userId) {
  const connection = await getStoredMatonConnection(userId);
  return Boolean(connection?.apiKey);
}
async function getGoogleCalendarStatus(userId) {
  const connection = await getStoredMatonConnection(userId);
  if (!connection) {
    return {
      connected: false,
      configured: true,
      provider: "maton",
      providerLabel: "Maton",
      checked: true,
      calendars: []
    };
  }
  try {
    const calendars = await listMatonCalendarsWithApiKey(connection.apiKey);
    const selectedCalendarId = await resolveCalendarId(userId, void 0, connection);
    const activeCalendarId = calendars.some((calendar) => calendar.id === selectedCalendarId) ? selectedCalendarId : inferPrimaryCalendarId(calendars);
    return {
      connected: true,
      configured: true,
      provider: "maton",
      providerLabel: "Maton",
      email: connection.metadata.email || inferEmailFromCalendars(calendars),
      selectedCalendarId: activeCalendarId,
      calendars,
      checked: true
    };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao carregar status:", error);
    return {
      connected: true,
      configured: true,
      provider: "maton",
      providerLabel: "Maton",
      email: connection.metadata.email,
      selectedCalendarId: connection.metadata.primaryCalendarId,
      checked: false,
      error: error instanceof Error ? error.message : "Falha ao validar a conex\xE3o com o Maton."
    };
  }
}
async function disconnectGoogleCalendar(userId) {
  try {
    const { error } = await supabase.from("google_calendar_tokens").delete().eq("user_id", userId);
    if (error) {
      return { success: false, error: "Erro ao remover a chave do Maton." };
    }
    await upsertSchedulingCalendarConfig(userId, {
      google_calendar_enabled: false,
      google_calendar_id: null
    });
    return { success: true };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao desconectar:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Falha ao desconectar a agenda do Maton."
    };
  }
}
async function createCalendarEvent(userId, eventData) {
  try {
    const { connection, selectedCalendarId } = await getValidatedMatonContext(userId);
    const payload = await matonRequest(
      connection.apiKey,
      `/google-calendar/calendar/v3/calendars/${encodeURIComponent(selectedCalendarId)}/events`,
      {
        method: "POST",
        body: JSON.stringify({
          summary: eventData.summary,
          description: eventData.description,
          location: eventData.location,
          start: {
            dateTime: eventData.startDateTime,
            timeZone: DEFAULT_TIMEZONE
          },
          end: {
            dateTime: eventData.endDateTime,
            timeZone: DEFAULT_TIMEZONE
          },
          attendees: eventData.attendeeEmail ? [{ email: eventData.attendeeEmail }] : void 0,
          colorId: eventData.colorId,
          reminders: {
            useDefault: false,
            overrides: [
              { method: "popup", minutes: 30 },
              { method: "email", minutes: 60 }
            ]
          }
        })
      }
    );
    return {
      success: true,
      eventId: payload.id,
      htmlLink: payload.htmlLink
    };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao criar evento:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Falha ao criar evento na agenda."
    };
  }
}
async function updateCalendarEvent(userId, eventId, eventData) {
  try {
    const { connection, selectedCalendarId } = await getValidatedMatonContext(userId);
    const currentEvent = await matonRequest(
      connection.apiKey,
      `/google-calendar/calendar/v3/calendars/${encodeURIComponent(selectedCalendarId)}/events/${encodeURIComponent(eventId)}`
    );
    await matonRequest(
      connection.apiKey,
      `/google-calendar/calendar/v3/calendars/${encodeURIComponent(selectedCalendarId)}/events/${encodeURIComponent(eventId)}`,
      {
        method: "PUT",
        body: JSON.stringify({
          ...currentEvent,
          summary: eventData.summary || currentEvent.summary,
          description: eventData.description ?? currentEvent.description,
          location: eventData.location ?? currentEvent.location,
          start: eventData.startDateTime ? {
            dateTime: eventData.startDateTime,
            timeZone: DEFAULT_TIMEZONE
          } : currentEvent.start,
          end: eventData.endDateTime ? {
            dateTime: eventData.endDateTime,
            timeZone: DEFAULT_TIMEZONE
          } : currentEvent.end
        })
      }
    );
    return { success: true };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao atualizar evento:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Falha ao atualizar evento na agenda."
    };
  }
}
async function deleteCalendarEvent(userId, eventId) {
  try {
    const { connection, selectedCalendarId } = await getValidatedMatonContext(userId);
    await matonRequest(
      connection.apiKey,
      `/google-calendar/calendar/v3/calendars/${encodeURIComponent(selectedCalendarId)}/events/${encodeURIComponent(eventId)}`,
      {
        method: "DELETE"
      }
    );
    return { success: true };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao deletar evento:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Falha ao remover evento da agenda."
    };
  }
}
async function listCalendarEvents(userId, startDate, endDate) {
  try {
    const { connection, selectedCalendarId } = await getValidatedMatonContext(userId);
    const events = await listCalendarEventsWithApiKey(connection.apiKey, selectedCalendarId, startDate, endDate);
    return {
      success: true,
      events
    };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao listar eventos:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Falha ao listar eventos da agenda."
    };
  }
}
async function listCalendarBusyWindows(userId, startDateTime, endDateTime, options) {
  try {
    const start = parseCalendarDateTimeWithTimeZone(startDateTime);
    const end = parseCalendarDateTimeWithTimeZone(endDateTime);
    const { success, events, error } = await listCalendarEvents(userId, start, end);
    if (!success || error) {
      return { success: false, error: error || "Falha ao consultar agenda via Maton." };
    }
    const windows = (events || []).filter(isBusyEvent).filter((event) => event.id !== options?.excludeEventId).map((event) => {
      const eventStart = readEventDateTime(event.start);
      const eventEnd = readEventDateTime(event.end);
      if (!eventStart || !eventEnd || !rangesOverlap(start, end, eventStart, eventEnd)) {
        return null;
      }
      return {
        eventId: event.id,
        summary: event.summary || "Evento sem t\xEDtulo",
        startDateTime: eventStart.toISOString(),
        endDateTime: eventEnd.toISOString()
      };
    }).filter((window) => Boolean(window));
    return { success: true, windows };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao listar janelas ocupadas:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Falha ao consultar agenda via Maton."
    };
  }
}
async function checkCalendarAvailability(userId, startDateTime, endDateTime, options) {
  try {
    const { success, windows, error } = await listCalendarBusyWindows(userId, startDateTime, endDateTime, {
      excludeEventId: options?.excludeEventId
    });
    if (!success || error) {
      const availableOnError = options?.failOpen !== false;
      return {
        available: availableOnError,
        checked: false,
        error: error || "Falha ao consultar a agenda via Maton."
      };
    }
    if (windows && windows.length > 0) {
      const conflict = windows[0];
      return {
        available: false,
        checked: true,
        conflictEvent: conflict.summary,
        conflictEventId: conflict.eventId
      };
    }
    return { available: true, checked: true };
  } catch (error) {
    console.error("[MatonCalendar] Erro ao verificar disponibilidade:", error);
    const availableOnError = options?.failOpen !== false;
    return {
      available: availableOnError,
      checked: false,
      error: error instanceof Error ? error.message : "Falha ao consultar a agenda via Maton."
    };
  }
}
async function syncAppointmentToCalendar(userId, appointment, serviceDurationMinutes = 60) {
  try {
    const startDateTime = buildCalendarDateTime(appointment.appointmentDate, appointment.appointmentTime);
    const endDateTime = addMinutesToCalendarDateTime(
      appointment.appointmentDate,
      appointment.appointmentTime,
      serviceDurationMinutes
    );
    const eventData = {
      summary: `Agendamento - ${appointment.clientName}`,
      description: [
        `Cliente: ${appointment.clientName}`,
        `Telefone: ${appointment.clientPhone}`,
        appointment.serviceName ? `Servi\xE7o: ${appointment.serviceName}` : "",
        appointment.location ? `Endere\xE7o: ${appointment.location}` : "",
        appointment.notes ? `Notas: ${appointment.notes}` : "",
        ...appointment.extraDetails || [],
        "--- Agendado via AgentZap ---",
        `ID interno: ${appointment.id}`
      ].filter(Boolean).join("\n"),
      startDateTime,
      endDateTime,
      location: appointment.location,
      colorId: "2"
    };
    if (appointment.googleEventId) {
      const result = await updateCalendarEvent(userId, appointment.googleEventId, eventData);
      return {
        success: result.success,
        eventId: appointment.googleEventId,
        error: result.error
      };
    }
    return createCalendarEvent(userId, eventData);
  } catch (error) {
    console.error("[MatonCalendar] Erro ao sincronizar agendamento:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Falha ao sincronizar o agendamento na agenda."
    };
  }
}
async function removeAppointmentFromCalendar(userId, googleEventId) {
  return deleteCalendarEvent(userId, googleEventId);
}

// server/schedulingService.ts
var CACHE_TTL_MS = 5 * 60 * 1e3;
var schedulingConfigCache = /* @__PURE__ */ new Map();
function cleanExpiredCache() {
  const now = Date.now();
  for (const [key, entry] of schedulingConfigCache.entries()) {
    if (now - entry.timestamp > CACHE_TTL_MS) {
      schedulingConfigCache.delete(key);
    }
  }
}
setInterval(cleanExpiredCache, 10 * 60 * 1e3);
function invalidateSchedulingCache(userId) {
  schedulingConfigCache.delete(userId);
  console.log(`\u{1F5D1}\uFE0F [Scheduling] Cache invalidado para user ${userId}`);
}
async function isSchedulingEnabled(userId) {
  const config = await getSchedulingConfigCached(userId);
  return config?.is_enabled === true;
}
var MAX_IMPLICIT_SLOT_DRIFT_MINUTES = 60;
var SAME_DAY_REBOOK_APPROVAL_TTL_MS = 15 * 60 * 1e3;
var sameDayRebookingApprovals = /* @__PURE__ */ new Map();
var VALIDATED_SLOT_OFFER_TTL_MS = 20 * 60 * 1e3;
var validatedSlotOffers = /* @__PURE__ */ new Map();
var SCHEDULING_STATE_TTL_MS = 6 * 60 * 60 * 1e3;
var schedulingConversationState = /* @__PURE__ */ new Map();
var schedulingPlannerTestDependencies = null;
function setSchedulingOrchestratorTestDependencies(deps) {
  schedulingPlannerTestDependencies = deps;
}
function buildSchedulingConversationStateKey(userId, clientPhone) {
  return `${userId}:${clientPhone}`;
}
function getSchedulingConversationState(userId, clientPhone) {
  const key = buildSchedulingConversationStateKey(userId, clientPhone);
  const state = schedulingConversationState.get(key);
  if (!state) {
    return null;
  }
  if (state.updatedAt + SCHEDULING_STATE_TTL_MS <= Date.now()) {
    schedulingConversationState.delete(key);
    return null;
  }
  return state;
}
function rememberSchedulingConversationState(userId, clientPhone, patch) {
  const cleanedPatch = Object.fromEntries(
    Object.entries(patch).filter(([, value]) => value !== void 0)
  );
  if (Object.keys(cleanedPatch).length === 0) {
    return getSchedulingConversationState(userId, clientPhone);
  }
  const key = buildSchedulingConversationStateKey(userId, clientPhone);
  const currentState = getSchedulingConversationState(userId, clientPhone) || { updatedAt: Date.now() };
  const nextState = {
    ...currentState,
    ...cleanedPatch,
    updatedAt: Date.now()
  };
  schedulingConversationState.set(key, nextState);
  return nextState;
}
function clearSchedulingConversationState(userId, clientPhone) {
  schedulingConversationState.delete(buildSchedulingConversationStateKey(userId, clientPhone));
}
function clearSchedulingConversationStateForTests() {
  schedulingConversationState.clear();
}
function rememberValidatedSlotOfferForTests(userId, clientPhone, date, time, serviceBundle) {
  rememberValidatedSlotOffer(userId, clientPhone, date, time, serviceBundle);
}
function getValidatedSlotOfferForTests(userId, clientPhone) {
  const offer = getValidatedSlotOffer(userId, clientPhone);
  return offer ? {
    date: offer.date,
    time: offer.time
  } : null;
}
function findClosestSchedulingSlotWithinToleranceForTests(times, targetTime, maxDiffMinutes = MAX_IMPLICIT_SLOT_DRIFT_MINUTES) {
  const slots = times.map((time) => ({
    start: normalizeSchedulingTimeValue(time),
    end: normalizeSchedulingTimeValue(time),
    available: true
  }));
  return findClosestSchedulingSlotWithinTolerance(slots, targetTime, maxDiffMinutes)?.start || null;
}
function buildSchedulingNextSlotsReplyWithMemoryForTests(userId, clientPhone, serviceBundle, slotsData, options) {
  return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, serviceBundle, slotsData, options);
}
function buildSchedulingServiceBundleMemoryKey(bundle) {
  const catalogParts = bundle.selectedServices.map((service) => `${String(service.id || "").trim() || normalizeSchedulingMessage(service.name)}:${Number(service.durationMinutes || 0)}`).sort();
  if (catalogParts.length > 0) {
    return catalogParts.join("|");
  }
  return normalizeSchedulingMessage(bundle.combinedServiceName || "");
}
function flattenSchedulingOfferedSlots(slotsData) {
  const seen = /* @__PURE__ */ new Set();
  const flattened = [];
  for (const dayData of slotsData) {
    const date = String(dayData?.date || "").trim();
    if (!date) {
      continue;
    }
    for (const slot of dayData.slots || []) {
      const time = normalizeSchedulingTimeValue(slot.start);
      if (!time) {
        continue;
      }
      const key = `${date} ${time}`;
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      flattened.push({ date, time });
      if (flattened.length >= 12) {
        return flattened;
      }
    }
  }
  return flattened;
}
function rememberSchedulingOfferedSlots(userId, clientPhone, serviceBundle, slotsData) {
  const offeredSlots = flattenSchedulingOfferedSlots(slotsData);
  return rememberSchedulingConversationState(userId, clientPhone, {
    offeredSlots,
    offeredSlotsServiceKey: offeredSlots.length > 0 ? buildSchedulingServiceBundleMemoryKey(serviceBundle) : ""
  });
}
function clearRememberedSchedulingOfferedSlots(userId, clientPhone) {
  return rememberSchedulingConversationState(userId, clientPhone, {
    offeredSlots: [],
    offeredSlotsServiceKey: ""
  });
}
function getRememberedOfferedSchedulingSlotsForBundle(rememberedState, serviceBundle) {
  if (!rememberedState?.offeredSlots || rememberedState.offeredSlots.length === 0) {
    return [];
  }
  const expectedServiceKey = buildSchedulingServiceBundleMemoryKey(serviceBundle);
  if (rememberedState.offeredSlotsServiceKey && rememberedState.offeredSlotsServiceKey !== expectedServiceKey) {
    return [];
  }
  return rememberedState.offeredSlots.map((slot) => ({
    date: String(slot.date || "").trim(),
    time: normalizeSchedulingTimeValue(slot.time)
  })).filter((slot) => Boolean(slot.date) && Boolean(slot.time));
}
function buildRememberedSchedulingSlotsData(rememberedState, serviceBundle) {
  const rememberedSlots = getRememberedOfferedSchedulingSlotsForBundle(rememberedState, serviceBundle);
  if (rememberedSlots.length === 0) {
    return [];
  }
  const groupedSlots = /* @__PURE__ */ new Map();
  for (const slot of rememberedSlots) {
    const time = normalizeSchedulingTimeValue(slot.time);
    if (!time) {
      continue;
    }
    const daySlots = groupedSlots.get(slot.date) || [];
    if (!daySlots.some((candidate) => candidate.start === time)) {
      daySlots.push({
        start: time,
        end: time,
        available: true
      });
    }
    groupedSlots.set(slot.date, daySlots);
  }
  return Array.from(groupedSlots.entries()).map(([date, slots]) => ({
    date,
    slots
  }));
}
function findClosestSchedulingSlotWithinTolerance(slots, targetTime, maxDiffMinutes = MAX_IMPLICIT_SLOT_DRIFT_MINUTES) {
  const normalizedTargetTime = normalizeSchedulingTimeValue(targetTime);
  if (!normalizedTargetTime) {
    return null;
  }
  const exactSlot = findExactAvailableSlot(slots, normalizedTargetTime);
  if (exactSlot) {
    return exactSlot;
  }
  const closestSlot = findClosestAvailableSlot(slots, normalizedTargetTime);
  if (!closestSlot) {
    return null;
  }
  const driftMinutes = Math.abs(
    timeToMinutes(closestSlot.start) - timeToMinutes(normalizedTargetTime)
  );
  return driftMinutes <= maxDiffMinutes ? closestSlot : null;
}
function resolveRememberedOfferedSchedulingSlot(rememberedState, serviceBundle, targetDate, targetTime) {
  if (!targetDate || !targetTime) {
    return null;
  }
  const rememberedSlots = getRememberedOfferedSchedulingSlotsForBundle(rememberedState, serviceBundle);
  if (rememberedSlots.length === 0) {
    return null;
  }
  const candidateSlots = rememberedSlots.filter((slot) => slot.date === targetDate).map((slot) => ({
    start: normalizeSchedulingTimeValue(slot.time),
    end: normalizeSchedulingTimeValue(slot.time),
    available: true
  }));
  if (candidateSlots.length === 0) {
    return null;
  }
  const matchedSlot = findClosestSchedulingSlotWithinTolerance(candidateSlots, targetTime);
  if (!matchedSlot) {
    return null;
  }
  return {
    date: targetDate,
    time: matchedSlot.start
  };
}
function resolveImplicitRememberedOfferedSchedulingSlot(rememberedState, serviceBundle, targetDate, targetTime) {
  const rememberedSlots = getRememberedOfferedSchedulingSlotsForBundle(rememberedState, serviceBundle);
  if (rememberedSlots.length === 0) {
    return null;
  }
  if (targetDate && targetTime) {
    return resolveRememberedOfferedSchedulingSlot(
      rememberedState,
      serviceBundle,
      targetDate,
      targetTime
    );
  }
  if (targetDate && !targetTime) {
    const slotsForDate = rememberedSlots.filter((slot) => slot.date === targetDate);
    return slotsForDate.length === 1 ? slotsForDate[0] : null;
  }
  if (!targetTime) {
    return null;
  }
  const uniqueDates = Array.from(new Set(rememberedSlots.map((slot) => slot.date)));
  if (uniqueDates.length === 1) {
    return resolveRememberedOfferedSchedulingSlot(
      rememberedState,
      serviceBundle,
      uniqueDates[0],
      targetTime
    );
  }
  const normalizedTargetTime = normalizeSchedulingTimeValue(targetTime);
  const exactMatches = rememberedSlots.filter((slot) => normalizeSchedulingTimeValue(slot.time) === normalizedTargetTime);
  if (exactMatches.length === 1) {
    return exactMatches[0];
  }
  if (exactMatches.length > 1) {
    return null;
  }
  const closestSlot = findClosestSchedulingSlotWithinTolerance(
    rememberedSlots.map((slot) => ({
      start: normalizeSchedulingTimeValue(slot.time),
      end: normalizeSchedulingTimeValue(slot.time),
      available: true
    })),
    targetTime
  );
  if (!closestSlot) {
    return null;
  }
  const closestMatches = rememberedSlots.filter((slot) => normalizeSchedulingTimeValue(slot.time) === normalizeSchedulingTimeValue(closestSlot.start));
  return closestMatches.length === 1 ? closestMatches[0] : null;
}
function schedulingBundleHasResolvedCatalogServices(bundle) {
  return Boolean(bundle?.selectedServices?.some((service) => Boolean(service.id)));
}
function buildResolvedBundleFromConversationState(config, state) {
  if (!state?.selectedServices || state.selectedServices.length === 0) {
    return null;
  }
  const selectedServices = state.selectedServices.map((service) => ({
    ...service,
    durationMinutes: Number(service.durationMinutes || 0) || 0,
    price: typeof service.price === "number" ? service.price : service.price == null ? null : Number(service.price)
  }));
  const combinedServiceName = selectedServices.map((service) => service.name).filter(Boolean).join(" + ") || config.service_name;
  const totalDurationMinutes = Number(state.totalDurationMinutes || 0) || selectedServices.reduce((sum, service) => sum + (service.durationMinutes || 0), 0) || config.service_duration;
  const totalPrice = state.totalPrice ?? selectedServices.reduce((sum, service) => {
    if (service.price == null) {
      return sum;
    }
    return (sum ?? 0) + service.price;
  }, 0);
  return {
    primaryServiceId: selectedServices.find((service) => service.id)?.id,
    combinedServiceName,
    totalDurationMinutes,
    totalPrice,
    requiresCustomerAddress: Boolean(state.requiresCustomerAddress),
    selectedServices
  };
}
function chooseEffectiveSchedulingServiceBundle(currentBundle, rememberedBundle, options) {
  if (!rememberedBundle) {
    return currentBundle;
  }
  const currentHasCatalogServices = schedulingBundleHasResolvedCatalogServices(currentBundle);
  const rememberedHasCatalogServices = schedulingBundleHasResolvedCatalogServices(rememberedBundle);
  if (options?.preferCurrentCatalogMatch && currentHasCatalogServices) {
    return currentBundle;
  }
  if (!currentHasCatalogServices && rememberedHasCatalogServices) {
    return rememberedBundle;
  }
  if (rememberedHasCatalogServices && rememberedBundle.selectedServices.length > currentBundle.selectedServices.length) {
    return rememberedBundle;
  }
  return currentBundle;
}
var SCHEDULING_PATTERNS = {
  check_availability: [
    /tem hor[aá]rio/i,
    /hor[aá]rio dispon[ií]vel/i,
    /quando (pode|posso|consigo)/i,
    /qual hor[aá]rio/i,
    /tem vaga/i,
    /est[aá] dispon[ií]vel/i,
    /podemos marcar/i,
    /posso agendar/i,
    /agenda livre/i,
    /disponibilidade/i
  ],
  // IMPORTANTE: reschedule deve vir ANTES de book_appointment para priorizar "reagendar"
  reschedule: [
    /remarcar/i,
    /reagendar/i,
    /trocar o hor[aá]rio/i,
    /mudar o hor[aá]rio/i,
    /alterar (o )?(meu )?agendamento/i,
    /outro hor[aá]rio/i
  ],
  cancel_appointment: [
    /cancelar/i,
    /desmarcar/i,
    /n[aã]o vou (poder )?(ir|comparecer)/i,
    /n[aã]o posso (ir|comparecer)/i,
    /preciso cancelar/i
  ],
  book_appointment: [
    /quero agendar/i,
    /quero marcar/i,
    /vou agendar/i,
    /pode agendar/i,
    /pode marcar/i,
    /reservar hor[aá]rio/i,
    /marcar um hor[aá]rio/i,
    /agendar para/i,
    /confirma o hor[aá]rio/i,
    /esse hor[aá]rio/i,
    /pode ser [àa]s/i
  ],
  info: [
    /onde (fica|é|[eé] o endereço)/i,
    /qual o endereço/i,
    /como funciona/i,
    /quanto tempo (dura|demora)/i,
    /quanto custa/i,
    /pre[çc]o/i,
    /valor/i
  ]
};
var DATE_PATTERNS = {
  today: /hoje/i,
  tomorrow: /amanh[ãa]/i,
  dayAfterTomorrow: /depois de amanh[ãa]/i,
  weekday: /(segunda|ter[çc]a|quarta|quinta|sexta|s[áa]bado|domingo)/i,
  specificDate: /(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?/,
  nextWeek: /semana que vem|pr[óo]xima semana/i
};
var TIME_PATTERNS = {
  // Captura: 14:00, 14h, 14h30, 14:30, 14 horas
  specific: /(\d{1,2})(?:(?:h|:)(\d{2})|(:(\d{2}))|h)?\s*(hrs?|horas?)?/i,
  // Formato alternativo: 14h30 (sem : )
  withH: /(\d{1,2})h(\d{2})/i,
  morning: /manh[ãa]|de manh[ãa]/i,
  afternoon: /tarde|de tarde/i,
  evening: /noite|de noite/i
};
var SCHEDULING_INTENT_MARKERS = {
  check_availability: [
    "tem horario",
    "horario disponivel",
    "qual horario",
    "tem vaga",
    "esta disponivel",
    "agenda livre",
    "disponibilidade",
    "primeiro horario",
    "proximo horario",
    "qualquer horario",
    "o que tiver"
  ],
  reschedule: [
    "remarcar",
    "reagendar",
    "trocar o horario",
    "mudar o horario",
    "alterar meu agendamento",
    "alterar o agendamento",
    "outro horario"
  ],
  cancel_appointment: [
    "cancelar",
    "desmarcar",
    "nao vou poder ir",
    "nao posso ir",
    "preciso cancelar"
  ],
  book_appointment: [
    "quero agendar",
    "quero marcar",
    "vou agendar",
    "pode agendar",
    "pode marcar",
    "reservar horario",
    "marcar um horario",
    "agendar para",
    "confirma o horario",
    "esse horario",
    "pode ser as"
  ],
  info: [
    "onde fica",
    "qual o endereco",
    "como funciona",
    "quanto tempo",
    "quanto custa",
    "preco",
    "valor"
  ]
};
function messageIncludesAnyMarker(normalizedMessage, markers) {
  return markers.some((marker) => normalizedMessage.includes(marker));
}
function detectSchedulingIntent(message) {
  const result = {
    detected: false,
    type: null,
    confidence: 0
  };
  {
    const normalizedMessage = normalizeTextForComparison(message).trim();
    const orderedIntents2 = [
      "check_availability",
      "reschedule",
      "cancel_appointment",
      "book_appointment",
      "info"
    ];
    for (const intentType of orderedIntents2) {
      if (messageIncludesAnyMarker(normalizedMessage, SCHEDULING_INTENT_MARKERS[intentType])) {
        result.detected = true;
        result.type = intentType;
        result.confidence = 0.8;
        break;
      }
    }
    if (!result.detected) {
      const genericMarkers = ["agend", "marc", "horario", "consulta", "atendimento"];
      if (messageIncludesAnyMarker(normalizedMessage, genericMarkers)) {
        result.detected = true;
        result.type = "info";
        result.confidence = 0.5;
      }
    }
    if (result.detected) {
      result.requestedDate = extractDate(normalizedMessage);
      result.requestedTime = extractTime(normalizedMessage);
      if (result.requestedDate) result.confidence += 0.1;
      if (result.requestedTime) result.confidence += 0.1;
    }
    return result;
  }
  const normalizedMsg = message.toLowerCase().trim();
  const requestedDate = extractDate(normalizedMsg);
  const requestedTime = extractTime(normalizedMsg);
  const orderedIntents = [
    "check_availability",
    "reschedule",
    "cancel_appointment",
    "book_appointment",
    "info"
  ];
  for (const intentType of orderedIntents) {
    const patterns = SCHEDULING_PATTERNS[intentType];
    for (const pattern of patterns) {
      if (pattern.test(normalizedMsg)) {
        result.detected = true;
        result.type = intentType;
        result.confidence = 0.8;
        break;
      }
    }
    if (result.detected) break;
  }
  if (!result.detected) {
    const genericPatterns = [
      /agend/i,
      /marc/i,
      /hor[áa]rio/i,
      /consulta/i,
      /atendimento/i
    ];
    for (const pattern of genericPatterns) {
      if (pattern.test(normalizedMsg)) {
        result.detected = true;
        result.type = "info";
        result.confidence = 0.5;
        break;
      }
    }
  }
  if (result.detected) {
    result.requestedDate = requestedDate;
    result.requestedTime = requestedTime;
    if (result.requestedDate) result.confidence += 0.1;
    if (result.requestedTime) result.confidence += 0.1;
  }
  if (!result.detected) {
    const inferredIntent = inferSchedulingIntentFromSignals(message, requestedDate, requestedTime);
    if (inferredIntent) {
      return inferredIntent;
    }
  }
  return result;
}
function extractDate(message) {
  const brazil = getBrazilDateTime();
  const today = brazil.date;
  if (DATE_PATTERNS.dayAfterTomorrow.test(message)) {
    const dayAfter = new Date(today);
    dayAfter.setDate(dayAfter.getDate() + 2);
    return formatDate(dayAfter);
  }
  if (DATE_PATTERNS.tomorrow.test(message)) {
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return formatDate(tomorrow);
  }
  if (DATE_PATTERNS.today.test(message)) {
    return formatDate(today);
  }
  const weekdayMatch = message.match(DATE_PATTERNS.weekday);
  if (weekdayMatch) {
    const weekdays = {
      "domingo": 0,
      "segunda": 1,
      "terca": 2,
      "ter\xE7a": 2,
      "quarta": 3,
      "quinta": 4,
      "sexta": 5,
      "sabado": 6,
      "s\xE1bado": 6
    };
    const targetDay = weekdays[weekdayMatch[1].toLowerCase()];
    if (targetDay !== void 0) {
      const brazil2 = getBrazilDateTime();
      const date = new Date(brazil2.date);
      const currentDay = date.getDay();
      let daysToAdd = targetDay - currentDay;
      if (daysToAdd <= 0) daysToAdd += 7;
      date.setDate(date.getDate() + daysToAdd);
      return formatDate(date);
    }
  }
  const specificMatch = message.match(DATE_PATTERNS.specificDate);
  if (specificMatch) {
    const brazil2 = getBrazilDateTime();
    const day = parseInt(specificMatch[1]);
    const month = parseInt(specificMatch[2]) - 1;
    const year = specificMatch[3] ? parseInt(specificMatch[3]) : brazil2.date.getFullYear();
    const fullYear = year < 100 ? 2e3 + year : year;
    return formatDate(new Date(fullYear, month, day));
  }
  if (DATE_PATTERNS.nextWeek.test(message)) {
    const brazil2 = getBrazilDateTime();
    const nextWeek = new Date(brazil2.date);
    nextWeek.setDate(nextWeek.getDate() + 7);
    return formatDate(nextWeek);
  }
  return void 0;
}
function extractTime(message) {
  const withHMatch = message.match(TIME_PATTERNS.withH);
  if (withHMatch) {
    const hour = parseInt(withHMatch[1]);
    const minutes = parseInt(withHMatch[2]);
    if (hour >= 0 && hour <= 23 && minutes >= 0 && minutes <= 59) {
      return `${hour.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
    }
  }
  const timeMatch = message.match(TIME_PATTERNS.specific);
  if (timeMatch) {
    const hour = parseInt(timeMatch[1]);
    const minutes = timeMatch[2] ? parseInt(timeMatch[2]) : timeMatch[4] ? parseInt(timeMatch[4]) : 0;
    if (hour >= 0 && hour <= 23 && minutes >= 0 && minutes <= 59) {
      return `${hour.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
    }
  }
  if (TIME_PATTERNS.morning.test(message)) {
    return "09:00";
  }
  if (TIME_PATTERNS.afternoon.test(message)) {
    return "14:00";
  }
  if (TIME_PATTERNS.evening.test(message)) {
    return "19:00";
  }
  return void 0;
}
function formatDate(date) {
  return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, "0")}-${date.getDate().toString().padStart(2, "0")}`;
}
function normalizeTextForComparison(value) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
function normalizeSchedulingMessage(value) {
  return normalizeTextForComparison(value).replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function tokenizeSchedulingMessage(value) {
  return normalizeSchedulingMessage(value).split(" ").map((token) => token.trim()).filter(Boolean);
}
var SCHEDULING_AVAILABILITY_TOKENS = /* @__PURE__ */ new Set([
  "tem",
  "teria",
  "pode",
  "posso",
  "consegue",
  "consigo",
  "livre",
  "vaga",
  "disponivel",
  "disponiveis",
  "horario",
  "horarios",
  "agenda",
  "agendar",
  "marcar",
  "reservar"
]);
var SCHEDULING_BOOKING_TOKENS = /* @__PURE__ */ new Set([
  "fechar",
  "confirmar",
  "confirmo",
  "confirma",
  "agendar",
  "marcar",
  "reservar"
]);
var SCHEDULING_CONTEXT_HINTS = [
  "agend",
  "horario",
  "dispon",
  "vaga",
  "consulta",
  "visita",
  "orcamento",
  "atendimento",
  "[agendar:"
];
var SCHEDULING_AVAILABILITY_PROMPT_HINTS = [
  "verifique o proximo horario disponivel",
  "verificar o proximo horario disponivel",
  "verifique os horarios",
  "verificar os horarios",
  "posso verificar os proximos horarios",
  "posso verificar os horarios",
  "verificar os proximos horarios",
  "posso verificar a disponibilidade",
  "verificar a disponibilidade",
  "verifique a disponibilidade",
  "disponibilidade para agendamento",
  "verifico a disponibilidade",
  "quer que eu verifique os horarios",
  "deseja que eu verifique",
  "gostaria que eu verifique",
  // Humanized variations (LLM may rephrase "verifique" → "veja", "checar", etc.)
  "veja os proximos horarios",
  "veja os horarios",
  "veja a disponibilidade",
  "ver os proximos horarios",
  "ver os horarios",
  "ver a disponibilidade",
  "checar os horarios",
  "checar a disponibilidade",
  "consultar os horarios",
  "consultar a disponibilidade",
  "horarios disponiveis na agenda",
  "proximos horarios disponiveis"
];
function inferSchedulingIntentFromSignals(message, requestedDate, requestedTime) {
  if (!requestedDate && !requestedTime) {
    return null;
  }
  const normalizedMessage = normalizeSchedulingMessage(message);
  const tokens = tokenizeSchedulingMessage(message);
  if (tokens.length === 0) {
    return null;
  }
  const hasAvailabilityCue = tokens.some((token) => SCHEDULING_AVAILABILITY_TOKENS.has(token));
  const hasBookingCue = tokens.some((token) => SCHEDULING_BOOKING_TOKENS.has(token));
  const shortFollowUp = tokens.length <= 4;
  const looksLikeQuestion = message.includes("?") || hasAvailabilityCue;
  if (hasBookingCue && requestedDate && requestedTime) {
    return {
      detected: true,
      type: "book_appointment",
      requestedDate,
      requestedTime,
      confidence: 0.72
    };
  }
  if (hasAvailabilityCue || looksLikeQuestion || shortFollowUp) {
    return {
      detected: true,
      type: "check_availability",
      requestedDate,
      requestedTime,
      confidence: requestedTime ? 0.8 : 0.7
    };
  }
  if (normalizedMessage.startsWith("e ") || normalizedMessage.startsWith("na ")) {
    return {
      detected: true,
      type: "check_availability",
      requestedDate,
      requestedTime,
      confidence: 0.65
    };
  }
  return null;
}
function hasRecentSchedulingContext(conversationHistory) {
  return conversationHistory.slice(-6).some((message) => {
    const text = String(message?.text || "").trim();
    if (!text) {
      return false;
    }
    const normalized = normalizeSchedulingMessage(text);
    if (!normalized) {
      return false;
    }
    if (extractDate(normalized) || extractTime(normalized)) {
      return true;
    }
    return SCHEDULING_CONTEXT_HINTS.some((hint) => normalized.includes(hint));
  });
}
function inferSchedulingIntentFromConversation(messageText, conversationHistory = []) {
  const directIntent = detectSchedulingIntent(messageText);
  if (directIntent.detected) {
    return directIntent;
  }
  const requestedDate = extractDate(messageText.toLowerCase());
  const requestedTime = extractTime(messageText.toLowerCase());
  const signalIntent = inferSchedulingIntentFromSignals(messageText, requestedDate, requestedTime);
  if (signalIntent) {
    return signalIntent;
  }
  if ((requestedDate || requestedTime) && hasRecentSchedulingContext(conversationHistory)) {
    return {
      detected: true,
      type: "check_availability",
      requestedDate,
      requestedTime,
      confidence: 0.68
    };
  }
  return directIntent;
}
function isAvailabilityLookupFollowUp(messageText, conversationHistory = []) {
  if (!looksLikeAffirmativeReply(messageText)) {
    return false;
  }
  const recentAgentMessages = [...conversationHistory].reverse().filter((message) => message?.fromMe && String(message?.text || "").trim().length > 0).slice(0, 4);
  return recentAgentMessages.some((message) => {
    const normalized = normalizeSchedulingMessage(String(message?.text || ""));
    if (!normalized) {
      return false;
    }
    return SCHEDULING_AVAILABILITY_PROMPT_HINTS.some((hint) => normalized.includes(hint));
  });
}
function isGenericAvailabilityLookup(messageText) {
  const normalized = normalizeSchedulingMessage(String(messageText || ""));
  if (!normalized) {
    return false;
  }
  const hints = [
    "proximos horarios",
    "horarios disponiveis",
    "quais horarios",
    "qual horario",
    "tem horario",
    "tem vaga",
    "disponibilidade",
    "quero agendar",
    "vamos agendar",
    "bora agendar",
    "pode agendar"
  ];
  return hints.some((hint) => normalized.includes(hint));
}
function buildSchedulingDateReferenceWindow(daysAhead = 14) {
  const lines = [];
  const base = getBrazilDateTime().date;
  for (let offset = 0; offset <= daysAhead; offset += 1) {
    const date = new Date(base);
    date.setDate(base.getDate() + offset);
    const isoDate = formatDate(date);
    const dayLabel = formatSchedulingDayLabel(isoDate);
    lines.push(`${isoDate} = ${dayLabel}`);
  }
  return lines.join("\n");
}
function normalizePlannerAction(value) {
  const normalized = String(value || "").trim().toUpperCase();
  switch (normalized) {
    case "QUOTE_ONLY":
    case "LOOKUP_NEXT_SLOTS":
    case "LOOKUP_DATE_AVAILABILITY":
    case "CHECK_EXACT_SLOT":
    case "REQUEST_SLOT_SELECTION":
    case "REQUEST_NAME":
    case "REQUEST_ADDRESS":
    case "READY_TO_BOOK":
    case "CANCEL_NEEDS_TARGET":
    case "CANCEL_READY":
      return normalized;
    default:
      return "IGNORE";
  }
}
function cleanPlannerJson(raw) {
  return String(raw || "").replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
}
function parseSchedulingPlannerDecision(raw) {
  const cleaned = cleanPlannerJson(raw);
  if (!cleaned) {
    return null;
  }
  try {
    const parsed = JSON.parse(cleaned);
    return {
      shouldHandle: Boolean(parsed.shouldHandle),
      action: normalizePlannerAction(parsed.action),
      selectedServiceIds: Array.isArray(parsed.selectedServiceIds) ? parsed.selectedServiceIds.map((value) => String(value || "").trim()).filter(Boolean) : [],
      requestedDate: parsed.requestedDate || null,
      requestedTime: parsed.requestedTime || null,
      selectedDate: parsed.selectedDate || null,
      selectedTime: parsed.selectedTime || null,
      customerName: parsed.customerName || null,
      customerAddress: parsed.customerAddress || null,
      wantsSchedulingNow: Boolean(parsed.wantsSchedulingNow),
      wantsBookingDetails: Boolean(parsed.wantsBookingDetails),
      confidence: typeof parsed.confidence === "number" ? parsed.confidence : 0,
      reasoning: parsed.reasoning || null
    };
  } catch (error) {
    console.error("[Scheduling] Planner JSON inv\xE1lido:", error);
    return null;
  }
}
async function getClientActiveAppointments(userId, clientPhone) {
  const { data, error } = await supabase.from("appointments").select("*").eq("user_id", userId).eq("client_phone", clientPhone).in("status", ["pending", "confirmed"]).order("appointment_date", { ascending: true });
  if (error) {
    console.error("[Scheduling] Error fetching active client appointments:", error);
    return [];
  }
  return (data || []).sort((left, right) => {
    const leftKey = `${left.appointment_date || ""} ${normalizeSchedulingTimeValue(left.start_time)}`;
    const rightKey = `${right.appointment_date || ""} ${normalizeSchedulingTimeValue(right.start_time)}`;
    return leftKey.localeCompare(rightKey, "pt-BR");
  }).slice(0, 8);
}
function extractOrdinalSlotFromListing(messageText, conversationHistory) {
  const normalized = normalizeSchedulingMessage(String(messageText || ""));
  if (!normalized) return null;
  if (extractTime(normalized)) {
    return null;
  }
  const isFirst = normalized.includes("primeir") || normalized.includes("pode ser") || normalized.includes("qualquer um") || normalized.includes("qualquer hora") || normalized.includes("qualquer hor") || normalized.includes("mais cedo") || normalized.includes("o de manha");
  const isLast = normalized.includes("ultim") || normalized.includes("mais tarde") || normalized.includes("o de tarde");
  const isSecond = normalized.includes("segund");
  const isThird = normalized.includes("terceir");
  if (!isFirst && !isLast && !isSecond && !isThird) return null;
  const recentAssistantSlotListing = [...conversationHistory].reverse().find((m) => m?.fromMe && /\d{2}[h:]\d{2}/.test(String(m?.text || "")));
  if (!recentAssistantSlotListing?.text) return null;
  const text = String(recentAssistantSlotListing.text);
  const slots = [];
  const dateReference = buildSchedulingDateReferenceWindow(14);
  const dayBlockPattern = /(?:(\d{2})\/(\d{2}))[^\d]*?(\d{2})[h:](\d{2})(?:[^\d]*?(?:,|ou|e)\s*(\d{2})[h:](\d{2}))?(?:[^\d]*?(?:,|ou|e)\s*(\d{2})[h:](\d{2}))?/g;
  let match;
  while ((match = dayBlockPattern.exec(text)) !== null) {
    const day = match[1];
    const month = match[2];
    const year = (/* @__PURE__ */ new Date()).getFullYear();
    const dateStr = `${year}-${month}-${day}`;
    slots.push({ date: dateStr, time: `${match[3]}:${match[4]}` });
    if (match[5] && match[6]) {
      slots.push({ date: dateStr, time: `${match[5]}:${match[6]}` });
    }
    if (match[7] && match[8]) {
      slots.push({ date: dateStr, time: `${match[7]}:${match[8]}` });
    }
  }
  if (slots.length === 0) return null;
  let index = 0;
  if (isLast) index = slots.length - 1;
  else if (isSecond && slots.length > 1) index = 1;
  else if (isThird && slots.length > 2) index = 2;
  const selected = slots[index];
  if (selected) {
    console.log(`\u{1F4C5} [OrdinalSlot] Deterministic extraction: "${messageText}" \u2192 slot #${index + 1}: ${selected.date} ${selected.time}`);
    return selected;
  }
  return null;
}
async function extractCustomerInfoViaLLM(messageText, conversationHistory, requiresAddress) {
  const recentAssistantMessages = [...conversationHistory].reverse().filter((m) => m?.fromMe && String(m?.text || "").trim().length > 0).slice(0, 3).map((m) => String(m.text).trim());
  const contextBlock = recentAssistantMessages.length > 0 ? "\xDALTIMAS MENSAGENS DA ASSISTENTE:\n" + recentAssistantMessages.join("\n---\n") : "";
  const systemPrompt = [
    "Voc\xEA \xE9 um extrator de dados de cliente. Analise a mensagem do cliente e extraia nome completo e endere\xE7o se presentes.",
    "O cliente pode enviar os dados SEM r\xF3tulos (sem 'nome:', sem 'endere\xE7o:'). Apenas os dados soltos.",
    "O cliente pode enviar tudo em uma \xFAnica mensagem com quebras de linha.",
    "O cliente pode enviar nome, endere\xE7o e e-mail misturados.",
    "Se a assistente acabou de pedir o endere\xE7o, considere que a resposta do cliente \xE9 o endere\xE7o (mesmo sem 'Rua').",
    "Se a assistente acabou de pedir o nome, considere que a resposta do cliente \xE9 o nome.",
    "",
    "REGRAS:",
    "- Nome: geralmente 2-4 palavras, sem n\xFAmeros, sem @.",
    "- Endere\xE7o: cont\xE9m rua/avenida/av/n\xFAmero OU \xE9 uma localiza\xE7\xE3o que faz sentido como endere\xE7o de servi\xE7o.",
    "- E-mail: ignore, n\xE3o extraia.",
    "- Se n\xE3o conseguir identificar com certeza, retorne null para o campo.",
    "",
    contextBlock,
    "",
    `MENSAGEM DO CLIENTE: ${String(messageText).trim()}`,
    "",
    "Responda SOMENTE com JSON:",
    '{ "name": "Nome Completo" ou null, "address": "Endere\xE7o completo" ou null }',
    "",
    "Responda s\xF3 com JSON. Sem explica\xE7\xF5es."
  ].join("\n");
  try {
    const response = await chatComplete({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Extraia nome e endere\xE7o do cliente." }
      ],
      maxTokens: 150,
      temperature: 0
    });
    const raw = String(response.choices?.[0]?.message?.content || "").trim();
    console.log(`\u{1F4C5} [CustomerInfoLLM] Raw LLM response: ${raw}`);
    const jsonMatch = raw.match(/\{[^}]+\}/);
    if (!jsonMatch) return null;
    const parsed = JSON.parse(jsonMatch[0]);
    const result = {};
    if (parsed.name && typeof parsed.name === "string" && parsed.name.trim().length >= 2) {
      result.customerName = parsed.name.trim();
    }
    if (parsed.address && typeof parsed.address === "string" && parsed.address.trim().length >= 3) {
      result.customerAddress = parsed.address.trim();
    }
    if (result.customerName || result.customerAddress) {
      console.log(`\u{1F4C5} [CustomerInfoLLM] Extracted: name=${result.customerName || "(none)"} address=${result.customerAddress || "(none)"} from "${messageText.substring(0, 80)}"`);
      return result;
    }
    return null;
  } catch (error) {
    console.error("[Scheduling] CustomerInfoLLM falhou:", error);
    return null;
  }
}
async function extractSlotSelectionViaLLM(messageText, conversationHistory) {
  const recentAssistantSlotListing = [...conversationHistory].reverse().find((m) => m?.fromMe && String(m?.text || "").includes(":"));
  if (!recentAssistantSlotListing?.text) {
    return null;
  }
  const dateReference = buildSchedulingDateReferenceWindow(14);
  const systemPrompt = [
    "Voc\xEA \xE9 um extrator de sele\xE7\xE3o de hor\xE1rio. Analise a mensagem do cliente e a lista de hor\xE1rios que a assistente ofereceu.",
    "O cliente pode ter digitado com ERROS DE DIGITA\xC7\xC3O (ex: 'qiunta' = quinta, 'terca' = ter\xE7a, 'seguda' = segunda).",
    "O cliente pode usar linguagem natural (ex: '08 e meia' = 08:30, 'nove' = 09:00, 'duas da tarde' = 14:00).",
    "O cliente pode usar refer\xEAncias ORDINAIS ou RELATIVAS (ex: 'primeiro hor\xE1rio' = primeiro da lista, '\xFAltimo' = \xFAltimo da lista, 'o mais cedo' = hor\xE1rio mais cedo, 'qualquer um' = primeiro da lista, 'o de manh\xE3' = primeiro hor\xE1rio do per\xEDodo manh\xE3), mas isso s\xF3 vale quando N\xC3O houver uma hora expl\xEDcita na mesma mensagem.",
    "",
    "REGRA: Resolva APENAS para hor\xE1rios que a assistente realmente ofereceu. N\xE3o invente hor\xE1rios.",
    "REGRA: Se a mensagem trouxer uma hora expl\xEDcita (ex: '9h45', '14:00', '08 e meia'), s\xF3 retorne um slot se essa hora corresponder de forma compat\xEDvel a um hor\xE1rio realmente oferecido.",
    'REGRA: Se a mensagem trouxer uma hora expl\xEDcita e ela N\xC3O corresponder a nenhum hor\xE1rio oferecido, responda { "date": null, "time": null }.',
    "REGRA: S\xF3 trate 'primeiro', 'pode ser', 'o primeiro dispon\xEDvel' ou 'qualquer um' como o PRIMEIRO hor\xE1rio quando a mensagem N\xC3O trouxer hora expl\xEDcita.",
    "",
    "MAPA DE DATAS (S\xE3o Paulo):",
    dateReference,
    "",
    "LISTA DE HOR\xC1RIOS OFERECIDOS PELA ASSISTENTE:",
    String(recentAssistantSlotListing.text).trim(),
    "",
    `MENSAGEM DO CLIENTE: ${String(messageText).trim()}`,
    "",
    "Se o cliente est\xE1 selecionando um hor\xE1rio da lista, responda SOMENTE JSON:",
    '{ "date": "YYYY-MM-DD", "time": "HH:MM" }',
    "",
    "Se N\xC3O est\xE1 selecionando hor\xE1rio, responda:",
    '{ "date": null, "time": null }',
    "",
    "Responda s\xF3 com JSON. Sem explica\xE7\xF5es."
  ].join("\n");
  try {
    const response = await chatComplete({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Extraia a sele\xE7\xE3o de hor\xE1rio do cliente." }
      ],
      maxTokens: 100,
      temperature: 0
    });
    const raw = String(response.choices?.[0]?.message?.content || "").trim();
    console.log(`\u{1F4C5} [SlotExtractLLM] Raw LLM response: ${raw}`);
    const jsonMatch = raw.match(/\{[^}]+\}/);
    if (!jsonMatch) return null;
    const parsed = JSON.parse(jsonMatch[0]);
    if (parsed.date && parsed.time && /^\d{4}-\d{2}-\d{2}$/.test(parsed.date) && /^\d{2}:\d{2}$/.test(parsed.time)) {
      console.log(`\u{1F4C5} [SlotExtractLLM] Extracted: date=${parsed.date} time=${parsed.time} from "${messageText}"`);
      return { date: parsed.date, time: parsed.time };
    }
    return null;
  } catch (error) {
    console.error("[Scheduling] SlotExtractLLM falhou:", error);
    return null;
  }
}
function buildSchedulingPlannerSystemPrompt(input) {
  const historyLines = input.conversationHistory.slice(-12).map((message) => `${message.fromMe ? "ASSISTENTE" : "CLIENTE"}: ${String(message.text || "").trim()}`).filter(Boolean).join("\n");
  const serviceLines = input.serviceBundle.selectedServices.length > 0 ? input.serviceBundle.selectedServices.map(
    (service) => `- ${service.name} | ${service.durationMinutes} min | ${service.price !== null ? `R$ ${service.price.toFixed(2).replace(".", ",")}` : "pre\xE7o n\xE3o informado"}`
  ).join("\n") : `- ${input.config.service_name}`;
  const appointmentLines = input.activeAppointments.length > 0 ? input.activeAppointments.map(
    (appointment) => `- ${appointment.appointment_date} ${normalizeSchedulingTimeValue(appointment.start_time)} | ${appointment.service_name || "agendamento"} | status=${appointment.status}`
  ).join("\n") : "- nenhum";
  const catalogLines = input.activeServices.length > 0 ? input.activeServices.map(
    (service) => `- id=${service.id} | ${service.name} | ${Number(service.duration_minutes || 0)} min | ${service.price !== null && service.price !== void 0 ? `R$ ${Number(service.price).toFixed(2).replace(".", ",")}` : "preco nao informado"} | endereco_obrigatorio=${service.requires_customer_address ? "sim" : "nao"}`
  ).join("\n") : "- nenhum";
  return [
    "Voc\xEA \xE9 um planner de agendamento com racioc\xEDnio de orquestrador LLM no estilo OpenClaw.",
    "Sua fun\xE7\xE3o \xE9 interpretar a conversa e devolver SOMENTE JSON v\xE1lido.",
    "Voc\xEA n\xE3o inventa hor\xE1rios. Voc\xEA decide quando o executor deve usar as ferramentas de agenda e quando deve apenas continuar a conversa com base na mem\xF3ria j\xE1 validada.",
    "Use contexto e continuidade da conversa. N\xE3o use atalho de palavra-chave.",
    "",
    "REGRA CR\xCDTICA: NUNCA invente disponibilidade e NUNCA pule a primeira consulta \xE0 agenda real.",
    "- Quando o cliente pedir hor\xE1rios, datas ou disponibilidade para QUALQUER dia, a a\xE7\xE3o DEVE ser LOOKUP_NEXT_SLOTS ou LOOKUP_DATE_AVAILABILITY ou CHECK_EXACT_SLOT.",
    "- NUNCA assuma que um hor\xE1rio est\xE1 livre sem consultar. O executor \xE9 quem verifica a agenda real (Google Calendar + agendamentos internos).",
    "- Mesmo para dias da semana gen\xE9ricos ('segunda', 'ter\xE7a'), use LOOKUP_DATE_AVAILABILITY com a data ISO correspondente.",
    "- Se a assistente JA consultou a agenda real e JA ofereceu hor\xE1rios v\xE1lidos nesta conversa, e o cliente escolher um desses hor\xE1rios, N\xC3O pe\xE7a LOOKUP_* de novo s\xF3 para repetir a mesma busca.",
    "- Nesse caso, preserve a continuidade: use REQUEST_NAME, REQUEST_ADDRESS ou READY_TO_BOOK conforme o que ainda faltar.",
    "- A valida\xE7\xE3o final de conflito acontece no executor quando ele tenta registrar o agendamento. S\xF3 volte a consultar a agenda se o cliente mudar dia/hor\xE1rio ou se o executor disser que houve conflito.",
    "",
    "Se a assistente acabou de oferecer verificar disponibilidade e o cliente confirmou, a a\xE7\xE3o correta \xE9 LOOKUP_NEXT_SLOTS.",
    "Se o cliente respondeu pagamento, CPF/CNPJ, nome, endere\xE7o ou outro dado operacional e ainda n\xE3o existe hor\xE1rio confirmado no hist\xF3rico, a a\xE7\xE3o correta \xE9 LOOKUP_NEXT_SLOTS.",
    "Se a assistente j\xE1 coletou nome/endere\xE7o e o cliente acabou de responder a \xFAltima pend\xEAncia administrativa, o pr\xF3ximo passo \xE9 consultar agenda real antes de falar qualquer hor\xE1rio.",
    "Se a assistente j\xE1 confirmou um hor\xE1rio espec\xEDfico e pediu nome/endere\xE7o, e o cliente respondeu com esses dados, a a\xE7\xE3o correta \xE9 READY_TO_BOOK.",
    "Se o cliente trouxe dados pessoais/endere\xE7o sem ter escolhido um hor\xE1rio real antes, a a\xE7\xE3o correta \xE9 REQUEST_SLOT_SELECTION.",
    "Se o cliente quer cancelar e o hor\xE1rio j\xE1 est\xE1 claro no contexto, use CANCEL_READY. Se n\xE3o estiver claro, use CANCEL_NEEDS_TARGET.",
    "REGRA DE HOR\xC1RIO APROXIMADO:",
    "- Quando o cliente citar um hor\xE1rio aproximado (ex: 'as 09', 'as 10', 'as 14'), e a assistente acabou de oferecer uma lista de hor\xE1rios, resolva para o hor\xE1rio MAIS PR\xD3XIMO da lista oferecida.",
    "- Exemplo: se a assistente ofereceu 09:45 e o cliente disse 'quarta as 09', requestedTime deve ser '09:45' (n\xE3o '09:00').",
    "- Exemplo: se a assistente ofereceu 08:30 e 09:45, e o cliente disse 'as 9', requestedTime deve ser '09:45'.",
    "- Se a assistente ofereceu hor\xE1rios reais de um \xFAnico dia e o cliente responder apenas com a hora (ex: '9h45', 'pode ser 9h45', 'pode agendar \xE0s 9h45'), trate isso como escolha do slot j\xE1 oferecido nesse mesmo dia.",
    "- Sempre prefira o hor\xE1rio que foi realmente oferecido ao cliente.",
    "",
    "Quando houver dia da semana citado, converta para a data ISO usando a refer\xEAncia abaixo.",
    "Se a conversa n\xE3o for de agendamento, use IGNORE com shouldHandle=false.",
    "Voce tambem precisa identificar os servicos ativos em contexto e devolver selectedServiceIds.",
    "Se a conversa ainda estiver em fase de orcamento ou explicacao do servico, use QUOTE_ONLY.",
    "So consulte agenda quando o cliente realmente quiser agendar ou quando o fluxo de agendamento ja estiver em andamento.",
    "Se o cliente apenas descreveu o servico, pediu valor, pediu explicacao ou ainda nao aceitou agendar, wantsSchedulingNow deve ser false.",
    "Se o cliente pediu disponibilidade, pediu para agendar, escolheu um horario oferecido ou esta completando nome/endereco depois de um horario validado, wantsSchedulingNow deve ser true.",
    "Se a ultima mensagem do cliente for apenas o nome e o pacote exigir endereco, a acao correta e REQUEST_ADDRESS.",
    "Mantenha os mesmos selectedServiceIds em respostas operacionais curtas como horario, nome, endereco e pagamento.",
    "",
    "REGRA DE COLETA DE ENDERE\xC7O:",
    "- Se o servi\xE7o tem endereco_obrigatorio=sim, o endere\xE7o DEVE ser coletado ANTES de usar READY_TO_BOOK.",
    "- Se o endere\xE7o ainda n\xE3o foi informado e o hor\xE1rio j\xE1 foi confirmado, use REQUEST_ADDRESS.",
    "- N\xE3o pule a coleta de endere\xE7o para servi\xE7os que exigem deslocamento.",
    "",
    "REGRA DO TELEFONE:",
    "- O n\xFAmero do celular do cliente J\xC1 EST\xC1 na conversa (\xE9 o n\xFAmero que est\xE1 falando). N\xC3O precisa pedir.",
    ...input.strictSchedulingRecovery ? [
      "",
      "MODO DE RECUPERA\xC7\xC3O:",
      "- H\xE1 forte chance de o fluxo j\xE1 estar em andamento.",
      "- Se o hist\xF3rico mostrar or\xE7amento + coleta de dados + pagamento/confirmacao operacional, N\xC3O use IGNORE: consulte a agenda real com LOOKUP_NEXT_SLOTS.",
      "- Exemplo: cliente respondeu 'Pix' depois de passar endere\xE7o e o assistente ainda n\xE3o confirmou um hor\xE1rio real => LOOKUP_NEXT_SLOTS.",
      "- Exemplo: cliente respondeu apenas o nome/endere\xE7o depois que um hor\xE1rio j\xE1 estava validado => READY_TO_BOOK."
    ] : [],
    "",
    "FORMATO EXATO:",
    "{",
    '  "shouldHandle": true,',
    '  "action": "QUOTE_ONLY",',
    '  "selectedServiceIds": ["svc-1"],',
    '  "requestedDate": null,',
    '  "requestedTime": null,',
    '  "selectedDate": null,',
    '  "selectedTime": null,',
    '  "customerName": null,',
    '  "customerAddress": null,',
    '  "wantsSchedulingNow": false,',
    '  "wantsBookingDetails": false,',
    '  "confidence": 0.0,',
    '  "reasoning": "curta"',
    "}",
    "",
    `DATA ATUAL (S\xE3o Paulo): ${getBrazilDateTime().dateStr}`,
    "MAPA DE DATAS:",
    buildSchedulingDateReferenceWindow(),
    "",
    "SERVI\xC7OS EM CONTEXTO:",
    serviceLines,
    "",
    "CATALOGO DE SERVICOS ATIVOS:",
    catalogLines,
    "",
    `TOTAL DO PACOTE: ${input.serviceBundle.totalDurationMinutes} min${input.serviceBundle.totalPrice !== null ? ` | R$ ${input.serviceBundle.totalPrice.toFixed(2).replace(".", ",")}` : ""}`,
    `ENDERE\xC7O OBRIGAT\xD3RIO: ${input.serviceBundle.requiresCustomerAddress ? "sim" : "n\xE3o"}`,
    "",
    "AGENDAMENTOS ATIVOS DO CLIENTE:",
    appointmentLines,
    "",
    "\xDALTIMAS MENSAGENS:",
    historyLines || "- sem hist\xF3rico",
    "",
    `MENSAGEM ATUAL DO CLIENTE: ${String(input.messageText || "").trim()}`,
    "",
    "Responda s\xF3 com JSON."
  ].join("\n");
}
async function callSchedulingPlanner(userId, clientPhone, messageText, conversationHistory, config, serviceBundle, activeServices) {
  if (schedulingPlannerTestDependencies?.callPlanner) {
    return schedulingPlannerTestDependencies.callPlanner({
      userId,
      clientPhone,
      messageText,
      conversationHistory,
      config,
      serviceBundle,
      activeServices
    });
  }
  const activeAppointments = await getClientActiveAppointments(userId, clientPhone);
  for (const strictSchedulingRecovery of [false, true]) {
    const systemPrompt = buildSchedulingPlannerSystemPrompt({
      messageText,
      conversationHistory,
      config,
      serviceBundle,
      activeServices,
      activeAppointments,
      strictSchedulingRecovery
    });
    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: "Analise a conversa e devolva o JSON do pr\xF3ximo passo do agendamento." }
    ];
    try {
      const response = await chatComplete({
        messages,
        maxTokens: 500,
        temperature: strictSchedulingRecovery ? 0 : 0.1
      });
      const raw = String(response.choices?.[0]?.message?.content || "");
      const parsed = parseSchedulingPlannerDecision(raw);
      console.log(`\u{1F4C5} [Planner] action=${parsed?.action} shouldHandle=${parsed?.shouldHandle} wantsSchedulingNow=${parsed?.wantsSchedulingNow} recovery=${strictSchedulingRecovery} reasoning=${parsed?.reasoning}`);
      if (parsed?.shouldHandle && parsed.action !== "IGNORE") {
        return parsed;
      }
      if (strictSchedulingRecovery) {
        return parsed;
      }
    } catch (error) {
      console.error("[Scheduling] Planner LLM falhou:", error);
      if (strictSchedulingRecovery) {
        return null;
      }
    }
  }
  return null;
}
function buildSchedulingExecutionGatePrompt(input) {
  const historyLines = input.conversationHistory.slice(-10).map((message) => `${message.fromMe ? "ASSISTENTE" : "CLIENTE"}: ${String(message.text || "").trim()}`).filter(Boolean).join("\n");
  const catalogLines = input.activeServices.length > 0 ? input.activeServices.map((service) => `- id=${service.id} | ${service.name}`).join("\n") : "- nenhum";
  const selectedLines = input.serviceBundle.selectedServices.length > 0 ? input.serviceBundle.selectedServices.map((service) => `- ${service.name}`).join("\n") : "- nenhum";
  return [
    "Voc\xEA \xE9 um gate sem\xE2ntico do orquestrador de agendamento.",
    "Sua fun\xE7\xE3o \xE9 decidir se o executor pode assumir a resposta deste turno ou se deve deixar a resposta seguir o prompt livre do cliente.",
    "Responda SOMENTE JSON v\xE1lido.",
    "",
    "LIBERE allowSchedulingExecution=true apenas quando houver uma destas situa\xE7\xF5es:",
    "- o cliente pediu para agendar",
    "- o cliente pediu hor\xE1rios, datas ou disponibilidade",
    "- o cliente escolheu um hor\xE1rio j\xE1 oferecido",
    "- o cliente est\xE1 continuando um fluxo de agendamento j\xE1 aberto com dados como nome/endere\xE7o depois de um hor\xE1rio validado",
    "",
    "BLOQUEIE allowSchedulingExecution=false quando o cliente apenas:",
    "- cumprimentou",
    "- descreveu o servi\xE7o ou problema",
    "- pediu or\xE7amento, pre\xE7o, explica\xE7\xE3o ou detalhes",
    "- ainda n\xE3o demonstrou querer consultar agenda agora",
    "",
    "Se houver d\xFAvida entre or\xE7amento e agenda no primeiro turno, bloqueie.",
    "O gate deve ser conservador: sem inten\xE7\xE3o clara de agenda, n\xE3o deixe o executor responder.",
    "",
    "FORMATO EXATO:",
    '{ "allowSchedulingExecution": false, "reasoning": "curta" }',
    "",
    "DECIS\xC3O DO PLANNER:",
    JSON.stringify({
      action: input.plannerDecision.action,
      wantsSchedulingNow: Boolean(input.plannerDecision.wantsSchedulingNow),
      requestedDate: input.plannerDecision.requestedDate || null,
      requestedTime: input.plannerDecision.requestedTime || null,
      selectedDate: input.plannerDecision.selectedDate || null,
      selectedTime: input.plannerDecision.selectedTime || null,
      reasoning: input.plannerDecision.reasoning || null
    }),
    "",
    "SERVI\xC7OS RESOLVIDOS NO CONTEXTO:",
    selectedLines,
    "",
    "CAT\xC1LOGO DE SERVI\xC7OS:",
    catalogLines,
    "",
    "\xDALTIMAS MENSAGENS:",
    historyLines || "- sem hist\xF3rico",
    "",
    `MENSAGEM ATUAL DO CLIENTE: ${String(input.messageText || "").trim()}`,
    "",
    "Responda s\xF3 com JSON."
  ].join("\n");
}
async function confirmSchedulingExecutionGate(userId, clientPhone, messageText, conversationHistory, plannerDecision, serviceBundle, activeServices) {
  if (schedulingPlannerTestDependencies?.callSchedulingGate) {
    const mockedDecision = await schedulingPlannerTestDependencies.callSchedulingGate({
      userId,
      clientPhone,
      messageText,
      conversationHistory,
      plannerDecision,
      serviceBundle,
      activeServices
    });
    if (typeof mockedDecision === "boolean") {
      return mockedDecision;
    }
  }
  if (schedulingPlannerTestDependencies?.callPlanner) {
    return true;
  }
  try {
    const response = await chatComplete({
      messages: [
        {
          role: "system",
          content: buildSchedulingExecutionGatePrompt({
            messageText,
            conversationHistory,
            plannerDecision,
            serviceBundle,
            activeServices
          })
        },
        {
          role: "user",
          content: "Decida se o executor de agenda deve assumir a resposta deste turno."
        }
      ],
      maxTokens: 180,
      temperature: 0
    });
    const raw = cleanPlannerJson(String(response.choices?.[0]?.message?.content || ""));
    const parsed = JSON.parse(raw);
    return parsed?.allowSchedulingExecution === true;
  } catch (error) {
    console.error("[Scheduling] Gate sem\xE2ntico falhou:", error);
    return false;
  }
}
function buildSchedulingServiceContextCandidates(messageText, conversationHistory = []) {
  const recentTexts = conversationHistory.filter((message) => !message?.fromMe).map((message) => String(message?.text || "").trim()).filter(Boolean).slice(-10);
  return [messageText, ...recentTexts].map((value) => String(value || "").trim()).filter(Boolean);
}
function buildSchedulingServiceContextText(messageText, conversationHistory = []) {
  return buildSchedulingServiceContextCandidates(messageText, conversationHistory).join(" | ");
}
function assistantJustAskedForAddress(conversationHistory = []) {
  const recentAssistantMessages = [...conversationHistory].reverse().filter((message) => message?.fromMe && String(message?.text || "").trim().length > 0).slice(0, 3);
  for (const msg of recentAssistantMessages) {
    const msgText = String(msg.text);
    if (msgText.length > 200) {
      continue;
    }
    const normalized = normalizeSchedulingMessage(msgText);
    if (normalized.includes("nome completo") || normalized.includes("seu nome") || normalized.includes("preciso do seu nome") || normalized.includes("nome para registrar") || normalized.includes("nome pra finalizar")) {
      return false;
    }
    if (normalized.includes("endereco completo") || normalized.includes("qual o endereco") || normalized.includes("endereco onde") || normalized.includes("preciso do endereco") || normalized.includes("rua") || normalized.includes("numero") || normalized.includes("bairro")) {
      return true;
    }
  }
  return false;
}
function findLastAssistantSchedulingConfirmationPrompt(conversationHistory = []) {
  const recentAssistantMessages = [...conversationHistory].reverse().filter((message) => message?.fromMe && String(message?.text || "").trim().length > 0).slice(0, 3);
  for (const msg of recentAssistantMessages) {
    const normalized = normalizeSchedulingMessage(String(msg.text));
    if (normalized.includes("nome completo") || normalized.includes("seu nome")) {
      return String(msg.text);
    }
  }
  return null;
}
function hasRecentAssistantSchedulingChoicePrompt(conversationHistory = []) {
  const recentAssistantMessages = [...conversationHistory].reverse().filter((message) => message?.fromMe && String(message?.text || "").trim().length > 0).slice(0, 3);
  if (recentAssistantMessages.length === 0) {
    return false;
  }
  for (const recentAssistantMessage of recentAssistantMessages) {
    const text = String(recentAssistantMessage.text);
    const normalized = normalizeSchedulingMessage(text);
    if (normalized.includes("qual desses horarios funciona melhor") || normalized.includes("depois que voce escolher o horario")) {
      return true;
    }
    if (normalized.includes("horarios disponiveis") && normalized.includes("proximo passo cliente escolhe um horario")) {
      return true;
    }
    if (normalized.includes("qual desses horarios") || normalized.includes("qual deles funciona") || normalized.includes("qual deles fica") || normalized.includes("qual deles e melhor") || normalized.includes("qual horario e melhor") || normalized.includes("qual horario funciona") || normalized.includes("qual funciona melhor") || normalized.includes("escolha um dos horarios") || normalized.includes("escolha um horario") || normalized.includes("qual desses dias") || normalized.includes("qual dia funciona") || normalized.includes("qual dia e melhor") || normalized.includes("qual dia fica melhor")) {
      return true;
    }
    const timeMatches = text.match(/\d{2}[h:]\d{2}/g);
    if (timeMatches && new Set(timeMatches).size >= 3) {
      return true;
    }
    const dayTimeMatches = text.match(/(?:segunda|terça|terca|quarta|quinta|sexta|sábado|sabado|domingo)[\s\S]{0,30}?\d{2}[h:]\d{2}/gi);
    if (dayTimeMatches && dayTimeMatches.length >= 2) {
      return true;
    }
  }
  return false;
}
function findRecentAssistantSuggestedSchedulingSlot(conversationHistory = []) {
  const recentAssistantMessages = [...conversationHistory].reverse().filter((message) => message?.fromMe && String(message?.text || "").trim().length > 0).slice(0, 3);
  for (const recentAssistantMessage of recentAssistantMessages) {
    const text = String(recentAssistantMessage.text || "");
    const normalized = normalizeSchedulingMessage(text);
    if (!normalized) {
      continue;
    }
    if (!normalized.includes("horario") && !normalized.includes("agenda") && !normalized.includes("agendamento") && !normalized.includes("disponivel")) {
      continue;
    }
    const date = extractDate(normalized);
    const time = extractTime(normalized);
    if (!date || !time) {
      continue;
    }
    const timeMatches = text.match(/\d{2}[h:]\d{2}/g);
    if (timeMatches && new Set(timeMatches).size > 1) {
      continue;
    }
    return { date, time };
  }
  return null;
}
function extractOrdinalSlotFromListingForTests(messageText, conversationHistory) {
  return extractOrdinalSlotFromListing(messageText, conversationHistory);
}
function findRecentRequestedSchedulingSlot(conversationHistory = []) {
  const recentCustomerMessages = [...conversationHistory].reverse().filter((message) => !message?.fromMe && String(message?.text || "").trim().length > 0);
  for (const message of recentCustomerMessages) {
    const intent = detectSchedulingIntent(String(message.text || ""));
    if (!intent.detected || !intent.requestedDate || !intent.requestedTime) {
      continue;
    }
    if (intent.type === "book_appointment" || intent.type === "reschedule" || intent.type === "check_availability") {
      return {
        requestedDate: intent.requestedDate,
        requestedTime: intent.requestedTime
      };
    }
  }
  return null;
}
function cleanSchedulingCustomerField(value) {
  return String(value || "").trim().replace(/^[\s,.:;-]+/, "").replace(/[\s,.:;-]+$/, "").trim();
}
function findSchedulingFieldPosition(messageText, cues) {
  const lowerMessage = String(messageText || "").toLocaleLowerCase("pt-BR");
  let bestMatch = null;
  for (const cue of cues) {
    const index = lowerMessage.indexOf(cue);
    if (index < 0) {
      continue;
    }
    if (!bestMatch || index < bestMatch.index) {
      bestMatch = { index, cue };
    }
  }
  return bestMatch;
}
function extractSchedulingCustomerInfo(messageText, requiresCustomerAddress) {
  const originalText = String(messageText || "").trim();
  if (!originalText) {
    return {};
  }
  const nameCue = findSchedulingFieldPosition(originalText, [
    "meu nome completo \xE9 ",
    "meu nome completo e ",
    "meu nome \xE9 ",
    "meu nome e ",
    "no nome ",
    "nome completo \xE9 ",
    "nome completo e ",
    "nome \xE9 ",
    "nome e ",
    "nome: "
  ]);
  const addressCue = findSchedulingFieldPosition(originalText, [
    "e o endereco completo \xE9 ",
    "e o endereco completo e ",
    "o endereco completo \xE9 ",
    "o endereco completo e ",
    "endereco completo \xE9 ",
    "endereco completo e ",
    "e o endereco \xE9 ",
    "e o endereco e ",
    "o endereco \xE9 ",
    "o endereco e ",
    "endereco \xE9 ",
    "endereco e ",
    "endereco: "
  ]);
  let customerName;
  let customerAddress;
  if (nameCue) {
    const nameStart = nameCue.index + nameCue.cue.length;
    const nameEnd = addressCue && addressCue.index > nameStart ? addressCue.index : originalText.length;
    customerName = cleanSchedulingCustomerField(originalText.slice(nameStart, nameEnd));
  }
  if (addressCue) {
    const addressStart = addressCue.index + addressCue.cue.length;
    customerAddress = cleanSchedulingCustomerField(originalText.slice(addressStart));
  } else if (requiresCustomerAddress) {
    const lowered = originalText.toLocaleLowerCase("pt-BR");
    const looksLikeStandaloneAddress = lowered.startsWith("rua ") || lowered.startsWith("avenida ") || lowered.startsWith("av ") || lowered.startsWith("travessa ") || lowered.startsWith("alameda ") || lowered.startsWith("estrada ");
    if (looksLikeStandaloneAddress) {
      customerAddress = cleanSchedulingCustomerField(originalText);
    }
  }
  return {
    customerName: customerName || void 0,
    customerAddress: customerAddress || void 0
  };
}
function getSchedulingAddressPrompt() {
  return "DADO NECESS\xC1RIO: endere\xE7o completo do local onde ser\xE1 realizado o servi\xE7o";
}
function getSchedulingNamePrompt() {
  return "DADO NECESS\xC1RIO: nome completo do cliente para registrar no agendamento";
}
function messageLooksLikeStandaloneSchedulingName(messageText) {
  const trimmed = String(messageText || "").trim();
  if (!trimmed) {
    return false;
  }
  const normalized = normalizeSchedulingMessage(trimmed);
  if (!normalized) {
    return false;
  }
  if (["oi", "ola", "ol\xE1", "bom dia", "boa tarde", "boa noite", "sim", "nao", "n\xE3o"].includes(normalized)) {
    return false;
  }
  const tokens = tokenizeSchedulingMessage(trimmed);
  if (tokens.length === 0 || tokens.length > 5) {
    return false;
  }
  if (tokens.some((token) => /\d/.test(token))) {
    return false;
  }
  const addressPrefixes = ["rua", "avenida", "av", "travessa", "alameda", "estrada"];
  if (addressPrefixes.includes(tokens[0])) {
    return false;
  }
  return tokens.every((token) => token.length >= 1);
}
function buildDeterministicSchedulingCreationReply(appointmentDate, appointmentTime, clientName, serviceName, customerAddress, options) {
  const tagParts = [
    `DATA=${appointmentDate}`,
    `HORA=${appointmentTime}`,
    `NOME="${clientName}"`,
    `SERVICO="${serviceName}"`
  ];
  if (customerAddress) {
    tagParts.push(`ENDERECO="${customerAddress}"`);
  }
  if (options?.approvalToken) {
    tagParts.push(`CONFIRMACAO_DIA=${options.approvalToken}`);
  }
  const dateLabel = formatSchedulingDayLabel(appointmentDate);
  const normalizedTime = normalizeSchedulingTimeValue(appointmentTime);
  return `[AGENDAR: ${tagParts.join(", ")}]
AGENDAMENTO CONFIRMADO: ${dateLabel} \xE0s ${normalizedTime} \u2014 ${serviceName} para ${clientName} \u2705`;
}
function formatSchedulingDayLabel(date) {
  const dateObj = /* @__PURE__ */ new Date(`${date}T12:00:00`);
  const dayNames = [
    "Domingo",
    "Segunda-feira",
    "Ter\xE7a-feira",
    "Quarta-feira",
    "Quinta-feira",
    "Sexta-feira",
    "S\xE1bado"
  ];
  const dayName = dayNames[dateObj.getDay()] || date;
  const formattedDate = `${dateObj.getDate().toString().padStart(2, "0")}/${(dateObj.getMonth() + 1).toString().padStart(2, "0")}`;
  return `${dayName} (${formattedDate})`;
}
function formatSchedulingTimeChoices(times) {
  const normalizedTimes = times.map((time) => normalizeSchedulingTimeValue(time)).filter(Boolean);
  if (normalizedTimes.length === 0) {
    return "";
  }
  if (normalizedTimes.length === 1) {
    return normalizedTimes[0];
  }
  if (normalizedTimes.length === 2) {
    return `${normalizedTimes[0]} ou ${normalizedTimes[1]}`;
  }
  return `${normalizedTimes.slice(0, -1).join(", ")} ou ${normalizedTimes[normalizedTimes.length - 1]}`;
}
function buildSchedulingNextSlotsReply(slotsData, options) {
  const {
    requiresCustomerAddress = false,
    unavailableDate,
    confirmedDate,
    confirmedTime,
    requestConfirmationDetails = false
  } = options || {};
  const normalizedConfirmedTime = confirmedTime ? normalizeSchedulingTimeValue(confirmedTime) : "";
  if (confirmedDate && normalizedConfirmedTime) {
    const dateLabel = formatSchedulingDayLabel(confirmedDate);
    const confirmLines = [
      `HOR\xC1RIO CONFIRMADO: ${dateLabel} \xE0s ${normalizedConfirmedTime}`,
      `STATUS: dispon\xEDvel`
    ];
    if (requestConfirmationDetails) {
      confirmLines.push(`DADOS NECESS\xC1RIOS: nome completo do cliente${requiresCustomerAddress ? " e endere\xE7o do local" : ""}`);
    } else if (requiresCustomerAddress) {
      confirmLines.push(`DADO NECESS\xC1RIO: endere\xE7o do local`);
    }
    return confirmLines.join("\n");
  }
  const lines = [];
  if (unavailableDate) {
    lines.push(`DATA INDISPON\xCDVEL: ${formatSchedulingDayLabel(unavailableDate)} \u2014 sem hor\xE1rio para esse atendimento`);
  }
  if (!slotsData.length) {
    lines.push("DISPONIBILIDADE: nenhum hor\xE1rio encontrado nos pr\xF3ximos dias pelo sistema online");
    lines.push("ORIENTA\xC7\xC3O: sugerir contato direto para verificar outras possibilidades");
    return lines.join("\n").trim() || null;
  }
  lines.push("HOR\xC1RIOS DISPON\xCDVEIS:");
  for (const dayData of slotsData) {
    const timeChoices = formatSchedulingTimeChoices(dayData.slots.map((slot) => slot.start));
    if (!timeChoices) {
      continue;
    }
    lines.push(`- ${formatSchedulingDayLabel(dayData.date)}: ${timeChoices}`);
  }
  lines.push("PR\xD3XIMO PASSO: cliente escolhe um hor\xE1rio");
  if (requiresCustomerAddress) {
    lines.push("DADO NECESS\xC1RIO: endere\xE7o do local");
  }
  return lines.join("\n").trim();
}
function buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, serviceBundle, slotsData, options) {
  if (options?.confirmedDate && options?.confirmedTime) {
    clearRememberedSchedulingOfferedSlots(userId, clientPhone);
    clearValidatedSlotOffer(userId, clientPhone);
  } else if (slotsData.length > 0) {
    rememberSchedulingOfferedSlots(userId, clientPhone, serviceBundle, slotsData);
    const singleDayWithSlots = slotsData.find((day) => day.slots.length > 0);
    const totalSlotCount = slotsData.reduce((count, day) => count + day.slots.length, 0);
    if (totalSlotCount === 1 && singleDayWithSlots?.slots[0]) {
      rememberValidatedSlotOffer(
        userId,
        clientPhone,
        singleDayWithSlots.date,
        singleDayWithSlots.slots[0].start,
        serviceBundle
      );
    } else {
      clearValidatedSlotOffer(userId, clientPhone);
    }
  } else {
    clearRememberedSchedulingOfferedSlots(userId, clientPhone);
    clearValidatedSlotOffer(userId, clientPhone);
  }
  return buildSchedulingNextSlotsReply(slotsData, options);
}
async function buildSchedulingSlotSelectionReminderReply(input) {
  const rememberedSlotsData = buildRememberedSchedulingSlotsData(
    input.rememberedState,
    input.serviceBundle
  );
  if (rememberedSlotsData.length > 0) {
    const rememberedReply = buildSchedulingNextSlotsReply(rememberedSlotsData, {
      requiresCustomerAddress: input.serviceBundle.requiresCustomerAddress
    });
    return rememberedReply ? `${input.leadingText}
${rememberedReply}` : input.leadingText;
  }
  const nextSlots = await getNextAvailableSlots(input.userId, 1, {
    serviceDurationMinutes: input.serviceBundle.totalDurationMinutes
  });
  const nextSlotsReply = buildSchedulingNextSlotsReplyWithMemory(
    input.userId,
    input.clientPhone,
    input.serviceBundle,
    nextSlots,
    {
      requiresCustomerAddress: input.serviceBundle.requiresCustomerAddress
    }
  );
  return nextSlotsReply ? `${input.leadingText}
${nextSlotsReply}` : input.leadingText;
}
function buildSameDayApprovalKey(userId, clientPhone, date) {
  return `${userId}:${clientPhone}:${date}`;
}
function rememberSameDayRebookingApproval(userId, clientPhone, date) {
  sameDayRebookingApprovals.set(buildSameDayApprovalKey(userId, clientPhone, date), {
    date,
    expiresAt: Date.now() + SAME_DAY_REBOOK_APPROVAL_TTL_MS
  });
}
function hasSameDayRebookingApproval(userId, clientPhone, date) {
  const key = buildSameDayApprovalKey(userId, clientPhone, date);
  const approval = sameDayRebookingApprovals.get(key);
  if (!approval) {
    return false;
  }
  if (approval.expiresAt <= Date.now()) {
    sameDayRebookingApprovals.delete(key);
    return false;
  }
  return true;
}
function consumeSameDayRebookingApproval(userId, clientPhone, date) {
  sameDayRebookingApprovals.delete(buildSameDayApprovalKey(userId, clientPhone, date));
}
function findPendingSameDayApprovalDate(userId, clientPhone) {
  const prefix = `${userId}:${clientPhone}:`;
  for (const [key, approval] of sameDayRebookingApprovals.entries()) {
    if (!key.startsWith(prefix)) {
      continue;
    }
    if (approval.expiresAt <= Date.now()) {
      sameDayRebookingApprovals.delete(key);
      continue;
    }
    return approval.date;
  }
  return null;
}
function buildValidatedSlotOfferKey(userId, clientPhone) {
  return `${userId}:${clientPhone}`;
}
function rememberValidatedSlotOffer(userId, clientPhone, date, time, serviceBundle) {
  validatedSlotOffers.set(buildValidatedSlotOfferKey(userId, clientPhone), {
    date,
    time,
    expiresAt: Date.now() + VALIDATED_SLOT_OFFER_TTL_MS,
    serviceBundle
  });
}
function getValidatedSlotOffer(userId, clientPhone) {
  const key = buildValidatedSlotOfferKey(userId, clientPhone);
  const offer = validatedSlotOffers.get(key);
  if (!offer) {
    return null;
  }
  if (offer.expiresAt <= Date.now()) {
    validatedSlotOffers.delete(key);
    return null;
  }
  return offer;
}
function markValidatedSlotOfferAccepted(userId, clientPhone) {
  const offer = getValidatedSlotOffer(userId, clientPhone);
  if (!offer) {
    return null;
  }
  offer.acceptedAt = Date.now();
  offer.expiresAt = Date.now() + VALIDATED_SLOT_OFFER_TTL_MS;
  validatedSlotOffers.set(buildValidatedSlotOfferKey(userId, clientPhone), offer);
  return offer;
}
function rememberAcceptedValidatedSlotOffer(userId, clientPhone, offer, patch) {
  const nextState = rememberSchedulingConversationState(userId, clientPhone, {
    confirmedDate: offer.date,
    confirmedTime: offer.time,
    selectedDate: offer.date,
    selectedTime: offer.time,
    selectedServices: offer.serviceBundle.selectedServices,
    totalDurationMinutes: offer.serviceBundle.totalDurationMinutes,
    totalPrice: offer.serviceBundle.totalPrice,
    requiresCustomerAddress: offer.serviceBundle.requiresCustomerAddress,
    offeredSlots: [],
    offeredSlotsServiceKey: "",
    ...patch
  });
  clearValidatedSlotOffer(userId, clientPhone);
  return nextState;
}
function clearValidatedSlotOffer(userId, clientPhone) {
  validatedSlotOffers.delete(buildValidatedSlotOfferKey(userId, clientPhone));
}
function normalizeServiceNameForLookup(value) {
  return normalizeTextForComparison(value).replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function normalizeServiceRequestTokens(serviceName) {
  const raw = String(serviceName || "").trim();
  if (!raw) {
    return [];
  }
  return raw.split(/\s*\+\s*/).flatMap((part) => {
    const normalized = normalizeServiceNameForLookup(part);
    if (!normalized) return [];
    return normalized.split(/\s+(?:e|com)\s+|,/i).map((token) => token.trim()).filter(Boolean);
  });
}
var SCHEDULING_GREETING_MESSAGES = /* @__PURE__ */ new Set([
  "oi",
  "ola",
  "ol\xE1",
  "bom dia",
  "boa tarde",
  "boa noite",
  "opa",
  "e ai",
  "e a\xED"
]);
function isGreetingOnlySchedulingMessage(messageText) {
  const normalized = normalizeSchedulingMessage(String(messageText || ""));
  return Boolean(normalized) && SCHEDULING_GREETING_MESSAGES.has(normalized);
}
var SERVICE_LOOKUP_STOPWORDS = /* @__PURE__ */ new Set([
  "a",
  "ao",
  "aos",
  "as",
  "com",
  "como",
  "da",
  "das",
  "de",
  "do",
  "dos",
  "e",
  "em",
  "no",
  "nos",
  "na",
  "nas",
  "o",
  "os",
  "ou",
  "para",
  "por",
  "pra",
  "pro",
  "um",
  "uma",
  "uns",
  "umas",
  "me",
  "meu",
  "minha",
  "preciso",
  "quero",
  "gostaria",
  "tem",
  "tenho",
  "temos",
  "faz",
  "fazer",
  "fazem",
  "queria",
  "voce",
  "voces",
  "voc\xEAs",
  "favor"
]);
var GENERIC_SERVICE_TERMS = /* @__PURE__ */ new Set([
  "agendamento",
  "assistencia",
  "atendimento",
  "avaliacao",
  "avaliar",
  "cliente",
  "completo",
  "completa",
  "conserto",
  "deslocamento",
  "endereco",
  "execucao",
  "fiacao",
  "fio",
  "instalacao",
  "instalar",
  "instalacaoo",
  "local",
  "manutencao",
  "orcamento",
  "passagem",
  "pedido",
  "pronto",
  "realizar",
  "reparo",
  "retirada",
  "servico",
  "simples",
  "tecnica",
  "tecnico",
  "troca",
  "trocar",
  "verificacao",
  "visita"
]);
var SERVICE_LOOKUP_TERM_ALIASES = {
  usg: "ultrassom",
  ultrassonografia: "ultrassom",
  ultrassonografico: "ultrassom",
  ultrassonografica: "ultrassom"
};
var BROAD_SERVICE_FAMILY_TERMS = /* @__PURE__ */ new Set([
  "agendamento",
  "atendimento",
  "consulta",
  "exame",
  "servico",
  "ultrassom"
]);
function singularizeServiceToken(token) {
  const value = String(token || "").trim();
  if (value.length <= 3) {
    return value;
  }
  if (value.endsWith("oes")) {
    return `${value.slice(0, -3)}ao`;
  }
  if (value.endsWith("ais")) {
    return `${value.slice(0, -3)}al`;
  }
  if (value.endsWith("eis")) {
    return `${value.slice(0, -3)}el`;
  }
  if (value.endsWith("is")) {
    return `${value.slice(0, -2)}il`;
  }
  if (value.endsWith("ns")) {
    return `${value.slice(0, -2)}m`;
  }
  if (value.endsWith("s") && !value.endsWith("us") && !value.endsWith("ss")) {
    return value.slice(0, -1);
  }
  return value;
}
function canonicalizeServiceLookupTerm(token) {
  const singular = singularizeServiceToken(token);
  return SERVICE_LOOKUP_TERM_ALIASES[singular] || singular;
}
function buildMeaningfulServiceTerms(value) {
  const normalized = normalizeServiceNameForLookup(value);
  if (!normalized) {
    return [];
  }
  const uniqueTerms = /* @__PURE__ */ new Set();
  for (const rawPart of normalized.split(" ")) {
    const part = rawPart.trim();
    if (!part || SERVICE_LOOKUP_STOPWORDS.has(part)) {
      continue;
    }
    const singular = canonicalizeServiceLookupTerm(part);
    if (!singular || SERVICE_LOOKUP_STOPWORDS.has(singular)) {
      continue;
    }
    uniqueTerms.add(singular);
  }
  return Array.from(uniqueTerms);
}
function buildServiceAnchorTerms(serviceName) {
  const terms = buildMeaningfulServiceTerms(serviceName).filter((term) => !GENERIC_SERVICE_TERMS.has(term));
  return terms.length > 0 ? terms : buildMeaningfulServiceTerms(serviceName);
}
function buildServiceLookupTermSet(value) {
  return new Set(buildMeaningfulServiceTerms(value));
}
function buildCatalogServiceTermFrequency(catalog) {
  const frequency = /* @__PURE__ */ new Map();
  for (const service of catalog) {
    const uniqueTerms = buildServiceLookupTermSet(service.name);
    for (const term of uniqueTerms) {
      frequency.set(term, (frequency.get(term) || 0) + 1);
    }
  }
  return frequency;
}
function extractCatalogRelevantRequestTerms(candidate, catalog) {
  const catalogTermFrequency = buildCatalogServiceTermFrequency(catalog);
  return buildMeaningfulServiceTerms(candidate).filter((term) => catalogTermFrequency.has(term));
}
function findDirectRelevantCatalogServices(candidate, catalog) {
  const relevantTerms = extractCatalogRelevantRequestTerms(candidate, catalog);
  if (relevantTerms.length === 0) {
    return [];
  }
  const broadTerms = relevantTerms.filter((term) => BROAD_SERVICE_FAMILY_TERMS.has(term));
  const specificTerms = relevantTerms.filter((term) => !BROAD_SERVICE_FAMILY_TERMS.has(term));
  const directMatches = catalog.filter((service) => {
    const serviceTerms = buildServiceLookupTermSet(service.name);
    if (specificTerms.length > 0 && !specificTerms.every((term) => serviceTerms.has(term))) {
      return false;
    }
    if (broadTerms.length > 0 && !broadTerms.every((term) => serviceTerms.has(term))) {
      return false;
    }
    return true;
  });
  if (directMatches.length > 0) {
    return directMatches;
  }
  if (specificTerms.length > 0) {
    return catalog.filter((service) => {
      const serviceTerms = buildServiceLookupTermSet(service.name);
      return specificTerms.every((term) => serviceTerms.has(term));
    });
  }
  return [];
}
function buildRelevantSchedulingDisambiguationServices(messageText, activeServices, selectedServiceIds = []) {
  const directMatches = findDirectRelevantCatalogServices(messageText, activeServices);
  if (directMatches.length > 0) {
    return directMatches;
  }
  const selectedIds = new Set(selectedServiceIds.filter(Boolean));
  if (selectedIds.size === 0) {
    return [];
  }
  return activeServices.filter((service) => selectedIds.has(service.id));
}
function scoreSchedulingServiceCandidate(service, requestSegment) {
  const serviceAnchorTerms = buildServiceAnchorTerms(service.name);
  const requestAnchorTerms = buildServiceAnchorTerms(requestSegment);
  if (serviceAnchorTerms.length === 0 || requestAnchorTerms.length === 0) {
    return 0;
  }
  const serviceMeaningfulTerms = new Set(buildMeaningfulServiceTerms(service.name));
  const requestMeaningfulTerms = new Set(buildMeaningfulServiceTerms(requestSegment));
  const normalizedServiceName = normalizeServiceNameForLookup(service.name);
  const normalizedRequestSegment = normalizeServiceNameForLookup(requestSegment);
  let score = 0;
  for (const requestAnchor of requestAnchorTerms) {
    if (serviceAnchorTerms.includes(requestAnchor)) {
      score += 100;
    }
  }
  for (const requestTerm of requestMeaningfulTerms) {
    if (serviceMeaningfulTerms.has(requestTerm)) {
      score += GENERIC_SERVICE_TERMS.has(requestTerm) ? 5 : 15;
    }
  }
  if (normalizedRequestSegment && normalizedServiceName.includes(normalizedRequestSegment)) {
    score += 25;
  }
  const unmatchedServiceAnchorTerms = serviceAnchorTerms.filter((term) => !requestAnchorTerms.includes(term));
  score -= unmatchedServiceAnchorTerms.length * 60;
  return score;
}
function serviceMatchesContextCandidate(serviceName, candidate) {
  const normalizedName = normalizeServiceNameForLookup(serviceName);
  const normalizedCandidate = normalizeServiceNameForLookup(candidate);
  if (!normalizedName || !normalizedCandidate) {
    return false;
  }
  const candidateMeaningfulTerms = buildMeaningfulServiceTerms(candidate);
  if (candidateMeaningfulTerms.length >= 2 && (normalizedCandidate.includes(normalizedName) || normalizedName.includes(normalizedCandidate))) {
    return true;
  }
  const anchorTerms = buildServiceAnchorTerms(serviceName);
  const candidateTerms = new Set(buildServiceAnchorTerms(candidate));
  if (anchorTerms.length > 0 && anchorTerms.some((term) => candidateTerms.has(term))) {
    return true;
  }
  const nameTerms = new Set(anchorTerms);
  let overlap = 0;
  for (const term of candidateTerms) {
    if (nameTerms.has(term)) {
      overlap += 1;
    }
  }
  return overlap >= 1;
}
function isLikelySchedulingServiceDescriptionMessage(messageText, conversationHistory = []) {
  const normalized = normalizeSchedulingMessage(String(messageText || ""));
  if (!normalized || isGreetingOnlySchedulingMessage(normalized)) {
    return false;
  }
  if (looksLikeAffirmativeReply(messageText) || isGenericAvailabilityLookup(messageText)) {
    return false;
  }
  const currentIntent = inferSchedulingIntentFromConversation(messageText, conversationHistory);
  if (currentIntent.type === "check_availability" || currentIntent.type === "book_appointment" || currentIntent.type === "reschedule" || currentIntent.type === "cancel_appointment" || currentIntent.requestedDate || currentIntent.requestedTime) {
    return false;
  }
  const extractedInfo = extractSchedulingCustomerInfo(messageText, true);
  if (extractedInfo.customerAddress || extractedInfo.customerName || messageLooksLikeStandaloneSchedulingName(messageText)) {
    return false;
  }
  return buildServiceAnchorTerms(messageText).length > 0;
}
function coerceServicePrice(value) {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }
  if (typeof value === "string" && value.trim()) {
    const normalized = Number(value.replace(",", "."));
    return Number.isFinite(normalized) ? normalized : null;
  }
  return null;
}
async function listActiveSchedulingServices(userId) {
  const { data, error } = await supabase.from("scheduling_services").select("id, name, duration_minutes, price, is_active, requires_customer_address").eq("user_id", userId).eq("is_active", true).order("display_order", { ascending: true });
  if (error) {
    console.error("[Scheduling] Error fetching active services:", error);
    return [];
  }
  return data || [];
}
async function resolveServiceViaLLM(userMessage, catalog) {
  if (!userMessage?.trim() || catalog.length === 0) return { serviceIds: [], isAmbiguous: false };
  if (schedulingPlannerTestDependencies?.resolveServiceViaLLM) {
    const mocked = await schedulingPlannerTestDependencies.resolveServiceViaLLM({
      userMessage,
      catalog
    });
    if (!mocked) {
      return { serviceIds: [], isAmbiguous: false };
    }
    const validIds = Array.isArray(mocked.serviceIds) ? mocked.serviceIds.filter((id) => catalog.some((service) => service.id === id)) : [];
    return {
      serviceIds: validIds,
      isAmbiguous: mocked.isAmbiguous === true
    };
  }
  const catalogText = catalog.map((s) => `- ID: ${s.id} | Nome: ${s.name} | R$${s.price ?? "?"} | ${s.duration_minutes ?? "?"}min`).join("\n");
  const prompt = `Voc\xEA \xE9 um assistente que identifica servi\xE7os a partir de um cat\xE1logo.

CAT\xC1LOGO DE SERVI\xC7OS:
${catalogText}

MENSAGEM DO CLIENTE:
"${userMessage}"

TAREFA: Identifique qual(is) servi\xE7o(s) do cat\xE1logo o cliente deseja.
- Se o cliente mencionar mais de um servi\xE7o, retorne todos.
- Se nenhum servi\xE7o corresponder, retorne array vazio.
- N\xE3o invente servi\xE7os que n\xE3o existam no cat\xE1logo.
- isAmbiguous = true quando o cliente usou um termo gen\xE9rico/vago que corresponde a V\xC1RIOS servi\xE7os (ex: "ultrassom" com 5 tipos, "consulta" com 3 tipos).
- isAmbiguous = false quando o cliente nomeou EXPLICITAMENTE os servi\xE7os que quer (ex: "corte e escova", "ultrassom abdominal").

Responda APENAS com JSON v\xE1lido, sem markdown:
{"serviceIds": ["id1", "id2"], "isAmbiguous": false, "reasoning": "breve explica\xE7\xE3o"}`;
  try {
    const response = await chatComplete({
      messages: [{ role: "user", content: prompt }],
      temperature: 0,
      maxTokens: 200,
      randomSeed: 42
    });
    const text = response?.choices?.[0]?.message?.content?.trim();
    if (!text) return { serviceIds: [], isAmbiguous: false };
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return { serviceIds: [], isAmbiguous: false };
    const parsed = JSON.parse(jsonMatch[0]);
    const ids = Array.isArray(parsed.serviceIds) ? parsed.serviceIds : [];
    const validIds = ids.filter((id) => catalog.some((s) => s.id === id));
    const isAmbiguous = parsed.isAmbiguous === true;
    if (validIds.length > 0) {
      console.log(`\u{1F4C5} [ServiceLLM] Identificou ${validIds.length} servi\xE7o(s)${isAmbiguous ? " (AMB\xCDGUO)" : ""}: ${parsed.reasoning || "sem raz\xE3o"}`);
    }
    return { serviceIds: validIds, isAmbiguous };
  } catch (err) {
    console.error("\u{1F4C5} [ServiceLLM] Erro:", err);
    return { serviceIds: [], isAmbiguous: false };
  }
}
async function resolveSchedulingServiceBundle(userId, requestedServiceName, config, options) {
  const activeServices = options?.activeServices || await listActiveSchedulingServices(userId);
  const uniqueActiveServices = [];
  const seenNormalizedServiceNames = /* @__PURE__ */ new Set();
  for (const service of activeServices) {
    const normalizedName = normalizeServiceNameForLookup(service.name);
    const dedupeKey = normalizedName || service.id;
    if (seenNormalizedServiceNames.has(dedupeKey)) {
      continue;
    }
    seenNormalizedServiceNames.add(dedupeKey);
    uniqueActiveServices.push(service);
  }
  const selectedServiceIds = (options?.selectedServiceIds || []).filter(Boolean);
  const matchedById = selectedServiceIds.length > 0 ? uniqueActiveServices.filter((service) => selectedServiceIds.includes(service.id)) : [];
  if (matchedById.length > 0) {
  }
  let llmMatched = [];
  let llmIsAmbiguous = false;
  if (matchedById.length === 0 && requestedServiceName?.trim() && uniqueActiveServices.length > 0) {
    const llmResult = await resolveServiceViaLLM(requestedServiceName, uniqueActiveServices);
    llmIsAmbiguous = llmResult.isAmbiguous;
    llmMatched = llmResult.serviceIds.map((id) => uniqueActiveServices.find((s) => s.id === id)).filter((s) => Boolean(s));
  }
  const directCandidate = String(options?.contextCandidates?.[0] || requestedServiceName || "").trim();
  const directRelevantMatches = directCandidate ? findDirectRelevantCatalogServices(directCandidate, uniqueActiveServices) : [];
  const shouldPreferDirectRelevantMatches = matchedById.length === 0 && directRelevantMatches.length > 0 && (llmMatched.length === 0 || !llmMatched.every((service) => directRelevantMatches.some((candidate) => candidate.id === service.id)) || directRelevantMatches.length > llmMatched.length);
  if (matchedById.length === 0 && directRelevantMatches.length > 1) {
    llmIsAmbiguous = true;
  }
  if (shouldPreferDirectRelevantMatches) {
    llmMatched = directRelevantMatches;
  }
  const contextCandidates = (options?.contextCandidates || [requestedServiceName || ""]).map((value) => String(value || "").trim()).filter(Boolean);
  const requestedTokens = contextCandidates.flatMap((candidate) => normalizeServiceRequestTokens(candidate));
  const bestServicesByToken = matchedById.length === 0 && llmMatched.length === 0 ? requestedTokens.map((token) => {
    const rankedCandidates = uniqueActiveServices.map((service) => ({
      service,
      score: scoreSchedulingServiceCandidate(service, token)
    })).filter((candidate) => candidate.score > 0).sort((left, right) => right.score - left.score);
    return rankedCandidates[0]?.service || null;
  }).filter((service) => Boolean(service)) : [];
  const matchedServices = matchedById.length > 0 ? matchedById : llmMatched.length > 0 ? llmMatched : bestServicesByToken.length > 0 ? Array.from(new Map(bestServicesByToken.map((service) => [service.id, service])).values()) : requestedTokens.length > 0 ? uniqueActiveServices.filter(
    (service) => contextCandidates.some((candidate) => serviceMatchesContextCandidate(service.name, candidate))
  ) : [];
  const selectedServices = matchedServices.length > 0 ? matchedServices : [{
    id: "",
    name: requestedServiceName || config.service_name || "Agendamento",
    duration_minutes: config.slot_duration || config.service_duration || 60,
    price: null,
    requires_customer_address: false
  }];
  const selectedServicePayload = selectedServices.map((service) => ({
    id: service.id,
    name: service.name,
    durationMinutes: Number(service.duration_minutes || config.slot_duration || 60),
    price: coerceServicePrice(service.price)
  }));
  const totalDurationMinutes = Math.max(
    selectedServicePayload.reduce((sum, service) => sum + (service.durationMinutes || 0), 0),
    Number(config.slot_duration || config.service_duration || 60)
  );
  const totalPrice = selectedServicePayload.reduce((sum, service) => {
    if (service.price === null || service.price === void 0) {
      return sum;
    }
    return (sum || 0) + service.price;
  }, 0);
  return {
    primaryServiceId: selectedServices.length === 1 && selectedServices[0].id ? selectedServices[0].id : void 0,
    combinedServiceName: selectedServicePayload.map((service) => service.name).join(" + "),
    totalDurationMinutes,
    totalPrice: totalPrice && totalPrice > 0 ? totalPrice : null,
    requiresCustomerAddress: selectedServices.some((service) => Boolean(service.requires_customer_address)),
    isAmbiguousMatch: llmIsAmbiguous,
    selectedServices: selectedServicePayload
  };
}
function formatServiceBreakdownLines(context) {
  const lines = context.selectedServices.map((service) => {
    const extras = [];
    if (service.durationMinutes > 0) {
      extras.push(`${service.durationMinutes} min`);
    }
    if (service.price !== null && service.price !== void 0) {
      extras.push(`R$ ${service.price.toFixed(2).replace(".", ",")}`);
    }
    return `Servi\xE7o: ${service.name}${extras.length ? ` (${extras.join(" | ")})` : ""}`;
  });
  if (context.totalPrice !== null && context.totalPrice !== void 0) {
    lines.push(`Total combinado: R$ ${context.totalPrice.toFixed(2).replace(".", ",")}`);
  }
  return lines;
}
function buildSchedulingContextFromBundle(serviceBundle, customerAddress) {
  return {
    domain: "scheduling",
    selectedServices: serviceBundle.selectedServices,
    totalDurationMinutes: serviceBundle.totalDurationMinutes,
    totalPrice: serviceBundle.totalPrice,
    customerAddress: customerAddress?.trim() || void 0
  };
}
function formatValidatedSlotHeading(date, time) {
  const dateObj = /* @__PURE__ */ new Date(`${date}T12:00:00`);
  const dayNames = ["domingo", "segunda-feira", "terca-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sabado"];
  const dayName = dayNames[dateObj.getDay()] || date;
  const formattedDate = `${dateObj.getDate().toString().padStart(2, "0")}/${(dateObj.getMonth() + 1).toString().padStart(2, "0")}`;
  return `${dayName} (${formattedDate}) as ${time}`;
}
function looksLikeAffirmativeReply(messageText) {
  const normalized = normalizeTextForComparison(messageText);
  return /^(sim|pode|pode sim|claro|confirmo|ok|beleza|isso|isso mesmo)\b/.test(normalized);
}
function readTagField(rawTag, fieldName) {
  const marker = `${fieldName}=`;
  const startIndex = rawTag.indexOf(marker);
  if (startIndex < 0) {
    return void 0;
  }
  const valueStart = startIndex + marker.length;
  let cursor = valueStart;
  let inQuotes = false;
  while (cursor < rawTag.length) {
    const current = rawTag[cursor];
    if (current === '"') {
      inQuotes = !inQuotes;
      cursor += 1;
      continue;
    }
    if (!inQuotes && (current === "," || current === "]")) {
      break;
    }
    cursor += 1;
  }
  return rawTag.slice(valueStart, cursor).trim().replace(/^"|"$/g, "") || void 0;
}
function extractSchedulingTags(text) {
  const tags = [];
  const marker = "[AGENDAR:";
  let searchIndex = text.indexOf(marker);
  while (searchIndex >= 0) {
    const endIndex = text.indexOf("]", searchIndex);
    const raw = endIndex >= 0 ? text.slice(searchIndex, endIndex + 1) : text.slice(searchIndex);
    const date = readTagField(raw, "DATA");
    const time = readTagField(raw, "HORA");
    const clientName = readTagField(raw, "NOME");
    const serviceName = readTagField(raw, "SERVICO");
    const customerAddress = readTagField(raw, "ENDERECO");
    const approvalToken = readTagField(raw, "CONFIRMACAO_DIA");
    if (date && time && clientName) {
      tags.push({
        raw,
        date,
        time,
        clientName,
        serviceName,
        customerAddress,
        approvalToken
      });
    }
    searchIndex = text.indexOf(marker, searchIndex + marker.length);
  }
  return tags;
}
function stripSchedulingTagArtifacts(text) {
  const marker = "[AGENDAR:";
  let result = text;
  let searchIndex = result.indexOf(marker);
  while (searchIndex >= 0) {
    const endIndex = result.indexOf("]", searchIndex);
    const lineBreakIndex = result.indexOf("\n", searchIndex);
    const removeUntil = endIndex >= 0 ? endIndex + 1 : lineBreakIndex >= 0 ? lineBreakIndex : result.length;
    result = `${result.slice(0, searchIndex)}${result.slice(removeUntil)}`;
    searchIndex = result.indexOf(marker);
  }
  return result.replace(/\n{3,}/g, "\n\n").trim();
}
function findExactAvailableSlot(slots, requestedTime) {
  const normalizedRequestedTime = normalizeSchedulingTimeValue(requestedTime);
  return slots.find((slot) => normalizeSchedulingTimeValue(slot.start) === normalizedRequestedTime);
}
function findClosestAvailableSlot(slots, requestedTime, toleranceMinutes = 59) {
  const requestedMinutes = timeToMinutes(normalizeSchedulingTimeValue(requestedTime) || requestedTime);
  let bestForward;
  let bestForwardDiff = Infinity;
  let bestBackward;
  let bestBackwardDiff = Infinity;
  for (const slot of slots) {
    if (!slot.available) continue;
    const slotMinutes = timeToMinutes(normalizeSchedulingTimeValue(slot.start));
    const diff = slotMinutes - requestedMinutes;
    const absDiff = Math.abs(diff);
    if (absDiff > toleranceMinutes) continue;
    if (diff >= 0 && absDiff < bestForwardDiff) {
      bestForwardDiff = absDiff;
      bestForward = slot;
    } else if (diff < 0 && absDiff < bestBackwardDiff) {
      bestBackwardDiff = absDiff;
      bestBackward = slot;
    }
  }
  return bestForward || bestBackward;
}
function responseLooksLikeSuccessfulScheduling(text) {
  const normalized = normalizeTextForComparison(text);
  const negativeHints = [
    "nao esta disponivel",
    "nao est\xE1 disponivel",
    "nao disponivel",
    "horario ocupado",
    "horario indisponivel",
    "erro ao agendar",
    "falha ao agendar",
    "pode me informar outro"
  ];
  if (negativeHints.some((hint) => normalized.includes(hint))) {
    return false;
  }
  const positiveHints = [
    "agendamento esta",
    "agendamento foi",
    "agendamento confirmado",
    "agendamento registrado",
    "horario esta confirmado",
    "seu horario esta confirmado",
    "seu horario foi reservado",
    "ficou reservado",
    "registrado na agenda",
    "vou registrar na agenda",
    "horario esta disponivel",
    "horario dispon\xEDvel",
    "reservei seu horario",
    "reserva confirmada"
  ];
  return positiveHints.some((hint) => normalized.includes(hint));
}
function splitResponseIntoBlocks(text) {
  const lines = String(text || "").split("\n");
  const blocks = [];
  let currentBlock = [];
  for (const line of lines) {
    const trimmedLine = line.trim();
    if (!trimmedLine) {
      if (currentBlock.length > 0) {
        blocks.push(currentBlock.join("\n").trim());
        currentBlock = [];
      }
      continue;
    }
    currentBlock.push(trimmedLine);
  }
  if (currentBlock.length > 0) {
    blocks.push(currentBlock.join("\n").trim());
  }
  return blocks;
}
function buildFailedSchedulingResponseText(responseText, errorMessage) {
  const sanitizedText = stripSchedulingTagArtifacts(responseText).trim();
  if (!sanitizedText) {
    return errorMessage;
  }
  const safeBlocks = splitResponseIntoBlocks(sanitizedText).filter((block) => !responseLooksLikeSuccessfulScheduling(block));
  const safeText = safeBlocks.join("\n\n").trim();
  if (!safeText || responseLooksLikeSuccessfulScheduling(safeText)) {
    return errorMessage;
  }
  if (safeText.includes(errorMessage)) {
    return safeText;
  }
  return `${safeText}

${errorMessage}`.trim();
}
function normalizeAppointmentDateValue(value) {
  if (value instanceof Date) {
    return formatDate(value);
  }
  const raw = String(value || "").trim();
  if (!raw) {
    return "";
  }
  if (raw.length >= 10 && raw[4] === "-" && raw[7] === "-") {
    return raw.slice(0, 10);
  }
  const parsed = new Date(raw);
  if (!Number.isNaN(parsed.getTime())) {
    return formatDate(parsed);
  }
  return raw;
}
function getNextAppointmentDateValue(value) {
  const normalizedDate = normalizeAppointmentDateValue(value);
  const parsed = /* @__PURE__ */ new Date(`${normalizedDate}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) {
    return normalizedDate;
  }
  parsed.setDate(parsed.getDate() + 1);
  return formatDate(parsed);
}
function toDatabaseTimeString(value) {
  const raw = String(value || "").trim();
  if (!raw) {
    return "00:00:00";
  }
  const sanitized = raw.replace("h", ":").replace("H", ":").replace(" horas", "").replace(" hora", "");
  const [hourPart = "00", minutePart = "00", secondPart = "00"] = sanitized.split(":");
  const hour = hourPart.padStart(2, "0");
  const minute = minutePart.padStart(2, "0");
  const second = secondPart.padStart(2, "0");
  return `${hour}:${minute}:${second}`;
}
function normalizeSchedulingTimeValue(value) {
  return toDatabaseTimeString(value).slice(0, 5);
}
async function getSchedulingConfigCached(userId) {
  const cached = schedulingConfigCache.get(userId);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }
  try {
    const { data, error } = await supabase.from("scheduling_config").select("*").eq("user_id", userId).single();
    const config = error || !data ? null : data;
    schedulingConfigCache.set(userId, {
      data: config,
      timestamp: Date.now()
    });
    return config;
  } catch (error) {
    console.error("[Scheduling] Error fetching config:", error);
    return null;
  }
}
async function getSchedulingConfig(userId) {
  return getSchedulingConfigCached(userId);
}
async function getExceptionForDate(userId, date) {
  try {
    const { data, error } = await supabase.from("scheduling_exceptions").select("*").eq("user_id", userId).eq("exception_date", date).single();
    if (error || !data) return null;
    return data;
  } catch (error) {
    console.error("[Scheduling] Error fetching exception:", error);
    return null;
  }
}
async function getAppointmentsForDate(userId, date) {
  try {
    const { data, error } = await supabase.from("appointments").select("*").eq("user_id", userId).eq("appointment_date", date).in("status", ["pending", "confirmed"]).order("start_time", { ascending: true });
    if (error) {
      console.error("[Scheduling] Error fetching appointments:", error);
      return [];
    }
    return data || [];
  } catch (error) {
    console.error("[Scheduling] Error fetching appointments:", error);
    return [];
  }
}
function isDayAvailable(date, config, exception) {
  const dateObj = /* @__PURE__ */ new Date(date + "T12:00:00");
  const dayOfWeek = dateObj.getDay();
  if (exception && (exception.exception_type === "blocked" || exception.exception_type === "holiday")) {
    return false;
  }
  if (!config.available_days.includes(dayOfWeek)) {
    return false;
  }
  const brazil = getBrazilDateTime();
  const todayBrazil = /* @__PURE__ */ new Date(brazil.dateStr + "T00:00:00");
  const targetDate = /* @__PURE__ */ new Date(date + "T00:00:00");
  if (targetDate < todayBrazil) {
    return false;
  }
  const maxDate = new Date(todayBrazil);
  maxDate.setDate(maxDate.getDate() + config.advance_booking_days);
  if (targetDate > maxDate) {
    return false;
  }
  return true;
}
async function getAvailableSlots(userId, date, providedConfig, options) {
  const config = providedConfig ?? await getSchedulingConfigCached(userId);
  console.log(`\u{1F4C5} [getAvailableSlots] Config para ${userId}:`, {
    is_enabled: config?.is_enabled,
    work_start_time: config?.work_start_time,
    work_end_time: config?.work_end_time,
    available_days: config?.available_days,
    slot_duration: config?.slot_duration,
    has_break: config?.has_break,
    break_start: config?.break_start_time,
    break_end: config?.break_end_time
  });
  if (!config || !config.is_enabled) {
    console.log(`\u{1F4C5} [getAvailableSlots] \u274C Config n\xE3o habilitada ou n\xE3o encontrada`);
    return [];
  }
  const exception = await getExceptionForDate(userId, date);
  if (!isDayAvailable(date, config, exception)) {
    return [];
  }
  const existingAppointments = await getAppointmentsForDate(userId, date);
  if (existingAppointments.length > 0) {
    console.log(`\u{1F4C5} [getAvailableSlots] ${date}: ${existingAppointments.length} agendamentos existentes:`, existingAppointments.map((a) => `${a.start_time}-${a.end_time} (${a.status})`));
  }
  let googleBusyWindows = [];
  if (config.google_calendar_enabled) {
    const googleCalendarConnected = await isGoogleCalendarConnected(userId);
    if (googleCalendarConnected) {
      const googleBusyResult = await listCalendarBusyWindows(
        userId,
        `${date}T00:00:00`,
        `${date}T23:59:59`
      );
      if (!googleBusyResult.success) {
        console.error("[Scheduling] Error fetching Google Calendar busy windows:", googleBusyResult.error);
        return [];
      }
      googleBusyWindows = googleBusyResult.windows || [];
      console.log(`\u{1F4C5} [getAvailableSlots] ${date}: ${googleBusyWindows.length} Google busy windows${googleBusyWindows.length > 0 ? ":" : " (calendar empty)"}`, googleBusyWindows.length > 0 ? googleBusyWindows.map((w) => `${w.startDateTime} \u2192 ${w.endDateTime}`) : "");
    }
  }
  let startTime = config.work_start_time;
  let endTime = config.work_end_time;
  if (exception?.exception_type === "modified_hours") {
    startTime = exception.custom_start_time || startTime;
    endTime = exception.custom_end_time || endTime;
  }
  const slots = [];
  const slotDuration = config.slot_duration;
  const appointmentDuration = options?.serviceDurationMinutes || config.slot_duration;
  const buffer = options?.bufferBetweenAppointments ?? config.buffer_between_appointments;
  console.log(`\u{1F4C5} [getAvailableSlots] ${date}: appointmentDuration=${appointmentDuration}, slotDuration=${slotDuration}, buffer=${buffer}, step=${slotDuration + buffer}, serviceDurationFromOptions=${options?.serviceDurationMinutes}, startTime=${startTime}, endTime=${endTime}`);
  const [startH, startM] = startTime.split(":").map(Number);
  const [endH, endM] = endTime.split(":").map(Number);
  const startMinutes = startH * 60 + startM;
  let endMinutes = endH * 60 + endM;
  if (endMinutes === 0 || endMinutes > 0 && endMinutes <= startMinutes) {
    endMinutes = 24 * 60;
  }
  let breakStartMinutes = 0;
  let breakEndMinutes = 0;
  if (config.has_break && config.break_start_time && config.break_end_time) {
    const [bsH, bsM] = config.break_start_time.split(":").map(Number);
    const [beH, beM] = config.break_end_time.split(":").map(Number);
    breakStartMinutes = bsH * 60 + bsM;
    breakEndMinutes = beH * 60 + beM;
  }
  const brazil = getBrazilDateTime();
  const today = brazil.dateStr;
  let minSlotMinutes = 0;
  if (date === today) {
    const currentMinutes2 = brazil.date.getHours() * 60 + brazil.date.getMinutes();
    minSlotMinutes = currentMinutes2 + config.min_booking_notice_hours * 60;
  }
  let currentMinutes = startMinutes;
  let appointmentCount = existingAppointments.length;
  while (currentMinutes + appointmentDuration <= endMinutes) {
    const slotEndMinutes = currentMinutes + appointmentDuration;
    const isInBreak = config.has_break && currentMinutes < breakEndMinutes && slotEndMinutes > breakStartMinutes;
    const respectsMinNotice = currentMinutes >= minSlotMinutes;
    const underDailyLimit = appointmentCount < config.max_appointments_per_day;
    const slotStartStr = minutesToTime(currentMinutes);
    const slotEndStr = minutesToTime(slotEndMinutes);
    const slotStartDate = parseCalendarDateTimeWithTimeZone(`${date}T${slotStartStr}:00`);
    const slotEndDate = parseCalendarDateTimeWithTimeZone(`${date}T${slotEndStr}:00`);
    const hasConflict = existingAppointments.some((apt) => {
      const aptStart = timeToMinutes(apt.start_time);
      const aptEnd = timeToMinutes(apt.end_time);
      return currentMinutes < aptEnd && slotEndMinutes > aptStart;
    });
    const hasGoogleConflict = googleBusyWindows.some((busyWindow) => {
      const busyStart = new Date(busyWindow.startDateTime);
      const busyEnd = new Date(busyWindow.endDateTime);
      return slotStartDate < busyEnd && slotEndDate > busyStart;
    });
    const available = !isInBreak && !hasConflict && !hasGoogleConflict && respectsMinNotice && underDailyLimit;
    if (!available) {
      console.log(`\u{1F4C5} [getAvailableSlots] ${date} slot ${slotStartStr}-${slotEndStr} BLOQUEADO: break=${isInBreak}, conflict=${hasConflict}, google=${hasGoogleConflict}, notice=${!respectsMinNotice}, dailyLimit=${!underDailyLimit}`);
    }
    slots.push({
      start: slotStartStr,
      end: slotEndStr,
      available
    });
    currentMinutes += slotDuration + buffer;
  }
  const availableSlots = slots.filter((s) => s.available);
  console.log(`\u{1F4C5} [getAvailableSlots] ${date}: Gerados ${slots.length} slots, ${availableSlots.length} dispon\xEDveis`);
  console.log(`\u{1F4C5} [getAvailableSlots] Slots dispon\xEDveis:`, availableSlots.map((s) => s.start).slice(0, 10), availableSlots.length > 10 ? "..." : "");
  return slots;
}
async function createPendingAppointment(userId, clientName, clientPhone, appointmentDate, startTime, clientNotes, providedConfig, serviceName, conversationId, customerAddress, approvalToken, professionalId, professionalName) {
  const config = providedConfig ?? await getSchedulingConfigCached(userId);
  if (!config || !config.is_enabled) {
    return { success: false, error: "Sistema de agendamento desativado" };
  }
  const serviceBundle = await resolveSchedulingServiceBundle(userId, serviceName, config);
  const effectiveServiceName = serviceBundle.combinedServiceName || serviceName || config.service_name;
  const normalizedAddress = String(customerAddress || "").trim();
  if (serviceBundle.requiresCustomerAddress && !normalizedAddress) {
    return { success: false, error: "MISSING_CUSTOMER_ADDRESS" };
  }
  const { data: existingAppointments, error: existingAppointmentsError } = await supabase.from("appointments").select("*").eq("user_id", userId).eq("client_phone", clientPhone).eq("appointment_date", appointmentDate).eq("start_time", `${startTime}:00`).in("status", ["pending", "confirmed"]).limit(5);
  if (existingAppointmentsError) {
    console.error("[Scheduling] Error checking existing appointment:", existingAppointmentsError);
  } else if (existingAppointments && existingAppointments.length > 0) {
    const normalizedClientName = String(clientName || "").trim().toLocaleLowerCase("pt-BR");
    const normalizedServiceName = String(effectiveServiceName || "").trim().toLocaleLowerCase("pt-BR");
    const matchedAppointment = existingAppointments.find((appointment) => {
      const sameName = String(appointment.client_name || "").trim().toLocaleLowerCase("pt-BR") === normalizedClientName;
      const sameService = !normalizedServiceName || String(appointment.service_name || "").trim().toLocaleLowerCase("pt-BR") === normalizedServiceName;
      return sameName && sameService;
    }) || existingAppointments.find(
      (appointment) => String(appointment.client_name || "").trim().toLocaleLowerCase("pt-BR") === normalizedClientName
    ) || existingAppointments[0];
    console.log(
      `[Scheduling] Reusing existing appointment ${matchedAppointment.id} for ${clientPhone} at ${appointmentDate} ${startTime}`
    );
    clearValidatedSlotOffer(userId, clientPhone);
    return { success: true, appointment: matchedAppointment };
  }
  const { data: sameDayAppointments, error: sameDayAppointmentsError } = await supabase.from("appointments").select("id, appointment_date, start_time, service_name").eq("user_id", userId).eq("client_phone", clientPhone).eq("appointment_date", appointmentDate).in("status", ["pending", "confirmed"]);
  if (sameDayAppointmentsError) {
    console.error("[Scheduling] Error checking same-day appointments:", sameDayAppointmentsError);
  } else if ((sameDayAppointments || []).length > 0) {
    const approved = String(approvalToken || "").trim().toUpperCase() === "SIM" && hasSameDayRebookingApproval(userId, clientPhone, appointmentDate);
    if (!approved) {
      return { success: false, error: "CLIENT_ALREADY_HAS_APPOINTMENT_SAME_DAY" };
    }
  }
  const slots = await getAvailableSlots(userId, appointmentDate, config, {
    serviceDurationMinutes: serviceBundle.totalDurationMinutes
  });
  let selectedSlot = slots.find((s) => s.start === startTime && s.available);
  let adjustedTime;
  if (!selectedSlot) {
    const requestedMinutes = timeToMinutes(startTime);
    const availableSlots = slots.filter((s) => s.available);
    if (availableSlots.length > 0) {
      const TOLERANCE_MINUTES = 30;
      let closestSlot = null;
      let minDiff = Infinity;
      for (const slot of availableSlots) {
        const slotMinutes = timeToMinutes(slot.start);
        const diff = Math.abs(slotMinutes - requestedMinutes);
        if (diff <= TOLERANCE_MINUTES && diff < minDiff) {
          minDiff = diff;
          closestSlot = slot;
        }
      }
      if (closestSlot) {
        selectedSlot = closestSlot;
        adjustedTime = closestSlot.start;
        console.log(`\u{1F4C5} [Scheduling] Hor\xE1rio ${startTime} n\xE3o dispon\xEDvel, ajustado para ${adjustedTime} (diferen\xE7a: ${minDiff}min)`);
      }
    }
  }
  if (!selectedSlot) {
    const availableSlots = slots.filter((s) => s.available).map((s) => s.start).join(", ");
    console.log(`\u{1F4C5} [Scheduling] Slot ${startTime} n\xE3o encontrado. Slots dispon\xEDveis: ${availableSlots || "nenhum"}`);
    return { success: false, error: "Hor\xE1rio n\xE3o dispon\xEDvel" };
  }
  const finalStartTime = selectedSlot.start;
  const startMinutes = timeToMinutes(finalStartTime);
  const endMinutes = startMinutes + serviceBundle.totalDurationMinutes;
  const endTime = minutesToTime(endMinutes);
  const googleCalendarConnected = config.google_calendar_enabled ? await isGoogleCalendarConnected(userId) : false;
  if (googleCalendarConnected) {
    const googleAvailability = await checkCalendarAvailability(
      userId,
      `${appointmentDate}T${finalStartTime}:00`,
      `${appointmentDate}T${endTime}:00`,
      { failOpen: false }
    );
    if (!googleAvailability.checked) {
      return { success: false, error: "N\xE3o foi poss\xEDvel validar a agenda do Google" };
    }
    if (!googleAvailability.available) {
      return {
        success: false,
        error: googleAvailability.conflictEvent ? `Hor\xE1rio em conflito com Google Agenda: ${googleAvailability.conflictEvent}` : "Hor\xE1rio em conflito com Google Agenda"
      };
    }
  }
  const status = config.auto_confirm ? "confirmed" : "pending";
  try {
    let safeConversationId = null;
    if (conversationId) {
      const { data: conversationRecord, error: conversationLookupError } = await supabase.from("conversations").select("id").eq("id", conversationId).maybeSingle();
      if (conversationLookupError) {
        console.warn("[Scheduling] Could not validate conversation_id, saving appointment without conversation link:", conversationLookupError);
      } else if (conversationRecord?.id) {
        safeConversationId = conversationRecord.id;
      }
    }
    const location = serviceBundle.requiresCustomerAddress ? normalizedAddress : config.location;
    const locationType = serviceBundle.requiresCustomerAddress ? "endereco_cliente" : config.location_type;
    const schedulingContext = buildSchedulingContextFromBundle(serviceBundle, normalizedAddress);
    const { data, error } = await supabase.from("appointments").insert({
      user_id: userId,
      client_name: clientName,
      client_phone: clientPhone,
      service_name: effectiveServiceName,
      service_id: serviceBundle.primaryServiceId || null,
      professional_id: professionalId || null,
      professional_name: professionalName || null,
      appointment_date: appointmentDate,
      start_time: finalStartTime,
      end_time: endTime,
      duration_minutes: serviceBundle.totalDurationMinutes,
      location,
      location_type: locationType,
      conversation_id: safeConversationId,
      status,
      confirmed_by_client: false,
      confirmed_by_business: config.auto_confirm,
      created_by_ai: true,
      client_notes: clientNotes,
      reminder_sent: false,
      ai_conversation_context: schedulingContext
    }).select().single();
    if (error) {
      console.error("[Scheduling] Error creating appointment:", error);
      return { success: false, error: "Erro ao criar agendamento" };
    }
    let appointment = data;
    if (googleCalendarConnected) {
      const syncResult = await syncAppointmentToCalendar(
        userId,
        {
          id: appointment.id,
          clientName: appointment.client_name,
          clientPhone: appointment.client_phone,
          appointmentDate: appointment.appointment_date,
          appointmentTime: appointment.start_time,
          serviceName: appointment.service_name || effectiveServiceName,
          notes: appointment.client_notes,
          googleEventId: appointment.google_event_id,
          location: appointment.location || location,
          extraDetails: formatServiceBreakdownLines(schedulingContext)
        },
        appointment.duration_minutes || serviceBundle.totalDurationMinutes
      );
      if (!syncResult.success || !syncResult.eventId) {
        await supabase.from("appointments").delete().eq("id", appointment.id);
        return {
          success: false,
          error: syncResult.error || "Falha ao sincronizar com Google Agenda"
        };
      }
      const { data: syncedAppointment } = await supabase.from("appointments").update({
        google_event_id: syncResult.eventId,
        google_calendar_synced: true,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("id", appointment.id).select().single();
      if (syncedAppointment) {
        appointment = syncedAppointment;
      }
    }
    if ((sameDayAppointments || []).length > 0) {
      consumeSameDayRebookingApproval(userId, clientPhone, appointmentDate);
    }
    clearValidatedSlotOffer(userId, clientPhone);
    if (config.booking_notification_enabled && config.booking_notification_phone) {
      const { sendSchedulingBookingNotification } = await import("./schedulingNotificationService-WSZK2BBW.js");
      await sendSchedulingBookingNotification(userId, config.booking_notification_phone, {
        id: appointment.id,
        clientName: appointment.client_name,
        clientPhone: appointment.client_phone,
        appointmentDate: appointment.appointment_date,
        startTime: appointment.start_time,
        endTime: appointment.end_time,
        location: appointment.location,
        serviceName: appointment.service_name,
        selectedServices: schedulingContext.selectedServices,
        totalPrice: schedulingContext.totalPrice
      }).catch((error2) => {
        console.error("[Scheduling] Failed to send booking notification:", error2);
      });
    }
    return { success: true, appointment, adjustedTime };
  } catch (error) {
    console.error("[Scheduling] Error creating appointment:", error);
    return { success: false, error: "Erro ao criar agendamento" };
  }
}
function timeToMinutes(time) {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}
function minutesToTime(minutes) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`;
}
function getBrazilDateTime() {
  const now = /* @__PURE__ */ new Date();
  const brazilTime = new Date(now.toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
  const dateStr = `${brazilTime.getFullYear()}-${(brazilTime.getMonth() + 1).toString().padStart(2, "0")}-${brazilTime.getDate().toString().padStart(2, "0")}`;
  const timeStr = `${String(brazilTime.getHours()).padStart(2, "0")}:${String(brazilTime.getMinutes()).padStart(2, "0")}`;
  return { date: brazilTime, dateStr, timeStr };
}
async function getClientAppointmentsForDate(userId, clientPhone, appointmentDate) {
  const { data, error } = await supabase.from("appointments").select("*").eq("user_id", userId).eq("client_phone", clientPhone).eq("appointment_date", appointmentDate).in("status", ["pending", "confirmed"]).order("start_time", { ascending: true });
  if (error) {
    console.error("[Scheduling] Error fetching client appointments for date:", error);
    return [];
  }
  return data || [];
}
function buildSchedulingQuoteReply(context) {
  const hasSingleService = context.selectedServices.length === 1;
  const lines = [];
  if (hasSingleService) {
    const service = context.selectedServices[0];
    lines.push(`SERVI\xC7O: ${service.name}`);
    if (service.price !== null && service.price !== void 0) {
      lines.push(`PRE\xC7O: R$ ${service.price.toFixed(2).replace(".", ",")}`);
    }
    if (service.durationMinutes > 0) {
      lines.push(`DURA\xC7\xC3O: ${service.durationMinutes} min`);
    }
  } else {
    lines.push("SERVI\xC7OS IDENTIFICADOS:");
    for (const service of context.selectedServices) {
      const detailParts = [];
      if (service.price !== null && service.price !== void 0) {
        detailParts.push(`R$ ${service.price.toFixed(2).replace(".", ",")}`);
      }
      if (service.durationMinutes > 0) {
        detailParts.push(`${service.durationMinutes} min`);
      }
      lines.push(`- ${service.name}${detailParts.length ? ` (${detailParts.join(" | ")})` : ""}`);
    }
    if (context.totalPrice !== null && context.totalPrice !== void 0) {
      lines.push(`TOTAL COMBINADO: R$ ${context.totalPrice.toFixed(2).replace(".", ",")}`);
    }
  }
  if (context.customerAddress !== void 0) {
    lines.push(`ENDERE\xC7O INFORMADO: ${context.customerAddress}`);
  }
  lines.push("PR\xD3XIMO PASSO: verificar hor\xE1rios dispon\xEDveis na agenda");
  return lines.join("\n");
}
function formatSchedulingDisambiguationServiceLine(service) {
  const detailParts = [];
  if (service.price !== null && service.price !== void 0) {
    detailParts.push(`R$ ${Number(service.price).toFixed(2).replace(".", ",")}`);
  }
  if (service.duration_minutes) {
    detailParts.push(`${Number(service.duration_minutes)} min`);
  }
  return `- ${service.name}${detailParts.length ? ` (${detailParts.join(" | ")})` : ""}`;
}
function buildSchedulingDisambiguationReply(services) {
  const limitedServices = services.slice(0, 6);
  const lines = [
    "PEDIDO AMBIGUO:",
    "O cliente descreveu o servico de forma generica e ainda nao da para assumir qual item do catalogo ele quer.",
    "OPCOES RELACIONADAS:",
    ...limitedServices.map((service) => formatSchedulingDisambiguationServiceLine(service))
  ];
  if (services.length > limitedServices.length) {
    lines.push(`- ... e mais ${services.length - limitedServices.length} opcao(oes) parecida(s) no catalogo`);
  }
  lines.push("PROXIMO PASSO: confirmar qual servico especifico o cliente deseja antes de seguir para agenda.");
  return lines.join("\n");
}
function buildSchedulingDisambiguationTurnRule(services) {
  const disambiguationReply = buildSchedulingDisambiguationReply(services);
  return `
REGRA EXTRA DESTE TURNO:
- O cliente descreveu o servico de forma generica e ainda NAO ha contexto suficiente para escolher um item especifico do catalogo.
- NAO assuma um servico por conta propria.
- Use SOMENTE as opcoes relacionadas abaixo como base para pedir esclarecimento.
- Pergunte de forma natural qual exame/servico/regiao ele quer antes de falar em agenda.
- Se houver muitas opcoes, cite so algumas representativas e convide o cliente a dizer qual delas faz sentido.
- NAO use frases template.
${disambiguationReply}
`;
}
function buildSchedulingDisambiguationTurnRuleFromReply(disambiguationReply) {
  const trimmedReply = String(disambiguationReply || "").trim();
  if (!trimmedReply) {
    return "";
  }
  return `
REGRA EXTRA DESTE TURNO:
- O cliente descreveu o servico de forma generica e ainda NAO ha contexto suficiente para escolher um item especifico do catalogo.
- NAO assuma um servico por conta propria.
- Use SOMENTE as opcoes relacionadas abaixo como base para pedir esclarecimento.
- Pergunte de forma natural qual exame/servico/regiao ele quer antes de falar em agenda.
- Se houver muitas opcoes, cite so algumas representativas e convide o cliente a dizer qual delas faz sentido.
- NAO use frases template.
${trimmedReply}
`;
}
function isSchedulingDisambiguationReply(reply) {
  const normalized = normalizeTextForComparison(reply);
  return normalized.includes("pedido ambiguo") && normalized.includes("opcoes relacionadas");
}
function isSchedulingQuoteStructuredReply(reply) {
  const normalized = normalizeTextForComparison(reply);
  return normalized.includes("servico:") || normalized.includes("servicos identificados:") || normalized.includes("proximo passo: verificar horarios disponiveis na agenda");
}
function resolvePlannerSlotSelection(decision, messageText, conversationHistory = [], rememberedState) {
  const currentTurnIntent = inferSchedulingIntentFromConversation(messageText, conversationHistory);
  const recentRequestedSlot = findRecentRequestedSchedulingSlot(conversationHistory);
  return {
    date: decision.selectedDate || decision.requestedDate || currentTurnIntent.requestedDate || rememberedState?.confirmedDate || rememberedState?.selectedDate || recentRequestedSlot?.requestedDate || null,
    time: decision.selectedTime || decision.requestedTime || currentTurnIntent.requestedTime || rememberedState?.confirmedTime || rememberedState?.selectedTime || recentRequestedSlot?.requestedTime || null
  };
}
async function resolveRecentCustomerServiceBundle(userId, conversationHistory, config, activeServices) {
  const recentCustomerMessages = [...conversationHistory].reverse().filter(
    (message) => !message?.fromMe && String(message?.text || "").trim().length > 0 && isLikelySchedulingServiceDescriptionMessage(String(message?.text || ""), conversationHistory)
  ).slice(0, 8);
  for (const message of recentCustomerMessages) {
    const bundle = await resolveSchedulingServiceBundle(userId, String(message.text || ""), config, {
      activeServices,
      contextCandidates: [String(message.text || "")]
    });
    if (schedulingBundleHasResolvedCatalogServices(bundle)) {
      return bundle;
    }
  }
  return null;
}
async function resolvePlannerCustomerInfo(decision, messageText, requiresCustomerAddress, conversationHistory = [], rememberedState) {
  const extractedInfo = extractSchedulingCustomerInfo(messageText, requiresCustomerAddress);
  const recentAssistantPrompt = findLastAssistantSchedulingConfirmationPrompt(conversationHistory);
  const recentAssistantPromptNormalized = normalizeSchedulingMessage(recentAssistantPrompt || "");
  const hasConfirmedSchedulingProgress = Boolean(
    rememberedState?.confirmedDate && rememberedState?.confirmedTime
  );
  const inferredStandaloneName = !decision.customerName && !extractedInfo.customerName && messageLooksLikeStandaloneSchedulingName(messageText) && (recentAssistantPromptNormalized.includes("nome completo") || recentAssistantPromptNormalized.includes("seu nome") || hasConfirmedSchedulingProgress) ? cleanSchedulingCustomerField(messageText) : "";
  const customerName = cleanSchedulingCustomerField(
    decision.customerName || extractedInfo.customerName || inferredStandaloneName || rememberedState?.customerName || ""
  );
  const justAskedAddress = assistantJustAskedForAddress(conversationHistory);
  const inferredStandaloneAddress = !decision.customerAddress && !extractedInfo.customerAddress && justAskedAddress && requiresCustomerAddress && String(messageText || "").trim().length > 0 ? cleanSchedulingCustomerField(messageText) : "";
  const customerAddress = cleanSchedulingCustomerField(
    decision.customerAddress || extractedInfo.customerAddress || inferredStandaloneAddress || rememberedState?.customerAddress || ""
  );
  const needsLLMFallback = (!customerName || requiresCustomerAddress && !customerAddress) && hasConfirmedSchedulingProgress && String(messageText || "").trim().length > 3 && (justAskedAddress || Boolean(recentAssistantPrompt) || hasConfirmedSchedulingProgress);
  if (needsLLMFallback) {
    console.log(`\u{1F4C5} [CustomerInfo] Rigid extraction incomplete (name=${customerName || "(none)"}, addr=${customerAddress || "(none)"}) \u2014 trying LLM fallback`);
    const llmInfo = await extractCustomerInfoViaLLM(messageText, conversationHistory, requiresCustomerAddress);
    if (llmInfo) {
      return {
        customerName: customerName || llmInfo.customerName || void 0,
        customerAddress: customerAddress || llmInfo.customerAddress || void 0
      };
    }
  }
  return {
    customerName: customerName || void 0,
    customerAddress: customerAddress || void 0
  };
}
async function validateExactSchedulingSlot(userId, date, time, config, serviceBundle) {
  const slotsForRequestedDate = await getAvailableSlots(userId, date, config, {
    serviceDurationMinutes: serviceBundle.totalDurationMinutes
  });
  const availableSlots = slotsForRequestedDate.filter((slot) => slot.available);
  const matchedSlot = findClosestSchedulingSlotWithinTolerance(availableSlots, time);
  if (matchedSlot) {
    return {
      available: true,
      slot: matchedSlot
    };
  }
  const alternatives = availableSlots.length > 0 ? [{ date, slots: availableSlots.slice(0, 6) }] : await getNextAvailableSlots(userId, 1, {
    serviceDurationMinutes: serviceBundle.totalDurationMinutes
  });
  return {
    available: false,
    alternatives
  };
}
async function ensureConfirmedSchedulingSlot(userId, clientPhone, config, serviceBundle, rememberedState, targetDate, targetTime) {
  if (rememberedState?.confirmedDate && rememberedState?.confirmedTime) {
    return {
      ok: true,
      rememberedState,
      confirmedDate: rememberedState.confirmedDate,
      confirmedTime: rememberedState.confirmedTime
    };
  }
  if (!targetDate || !targetTime) {
    return {
      ok: true,
      rememberedState,
      confirmedDate: null,
      confirmedTime: null
    };
  }
  const rememberedOfferedSlot = resolveRememberedOfferedSchedulingSlot(
    rememberedState,
    serviceBundle,
    targetDate,
    targetTime
  );
  if (rememberedOfferedSlot) {
    const nextState2 = rememberSchedulingConversationState(userId, clientPhone, {
      confirmedDate: rememberedOfferedSlot.date,
      confirmedTime: rememberedOfferedSlot.time,
      selectedDate: rememberedOfferedSlot.date,
      selectedTime: rememberedOfferedSlot.time,
      offeredSlots: [],
      offeredSlotsServiceKey: ""
    });
    return {
      ok: true,
      rememberedState: nextState2 || rememberedState,
      confirmedDate: rememberedOfferedSlot.date,
      confirmedTime: rememberedOfferedSlot.time
    };
  }
  const exactValidation = await validateExactSchedulingSlot(
    userId,
    targetDate,
    targetTime,
    config,
    serviceBundle
  );
  if (!exactValidation.available) {
    return {
      ok: false,
      reply: buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, serviceBundle, exactValidation.alternatives, {
        requiresCustomerAddress: serviceBundle.requiresCustomerAddress,
        unavailableDate: targetDate
      }) || "N\xE3o encontrei esse hor\xE1rio dispon\xEDvel agora. Posso te mostrar outros hor\xE1rios reais."
    };
  }
  const nextState = rememberSchedulingConversationState(userId, clientPhone, {
    confirmedDate: targetDate,
    confirmedTime: exactValidation.slot.start,
    selectedDate: targetDate,
    selectedTime: exactValidation.slot.start,
    offeredSlots: [],
    offeredSlotsServiceKey: ""
  });
  return {
    ok: true,
    rememberedState: nextState || rememberedState,
    confirmedDate: targetDate,
    confirmedTime: exactValidation.slot.start
  };
}
function buildFallbackSchedulingPlannerDecision(input) {
  const currentIntent = inferSchedulingIntentFromConversation(input.messageText, input.conversationHistory);
  const extractedInfo = extractSchedulingCustomerInfo(
    input.messageText,
    input.serviceBundle.requiresCustomerAddress
  );
  const standaloneName = messageLooksLikeStandaloneSchedulingName(input.messageText) ? cleanSchedulingCustomerField(input.messageText) : "";
  const selectedServiceIds = (input.rememberedState?.selectedServices || input.serviceBundle.selectedServices).map((service) => String(service.id || "").trim()).filter(Boolean);
  if (hasRecentAssistantSchedulingChoicePrompt(input.conversationHistory) && currentIntent.requestedDate && currentIntent.requestedTime) {
    return {
      shouldHandle: true,
      action: "READY_TO_BOOK",
      selectedServiceIds,
      requestedDate: currentIntent.requestedDate,
      requestedTime: currentIntent.requestedTime,
      selectedDate: currentIntent.requestedDate,
      selectedTime: currentIntent.requestedTime,
      customerName: null,
      customerAddress: null,
      wantsSchedulingNow: true,
      wantsBookingDetails: true,
      confidence: 0.99,
      reasoning: "fallback deterministico: cliente escolheu um horario oferecido"
    };
  }
  if (input.rememberedState?.confirmedDate && input.rememberedState?.confirmedTime) {
    const hasOperationalPayload = Boolean(
      extractedInfo.customerAddress || extractedInfo.customerName || standaloneName
    );
    if (hasOperationalPayload) {
      return {
        shouldHandle: true,
        action: "READY_TO_BOOK",
        selectedServiceIds,
        requestedDate: input.rememberedState.confirmedDate,
        requestedTime: input.rememberedState.confirmedTime,
        selectedDate: input.rememberedState.confirmedDate,
        selectedTime: input.rememberedState.confirmedTime,
        customerName: extractedInfo.customerName || standaloneName || null,
        customerAddress: extractedInfo.customerAddress || null,
        wantsSchedulingNow: true,
        wantsBookingDetails: true,
        confidence: 0.99,
        reasoning: "fallback deterministico: cliente respondeu dado operacional apos horario travado"
      };
    }
  }
  const hasOperationalPayloadWithoutConfirmedSlot = Boolean(
    selectedServiceIds.length > 0 && (extractedInfo.customerAddress || extractedInfo.customerName || standaloneName) && !input.rememberedState?.confirmedDate && !input.rememberedState?.confirmedTime && hasRecentSchedulingContext(input.conversationHistory)
  );
  if (hasOperationalPayloadWithoutConfirmedSlot) {
    return {
      shouldHandle: true,
      action: "REQUEST_SLOT_SELECTION",
      selectedServiceIds,
      requestedDate: currentIntent.requestedDate || null,
      requestedTime: currentIntent.requestedTime || null,
      selectedDate: null,
      selectedTime: null,
      customerName: extractedInfo.customerName || standaloneName || null,
      customerAddress: extractedInfo.customerAddress || null,
      wantsSchedulingNow: true,
      wantsBookingDetails: false,
      confidence: 0.99,
      reasoning: "fallback deterministico: cliente enviou dado operacional sem horario confirmado"
    };
  }
  return null;
}
function shouldPreferFallbackSchedulingDecision(primaryDecision, fallbackDecision) {
  if (!fallbackDecision?.shouldHandle || fallbackDecision.action === "IGNORE") {
    return false;
  }
  if (!primaryDecision?.shouldHandle || primaryDecision.action === "IGNORE") {
    return true;
  }
  if (primaryDecision.action === "CANCEL_READY" || primaryDecision.action === "CANCEL_NEEDS_TARGET") {
    return false;
  }
  if (fallbackDecision.wantsSchedulingNow && !primaryDecision.wantsSchedulingNow) {
    return true;
  }
  if (fallbackDecision.action === "READY_TO_BOOK" && primaryDecision.action !== "READY_TO_BOOK") {
    return true;
  }
  if (fallbackDecision.action === "REQUEST_SLOT_SELECTION" && (primaryDecision.action === "QUOTE_ONLY" || primaryDecision.action === "LOOKUP_NEXT_SLOTS" || primaryDecision.action === "LOOKUP_DATE_AVAILABILITY" || primaryDecision.action === "CHECK_EXACT_SLOT")) {
    return true;
  }
  return false;
}
function buildSchedulingValidatedTurnRule(validatedReply) {
  const trimmedReply = String(validatedReply || "").trim();
  if (!trimmedReply) {
    return "";
  }
  return `
REGRA EXTRA DESTE TURNO (OBRIGAT\xD3RIA \u2014 resultado da consulta real \xE0 agenda):
- A decis\xE3o de agendamento deste turno j\xE1 foi validada pelo executor com consulta real ao Google Calendar e agendamentos internos.
- SIGA EXATAMENTE o resultado abaixo. Estes s\xE3o os \xDANICOS hor\xE1rios reais dispon\xEDveis.
- N\xC3O invente, adicione ou sugira outros hor\xE1rios al\xE9m dos listados abaixo.
- Se o bloco abaixo listar hor\xE1rios reais e o cliente escolher um deles nos pr\xF3ximos turnos, trate esse hor\xE1rio como mem\xF3ria v\xE1lida da conversa e continue o atendimento sem mandar pesquisar tudo de novo.
- Se a lista validada trouxer hor\xE1rios reais de um \xFAnico dia e o cliente responder s\xF3 com a hora (ex: '9h45' ou 'pode ser 9h45'), trate isso como escolha v\xE1lida do slot j\xE1 oferecido.
- A agenda s\xF3 deve ser consultada novamente se o cliente pedir outro dia/hor\xE1rio ou se o executor avisar que houve conflito ao registrar.
- N\xC3O pule etapas: se o sistema pede nome/endere\xE7o, pe\xE7a ao cliente antes de confirmar.
- Se o servi\xE7o exige ir at\xE9 o local do cliente (EXIGE ENDERE\xC7O), colete o endere\xE7o ANTES de usar a tag [AGENDAR:].
- O telefone do cliente j\xE1 est\xE1 na conversa \u2014 N\xC3O pergunte o telefone.
${trimmedReply}
`;
}
function isAmbiguousServiceQuery(serviceBundle) {
  return serviceBundle.isAmbiguousMatch === true;
}
function buildSchedulingQuoteTurnRule(quoteReply) {
  const trimmedReply = String(quoteReply || "").trim();
  if (!trimmedReply) {
    return "";
  }
  return `
REGRA EXTRA DESTE TURNO:
- A conversa ainda est\xE1 em fase de or\xE7amento/descri\xE7\xE3o do servi\xE7o.
- N\xC3O responda com hor\xE1rios nem tente agendar ainda.
- NUNCA invente ou sugira hor\xE1rios espec\xEDficos. Se o cliente perguntar sobre disponibilidade, diga que vai verificar na agenda.
- Use os DADOS ESTRUTURADOS abaixo como verdade deste turno. Responda de forma NATURAL e CONVERSACIONAL, como uma IA inteligente conversando pelo WhatsApp.
- N\xC3O copie os dados no formato listado \u2014 transforme-os em uma resposta fluida e humana seguindo o prompt principal do cliente.
- NUNCA use frases template como "Encontrei essa op\xE7\xE3o pra voc\xEA" ou "Separei estas possibilidades" \u2014 fale com suas pr\xF3prias palavras.
${trimmedReply}
`;
}
async function generateStateFirstSchedulingReply(input) {
  const {
    userId,
    clientPhone,
    messageText,
    conversationHistory,
    config,
    serviceBundle,
    pendingApprovalDate,
    shouldPersistCurrentBundle,
    ambiguousServices
  } = input;
  let rememberedState = input.rememberedState;
  if (!schedulingBundleHasResolvedCatalogServices(serviceBundle)) {
    console.log(`\u{1F4C5} [StateFirst] EARLY EXIT \u2014 no catalog services in bundle. Bundle: ${serviceBundle.combinedServiceName}, services: ${JSON.stringify(serviceBundle.selectedServices.map((s) => ({ id: s.id, name: s.name })))}`);
    return null;
  }
  const currentIntent = inferSchedulingIntentFromConversation(messageText, conversationHistory);
  if (currentIntent.type === "cancel_appointment") {
    console.log(`\u{1F4C5} [StateFirst] Cancel intent detected \u2014 delegating to planner`);
    return null;
  }
  const recentChoicePrompt = hasRecentAssistantSchedulingChoicePrompt(conversationHistory);
  const recentRequestedSlot = findRecentRequestedSchedulingSlot(conversationHistory);
  const noopDecision = {
    shouldHandle: false,
    action: "IGNORE",
    selectedServiceIds: [],
    requestedDate: null,
    requestedTime: null,
    selectedDate: null,
    selectedTime: null,
    customerName: null,
    customerAddress: null,
    wantsSchedulingNow: false,
    wantsBookingDetails: false,
    confidence: 0,
    reasoning: null
  };
  const customerInfo = await resolvePlannerCustomerInfo(
    noopDecision,
    messageText,
    serviceBundle.requiresCustomerAddress,
    conversationHistory,
    rememberedState
  );
  const hasConfirmedSlot = Boolean(rememberedState?.confirmedDate && rememberedState?.confirmedTime);
  const hasStandaloneNamePayload = Boolean(
    recentChoicePrompt && messageLooksLikeStandaloneSchedulingName(messageText)
  );
  const hasOperationalPayload = Boolean(
    customerInfo.customerAddress || customerInfo.customerName || hasStandaloneNamePayload
  );
  const hasRememberedServiceContext = Boolean(rememberedState?.selectedServices?.length);
  const isAffirmativeSchedulingFollowUp = Boolean(
    looksLikeAffirmativeReply(messageText) && hasRememberedServiceContext && !hasConfirmedSlot && !hasOperationalPayload
  );
  const wantsAvailabilityLookup = Boolean(
    isAvailabilityLookupFollowUp(messageText, conversationHistory) || isAffirmativeSchedulingFollowUp || isGenericAvailabilityLookup(messageText) || currentIntent.type === "check_availability" || currentIntent.type === "reschedule" || currentIntent.type === "book_appointment" && !currentIntent.requestedDate && !currentIntent.requestedTime
  );
  rememberSchedulingConversationState(userId, clientPhone, {
    selectedServices: shouldPersistCurrentBundle ? serviceBundle.selectedServices : void 0,
    totalDurationMinutes: shouldPersistCurrentBundle ? serviceBundle.totalDurationMinutes : void 0,
    totalPrice: shouldPersistCurrentBundle ? serviceBundle.totalPrice : void 0,
    requiresCustomerAddress: shouldPersistCurrentBundle ? serviceBundle.requiresCustomerAddress : void 0,
    customerName: customerInfo.customerName,
    customerAddress: customerInfo.customerAddress
  });
  rememberedState = getSchedulingConversationState(userId, clientPhone);
  const rememberedSlotFromOfferedContext = !hasConfirmedSlot ? resolveImplicitRememberedOfferedSchedulingSlot(
    rememberedState,
    serviceBundle,
    currentIntent.requestedDate || null,
    currentIntent.requestedTime || null
  ) : null;
  const assistantSuggestedSlot = !hasConfirmedSlot && !rememberedSlotFromOfferedContext && hasOperationalPayload ? findRecentAssistantSuggestedSchedulingSlot(conversationHistory) : null;
  const slotSelectionDate = currentIntent.requestedDate || rememberedSlotFromOfferedContext?.date || assistantSuggestedSlot?.date || null;
  const slotSelectionTime = currentIntent.requestedTime || rememberedSlotFromOfferedContext?.time || assistantSuggestedSlot?.time || null;
  const slotSelectionNeedsRecentChoicePrompt = Boolean(
    (rememberedSlotFromOfferedContext || assistantSuggestedSlot) && !currentIntent.requestedDate
  );
  const hasSlotSelectionContext = slotSelectionNeedsRecentChoicePrompt ? recentChoicePrompt || Boolean(assistantSuggestedSlot) : recentChoicePrompt || hasRememberedServiceContext;
  if (!hasConfirmedSlot && slotSelectionDate && slotSelectionTime && hasSlotSelectionContext) {
    console.log(`\u{1F4C5} [StateFirst] Slot selection path: date=${slotSelectionDate} time=${slotSelectionTime} remembered=${rememberedSlotFromOfferedContext ? "yes" : "no"}`);
    const lockedSlot = await ensureConfirmedSchedulingSlot(
      userId,
      clientPhone,
      config,
      serviceBundle,
      rememberedState,
      slotSelectionDate,
      slotSelectionTime
    );
    if (!lockedSlot.ok) {
      return lockedSlot.reply;
    }
    rememberedState = lockedSlot.rememberedState;
    if (serviceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
      return getSchedulingAddressPrompt();
    }
    if (!customerInfo.customerName) {
      return getSchedulingNamePrompt();
    }
  }
  if (hasConfirmedSlot || rememberedState?.confirmedDate && rememberedState?.confirmedTime) {
    const confirmedDate = rememberedState?.confirmedDate || null;
    const confirmedTime = rememberedState?.confirmedTime || null;
    if (serviceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
      return getSchedulingAddressPrompt();
    }
    if (!customerInfo.customerName) {
      return getSchedulingNamePrompt();
    }
    if (!confirmedDate || !confirmedTime) {
      return null;
    }
    const existingSameDayAppointments = await getClientAppointmentsForDate(userId, clientPhone, confirmedDate);
    const approvalToken = pendingApprovalDate && pendingApprovalDate === confirmedDate ? "SIM" : void 0;
    if (existingSameDayAppointments.length > 0 && approvalToken !== "SIM") {
      rememberSameDayRebookingApproval(userId, clientPhone, confirmedDate);
      const appointmentSummary = existingSameDayAppointments.map((appointment) => `${normalizeSchedulingTimeValue(appointment.start_time)} (${appointment.service_name || "agendamento"})`).join(", ");
      return `Voc\xEA j\xE1 possui agendamento no dia ${formatSchedulingDayLabel(confirmedDate)}: ${appointmentSummary}. Quer mesmo criar mais um hor\xE1rio nesse mesmo dia?`;
    }
    return buildDeterministicSchedulingCreationReply(
      confirmedDate,
      confirmedTime,
      customerInfo.customerName,
      serviceBundle.combinedServiceName || "Agendamento",
      customerInfo.customerAddress,
      { approvalToken }
    );
  }
  if (hasOperationalPayload && !hasConfirmedSlot) {
    return buildSchedulingSlotSelectionReminderReply({
      userId,
      clientPhone,
      serviceBundle,
      rememberedState,
      leadingText: "Antes de eu finalizar, preciso que voc\xEA escolha um dos hor\xE1rios dispon\xEDveis primeiro."
    });
  }
  if (recentChoicePrompt && !hasConfirmedSlot && currentIntent.requestedTime && !currentIntent.requestedDate && !rememberedSlotFromOfferedContext) {
    console.log(`\u{1F4C5} [StateFirst] explicit time ${currentIntent.requestedTime} does not match remembered offered slots \u2014 asking for a real listed slot`);
    return buildSchedulingSlotSelectionReminderReply({
      userId,
      clientPhone,
      serviceBundle,
      rememberedState,
      leadingText: "Preciso que voc\xEA escolha um dia e hor\xE1rio espec\xEDfico da lista abaixo:"
    });
  }
  if (recentChoicePrompt && !hasConfirmedSlot && !(currentIntent.requestedDate && currentIntent.requestedTime)) {
    console.log(`\u{1F4C5} [StateFirst] recentChoicePrompt=true but regex failed (date=${currentIntent.requestedDate}, time=${currentIntent.requestedTime}) \u2014 trying deterministic ordinal + LLM slot extraction`);
    const ordinalSlot = extractOrdinalSlotFromListing(messageText, conversationHistory);
    const llmSlot = ordinalSlot || await extractSlotSelectionViaLLM(messageText, conversationHistory);
    if (llmSlot) {
      console.log(`\u{1F4C5} [StateFirst] LLM extracted slot: date=${llmSlot.date} time=${llmSlot.time}`);
      const lockedSlot = await ensureConfirmedSchedulingSlot(
        userId,
        clientPhone,
        config,
        serviceBundle,
        rememberedState,
        llmSlot.date,
        llmSlot.time
      );
      if (!lockedSlot.ok) {
        return lockedSlot.reply;
      }
      rememberedState = lockedSlot.rememberedState;
      if (serviceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
        return getSchedulingAddressPrompt();
      }
      if (!customerInfo.customerName) {
        return getSchedulingNamePrompt();
      }
      const cd = lockedSlot.confirmedDate;
      const ct = lockedSlot.confirmedTime;
      if (cd && ct) {
        const existingSameDay = await getClientAppointmentsForDate(userId, clientPhone, cd);
        const approvalToken = pendingApprovalDate && pendingApprovalDate === cd ? "SIM" : void 0;
        if (existingSameDay.length > 0 && approvalToken !== "SIM") {
          rememberSameDayRebookingApproval(userId, clientPhone, cd);
          const summary = existingSameDay.map((a) => `${normalizeSchedulingTimeValue(a.start_time)} (${a.service_name || "agendamento"})`).join(", ");
          return `Voc\xEA j\xE1 possui agendamento no dia ${formatSchedulingDayLabel(cd)}: ${summary}. Quer mesmo criar mais um hor\xE1rio nesse mesmo dia?`;
        }
        return buildDeterministicSchedulingCreationReply(
          cd,
          ct,
          customerInfo.customerName,
          serviceBundle.combinedServiceName || "Agendamento",
          customerInfo.customerAddress,
          { approvalToken }
        );
      }
    }
    console.log(`\u{1F4C5} [StateFirst] LLM extraction also failed \u2014 re-showing slots with specific request`);
    return buildSchedulingSlotSelectionReminderReply({
      userId,
      clientPhone,
      serviceBundle,
      rememberedState,
      leadingText: "Preciso que voc\xEA escolha um dia e hor\xE1rio espec\xEDfico da lista abaixo:"
    });
  }
  if (wantsAvailabilityLookup && !hasConfirmedSlot && !recentChoicePrompt) {
    const nextSlots = await getNextAvailableSlots(userId, 1, {
      serviceDurationMinutes: serviceBundle.totalDurationMinutes
    });
    return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, serviceBundle, nextSlots, {
      requiresCustomerAddress: serviceBundle.requiresCustomerAddress
    });
  }
  if (!hasConfirmedSlot && !wantsAvailabilityLookup && !recentChoicePrompt && !recentRequestedSlot && !currentIntent.requestedDate && !currentIntent.requestedTime) {
    if (isAmbiguousServiceQuery(serviceBundle)) {
      console.log(`\u{1F4C5} [StateFirst] Pergunta amb\xEDgua detectada \u2014 retornando desambigua\xE7\xE3o do cat\xE1logo`);
      return ambiguousServices && ambiguousServices.length > 0 ? buildSchedulingDisambiguationReply(ambiguousServices) : null;
    }
    return buildSchedulingQuoteReply({
      domain: "scheduling",
      selectedServices: serviceBundle.selectedServices,
      totalDurationMinutes: serviceBundle.totalDurationMinutes,
      totalPrice: serviceBundle.totalPrice,
      customerAddress: customerInfo.customerAddress,
      requiresCustomerAddress: serviceBundle.requiresCustomerAddress
    });
  }
  return null;
}
async function generatePlannerDrivenSchedulingReply(userId, clientPhone, messageText, conversationHistory = []) {
  const config = await getSchedulingConfigCached(userId);
  if (!config || !config.is_enabled) {
    return null;
  }
  const pendingApprovalDate = looksLikeAffirmativeReply(messageText) ? findPendingSameDayApprovalDate(userId, clientPhone) : null;
  const activeServices = await listActiveSchedulingServices(userId);
  const currentMessageLooksLikeServiceDescription = isLikelySchedulingServiceDescriptionMessage(
    messageText,
    conversationHistory
  );
  const serviceContextCandidates = buildSchedulingServiceContextCandidates(messageText, conversationHistory);
  const serviceContextText = buildSchedulingServiceContextText(messageText, conversationHistory);
  let rememberedState = getSchedulingConversationState(userId, clientPhone);
  const currentMessageServiceBundle = await resolveSchedulingServiceBundle(userId, messageText, config, {
    activeServices,
    contextCandidates: [messageText]
  });
  const preliminaryServiceBundle = await resolveSchedulingServiceBundle(userId, serviceContextText, config, {
    activeServices,
    contextCandidates: serviceContextCandidates
  });
  const recentCustomerServiceBundle = await resolveRecentCustomerServiceBundle(
    userId,
    conversationHistory,
    config,
    activeServices
  );
  const ambiguousCurrentServices = buildRelevantSchedulingDisambiguationServices(
    messageText,
    activeServices,
    currentMessageServiceBundle.selectedServices.map((service) => service.id).filter(Boolean)
  );
  const earlySchedulingProgress = Boolean(
    rememberedState?.confirmedDate || rememberedState?.confirmedTime || rememberedState?.selectedDate || rememberedState?.selectedTime
  );
  if (isAmbiguousServiceQuery(currentMessageServiceBundle) && !earlySchedulingProgress) {
    console.log(
      `\u{1F4C5} [Planner] AMBIGUOUS SERVICE QUERY \u2014 "${messageText}" matched ${currentMessageServiceBundle.selectedServices.length} services: ${currentMessageServiceBundle.selectedServices.map((s) => s.name).join(", ")}. Returning deterministic disambiguation.`
    );
    return ambiguousCurrentServices.length > 0 ? buildSchedulingDisambiguationReply(ambiguousCurrentServices) : null;
  }
  if (currentMessageLooksLikeServiceDescription && schedulingBundleHasResolvedCatalogServices(currentMessageServiceBundle)) {
    rememberSchedulingConversationState(userId, clientPhone, {
      selectedServices: currentMessageServiceBundle.selectedServices,
      totalDurationMinutes: currentMessageServiceBundle.totalDurationMinutes,
      totalPrice: currentMessageServiceBundle.totalPrice,
      requiresCustomerAddress: currentMessageServiceBundle.requiresCustomerAddress
    });
    rememberedState = getSchedulingConversationState(userId, clientPhone);
  }
  const shouldPreferCurrentMessageBundle = Boolean(
    currentMessageLooksLikeServiceDescription && schedulingBundleHasResolvedCatalogServices(currentMessageServiceBundle)
  );
  const rememberedBundle = buildResolvedBundleFromConversationState(config, rememberedState);
  const shouldFreezeRememberedBundle = Boolean(rememberedBundle) && !shouldPreferCurrentMessageBundle && !schedulingBundleHasResolvedCatalogServices(currentMessageServiceBundle);
  const hasRealSchedulingContext = Boolean(
    rememberedBundle || schedulingBundleHasResolvedCatalogServices(recentCustomerServiceBundle) || currentMessageLooksLikeServiceDescription
  );
  const hasRememberedSchedulingProgress = Boolean(
    rememberedState?.confirmedDate || rememberedState?.confirmedTime || rememberedState?.selectedDate || rememberedState?.selectedTime
  );
  if (!hasRealSchedulingContext && !hasRememberedSchedulingProgress) {
    return null;
  }
  const prePlannerCandidateBundle = shouldPreferCurrentMessageBundle ? currentMessageServiceBundle : recentCustomerServiceBundle || preliminaryServiceBundle;
  const historyBundle = chooseEffectiveSchedulingServiceBundle(
    prePlannerCandidateBundle,
    rememberedBundle,
    { preferCurrentCatalogMatch: shouldPreferCurrentMessageBundle }
  );
  const effectivePrePlannerBundle = shouldFreezeRememberedBundle && rememberedBundle ? rememberedBundle : historyBundle;
  const stateFirstReply = await generateStateFirstSchedulingReply({
    userId,
    clientPhone,
    messageText,
    conversationHistory,
    config,
    serviceBundle: effectivePrePlannerBundle,
    rememberedState,
    pendingApprovalDate,
    shouldPersistCurrentBundle: schedulingBundleHasResolvedCatalogServices(currentMessageServiceBundle),
    ambiguousServices: ambiguousCurrentServices
  });
  if (stateFirstReply) {
    return stateFirstReply;
  }
  const plannerDecision = await callSchedulingPlanner(
    userId,
    clientPhone,
    messageText,
    conversationHistory,
    config,
    preliminaryServiceBundle,
    activeServices
  );
  let resolvedPlannerDecision = plannerDecision;
  const serviceBundle = await resolveSchedulingServiceBundle(userId, serviceContextText, config, {
    activeServices,
    selectedServiceIds: resolvedPlannerDecision?.selectedServiceIds,
    contextCandidates: serviceContextCandidates
  });
  const plannerResolvedBundle = shouldPreferCurrentMessageBundle && !schedulingBundleHasResolvedCatalogServices(serviceBundle) ? currentMessageServiceBundle : serviceBundle;
  const effectiveServiceBundle = shouldFreezeRememberedBundle && rememberedBundle ? rememberedBundle : chooseEffectiveSchedulingServiceBundle(plannerResolvedBundle, rememberedBundle, {
    preferCurrentCatalogMatch: shouldPreferCurrentMessageBundle
  });
  const fallbackPlannerDecision = buildFallbackSchedulingPlannerDecision({
    messageText,
    conversationHistory,
    rememberedState,
    serviceBundle: effectiveServiceBundle
  });
  if (shouldPreferFallbackSchedulingDecision(resolvedPlannerDecision, fallbackPlannerDecision)) {
    resolvedPlannerDecision = fallbackPlannerDecision;
  }
  if (!resolvedPlannerDecision?.shouldHandle || resolvedPlannerDecision.action === "IGNORE") {
    return null;
  }
  const { date: targetDate, time: targetTime } = resolvePlannerSlotSelection(
    resolvedPlannerDecision,
    messageText,
    conversationHistory,
    rememberedState
  );
  const customerInfo = await resolvePlannerCustomerInfo(
    resolvedPlannerDecision,
    messageText,
    effectiveServiceBundle.requiresCustomerAddress,
    conversationHistory,
    rememberedState
  );
  const recentRequestedSlot = findRecentRequestedSchedulingSlot(conversationHistory);
  const hasConfirmedBookingContext = Boolean(findLastAssistantSchedulingConfirmationPrompt(conversationHistory));
  const hasChoicePromptContext = hasRecentAssistantSchedulingChoicePrompt(conversationHistory);
  const hasExplicitRequestedSlot = Boolean(
    hasConfirmedBookingContext || resolvedPlannerDecision.requestedDate && resolvedPlannerDecision.requestedTime || recentRequestedSlot
  );
  const hasSchedulingProgress = hasConfirmedBookingContext || hasChoicePromptContext || hasExplicitRequestedSlot;
  const hasMatchedCatalogServices = effectiveServiceBundle.selectedServices.some((service) => Boolean(service.id));
  const catalogIsConfigured = activeServices.length > 0;
  const quoteContext = {
    domain: "scheduling",
    selectedServices: effectiveServiceBundle.selectedServices,
    totalDurationMinutes: effectiveServiceBundle.totalDurationMinutes,
    totalPrice: effectiveServiceBundle.totalPrice,
    customerAddress: customerInfo.customerAddress,
    requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
  };
  const updatedConversationState = rememberSchedulingConversationState(userId, clientPhone, {
    selectedServices: hasMatchedCatalogServices ? effectiveServiceBundle.selectedServices : rememberedState?.selectedServices,
    totalDurationMinutes: hasMatchedCatalogServices ? effectiveServiceBundle.totalDurationMinutes : rememberedState?.totalDurationMinutes,
    totalPrice: hasMatchedCatalogServices ? effectiveServiceBundle.totalPrice : rememberedState?.totalPrice,
    requiresCustomerAddress: hasMatchedCatalogServices ? effectiveServiceBundle.requiresCustomerAddress : rememberedState?.requiresCustomerAddress,
    customerName: customerInfo.customerName,
    customerAddress: customerInfo.customerAddress,
    selectedDate: targetDate || rememberedState?.selectedDate,
    selectedTime: targetTime || rememberedState?.selectedTime
  });
  rememberedState = updatedConversationState || rememberedState;
  const confirmedDate = rememberedState?.confirmedDate || null;
  const confirmedTime = rememberedState?.confirmedTime || null;
  if (catalogIsConfigured && !hasMatchedCatalogServices && !hasSchedulingProgress && resolvedPlannerDecision.wantsSchedulingNow !== true && resolvedPlannerDecision.action !== "CANCEL_READY" && resolvedPlannerDecision.action !== "CANCEL_NEEDS_TARGET") {
    return null;
  }
  if (resolvedPlannerDecision.wantsSchedulingNow === false && !hasSchedulingProgress && (resolvedPlannerDecision.action === "LOOKUP_NEXT_SLOTS" || resolvedPlannerDecision.action === "LOOKUP_DATE_AVAILABILITY" || resolvedPlannerDecision.action === "CHECK_EXACT_SLOT" || resolvedPlannerDecision.action === "REQUEST_SLOT_SELECTION" || resolvedPlannerDecision.action === "REQUEST_NAME" || resolvedPlannerDecision.action === "REQUEST_ADDRESS" || resolvedPlannerDecision.action === "READY_TO_BOOK")) {
    return null;
  }
  const actionNeedsRealSchedulingExecution = resolvedPlannerDecision.action === "LOOKUP_NEXT_SLOTS" || resolvedPlannerDecision.action === "LOOKUP_DATE_AVAILABILITY" || resolvedPlannerDecision.action === "CHECK_EXACT_SLOT" || resolvedPlannerDecision.action === "REQUEST_SLOT_SELECTION" || resolvedPlannerDecision.action === "REQUEST_NAME" || resolvedPlannerDecision.action === "REQUEST_ADDRESS" || resolvedPlannerDecision.action === "READY_TO_BOOK";
  if (actionNeedsRealSchedulingExecution && !hasSchedulingProgress) {
    const allowSchedulingExecution = await confirmSchedulingExecutionGate(
      userId,
      clientPhone,
      messageText,
      conversationHistory,
      resolvedPlannerDecision,
      serviceBundle,
      activeServices
    );
    if (!allowSchedulingExecution) {
      return null;
    }
  }
  switch (resolvedPlannerDecision.action) {
    case "QUOTE_ONLY":
      return null;
    case "LOOKUP_NEXT_SLOTS": {
      if (confirmedDate && confirmedTime) {
        console.log(`\u{1F4C5} [Planner] GUARD: slot already confirmed (${confirmedDate} ${confirmedTime}) \u2014 overriding LOOKUP_NEXT_SLOTS`);
        if (effectiveServiceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
          return getSchedulingAddressPrompt();
        }
        if (!customerInfo.customerName) {
          return getSchedulingNamePrompt();
        }
        return buildDeterministicSchedulingCreationReply(
          confirmedDate,
          confirmedTime,
          customerInfo.customerName,
          effectiveServiceBundle.combinedServiceName || "Agendamento",
          customerInfo.customerAddress
        );
      }
      const nextSlots = await getNextAvailableSlots(userId, 1, {
        serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
      });
      return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
        requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
      });
    }
    case "LOOKUP_DATE_AVAILABILITY": {
      if (confirmedDate && confirmedTime) {
        console.log(`\u{1F4C5} [Planner] GUARD: slot already confirmed (${confirmedDate} ${confirmedTime}) \u2014 overriding LOOKUP_DATE_AVAILABILITY`);
        if (effectiveServiceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
          return getSchedulingAddressPrompt();
        }
        if (!customerInfo.customerName) {
          return getSchedulingNamePrompt();
        }
        return buildDeterministicSchedulingCreationReply(
          confirmedDate,
          confirmedTime,
          customerInfo.customerName,
          effectiveServiceBundle.combinedServiceName || "Agendamento",
          customerInfo.customerAddress
        );
      }
      if (!targetDate) {
        const nextSlots = await getNextAvailableSlots(userId, 1, {
          serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
        });
        return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
        });
      }
      const slotsForRequestedDate = await getAvailableSlots(userId, targetDate, config, {
        serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
      });
      const availableSlots = slotsForRequestedDate.filter((slot) => slot.available);
      if (availableSlots.length === 0) {
        const nextSlots = await getNextAvailableSlots(userId, 1, {
          serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
        });
        return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress,
          unavailableDate: targetDate
        });
      }
      return buildSchedulingNextSlotsReplyWithMemory(
        userId,
        clientPhone,
        effectiveServiceBundle,
        [{ date: targetDate, slots: availableSlots.slice(0, 8) }],
        {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
        }
      );
    }
    case "CHECK_EXACT_SLOT": {
      if (!targetDate || !targetTime) {
        const nextSlots = await getNextAvailableSlots(userId, 1, {
          serviceDurationMinutes: serviceBundle.totalDurationMinutes
        });
        return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, serviceBundle, nextSlots, {
          requiresCustomerAddress: serviceBundle.requiresCustomerAddress
        });
      }
      const slotsForRequestedDate = await getAvailableSlots(userId, targetDate, config, {
        serviceDurationMinutes: serviceBundle.totalDurationMinutes
      });
      const availableSlots = slotsForRequestedDate.filter((slot) => slot.available);
      const matchedSlot = findExactAvailableSlot(availableSlots, targetTime) || findClosestAvailableSlot(availableSlots, targetTime);
      if (matchedSlot) {
        const nextState = rememberSchedulingConversationState(userId, clientPhone, {
          confirmedDate: targetDate,
          confirmedTime: matchedSlot.start,
          selectedDate: targetDate,
          selectedTime: matchedSlot.start
        });
        rememberedState = nextState || rememberedState;
        if (resolvedPlannerDecision.wantsBookingDetails) {
          const dateLabel = formatSchedulingDayLabel(targetDate);
          const normalizedExactTime = normalizeSchedulingTimeValue(matchedSlot.start);
          if (effectiveServiceBundle.requiresCustomerAddress) {
            return `${dateLabel} \xE0s ${normalizedExactTime} est\xE1 dispon\xEDvel! Pra finalizar, preciso do endere\xE7o do local.`;
          }
          return `${dateLabel} \xE0s ${normalizedExactTime} est\xE1 dispon\xEDvel! Pra finalizar, preciso do seu nome completo.`;
        }
        return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, [], {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress,
          confirmedDate: targetDate,
          confirmedTime: matchedSlot.start,
          requestConfirmationDetails: false
        });
      }
      const alternativeSlots = availableSlots.length > 0 ? [{ date: targetDate, slots: availableSlots.slice(0, 6) }] : await getNextAvailableSlots(userId, 1, {
        serviceDurationMinutes: serviceBundle.totalDurationMinutes
      });
      return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, alternativeSlots, {
        requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress,
        unavailableDate: targetDate
      });
    }
    case "REQUEST_SLOT_SELECTION": {
      if (confirmedDate && confirmedTime) {
        console.log(`\u{1F4C5} [Planner] GUARD: slot already confirmed (${confirmedDate} ${confirmedTime}) \u2014 overriding REQUEST_SLOT_SELECTION`);
        if (effectiveServiceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
          return getSchedulingAddressPrompt();
        }
        if (!customerInfo.customerName) {
          return getSchedulingNamePrompt();
        }
        return buildDeterministicSchedulingCreationReply(
          confirmedDate,
          confirmedTime,
          customerInfo.customerName,
          effectiveServiceBundle.combinedServiceName || "Agendamento",
          customerInfo.customerAddress
        );
      }
      const nextSlots = await getNextAvailableSlots(userId, 1, {
        serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
      });
      const nextSlotsReply = buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
        requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
      });
      if (!nextSlotsReply) {
        return "Antes de eu finalizar, preciso que voc\xEA escolha um hor\xE1rio dispon\xEDvel primeiro.";
      }
      return `Antes de eu finalizar, preciso que voc\xEA escolha um dos hor\xE1rios dispon\xEDveis primeiro.
${nextSlotsReply}`;
    }
    case "REQUEST_NAME": {
      if (!hasExplicitRequestedSlot) {
        const nextSlots = await getNextAvailableSlots(userId, 1, {
          serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
        });
        const nextSlotsReply = buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
        });
        return nextSlotsReply ? `Antes de eu pedir seus dados, preciso validar um hor\xE1rio real para voc\xEA.
${nextSlotsReply}` : "Antes de eu pedir seus dados, preciso validar um hor\xE1rio dispon\xEDvel primeiro.";
      }
      const lockedSlot = await ensureConfirmedSchedulingSlot(
        userId,
        clientPhone,
        config,
        effectiveServiceBundle,
        rememberedState,
        targetDate,
        targetTime
      );
      if (!lockedSlot.ok) {
        return lockedSlot.reply;
      }
      rememberedState = lockedSlot.rememberedState;
      if (effectiveServiceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
        return getSchedulingAddressPrompt();
      }
      return getSchedulingNamePrompt();
    }
    case "REQUEST_ADDRESS": {
      if (!hasExplicitRequestedSlot) {
        const nextSlots = await getNextAvailableSlots(userId, 1, {
          serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
        });
        const nextSlotsReply = buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
        });
        return nextSlotsReply ? `Antes de eu pedir o endere\xE7o, preciso validar um hor\xE1rio real para voc\xEA.
${nextSlotsReply}` : "Antes de eu pedir o endere\xE7o, preciso validar um hor\xE1rio dispon\xEDvel primeiro.";
      }
      const lockedSlot = await ensureConfirmedSchedulingSlot(
        userId,
        clientPhone,
        config,
        effectiveServiceBundle,
        rememberedState,
        targetDate,
        targetTime
      );
      if (!lockedSlot.ok) {
        return lockedSlot.reply;
      }
      rememberedState = lockedSlot.rememberedState;
      return getSchedulingAddressPrompt();
    }
    case "READY_TO_BOOK": {
      const lockedSlot = await ensureConfirmedSchedulingSlot(
        userId,
        clientPhone,
        config,
        effectiveServiceBundle,
        rememberedState,
        targetDate,
        targetTime
      );
      if (!lockedSlot.ok) {
        return lockedSlot.reply;
      }
      rememberedState = lockedSlot.rememberedState;
      const finalDate = lockedSlot.confirmedDate || targetDate;
      const finalTime = lockedSlot.confirmedTime || targetTime;
      if (!hasExplicitRequestedSlot && !(finalDate && finalTime)) {
        const nextSlots = await getNextAvailableSlots(userId, 1, {
          serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
        });
        return buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
        });
      }
      if (!finalDate || !finalTime) {
        const nextSlots = await getNextAvailableSlots(userId, 1, {
          serviceDurationMinutes: effectiveServiceBundle.totalDurationMinutes
        });
        const nextSlotsReply = buildSchedulingNextSlotsReplyWithMemory(userId, clientPhone, effectiveServiceBundle, nextSlots, {
          requiresCustomerAddress: effectiveServiceBundle.requiresCustomerAddress
        });
        return nextSlotsReply ? `Antes de eu finalizar, preciso que voc\xEA escolha um dos hor\xE1rios dispon\xEDveis primeiro.
${nextSlotsReply}` : "Antes de eu finalizar, preciso que voc\xEA escolha um hor\xE1rio dispon\xEDvel primeiro.";
      }
      const lockedDate = rememberedState?.confirmedDate || finalDate;
      const lockedTime = rememberedState?.confirmedTime || finalTime;
      if (!customerInfo.customerName) {
        if (effectiveServiceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
          return getSchedulingAddressPrompt();
        }
        return getSchedulingNamePrompt();
      }
      if (effectiveServiceBundle.requiresCustomerAddress && !customerInfo.customerAddress) {
        return getSchedulingAddressPrompt();
      }
      const existingSameDayAppointments = await getClientAppointmentsForDate(userId, clientPhone, lockedDate);
      const approvalToken = pendingApprovalDate && pendingApprovalDate === lockedDate ? "SIM" : void 0;
      if (existingSameDayAppointments.length > 0 && approvalToken !== "SIM") {
        rememberSameDayRebookingApproval(userId, clientPhone, lockedDate);
        const appointmentSummary = existingSameDayAppointments.map((appointment) => `${normalizeSchedulingTimeValue(appointment.start_time)} (${appointment.service_name || "agendamento"})`).join(", ");
        return `Voc\xEA j\xE1 possui agendamento no dia ${formatSchedulingDayLabel(lockedDate)}: ${appointmentSummary}. Quer mesmo criar mais um hor\xE1rio nesse mesmo dia?`;
      }
      return buildDeterministicSchedulingCreationReply(
        lockedDate,
        lockedTime,
        customerInfo.customerName,
        effectiveServiceBundle.combinedServiceName || "Agendamento",
        customerInfo.customerAddress,
        {
          approvalToken
        }
      );
    }
    case "CANCEL_NEEDS_TARGET":
      return "Para cancelar certinho, me confirme a data e o hor\xE1rio do agendamento que voc\xEA quer cancelar.";
    case "CANCEL_READY": {
      let effectiveCancelDate = targetDate;
      let effectiveCancelTime = targetTime;
      if (!effectiveCancelDate) {
        const recentBookingConf = [...conversationHistory].reverse().find(
          (m) => m.fromMe && /agendad[oa]|confirmad[oa]|marcad[oa]/i.test(String(m.text || ""))
        );
        if (recentBookingConf) {
          const dateMatch = String(recentBookingConf.text).match(/(\d{2})\/(\d{2})/);
          const timeMatch = String(recentBookingConf.text).match(/(\d{2})[h:](\d{2})/);
          if (dateMatch) {
            const now = /* @__PURE__ */ new Date();
            effectiveCancelDate = `${now.getFullYear()}-${dateMatch[2]}-${dateMatch[1]}`;
          }
          if (timeMatch) {
            effectiveCancelTime = `${timeMatch[1]}:${timeMatch[2]}`;
          }
        }
      }
      if (!effectiveCancelDate) {
        const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        const { data: futureAppointments } = await supabase.from("appointments").select("*").eq("user_id", userId).eq("client_phone", clientPhone).gte("appointment_date", today).in("status", ["pending", "confirmed"]).order("appointment_date", { ascending: true }).order("start_time", { ascending: true }).limit(1);
        if (futureAppointments && futureAppointments.length > 0) {
          const apt = futureAppointments[0];
          const clientName2 = apt.client_name || customerInfo.customerName || "Cliente";
          return `[CANCELAR: DATA=${apt.appointment_date}, HORA=${normalizeSchedulingTimeValue(apt.start_time)}, NOME="${clientName2}"]
Entendido. Vou cancelar o agendamento para voc\xEA.`;
        }
        return "Para cancelar certinho, me confirme a data e o hor\xE1rio do agendamento que voc\xEA quer cancelar.";
      }
      const appointmentsForDate = await getClientAppointmentsForDate(userId, clientPhone, effectiveCancelDate);
      let appointmentToCancel;
      if (effectiveCancelTime) {
        appointmentToCancel = appointmentsForDate.find(
          (appointment) => normalizeSchedulingTimeValue(appointment.start_time) === normalizeSchedulingTimeValue(effectiveCancelTime)
        );
      } else if (appointmentsForDate.length === 1) {
        appointmentToCancel = appointmentsForDate[0];
      }
      if (!appointmentToCancel) {
        if (appointmentsForDate.length > 0) {
          appointmentToCancel = appointmentsForDate[0];
        }
      }
      if (!appointmentToCancel) {
        const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        const { data: anyAppointments } = await supabase.from("appointments").select("*").eq("user_id", userId).eq("client_phone", clientPhone).gte("appointment_date", today).in("status", ["pending", "confirmed"]).order("appointment_date", { ascending: true }).order("start_time", { ascending: true }).limit(1);
        if (anyAppointments && anyAppointments.length > 0) {
          appointmentToCancel = anyAppointments[0];
        }
      }
      if (!appointmentToCancel) {
        if (effectiveCancelTime) {
          return `N\xE3o encontrei um agendamento ativo em ${formatSchedulingDayLabel(effectiveCancelDate)} \xE0s ${normalizeSchedulingTimeValue(effectiveCancelTime)} para este n\xFAmero.`;
        }
        return "N\xE3o encontrei nenhum agendamento ativo para cancelar neste n\xFAmero.";
      }
      const clientName = appointmentToCancel.client_name || customerInfo.customerName || "Cliente";
      return `[CANCELAR: DATA=${appointmentToCancel.appointment_date}, HORA=${normalizeSchedulingTimeValue(appointmentToCancel.start_time)}, NOME="${clientName}"]
Entendido. Vou cancelar o agendamento para voc\xEA.`;
    }
    default:
      return null;
  }
}
async function generateSchedulingTurnPrompt(userId, clientPhone, messageText, conversationHistory = []) {
  const isAffirmativeReply = looksLikeAffirmativeReply(messageText);
  const intent = detectSchedulingIntent(messageText);
  const rememberedStateBeforeValidatedOffer = getSchedulingConversationState(userId, clientPhone);
  if (intent.requestedDate || intent.requestedTime || intent.type === "reschedule") {
    clearValidatedSlotOffer(userId, clientPhone);
  }
  const activeValidatedOffer = getValidatedSlotOffer(userId, clientPhone);
  let acceptedValidatedOffer = null;
  let validatedOfferOperationalPayload = false;
  if (activeValidatedOffer) {
    const operationalPayloadInfo = await resolvePlannerCustomerInfo(
      {
        shouldHandle: false,
        action: "IGNORE",
        selectedServiceIds: activeValidatedOffer.serviceBundle.selectedServices.map((service) => service.id).filter(Boolean),
        requestedDate: null,
        requestedTime: null,
        selectedDate: null,
        selectedTime: null,
        customerName: null,
        customerAddress: null,
        wantsSchedulingNow: true,
        wantsBookingDetails: true,
        confidence: 0,
        reasoning: "turn prompt: payload after validated slot offer"
      },
      messageText,
      activeValidatedOffer.serviceBundle.requiresCustomerAddress,
      conversationHistory,
      rememberedStateBeforeValidatedOffer
    );
    validatedOfferOperationalPayload = Boolean(
      operationalPayloadInfo.customerAddress || operationalPayloadInfo.customerName
    );
    if (isAffirmativeReply || validatedOfferOperationalPayload) {
      acceptedValidatedOffer = markValidatedSlotOfferAccepted(userId, clientPhone) || activeValidatedOffer;
      rememberAcceptedValidatedSlotOffer(userId, clientPhone, acceptedValidatedOffer, {
        customerName: operationalPayloadInfo.customerName || rememberedStateBeforeValidatedOffer?.customerName,
        customerAddress: operationalPayloadInfo.customerAddress || rememberedStateBeforeValidatedOffer?.customerAddress
      });
    }
  }
  if (acceptedValidatedOffer && isAffirmativeReply && !validatedOfferOperationalPayload) {
    const acceptedOffer = acceptedValidatedOffer;
    const slotLabel = formatValidatedSlotHeading(acceptedOffer.date, acceptedOffer.time);
    const serviceLines = formatServiceBreakdownLines(
      buildSchedulingContextFromBundle(acceptedOffer.serviceBundle)
    ).map((line) => `- ${line}`).join("\n");
    return `
REGRA EXTRA DESTE TURNO:
- O cliente acabou de ACEITAR o horario validado em tempo real: ${slotLabel}.
- Mantenha exatamente esta mesma data e hora; nao troque para outro horario.
- Antes de usar [AGENDAR:], finalize apenas o que faltar: nome do cliente, forma de pagamento e endereco se o servico exigir.
- Se esses dados ja estiverem fechados, use [AGENDAR:] agora com DATA=${acceptedOffer.date}, HORA=${acceptedOffer.time} e SERVICO="${acceptedOffer.serviceBundle.combinedServiceName}".
- Nao consulte nem ofereca outro horario neste turno.
${serviceLines ? `${serviceLines}
` : ""}`;
  }
  const pendingApprovalDate = isAffirmativeReply ? findPendingSameDayApprovalDate(userId, clientPhone) : null;
  if (pendingApprovalDate) {
    return `
REGRA EXTRA DESTE TURNO:
- O cliente acabou de autorizar um novo agendamento no mesmo dia (${pendingApprovalDate}).
- Se voc\xEA for realmente criar esse novo agendamento, inclua CONFIRMACAO_DIA=SIM na tag [AGENDAR:].
- N\xE3o use essa confirma\xE7\xE3o para outro dia.
`;
  }
  const validatedReply = await generatePlannerDrivenSchedulingReply(
    userId,
    clientPhone,
    messageText,
    conversationHistory
  );
  if (validatedReply) {
    if (isSchedulingDisambiguationReply(validatedReply)) {
      return buildSchedulingDisambiguationTurnRuleFromReply(validatedReply);
    }
    if (isSchedulingQuoteStructuredReply(validatedReply)) {
      return buildSchedulingQuoteTurnRule(validatedReply);
    }
    return buildSchedulingValidatedTurnRule(validatedReply);
  }
  const normalizedForGreeting = normalizeSchedulingMessage(messageText);
  if (normalizedForGreeting && isGreetingOnlySchedulingMessage(normalizedForGreeting)) {
    const greetingState = getSchedulingConversationState(userId, clientPhone);
    const hasProgressOnGreeting = Boolean(
      greetingState?.confirmedDate || greetingState?.confirmedTime || greetingState?.selectedDate || greetingState?.selectedTime
    );
    if (!hasProgressOnGreeting) {
      return "";
    }
  }
  const config = await getSchedulingConfigCached(userId);
  if (!config || !config.is_enabled) {
    return "";
  }
  const activeServices = await listActiveSchedulingServices(userId);
  if (activeServices.length === 0) {
    return "";
  }
  const rememberedState = getSchedulingConversationState(userId, clientPhone);
  const serviceContextCandidates = buildSchedulingServiceContextCandidates(messageText, conversationHistory);
  const serviceContextText = buildSchedulingServiceContextText(messageText, conversationHistory);
  const currentIntent = inferSchedulingIntentFromConversation(messageText, conversationHistory);
  const requestedBundle = await resolveSchedulingServiceBundle(userId, serviceContextText, config, {
    activeServices,
    contextCandidates: serviceContextCandidates
  });
  const rememberedBundle = buildResolvedBundleFromConversationState(config, rememberedState);
  const shouldPreferCurrentMessageBundle = Boolean(
    isLikelySchedulingServiceDescriptionMessage(messageText, conversationHistory) && schedulingBundleHasResolvedCatalogServices(requestedBundle)
  );
  const effectiveBundle = chooseEffectiveSchedulingServiceBundle(requestedBundle, rememberedBundle, {
    preferCurrentCatalogMatch: shouldPreferCurrentMessageBundle
  });
  const hasMatchedCatalogServices = schedulingBundleHasResolvedCatalogServices(effectiveBundle);
  if (!hasMatchedCatalogServices) {
    return "";
  }
  const hasSchedulingProgress = Boolean(
    rememberedState?.confirmedDate || rememberedState?.confirmedTime || rememberedState?.selectedDate || rememberedState?.selectedTime || hasRecentAssistantSchedulingChoicePrompt(conversationHistory)
  );
  const wantsSchedulingNow = Boolean(
    isAvailabilityLookupFollowUp(messageText, conversationHistory) || isGenericAvailabilityLookup(messageText) || currentIntent.type === "book_appointment" || currentIntent.type === "check_availability" || currentIntent.type === "reschedule" || currentIntent.type === "cancel_appointment"
  );
  if (hasSchedulingProgress || wantsSchedulingNow) {
    return "";
  }
  if (isAmbiguousServiceQuery(effectiveBundle)) {
    const relevantServices = buildRelevantSchedulingDisambiguationServices(
      messageText,
      activeServices,
      effectiveBundle.selectedServices.map((service) => service.id).filter(Boolean)
    );
    console.log(
      `\u{1F4C5} [TurnPrompt] AMBIGUOUS \u2014 LLM flagged query as ambiguous. Showing ${relevantServices.length} services for disambiguation.`
    );
    return relevantServices.length > 0 ? buildSchedulingDisambiguationTurnRule(relevantServices) : "";
  }
  rememberSchedulingConversationState(userId, clientPhone, {
    selectedServices: effectiveBundle.selectedServices,
    totalDurationMinutes: effectiveBundle.totalDurationMinutes,
    totalPrice: effectiveBundle.totalPrice,
    requiresCustomerAddress: effectiveBundle.requiresCustomerAddress,
    customerAddress: rememberedState?.customerAddress,
    customerName: rememberedState?.customerName
  });
  const quoteContext = {
    domain: "scheduling",
    selectedServices: effectiveBundle.selectedServices,
    totalDurationMinutes: effectiveBundle.totalDurationMinutes,
    totalPrice: effectiveBundle.totalPrice,
    customerAddress: rememberedState?.customerAddress,
    requiresCustomerAddress: effectiveBundle.requiresCustomerAddress
  };
  return buildSchedulingQuoteTurnRule(buildSchedulingQuoteReply(quoteContext));
}
async function generateDeterministicSchedulingReply(userId, clientPhone, messageText, conversationHistory = []) {
  return generatePlannerDrivenSchedulingReply(
    userId,
    clientPhone,
    messageText,
    conversationHistory
  );
}
async function generateSchedulingPromptBlock(userId) {
  const config = await getSchedulingConfigCached(userId);
  if (!config || !config.is_enabled) {
    return "";
  }
  const daysMap = {
    0: "Domingo",
    1: "Segunda",
    2: "Ter\xE7a",
    3: "Quarta",
    4: "Quinta",
    5: "Sexta",
    6: "S\xE1bado"
  };
  const availableDaysText = config.available_days.map((d) => daysMap[d]).join(", ");
  let breakText = "";
  if (config.has_break) {
    breakText = ` (pausa ${config.break_start_time}-${config.break_end_time})`;
  }
  {
    const brazilNow = getBrazilDateTime();
    const promptTodayStr = brazilNow.dateStr;
    const promptCurrentTime = brazilNow.timeStr;
    const promptTomorrow = new Date(brazilNow.date);
    promptTomorrow.setDate(promptTomorrow.getDate() + 1);
    const promptTomorrowStr = `${promptTomorrow.getFullYear()}-${(promptTomorrow.getMonth() + 1).toString().padStart(2, "0")}-${promptTomorrow.getDate().toString().padStart(2, "0")}`;
    const cancellationInfo = config.allow_cancellation ? "O cliente pode cancelar seu agendamento a qualquer momento." : "O cliente NAO pode cancelar pelo chat. Para cancelamentos, deve entrar em contato por outro meio.";
    let servicesGuardrailText = "";
    try {
      const { data: services } = await supabase.from("scheduling_services").select("name, description, duration_minutes, price, is_active, requires_customer_address").eq("user_id", userId).eq("is_active", true).order("display_order", { ascending: true });
      if (services && services.length > 0) {
        servicesGuardrailText = `

SERVICOS DISPONIVEIS:
${services.map((service) => {
          let line = `- ${service.name}`;
          if (service.duration_minutes) line += ` (${service.duration_minutes} min)`;
          if (service.price) line += ` - R$ ${Number(service.price).toFixed(2).replace(".", ",")}`;
          if (service.description) line += ` - ${service.description}`;
          if (service.requires_customer_address) line += ` - exige endereco do cliente`;
          return line;
        }).join("\n")}
Confirme sempre qual servico o cliente quer. Se houver mais de um servico, some tempos e valores no mesmo agendamento.`;
      }
    } catch (error) {
    }
    const currentMinutes = brazilNow.date.getHours() * 60 + brazilNow.date.getMinutes();
    const minBookingMinutes = currentMinutes + config.min_booking_notice_hours * 60;
    const minBookingTime = minutesToTime(minBookingMinutes > 24 * 60 ? 24 * 60 : minBookingMinutes);
    const noticeText = config.min_booking_notice_hours > 0 ? `
ANTECEDENCIA MINIMA: ${config.min_booking_notice_hours}h (para hoje, apenas horarios a partir de ${minBookingTime})` : "";
    return `
---
RECURSO DE AGENDAMENTO ATIVO
Agora: ${promptTodayStr} ${promptCurrentTime} | Atendimento: ${availableDaysText}, ${config.work_start_time}-${config.work_end_time}${breakText}${noticeText}
${servicesGuardrailText}

REGRAS DE ORQUESTRACAO OPENCLAW:
- Voce nunca pode inventar horario, data ou disponibilidade.
- Voce nunca pode responder com horario exato usando memoria, chute, exemplo ou regra estatica.
- Horario exato so pode ser citado quando vier validado na REGRA EXTRA DESTE TURNO.
- Se a REGRA EXTRA DESTE TURNO nao trouxer horario validado, nao informe horario exato.
- Antes de qualquer horario exato, consulte a agenda real com Google/Maton.
- Pense em agenda e agendamento como ferramentas do orquestrador: converse normalmente e so use a ferramenta quando a intencao do cliente realmente pedir isso.
- Se a REGRA EXTRA DESTE TURNO trouxer uma lista de horarios reais e o cliente escolher um deles depois, continue a conversa com base nessa memoria validada e nao volte a pesquisar o mesmo horario por habito.
- Se a lista validada trouxer horarios reais de um unico dia e o cliente responder so com a hora (ex: "9h45" ou "pode ser 9h45"), isso ja conta como escolha do slot oferecido.
- So volte a consultar a agenda se o cliente mudar dia/horario ou se o sistema informar conflito ao registrar o agendamento.
- Antes de pedir endereco, forma de pagamento ou outros dados finais, primeiro feche o horario validado.
- So depois de o cliente aceitar o horario validado e permitido pedir endereco, pagamento, nome final e usar [AGENDAR:].
- Se o servico exigir atendimento no endereco do cliente, colete o endereco apenas depois de o horario estar aceito e antes da tag.
- Se o cliente pedir "primeiro horario", "proximo horario" ou "qualquer horario", consulte a agenda real e responda somente com slot realmente livre.
- Se nao houver horario validado no turno, pergunte o dia ou periodo preferido. Nao improvise agenda.

POLITICA DE CANCELAMENTO:
${cancellationInfo}

REGRA CRITICA DE AGENDAMENTO:
PARA CADA CLIENTE diferente que quiser agendar, voce DEVE usar a tag [AGENDAR:].
A tag e o que realmente cria o agendamento no sistema.
Sem a tag = sem agendamento = cliente nao vai receber confirmacao/lembrete.

COMO USAR:
[AGENDAR: DATA=YYYY-MM-DD, HORA=HH:MM, NOME=Nome do Cliente, SERVICO=Nome do Servico]
- Se houver atendimento no local do cliente, inclua ENDERECO="Rua, numero, bairro".
- Se houver mais de um servico, coloque todos em SERVICO separados por " + ".
- Se o cliente autorizou outro agendamento no mesmo dia, inclua CONFIRMACAO_DIA=SIM.

Exemplos:
- Hoje: DATA=${promptTodayStr}
- Amanha: DATA=${promptTomorrowStr}

FLUXO DE AGENDAMENTO:
1. Cliente pergunta agenda ou pede horario -> consulte e valide primeiro.
2. So depois de validar -> ofereca o horario validado e pergunte se quer fechar esse horario.
3. So depois da aceitacao do horario -> colete nome final, pagamento e endereco se necessario.
4. Tem horario aceito + dados finais -> USE A TAG.
Ex.: [AGENDAR: DATA=${promptTomorrowStr}, HORA=10:15, NOME=Joao, SERVICO=Consulta]
Ex. com endereco: [AGENDAR: DATA=${promptTomorrowStr}, HORA=14:00, NOME=Maria, SERVICO=Instalacao, ENDERECO="Rua Exemplo, 123"]
Ex. com dois servicos: [AGENDAR: DATA=${promptTomorrowStr}, HORA=10:15, NOME=Joao, SERVICO=Corte + Escova]

REGRA CRITICA DE CANCELAMENTO:
Quando o cliente pedir para CANCELAR um agendamento, voce DEVE usar a tag [CANCELAR:].
Sem a tag = o agendamento nao sera realmente cancelado no sistema.

COMO USAR:
[CANCELAR: DATA=YYYY-MM-DD, HORA=HH:MM, NOME=Nome do Cliente]

FLUXO DE CANCELAMENTO:
1. Cliente pede para cancelar -> confirme os dados do agendamento.
2. Apos confirmacao -> USE A TAG. Ex: [CANCELAR: DATA=${promptTomorrowStr}, HORA=10:15, NOME=Joao]
3. Apos a tag, ofereca remarcar somente depois de consultar a agenda real.
---
`;
  }
}
async function processSchedulingTags(responseText, userId, clientPhone, conversationId) {
  let modifiedText = responseText;
  let appointmentCreated;
  const schedulingTags = extractSchedulingTags(responseText);
  let schedulingConfig = null;
  try {
    schedulingConfig = await getSchedulingConfigCached(userId);
  } catch (e) {
    console.error("\u{1F4C5} [Scheduling] Error fetching config:", e);
  }
  for (const tag of schedulingTags) {
    const { raw: fullMatch, date, time, clientName, serviceName, customerAddress, approvalToken } = tag;
    const result = await createPendingAppointment(
      userId,
      clientName.trim(),
      clientPhone,
      date,
      time,
      void 0,
      schedulingConfig,
      serviceName?.trim(),
      conversationId,
      customerAddress?.trim(),
      approvalToken?.trim()
    );
    if (result.success && result.appointment) {
      console.log(`\u2705 [Scheduling] Appointment created: ${result.appointment.id}`);
      appointmentCreated = result.appointment;
      modifiedText = modifiedText.replace(fullMatch, "");
      const trimmed = stripSchedulingTagArtifacts(modifiedText).trim();
      if (!trimmed.endsWith("\u2705") && !trimmed.endsWith("\u{1F4C5}") && !trimmed.endsWith("\u{1F44D}") && !trimmed.endsWith("\u{1F60A}")) {
        modifiedText = trimmed + " \u2705";
      }
    } else {
      console.log(`\u274C [Scheduling] Failed to create appointment: ${result.error}`);
      modifiedText = modifiedText.replace(fullMatch, "");
      const trimmedMsg = stripSchedulingTagArtifacts(modifiedText).trim();
      const confirmacaoPatterns = [
        /reservei\s+seu\s+hor[aá]rio/i,
        /agendei\s+(para|seu)/i,
        /hor[aá]rio\s+(confirmado|reservado|agendado)/i,
        /agendamento\s+(realizado|confirmado|feito)/i,
        /ficou\s+(agendado|marcado|reservado)/i,
        /confirmei\s+seu\s+hor[aá]rio/i,
        /vou\s+reservar\s+seu\s+hor[aá]rio/i,
        /reservando\s+seu\s+hor[aá]rio/i,
        /seu\s+hor[aá]rio\s+(está|foi)\s+(reservado|marcado|agendado)/i
      ];
      const mensagemParecioConfirmacao = confirmacaoPatterns.some((p) => p.test(trimmedMsg)) || responseLooksLikeSuccessfulScheduling(trimmedMsg);
      let errorMessage;
      if (result.error === "Hor\xE1rio n\xE3o dispon\xEDvel") {
        errorMessage = `Opa! Infelizmente esse hor\xE1rio (${time} de ${date}) n\xE3o est\xE1 dispon\xEDvel para agendamento. \u{1F615} Pode me informar outro hor\xE1rio ou data de prefer\xEAncia? Vou verificar a disponibilidade! \u{1F60A}`;
      } else if (result.error === "CLIENT_ALREADY_HAS_APPOINTMENT_SAME_DAY") {
        errorMessage = `Vi que voc\xEA j\xE1 tem um agendamento nesse mesmo dia. Se quiser marcar outro hor\xE1rio no mesmo dia, me confirme isso antes que eu verifico e registro certinho.`;
      } else if (result.error === "MISSING_CUSTOMER_ADDRESS") {
        errorMessage = `Para esse servi\xE7o eu preciso primeiro do endere\xE7o completo onde o atendimento ser\xE1 feito. Me manda rua, n\xFAmero e bairro que eu continuo o agendamento.`;
      } else if (result.error === "Sistema de agendamento desativado") {
        errorMessage = `O sistema de agendamento est\xE1 desativado no momento. Por favor, entre em contato diretamente para marcar seu hor\xE1rio! \u{1F60A}`;
      } else {
        errorMessage = `Puxa, tive um problema t\xE9cnico ao registrar o hor\xE1rio ${time} de ${date}. \u{1F605} Por favor, confirme a data e hor\xE1rio novamente para eu tentar salvar!`;
      }
      if (trimmedMsg === "" || mensagemParecioConfirmacao) {
        modifiedText = errorMessage;
        console.log(`\u{1F4C5} [Scheduling] \u26A0\uFE0F Mensagem de confirma\xE7\xE3o falsa detectada e substitu\xEDda por erro`);
      } else {
        modifiedText = trimmedMsg + `

\u26A0\uFE0F ${errorMessage}`;
      }
    }
  }
  return { text: stripSchedulingTagArtifacts(modifiedText).trim(), appointmentCreated };
}
async function processSchedulingCancelTags(responseText, userId, clientPhone) {
  const cancelTagRegex = /\[CANCELAR:\s*DATA=(\d{4}-\d{2}-\d{2}),\s*HORA=(\d{2}:\d{2}),\s*NOME=([^\]]+)\]/gi;
  let match = cancelTagRegex.exec(responseText);
  let modifiedText = responseText;
  let appointmentCancelled = false;
  while (match) {
    const [fullMatch, date, time, clientName] = match;
    console.log(`\u{1F4C5} [Scheduling] Detected cancellation tag: ${fullMatch}`);
    try {
      const { data: appointments, error } = await supabase.from("appointments").select("*").eq("user_id", userId).eq("appointment_date", date).eq("start_time", `${time}:00`).in("status", ["pending", "confirmed"]).limit(5);
      if (error) {
        console.error(`\u274C [Scheduling] Error finding appointment to cancel:`, error);
        modifiedText = modifiedText.replace(fullMatch, "");
        match = cancelTagRegex.exec(responseText);
        continue;
      }
      let appointmentToCancel = appointments?.find(
        (a) => a.client_name?.toLowerCase().trim() === clientName.trim().toLowerCase() || a.client_phone === clientPhone
      );
      if (!appointmentToCancel && appointments && appointments.length > 0) {
        appointmentToCancel = appointments[0];
      }
      if (appointmentToCancel) {
        const { error: updateError } = await supabase.from("appointments").update({
          status: "cancelled",
          cancelled_at: (/* @__PURE__ */ new Date()).toISOString(),
          cancelled_by: "client",
          cancellation_reason: "Cancelado pelo cliente via IA",
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("id", appointmentToCancel.id);
        if (!updateError) {
          console.log(`\u2705 [Scheduling] Appointment cancelled: ${appointmentToCancel.id}`);
          appointmentCancelled = true;
          modifiedText = modifiedText.replace(fullMatch, "");
          const googleEventId = appointmentToCancel.google_event_id || appointmentToCancel.google_calendar_event_id;
          if (googleEventId) {
            const removalResult = await removeAppointmentFromCalendar(userId, googleEventId);
            if (removalResult.success) {
              await supabase.from("appointments").update({
                google_event_id: null,
                google_calendar_synced: false,
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              }).eq("id", appointmentToCancel.id);
            } else {
              console.error(`\u274C [Scheduling] Error removing Google Calendar event ${googleEventId}:`, removalResult.error);
            }
          }
        } else {
          console.error(`\u274C [Scheduling] Error cancelling appointment:`, updateError);
          modifiedText = modifiedText.replace(fullMatch, "");
        }
      } else {
        console.log(`\u26A0\uFE0F [Scheduling] No matching appointment found to cancel for ${date} ${time} ${clientName}`);
        modifiedText = modifiedText.replace(fullMatch, "");
      }
    } catch (err) {
      console.error(`\u274C [Scheduling] Exception cancelling appointment:`, err);
      modifiedText = modifiedText.replace(fullMatch, "");
    }
    match = cancelTagRegex.exec(responseText);
  }
  return { text: modifiedText.trim(), appointmentCancelled };
}
async function getNextAvailableSlots(userId, maxSlots = 1, options) {
  const result = [];
  const brazilNow = getBrazilDateTime();
  const todayStr = brazilNow.dateStr;
  const todayDate = /* @__PURE__ */ new Date(`${todayStr}T12:00:00`);
  for (let i = 0; i < 14 && result.length < maxSlots; i++) {
    const date = new Date(todayDate);
    date.setDate(date.getDate() + i);
    const dateStr = formatDate(date);
    const slots = await getAvailableSlots(userId, dateStr, void 0, {
      serviceDurationMinutes: options?.serviceDurationMinutes
    });
    const availableSlots = slots.filter((s) => s.available);
    if (availableSlots.length > 0) {
      result.push({
        date: dateStr,
        slots: availableSlots.slice(0, 3)
        // Max 3 slots por dia
      });
    }
  }
  if (result.length === 0) {
    console.log(`\u{1F4C5} [getNextAvailableSlots] NENHUM hor\xE1rio encontrado em 14 dias (userId=${userId}, serviceDuration=${options?.serviceDurationMinutes})`);
  }
  return result;
}
function formatAvailableSlotsForAI(slotsData) {
  if (slotsData.length === 0) {
    return "No momento, n\xE3o encontrei hor\xE1rios dispon\xEDveis nos pr\xF3ximos dias pelo sistema online. Mas pode ser que tenhamos alguma disponibilidade \u2014 entre em contato diretamente para verificar!";
  }
  const lines = ["\u{1F4C5} *Hor\xE1rios dispon\xEDveis:*"];
  for (const dayData of slotsData) {
    const dateObj = /* @__PURE__ */ new Date(dayData.date + "T12:00:00");
    const dayNames = ["Domingo", "Segunda", "Ter\xE7a", "Quarta", "Quinta", "Sexta", "S\xE1bado"];
    const dayName = dayNames[dateObj.getDay()];
    const formattedDate = `${dateObj.getDate().toString().padStart(2, "0")}/${(dateObj.getMonth() + 1).toString().padStart(2, "0")}`;
    const times = dayData.slots.map((s) => s.start).join(", ");
    lines.push(`\u2022 *${dayName} (${formattedDate}):* ${times}`);
  }
  lines.push("\nQual hor\xE1rio fica melhor para voc\xEA?");
  return lines.join("\n");
}

export {
  DEFAULT_CALENDAR_TIMEZONE,
  buildCalendarDateTime,
  parseCalendarDateTimeWithTimeZone,
  addMinutesToCalendarDateTime,
  rangesOverlap,
  isGoogleCalendarConfigured,
  getGoogleAuthUrl,
  handleGoogleCallback,
  connectMatonCalendar,
  updateSelectedCalendar,
  isGoogleCalendarConnected,
  getGoogleCalendarStatus,
  disconnectGoogleCalendar,
  listCalendarEvents,
  listCalendarBusyWindows,
  checkCalendarAvailability,
  syncAppointmentToCalendar,
  removeAppointmentFromCalendar,
  invalidateSchedulingCache,
  isSchedulingEnabled,
  setSchedulingOrchestratorTestDependencies,
  clearSchedulingConversationState,
  clearSchedulingConversationStateForTests,
  rememberValidatedSlotOfferForTests,
  getValidatedSlotOfferForTests,
  findClosestSchedulingSlotWithinToleranceForTests,
  buildSchedulingNextSlotsReplyWithMemoryForTests,
  detectSchedulingIntent,
  extractOrdinalSlotFromListingForTests,
  extractSchedulingTags,
  stripSchedulingTagArtifacts,
  findExactAvailableSlot,
  findClosestAvailableSlot,
  responseLooksLikeSuccessfulScheduling,
  buildFailedSchedulingResponseText,
  normalizeAppointmentDateValue,
  getNextAppointmentDateValue,
  toDatabaseTimeString,
  normalizeSchedulingTimeValue,
  getSchedulingConfigCached,
  getSchedulingConfig,
  getExceptionForDate,
  getAppointmentsForDate,
  isDayAvailable,
  getAvailableSlots,
  createPendingAppointment,
  isSchedulingDisambiguationReply,
  generateSchedulingTurnPrompt,
  generateDeterministicSchedulingReply,
  generateSchedulingPromptBlock,
  processSchedulingTags,
  processSchedulingCancelTags,
  getNextAvailableSlots,
  formatAvailableSlotsForAI
};
