import {
  foldMediaName,
  init_textUtils,
  processResponsePlaceholders
} from "./chunk-JDBD3TU2.js";
import {
  storage
} from "./chunk-7SPF5OKO.js";

// server/mediaCustomerCaption.ts
function resolveCustomerFacingMediaCaption(media) {
  const caption = typeof media?.caption === "string" ? media.caption.trim() : "";
  return caption || void 0;
}

// server/simulatorMediaActions.ts
init_textUtils();
function expandSimulatorMediaAction(action, mediaLibrary, contactName) {
  if (action?.type === "send_text") {
    const text = processResponsePlaceholders(String(action.text || "").trim(), contactName);
    return text ? [{ type: "send_text", text }] : [];
  }
  if (action?.type === "send_media_url" && action.media_url) {
    const directAction = {
      type: "send_media_url",
      media_url: action.media_url,
      media_type: action.media_type || "image",
      caption: action.caption ? processResponsePlaceholders(String(action.caption), contactName) : "",
      media_name: action.media_name
    };
    if (action.file_name) {
      directAction.file_name = action.file_name;
    }
    return [directAction];
  }
  if (action?.type !== "send_media" || !action.media_name) {
    return [];
  }
  const targetMediaName = foldMediaName(action.media_name);
  const mediaItem = mediaLibrary.find((item) => foldMediaName(item.name) === targetMediaName);
  if (!mediaItem) {
    return [];
  }
  if (mediaItem.mediaType !== "flow") {
    const singleAction = {
      type: "send_media",
      media_name: action.media_name,
      media_url: mediaItem.storageUrl,
      media_type: mediaItem.mediaType,
      caption: resolveCustomerFacingMediaCaption(mediaItem)
    };
    if (mediaItem.fileName) {
      singleAction.file_name = mediaItem.fileName;
    }
    return [singleAction];
  }
  const flowItems = Array.isArray(mediaItem.flowItems) ? [...mediaItem.flowItems] : [];
  const expanded = [];
  for (const item of flowItems.sort((a, b) => (a.order || 0) - (b.order || 0))) {
    if (item?.type === "text") {
      const text = processResponsePlaceholders(String(item.text || "").trim(), contactName);
      if (text) {
        expanded.push({ type: "send_text", text });
      }
      continue;
    }
    if (item?.type === "media" && item.storageUrl) {
      const flowAction = {
        type: "send_media_url",
        media_url: item.storageUrl,
        media_type: item.mediaType || "image",
        caption: item.caption ? processResponsePlaceholders(String(item.caption), contactName) : "",
        media_name: action.media_name
      };
      if (item.fileName) {
        flowAction.file_name = item.fileName;
      }
      expanded.push(flowAction);
    }
  }
  return expanded;
}

// server/simulatorChannelGuard.ts
var defaultDeps = {
  getConnectionByUserId: storage.getConnectionByUserId.bind(storage),
  getAgentConfig: storage.getAgentConfig.bind(storage),
  getBusinessAgentConfig: storage.getBusinessAgentConfig.bind(storage)
};
async function getSimulatorChannelGuardResult(userId, deps = defaultDeps) {
  const [connection, agentConfig, businessAgentConfig] = await Promise.all([
    deps.getConnectionByUserId(userId),
    deps.getAgentConfig(userId),
    deps.getBusinessAgentConfig(userId)
  ]);
  if (connection?.isConnected && agentConfig && agentConfig.isActive === false) {
    return {
      channelReady: false,
      blockSource: "global_agent",
      blockReason: "O agente global est\xE1 desligado em Meu Agente IA. Ative-o para que o WhatsApp real responda.",
      connectionId: connection.id
    };
  }
  if (connection?.isConnected && businessAgentConfig && businessAgentConfig.isActive === false) {
    return {
      channelReady: false,
      blockSource: "business_agent",
      blockReason: "A IA operacional do agente est\xE1 desligada. Reative em Meu Agente IA antes de confiar no simulador.",
      connectionId: connection.id
    };
  }
  return {
    channelReady: true,
    blockSource: null,
    blockReason: null,
    connectionId: connection?.id ?? null
  };
}

export {
  expandSimulatorMediaAction,
  getSimulatorChannelGuardResult
};
