import {
  describeAppRuntimeProfile
} from "./chunk-M5SA4G4P.js";
import "./chunk-KFQGP6VL.js";

// server/index.ts
import "dotenv/config";
var SERVICE_MODE = process.env.SERVICE_MODE || "monolith";
var BOOT_ID = (/* @__PURE__ */ new Date()).toISOString();
var APP_RUNTIME_PROFILE = describeAppRuntimeProfile();
process.env.BOOT_ID = BOOT_ID;
process.env.APP_RUNTIME_PROFILE_EFFECTIVE = APP_RUNTIME_PROFILE;
console.log(`[BOOT] Starting server bootId=${BOOT_ID} mode=${SERVICE_MODE}`);
console.log(`[BOOT] runtimeProfile=${APP_RUNTIME_PROFILE}`);
console.log(
  `[BOOT] node=${process.version} env=${process.env.NODE_ENV || "unknown"} port=${process.env.PORT || "unknown"}`
);
console.log(
  `[BOOT] railwayCommit=${process.env.RAILWAY_GIT_COMMIT_SHA || process.env.RAILWAY_GIT_COMMIT || "unknown"}`
);
if (SERVICE_MODE === "proxy") {
  console.log("[PROXY MODE] Loading lightweight proxy module...");
  import("./proxy-YL4VGF4S.js").then(({ startProxy }) => {
    startProxy();
  }).catch((error) => {
    console.error("[PROXY MODE] Failed to start proxy:", error);
    process.exit(1);
  });
} else if (SERVICE_MODE === "wa-gateway") {
  console.log("[WA-GATEWAY MODE] Loading dedicated WhatsApp gateway...");
  import("./wa-gateway-FZHCMVGI.js").then(({ startWhatsAppGateway }) => {
    startWhatsAppGateway();
  }).catch((error) => {
    console.error("[WA-GATEWAY MODE] Failed to start:", error);
    process.exit(1);
  });
} else {
  console.log(`[${SERVICE_MODE.toUpperCase()} MODE] Loading full application...`);
  import("./full-app-35B473SM.js").then(({ startFullApp }) => {
    startFullApp();
  }).catch((error) => {
    console.error(`[${SERVICE_MODE.toUpperCase()} MODE] Failed to start:`, error);
    process.exit(1);
  });
}
