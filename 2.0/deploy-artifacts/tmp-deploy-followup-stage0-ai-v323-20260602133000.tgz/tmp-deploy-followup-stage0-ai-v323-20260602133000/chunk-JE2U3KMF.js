import {
  generateWithEdgeTTS
} from "./chunk-SFLSWTY7.js";
import {
  convertBufferToWhatsAppAudio
} from "./chunk-DH4QIP4D.js";
import {
  shouldBlockAutomatedConversationSend
} from "./chunk-R2H3ZHAP.js";
import {
  storage
} from "./chunk-7SPF5OKO.js";

// shared/agentSignature.ts
var GENERIC_SIGNATURE_NAMES = /* @__PURE__ */ new Set([
  "agente",
  "agente ia",
  "agente virtual",
  "assistente",
  "assistente ia",
  "assistente virtual",
  "atendente",
  "atendente ia",
  "atendente virtual",
  "chatbot",
  "equipe",
  "ia",
  "inteligencia artificial",
  "robo",
  "suporte",
  "time",
  "vendedor",
  "vendedora"
]);
function collapseWhitespace(value) {
  return value.replace(/\s+/g, " ").trim();
}
function stripPromptFormatting(value) {
  return collapseWhitespace(
    value.replace(/[*_`~]/g, " ").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
  );
}
function toTitleCase(value) {
  return value.split(" ").filter(Boolean).map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(" ");
}
function normalizeCandidate(value) {
  return stripPromptFormatting(value).toLowerCase();
}
function normalizeAgentSignatureName(value) {
  const trimmed = collapseWhitespace(String(value || ""));
  return trimmed || null;
}
function isGenericAgentSignatureName(value) {
  const normalized = normalizeCandidate(String(value || ""));
  return !normalized || GENERIC_SIGNATURE_NAMES.has(normalized);
}
function detectAgentSignatureNameFromPrompt(prompt) {
  const source = stripPromptFormatting(String(prompt || ""));
  if (!source) return null;
  const patterns = [
    /\bvoce e (?:o |a |um |uma )?([^,.;:\n]+?)(?:,\s*[^.;:\n]+?)?\s+da\b/i,
    /\bsou (?:o |a )?([^,.;:\n]+?)(?:,\s*[^.;:\n]+?)?\s+da\b/i
  ];
  for (const pattern of patterns) {
    const match = source.match(pattern);
    const candidate = normalizeAgentSignatureName(match?.[1] || "");
    if (candidate && !isGenericAgentSignatureName(candidate)) {
      return toTitleCase(candidate);
    }
  }
  return null;
}
function resolveAgentSignatureName(options) {
  const configured = normalizeAgentSignatureName(options.configuredSignature);
  if (configured) {
    return configured;
  }
  return detectAgentSignatureNameFromPrompt(options.prompt);
}
function formatWhatsappSignaturePrefix(name) {
  return `*${name}:*`;
}
function normalizeSignatureLineForComparison(value) {
  return value.replace(/[*\s]/g, "").trim().toLowerCase();
}
function stripStandaloneSignatureArtifacts(body, name) {
  const expected = `${String(name || "").trim()}:`;
  const expectedNormalized = normalizeSignatureLineForComparison(expected);
  if (!expectedNormalized) {
    return body;
  }
  const normalizedLines = body.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  while (normalizedLines.length > 0) {
    const firstLine = normalizedLines[0];
    if (normalizeSignatureLineForComparison(firstLine) !== expectedNormalized) {
      break;
    }
    normalizedLines.shift();
  }
  while (normalizedLines.length > 0) {
    const lastLine = normalizedLines[normalizedLines.length - 1];
    if (normalizeSignatureLineForComparison(lastLine) !== expectedNormalized) {
      break;
    }
    normalizedLines.pop();
  }
  return normalizedLines.join("\n").trim();
}
function stripTrailingSignatureSuffix(body, name) {
  const trimmedName = String(name || "").trim();
  if (!trimmedName) {
    return body;
  }
  const suffixes = [
    formatWhatsappSignaturePrefix(trimmedName),
    `${trimmedName}:*`,
    `${trimmedName}:`
  ];
  let nextBody = body.trim();
  let changed = true;
  while (changed && nextBody) {
    changed = false;
    for (const suffix of suffixes) {
      if (!suffix) continue;
      if (!nextBody.endsWith(suffix)) continue;
      nextBody = nextBody.slice(0, -suffix.length).trimEnd();
      changed = true;
    }
  }
  return nextBody;
}
function stripLeadingSignaturePrefix(body, name) {
  const trimmedName = String(name || "").trim();
  if (!trimmedName) {
    return body;
  }
  const escapedName = trimmedName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const leadingSignaturePattern = new RegExp(
    `^\\s*(?:\\*${escapedName}:\\*|${escapedName}:\\*?)\\s*`,
    "i"
  );
  return body.replace(leadingSignaturePattern, "").trimStart();
}
function prependWhatsappSignature(text, name) {
  const originalBody = String(text || "").trim();
  if (!originalBody) return originalBody;
  const resolvedName = normalizeAgentSignatureName(name);
  if (!resolvedName) {
    return originalBody;
  }
  let body = stripStandaloneSignatureArtifacts(originalBody, resolvedName);
  body = stripLeadingSignaturePrefix(body, resolvedName);
  body = stripTrailingSignatureSuffix(body, resolvedName);
  if (!body) return body;
  const prefix = formatWhatsappSignaturePrefix(resolvedName);
  if (body === prefix || body.startsWith(`${prefix}
`) || body.startsWith(`${prefix}\r
`)) {
    return body;
  }
  return `${prefix}
${body}`;
}
function consumeLeadingSignature(body, prefix) {
  if (!body.startsWith(prefix)) {
    return null;
  }
  let cursor = prefix.length;
  while (cursor < body.length) {
    const current = body[cursor];
    if (current === " " || current === "	" || current === "\n" || current === "\r") {
      cursor += 1;
      continue;
    }
    break;
  }
  return body.slice(cursor).trimStart();
}
function detectGenericWhatsappSignaturePrefix(body) {
  const firstLineBreak = body.indexOf("\n");
  const firstLine = (firstLineBreak >= 0 ? body.slice(0, firstLineBreak) : body).trim();
  if (!firstLine.startsWith("*") || !firstLine.endsWith("*")) {
    return null;
  }
  const inner = firstLine.slice(1, -1).trim();
  if (!inner.endsWith(":") || inner.length < 2 || inner.length > 80) {
    return null;
  }
  return firstLine;
}
function stripWhatsappSignatureForSpeech(text, name) {
  const originalBody = String(text || "").trim();
  if (!originalBody) {
    return originalBody;
  }
  const resolvedName = normalizeAgentSignatureName(name);
  const body = resolvedName ? stripTrailingSignatureSuffix(
    stripStandaloneSignatureArtifacts(originalBody, resolvedName),
    resolvedName
  ) : originalBody;
  const candidatePrefixes = [];
  if (resolvedName) {
    candidatePrefixes.push(formatWhatsappSignaturePrefix(resolvedName));
    candidatePrefixes.push(`${resolvedName}:`);
  }
  const genericWhatsappPrefix = detectGenericWhatsappSignaturePrefix(body);
  if (genericWhatsappPrefix) {
    candidatePrefixes.push(genericWhatsappPrefix);
  }
  for (const prefix of candidatePrefixes) {
    const stripped = consumeLeadingSignature(body, prefix);
    if (stripped !== null) {
      return stripped;
    }
  }
  return body;
}

// server/audioResponsePolicy.ts
function resolveAudioResponseDecision(input) {
  const customerMessageWasAudio = Boolean(input.customerMessageWasAudio);
  const firstAgentReplyInConversation = Boolean(input.firstAgentReplyInConversation);
  const responseMode = input.responseMode === "first_message_text_audio_then_mirror" ? "audio_first_message_then_customer_audio" : input.responseMode;
  if (responseMode === "audio_text") {
    return {
      responseMode: input.responseMode,
      shouldSendText: true,
      shouldGenerateAudio: true,
      fallbackToTextIfAudioFails: false
    };
  }
  if (responseMode === "audio_only") {
    return {
      responseMode: input.responseMode,
      shouldSendText: false,
      shouldGenerateAudio: true,
      fallbackToTextIfAudioFails: true
    };
  }
  if (responseMode === "audio_first_message_then_customer_audio") {
    if (firstAgentReplyInConversation) {
      return {
        responseMode: input.responseMode,
        shouldSendText: true,
        shouldGenerateAudio: true,
        fallbackToTextIfAudioFails: false
      };
    }
    return {
      responseMode: input.responseMode,
      shouldSendText: !customerMessageWasAudio,
      shouldGenerateAudio: customerMessageWasAudio,
      fallbackToTextIfAudioFails: customerMessageWasAudio
    };
  }
  return {
    responseMode: input.responseMode,
    shouldSendText: !customerMessageWasAudio,
    shouldGenerateAudio: customerMessageWasAudio,
    fallbackToTextIfAudioFails: customerMessageWasAudio
  };
}

// server/audioResponseService.ts
var VOICE_MAP = {
  female: "pt-BR-FranciscaNeural",
  male: "pt-BR-AntonioNeural"
};
function normalizeAudioVoiceType(voiceType) {
  const value = String(voiceType || "").trim().toLowerCase();
  if (value === "santa" || value === "alex") return "male";
  if (value === "dora") return "female";
  return value === "male" || value === "female" ? value : "female";
}
var URL_REGEX = /(?:https?:\/\/|www\.)[^\s]+/gi;
var DOMAIN_REGEX = /\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+(?:com(?:\.br)?|net|org|io|app|dev|co|ai|me|br|site|online|info|biz|gov|edu)(?:\/[^\s]*)?/gi;
function sanitizeTextForTTS(text) {
  if (!text) return text;
  let cleanedText = text;
  cleanedText = cleanedText.replace(/(?:https?:\/\/|www\.)[^\s]+/gi, "");
  cleanedText = cleanedText.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, "");
  cleanedText = cleanedText.replace(/[\u{1F600}-\u{1F64F}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{1F300}-\u{1F5FF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{1F680}-\u{1F6FF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{1F1E0}-\u{1F1FF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{2600}-\u{26FF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{2700}-\u{27BF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{FE00}-\u{FE0F}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{1F900}-\u{1F9FF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{1FA00}-\u{1FA6F}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{1FA70}-\u{1FAFF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{200D}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{20E3}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{E0020}-\u{E007F}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{2300}-\u{23FF}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{2B05}-\u{2B55}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{FE00}-\u{FE0F}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{200B}-\u{200F}]/gu, "");
  cleanedText = cleanedText.replace(/[\u{2028}-\u{2029}]/gu, "");
  cleanedText = cleanedText.replace(/```[\s\S]*?```/g, "");
  cleanedText = cleanedText.replace(/\*{1,3}([^*]+)\*{1,3}/g, "$1");
  cleanedText = cleanedText.replace(/\*/g, "");
  cleanedText = cleanedText.replace(/_+([^_]+)_+/g, "$1");
  cleanedText = cleanedText.replace(/_/g, " ");
  cleanedText = cleanedText.replace(/~+([^~]+)~+/g, "$1");
  cleanedText = cleanedText.replace(/~/g, "");
  cleanedText = cleanedText.replace(/`+([^`]+)`+/g, "$1");
  cleanedText = cleanedText.replace(/`/g, "");
  cleanedText = cleanedText.replace(/[""\u201C\u201D\u201E\u201F\u2033\u2036]/g, "");
  cleanedText = cleanedText.replace(/[''\u2018\u2019\u201A\u201B\u2032\u2035]/g, "");
  cleanedText = cleanedText.replace(/[«»\u2039\u203A]/g, "");
  cleanedText = cleanedText.replace(/'/g, "");
  cleanedText = cleanedText.replace(/"/g, "");
  cleanedText = cleanedText.replace(/[═━─—–╔╗╚╝╠╣╦╩╬║├┤┬┴┼┌┐└┘│▔▁▂▃▄▅▆▇█▉▊▋▌▍▎▏░▒▓]/g, "");
  cleanedText = cleanedText.replace(/-{3,}/g, "");
  cleanedText = cleanedText.replace(/_{3,}/g, "");
  cleanedText = cleanedText.replace(/[→←↑↓↔↕⇒⇐⇑⇓⇔➜➤➡➔➝➞➠►▶◀◁▷◆◇▸▹▻●○•]/g, "");
  cleanedText = cleanedText.replace(/@/g, "");
  cleanedText = cleanedText.replace(/#(?!\d)/g, "");
  cleanedText = cleanedText.replace(/\^/g, "");
  cleanedText = cleanedText.replace(/\|/g, "");
  cleanedText = cleanedText.replace(/[<>]/g, "");
  cleanedText = cleanedText.replace(/[=+]/g, "");
  cleanedText = cleanedText.replace(/&(?!(\w+;))/g, "e");
  cleanedText = cleanedText.replace(/\[([^\]]*)\]/g, "$1");
  cleanedText = cleanedText.replace(/\{([^}]*)\}/g, "$1");
  cleanedText = cleanedText.replace(/\(\s*\)/g, "");
  cleanedText = cleanedText.replace(/\(\(([^)]*)\)\)/g, "$1");
  cleanedText = cleanedText.replace(/R\$\s*(\d)/g, "$1");
  cleanedText = cleanedText.replace(/^>\s*/gm, "");
  cleanedText = cleanedText.replace(/^[-•]\s*/gm, "");
  cleanedText = cleanedText.replace(/^#+\s+/gm, "");
  cleanedText = cleanedText.replace(/\.{4,}/g, "...");
  cleanedText = cleanedText.replace(/!{2,}/g, "!");
  cleanedText = cleanedText.replace(/\?{2,}/g, "?");
  cleanedText = cleanedText.replace(/,{2,}/g, ",");
  cleanedText = cleanedText.replace(/;{2,}/g, ";");
  cleanedText = cleanedText.replace(/:{2,}/g, ":");
  cleanedText = cleanedText.replace(/\\[nrtfvb]/g, " ");
  cleanedText = cleanedText.replace(/\\/g, "");
  cleanedText = cleanedText.replace(/&nbsp;/gi, " ");
  cleanedText = cleanedText.replace(/&amp;/gi, "e");
  cleanedText = cleanedText.replace(/&lt;/gi, "");
  cleanedText = cleanedText.replace(/&gt;/gi, "");
  cleanedText = cleanedText.replace(/&quot;/gi, "");
  cleanedText = cleanedText.replace(/&#\d+;/g, "");
  cleanedText = cleanedText.replace(/&\w+;/g, "");
  cleanedText = cleanedText.replace(/\n{3,}/g, "\n\n");
  cleanedText = cleanedText.replace(/[ \t]{2,}/g, " ");
  cleanedText = cleanedText.replace(/\s+([.,!?;:])/g, "$1");
  cleanedText = cleanedText.replace(/^\s+$/gm, "");
  cleanedText = cleanedText.trim();
  if (text.length !== cleanedText.length) {
    const removed = text.length - cleanedText.length;
    console.log(`[TTS-SANITIZE] Texto sanitizado para audio:`);
    console.log(`   Original (${text.length} chars): "${text.substring(0, 80)}..."`);
    console.log(`   Limpo (${cleanedText.length} chars): "${cleanedText.substring(0, 80)}..."`);
    console.log(`   Removidos: ${removed} caracteres de formatacao`);
  }
  return cleanedText;
}
async function sendTextCompanionForLinks(jid, responseText, socket, options) {
  if (!responseRequiresTextCompanion(responseText)) {
    return true;
  }
  try {
    await new Promise((resolve) => setTimeout(resolve, 450));
    const sentMessage = await socket.sendMessage(jid, { text: responseText });
    try {
      await options?.onTextCompanionSent?.({
        messageId: sentMessage?.key?.id || null,
        text: responseText
      });
    } catch (callbackError) {
      console.error("[TTS-RESPONSE] Erro no callback de texto complementar:", callbackError);
    }
    console.log(`\xF0\u0178\u201D\u2014 [TTS-RESPONSE] Texto complementar com link enviado para ${jid}`);
    return true;
  } catch (error) {
    console.error("[TTS-RESPONSE] Erro ao enviar texto complementar com link:", error);
    return false;
  }
}
function normalizeDetectedLink(rawValue) {
  const trimmed = rawValue.trim().replace(/[).,;!?]+$/g, "");
  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }
  if (/^www\./i.test(trimmed)) {
    return `https://${trimmed}`;
  }
  return `https://${trimmed}`;
}
function extractLinksFromText(text) {
  if (!text) return [];
  const matches = [
    ...text.match(URL_REGEX) ?? [],
    ...text.match(DOMAIN_REGEX) ?? []
  ];
  const uniqueLinks = /* @__PURE__ */ new Set();
  for (const match of matches) {
    uniqueLinks.add(normalizeDetectedLink(match));
  }
  return Array.from(uniqueLinks);
}
function responseRequiresTextCompanion(text) {
  return extractLinksFromText(text).length > 0;
}
function resolveAudioResponseDecision2(input) {
  return resolveAudioResponseDecision(input);
}
async function getAudioResponseSettings(userId, context) {
  try {
    const config = await storage.getAudioConfig(userId);
    if (!config || !config.isEnabled) {
      console.log(`\u{1F507} [TTS-RESPONSE] \xC1udio desabilitado para usu\xE1rio ${userId.substring(0, 8)}...`);
      return {
        responseMode: "disabled",
        shouldSendText: true,
        shouldGenerateAudio: false,
        fallbackToTextIfAudioFails: false
      };
    }
    const responseMode = config.responseMode ?? "first_message_text_audio_then_mirror";
    const decision = resolveAudioResponseDecision({
      responseMode,
      customerMessageWasAudio: context?.customerMessageWasAudio,
      firstAgentReplyInConversation: context?.firstAgentReplyInConversation ?? context?.isFirstOutboundMessage
    });
    const usage = await storage.canSendAudio(userId);
    if (!usage.canSend) {
      console.log(`\u26A0\uFE0F [TTS-RESPONSE] Limite di\xE1rio atingido para usu\xE1rio ${userId.substring(0, 8)}... (${usage.limit}/${usage.limit})`);
      return {
        responseMode: decision.responseMode,
        shouldSendText: true,
        shouldGenerateAudio: false,
        fallbackToTextIfAudioFails: false
      };
    }
    const voice = VOICE_MAP[normalizeAudioVoiceType(config.voiceType)] || VOICE_MAP.female;
    const speedNum = parseFloat(config.speed);
    const ratePercent = Math.round((speedNum - 1) * 100);
    const rate = ratePercent >= 0 ? `+${ratePercent}%` : `${ratePercent}%`;
    console.log(
      `\u{1F3A4} [TTS-RESPONSE] \xC1udio habilitado - Mode: ${responseMode}, Voice: ${voice}, Speed: ${speedNum}x, Restante: ${usage.isUnlimited ? "ilimitado" : `${usage.remaining}/${usage.limit}`}`
    );
    return {
      responseMode: decision.responseMode,
      shouldSendText: decision.shouldSendText,
      shouldGenerateAudio: decision.shouldGenerateAudio,
      fallbackToTextIfAudioFails: decision.fallbackToTextIfAudioFails,
      voice,
      speed: config.speed,
      rate
    };
  } catch (error) {
    console.error("[TTS-RESPONSE] Erro ao verificar config:", error);
    return {
      responseMode: "disabled",
      shouldSendText: true,
      shouldGenerateAudio: false,
      fallbackToTextIfAudioFails: false
    };
  }
}
async function shouldGenerateAudioResponse(userId, context) {
  const settings = await getAudioResponseSettings(userId, context);
  if (!settings.shouldGenerateAudio || !settings.voice || !settings.speed || !settings.rate) {
    return null;
  }
  return {
    shouldGenerate: true,
    voice: settings.voice,
    speed: settings.speed,
    rate: settings.rate
  };
}
async function prepareTtsAudioForWhatsAppVoiceMessage(audioBuffer) {
  const convertedAudio = await convertBufferToWhatsAppAudio(audioBuffer, "audio/mpeg");
  const shouldUsePtt = convertedAudio.mimeType === "audio/ogg; codecs=opus";
  if (!shouldUsePtt) {
    console.warn(
      `[TTS-RESPONSE] Convers\xE3o para nota de voz n\xE3o ficou em OGG/Opus. Enviando como \xE1udio normal (${convertedAudio.mimeType}) para evitar m\xEDdia corrompida.`
    );
  }
  return {
    audioBuffer: convertedAudio.buffer,
    mimeType: convertedAudio.mimeType,
    ptt: shouldUsePtt,
    converted: convertedAudio.converted
  };
}
async function generateAudioForResponse(text, voice, rate, options) {
  try {
    const textWithoutVisualSignature = stripWhatsappSignatureForSpeech(
      text,
      options?.signatureName
    );
    const sanitizedText = sanitizeTextForTTS(textWithoutVisualSignature);
    if (!sanitizedText || sanitizedText.trim().length === 0) {
      console.log(`\u26A0\uFE0F [TTS-RESPONSE] Texto vazio ap\xF3s sanitiza\xE7\xE3o, pulando gera\xE7\xE3o de \xE1udio`);
      return null;
    }
    const maxLength = 500;
    const trimmedText = sanitizedText.length > maxLength ? sanitizedText.substring(0, maxLength) + "..." : sanitizedText;
    console.log(`\u{1F399}\uFE0F [TTS-RESPONSE] Gerando \xE1udio para: "${trimmedText.substring(0, 50)}..."`);
    const audioBuffer = await generateWithEdgeTTS(trimmedText, voice, rate);
    if (!audioBuffer || audioBuffer.length < 1e3) {
      console.error("[TTS-RESPONSE] \xC1udio gerado muito pequeno ou vazio");
      return null;
    }
    console.log(`\u2705 [TTS-RESPONSE] \xC1udio gerado: ${audioBuffer.length} bytes`);
    return audioBuffer;
  } catch (error) {
    console.error("[TTS-RESPONSE] Erro ao gerar \xE1udio:", error);
    return null;
  }
}
async function sendAudioAsVoiceMessage(userId, jid, audioBuffer, socket, conversationId, options) {
  try {
    const pauseCheck = await shouldBlockAutomatedConversationSend({
      userId,
      jid,
      conversationId,
      origin: "ai_agent"
    });
    if (pauseCheck.blocked) {
      console.log(`\u23F8\uFE0F [TTS-RESPONSE] \xC1udio bloqueado para conversa ${pauseCheck.conversationId} porque a IA est\xE1 pausada`);
      return false;
    }
    const preparedAudio = await prepareTtsAudioForWhatsAppVoiceMessage(audioBuffer);
    console.log(
      `\u{1F4E4} [TTS-RESPONSE] Enviando \xE1udio para ${jid} (mime=${preparedAudio.mimeType}, ptt=${preparedAudio.ptt}, converted=${preparedAudio.converted})`
    );
    const sentMessage = await socket.sendMessage(jid, {
      audio: preparedAudio.audioBuffer,
      mimetype: preparedAudio.mimeType,
      ptt: preparedAudio.ptt
    });
    const sentMessageId = sentMessage?.key?.id || null;
    if (sentMessageId) {
      try {
        options?.registerSentMessageId?.(sentMessageId);
      } catch (registerError) {
        console.error("[TTS-RESPONSE] Erro ao registrar messageId do \xE1udio enviado:", registerError);
      }
    }
    try {
      await options?.onSent?.({
        messageId: sentMessageId,
        mediaMimeType: preparedAudio.mimeType
      });
    } catch (callbackError) {
      console.error("[TTS-RESPONSE] Erro no callback de audio enviado:", callbackError);
    }
    const counterResult = await storage.incrementAudioMessageCounter(userId);
    console.log(`\u{1F4CA} [TTS-RESPONSE] Contador atualizado: ${counterResult.count}/${counterResult.limit}`);
    console.log(`\u2705 [TTS-RESPONSE] \xC1udio enviado com sucesso!`);
    return true;
  } catch (error) {
    console.error("[TTS-RESPONSE] Erro ao enviar \xE1udio:", error);
    return false;
  }
}
async function processAudioResponseForAgent(userId, jid, responseText, socket, context, options) {
  try {
    const settings = await getAudioResponseSettings(userId, context);
    if (!settings.shouldGenerateAudio || !settings.voice || !settings.rate) {
      return false;
    }
    const audioBuffer = await generateAudioForResponse(
      responseText,
      settings.voice,
      settings.rate,
      {
        signatureName: options?.signatureName
      }
    );
    if (!audioBuffer) {
      console.warn("[TTS-RESPONSE] Falha ao gerar \xE1udio, continuando sem ele");
      return false;
    }
    await new Promise((resolve) => setTimeout(resolve, 1e3 + Math.random() * 500));
    const sent = await sendAudioAsVoiceMessage(
      userId,
      jid,
      audioBuffer,
      socket,
      context?.conversationId,
      options
    );
    if (!sent) {
      return false;
    }
    if (!settings.shouldSendText && responseRequiresTextCompanion(responseText)) {
      return sendTextCompanionForLinks(jid, responseText, socket, options);
    }
    return true;
  } catch (error) {
    console.error("[TTS-RESPONSE] Erro no processamento:", error);
    return false;
  }
}

export {
  normalizeAgentSignatureName,
  resolveAgentSignatureName,
  prependWhatsappSignature,
  extractLinksFromText,
  responseRequiresTextCompanion,
  resolveAudioResponseDecision2 as resolveAudioResponseDecision,
  getAudioResponseSettings,
  shouldGenerateAudioResponse,
  prepareTtsAudioForWhatsAppVoiceMessage,
  generateAudioForResponse,
  sendAudioAsVoiceMessage,
  processAudioResponseForAgent
};
