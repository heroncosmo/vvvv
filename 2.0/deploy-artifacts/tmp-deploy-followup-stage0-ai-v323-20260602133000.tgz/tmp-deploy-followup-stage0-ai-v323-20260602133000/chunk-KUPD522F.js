// server/broadcastTemplate.ts
var BRAZIL_TIME_ZONE = "America/Sao_Paulo";
var GREETING_PLACEHOLDER_PATTERN = /\[(?:saudacao|sauda(?:c|\u00e7)(?:a|\u00e3)o|cumprimento)\]/gi;
function getBrazilHour(date) {
  try {
    const parts = new Intl.DateTimeFormat("pt-BR", {
      timeZone: BRAZIL_TIME_ZONE,
      hour: "2-digit",
      hour12: false
    }).formatToParts(date);
    const hourText = parts.find((part) => part.type === "hour")?.value;
    const hour = Number(hourText);
    if (Number.isFinite(hour)) return hour % 24;
  } catch (_error) {
  }
  return date.getHours();
}
function resolveBroadcastGreetingForDate(date = /* @__PURE__ */ new Date()) {
  const hour = getBrazilHour(date);
  if (hour >= 5 && hour < 12) return "Bom dia";
  if (hour >= 12 && hour < 18) return "Boa tarde";
  return "Boa noite";
}
function applyBroadcastTemplate(template, name, options) {
  const safeName = String(name || "Cliente").trim() || "Cliente";
  return String(template || "").replace(/\[nome\]/gi, safeName).replace(GREETING_PLACEHOLDER_PATTERN, resolveBroadcastGreetingForDate(options?.now));
}

export {
  applyBroadcastTemplate
};
