import {
  ensureUserSessionOperational,
  extractIdentityPersonKey,
  isLidWhatsAppJid,
  isPersonalWhatsAppJid,
  messageQueueService,
  normalizeWhatsAppIdentity
} from "./chunk-JDBD3TU2.js";
import {
  isWhatsAppGatewayRuntime,
  previewGatewayStatusAudience,
  resolveAppVisibleConnectionOwner,
  sendGatewayStatusPost
} from "./chunk-LYL74IEX.js";
import {
  generateWithLLM
} from "./chunk-M7TXNZTC.js";
import {
  db,
  pool,
  runtimeAutoMigrationsEnabled
} from "./chunk-R6CXRQMB.js";
import {
  statusPostItems,
  statusPosts,
  statusPublishJobs,
  statusPublishRunItems,
  statusPublishRuns,
  statusRotationPosts,
  statusRotations,
  whatsappConnections,
  whatsappContacts
} from "./chunk-JC6URYU5.js";

// server/whatsappRuntimeMigrations.ts
async function ensureWhatsAppRuntimeSchema() {
  if (!runtimeAutoMigrationsEnabled) {
    console.log("[MIGRATION] WhatsApp runtime schema skipped by runtime auto-migration flag");
    return;
  }
  try {
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS gateway_api_enabled BOOLEAN NOT NULL DEFAULT false`);
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS gateway_api_token_hash TEXT`);
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS gateway_api_token_preview VARCHAR(64)`);
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS gateway_api_last_used_at TIMESTAMP`);
    await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS gateway_api_rotated_at TIMESTAMP`);
    await pool.query(`ALTER TABLE whatsapp_connections ADD COLUMN IF NOT EXISTS ai_enabled BOOLEAN NOT NULL DEFAULT true`);
    await pool.query(`ALTER TABLE admin_whatsapp_connection ADD COLUMN IF NOT EXISTS ai_enabled BOOLEAN NOT NULL DEFAULT true`);
    await pool.query(`ALTER TABLE whatsapp_connections ADD COLUMN IF NOT EXISTS public_api_enabled BOOLEAN NOT NULL DEFAULT false`);
    await pool.query(`ALTER TABLE whatsapp_connections ADD COLUMN IF NOT EXISTS public_api_token_hash TEXT`);
    await pool.query(`ALTER TABLE whatsapp_connections ADD COLUMN IF NOT EXISTS public_api_token_preview VARCHAR(64)`);
    await pool.query(`ALTER TABLE whatsapp_connections ADD COLUMN IF NOT EXISTS public_api_last_used_at TIMESTAMP`);
    await pool.query(`ALTER TABLE whatsapp_connections ADD COLUMN IF NOT EXISTS public_api_rotated_at TIMESTAMP`);
    console.log("[MIGRATION] WhatsApp runtime schema ensured");
  } catch (error) {
    console.error("[MIGRATION] Failed to ensure WhatsApp runtime schema:", error);
  }
}

// server/gatewayPlatformTokens.ts
import crypto from "crypto";
var GATEWAY_ACCOUNT_TOKEN_PREFIX = "agz";
function generateGatewayAccountToken(userId) {
  return `${GATEWAY_ACCOUNT_TOKEN_PREFIX}_${userId}_${crypto.randomBytes(24).toString("hex")}`;
}
function hashGatewayAccountToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
function buildGatewayAccountTokenPreview(token) {
  if (token.length <= 12) {
    return token;
  }
  return `${token.slice(0, 8)}...${token.slice(-4)}`;
}
function parseGatewayAccountToken(token) {
  const trimmed = String(token || "").trim();
  if (!trimmed.startsWith(`${GATEWAY_ACCOUNT_TOKEN_PREFIX}_`)) {
    return null;
  }
  const parts = trimmed.split("_");
  if (parts.length !== 3) {
    return null;
  }
  const [, userId, secret] = parts;
  if (!userId || !secret) {
    return null;
  }
  return { userId, secret };
}
function verifyGatewayAccountToken(token, expectedHash) {
  if (!expectedHash) {
    return false;
  }
  const candidate = Buffer.from(hashGatewayAccountToken(token), "utf8");
  const expected = Buffer.from(expectedHash, "utf8");
  if (candidate.length !== expected.length) {
    return false;
  }
  return crypto.timingSafeEqual(candidate, expected);
}

// server/statusBrazilTime.ts
var STATUS_BRAZIL_TIME_ZONE = "America/Sao_Paulo";
var STATUS_BRAZIL_UTC_OFFSET = "-03:00";
function padDatePart(value) {
  return String(value).padStart(2, "0");
}
function normalizeDateTimeInput(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) {
    return "";
  }
  if (!trimmed.includes("T") && trimmed.includes(" ")) {
    const parts = trimmed.split(" ");
    const datePart = parts.shift() || "";
    return [datePart, parts.join(" ")].filter(Boolean).join("T");
  }
  return trimmed;
}
function hasExplicitTimeZone(value) {
  if (!value) {
    return false;
  }
  if (value.endsWith("Z") || value.endsWith("z")) {
    return true;
  }
  const timeIndex = value.indexOf("T");
  if (timeIndex < 0) {
    return false;
  }
  const tail = value.slice(timeIndex + 1);
  const plusIndex = tail.lastIndexOf("+");
  const minusIndex = tail.lastIndexOf("-");
  const offsetIndex = Math.max(plusIndex, minusIndex);
  if (offsetIndex < 0) {
    return false;
  }
  const offset = tail.slice(offsetIndex);
  return offset.length === 6 && offset[3] === ":";
}
function getStatusBrazilParts(reference = /* @__PURE__ */ new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: STATUS_BRAZIL_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  }).formatToParts(reference);
  const byType = new Map(parts.map((part) => [part.type, part.value]));
  return {
    year: Number(byType.get("year") || "0"),
    month: Number(byType.get("month") || "0"),
    day: Number(byType.get("day") || "0"),
    hour: Number(byType.get("hour") || "0"),
    minute: Number(byType.get("minute") || "0"),
    second: Number(byType.get("second") || "0")
  };
}
function fromStatusBrazilParts(parts) {
  return /* @__PURE__ */ new Date(
    `${parts.year}-${padDatePart(parts.month)}-${padDatePart(parts.day)}T${padDatePart(parts.hour)}:${padDatePart(parts.minute)}:${padDatePart(parts.second)}${STATUS_BRAZIL_UTC_OFFSET}`
  );
}
function parseStatusBrazilDateTime(value) {
  if (!value) {
    return null;
  }
  if (value instanceof Date) {
    return Number.isFinite(value.getTime()) ? new Date(value) : null;
  }
  const normalized = normalizeDateTimeInput(value);
  if (!normalized) {
    return null;
  }
  const parsed = new Date(
    hasExplicitTimeZone(normalized) ? normalized : `${normalized}${STATUS_BRAZIL_UTC_OFFSET}`
  );
  return Number.isFinite(parsed.getTime()) ? parsed : null;
}
function formatStatusBrazilTime(value) {
  const parsed = parseStatusBrazilDateTime(value);
  if (!parsed) {
    return "-";
  }
  return parsed.toLocaleTimeString("pt-BR", {
    timeZone: STATUS_BRAZIL_TIME_ZONE,
    hour: "2-digit",
    minute: "2-digit"
  });
}
function startOfStatusBrazilMinute(date) {
  const parts = getStatusBrazilParts(date);
  return fromStatusBrazilParts({ ...parts, second: 0 });
}
function getStatusBrazilWeekday(date) {
  const parts = getStatusBrazilParts(date);
  return new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay();
}
function addStatusBrazilDays(date, days) {
  const parts = getStatusBrazilParts(date);
  const pseudo = new Date(Date.UTC(parts.year, parts.month - 1, parts.day));
  pseudo.setUTCDate(pseudo.getUTCDate() + days);
  return fromStatusBrazilParts({
    year: pseudo.getUTCFullYear(),
    month: pseudo.getUTCMonth() + 1,
    day: pseudo.getUTCDate(),
    hour: parts.hour,
    minute: parts.minute,
    second: parts.second
  });
}
function getLastBrazilMonthDay(year, month) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}
function addStatusBrazilMonths(date, months) {
  const parts = getStatusBrazilParts(date);
  const pseudo = new Date(Date.UTC(parts.year, parts.month - 1, 1));
  pseudo.setUTCMonth(pseudo.getUTCMonth() + months);
  const year = pseudo.getUTCFullYear();
  const month = pseudo.getUTCMonth() + 1;
  return fromStatusBrazilParts({
    year,
    month,
    day: Math.min(parts.day, getLastBrazilMonthDay(year, month)),
    hour: parts.hour,
    minute: parts.minute,
    second: parts.second
  });
}

// server/statusProcessingRuntime.ts
var DEFAULT_STATUS_SEND_TIMEOUT_MS = 9e4;
var INTERRUPTED_PROCESSING_RECOVERY_GRACE_MS = 1e4;
var DEFAULT_IMMEDIATE_STATUS_RECOVERY_MAX_AGE_MS = 10 * 60 * 1e3;
function toValidDate(value) {
  if (!value) {
    return null;
  }
  const parsed = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    return null;
  }
  return parsed;
}
function getStatusSendTimeoutMs() {
  const parsed = Number(process.env.STATUS_SEND_TIMEOUT_MS || process.env.STATUS_POST_SEND_TIMEOUT_MS);
  if (Number.isFinite(parsed) && parsed >= 1e4) {
    return parsed;
  }
  return DEFAULT_STATUS_SEND_TIMEOUT_MS;
}
function getImmediateStatusRecoveryMaxAgeMs() {
  const parsed = Number(process.env.STATUS_IMMEDIATE_RECOVERY_MAX_AGE_MS);
  if (Number.isFinite(parsed) && parsed >= 6e4) {
    return parsed;
  }
  return DEFAULT_IMMEDIATE_STATUS_RECOVERY_MAX_AGE_MS;
}
function createStatusSendTimeoutError(timeoutMs = getStatusSendTimeoutMs()) {
  const seconds = Math.ceil(timeoutMs / 1e3);
  const error = new Error(`Status send timed out after ${seconds}s`);
  error.name = "StatusSendTimeoutError";
  return error;
}
async function withStatusSendTimeout(operation, timeoutMs = getStatusSendTimeoutMs()) {
  let timeoutHandle = null;
  try {
    return await Promise.race([
      operation,
      new Promise((_, reject) => {
        timeoutHandle = setTimeout(() => {
          reject(createStatusSendTimeoutError(timeoutMs));
        }, timeoutMs);
      })
    ]);
  } finally {
    if (timeoutHandle) {
      clearTimeout(timeoutHandle);
    }
  }
}
function isInterruptedScheduledStatusProcessing(params) {
  if (params.status !== "processing") {
    return false;
  }
  const updatedAt = toValidDate(params.updatedAt);
  const bootStartedAt = toValidDate(params.schedulerBootStartedAt);
  if (!updatedAt || !bootStartedAt) {
    return false;
  }
  return updatedAt.getTime() < bootStartedAt.getTime();
}
function shouldRecoverInterruptedScheduledStatus(params) {
  if (!isInterruptedScheduledStatusProcessing({
    status: params.status,
    updatedAt: params.updatedAt,
    schedulerBootStartedAt: params.schedulerBootStartedAt
  })) {
    return false;
  }
  const bootStartedAt = toValidDate(params.schedulerBootStartedAt);
  const now = params.now || /* @__PURE__ */ new Date();
  if (!bootStartedAt) {
    return false;
  }
  return now.getTime() >= bootStartedAt.getTime() + INTERRUPTED_PROCESSING_RECOVERY_GRACE_MS;
}
function shouldExpireInterruptedImmediateStatus(params) {
  if (!isInterruptedScheduledStatusProcessing({
    status: params.status,
    updatedAt: params.updatedAt,
    schedulerBootStartedAt: params.schedulerBootStartedAt
  })) {
    return false;
  }
  if (params.requestedAction !== "now") {
    return false;
  }
  const createdAt = toValidDate(params.createdAt);
  if (!createdAt) {
    return false;
  }
  const now = params.now || /* @__PURE__ */ new Date();
  return now.getTime() - createdAt.getTime() > getImmediateStatusRecoveryMaxAgeMs();
}
function buildInterruptedScheduledStatusMessage(now = /* @__PURE__ */ new Date()) {
  return `Envio interrompido por reinicio da aplicacao. Retomando automaticamente desde ${formatStatusBrazilTime(now)}.`;
}
function buildExpiredImmediateScheduledStatusMessage(now = /* @__PURE__ */ new Date()) {
  return `O envio imediato expirou apos uma interrupcao e nao sera retomado automaticamente desde ${formatStatusBrazilTime(now)}. Confirme o status novamente para publicar na hora certa.`;
}
function getScheduledStatusPresentation(params) {
  if (isInterruptedScheduledStatusProcessing({
    status: params.status,
    updatedAt: params.updatedAt,
    schedulerBootStartedAt: params.schedulerBootStartedAt
  })) {
    return {
      displayStatus: "retrying",
      statusDetail: params.errorMessage || "O aplicativo reiniciou durante esse envio. Vamos retomar automaticamente.",
      wasInterrupted: true
    };
  }
  return {
    displayStatus: params.status,
    statusDetail: params.errorMessage || null,
    wasInterrupted: false
  };
}

// server/statusPostingService.ts
import { and, asc, desc, eq, inArray, lte, or, isNull } from "drizzle-orm";

// server/statusPostingHelpers.ts
var STATUS_POST_KIND = "status-post";
var STATUS_JID = "status@broadcast";
function normalizeSelectedWeekdays(days) {
  const unique = /* @__PURE__ */ new Set();
  for (const value of days || []) {
    if (!Number.isInteger(value)) {
      continue;
    }
    const weekday = Number(value);
    if (weekday >= 0 && weekday <= 6) {
      unique.add(weekday);
    }
  }
  return Array.from(unique).sort((left, right) => left - right);
}
function normalizeStatusAudienceCandidate(value) {
  const normalized = normalizeWhatsAppIdentity(value);
  if (!normalized) {
    return null;
  }
  if (normalized === STATUS_JID || normalized.endsWith("@g.us") || normalized.endsWith("@broadcast") || normalized.endsWith("@newsletter") || normalized.endsWith("@bot")) {
    return null;
  }
  return normalized;
}
function buildAudiencePersonKey(value) {
  return extractIdentityPersonKey(value);
}
function isExplicitPersonalWhatsAppJid(value) {
  const rawValue = String(value || "").trim().toLowerCase();
  if (!rawValue.endsWith("@s.whatsapp.net") && !rawValue.endsWith("@c.us")) {
    return false;
  }
  return isPersonalWhatsAppJid(value);
}
function getAudienceCandidatePriority(source, rawValue, personSignals) {
  const normalized = normalizeStatusAudienceCandidate(rawValue);
  const isWhatsappPn = isPersonalWhatsAppJid(normalized);
  const isLid = isLidWhatsAppJid(normalized);
  if (source === "primary" && isWhatsappPn) {
    if (personSignals?.hasLidIdentity && !personSignals.hasExplicitPhoneJid) {
      const rawPhoneValue = String(rawValue || "").trim();
      const rawAtIndex = rawPhoneValue.indexOf("@");
      if (rawAtIndex >= 0 && rawPhoneValue.toLowerCase().endsWith("@s.whatsapp.net")) {
        return 1;
      }
    }
    return 4;
  }
  if (source === "primary" && isLid) {
    return 3;
  }
  if (source === "lid" && isLid) {
    return 2;
  }
  if (source === "phone") {
    return 1;
  }
  return 0;
}
function normalizeStatusAudienceCandidates(values) {
  const unique = /* @__PURE__ */ new Set();
  for (const value of values) {
    const normalized = normalizeStatusAudienceCandidate(value);
    if (normalized) {
      unique.add(normalized);
    }
  }
  return Array.from(unique);
}
function chunkStatusAudience(values, chunkSize) {
  const chunks = [];
  for (let index = 0; index < values.length; index += chunkSize) {
    chunks.push(values.slice(index, index + chunkSize));
  }
  return chunks;
}
async function resolveReachableStatusJidList(socket, statusJidList2) {
  const normalizedAudience = normalizeStatusAudienceCandidates(statusJidList2);
  if (!socket?.onWhatsApp) {
    return normalizedAudience;
  }
  const lidAudience = [];
  const phoneAudience = [];
  for (const jid of normalizedAudience) {
    if (isLidWhatsAppJid(jid)) {
      lidAudience.push(jid);
      continue;
    }
    if (isPersonalWhatsAppJid(jid)) {
      phoneAudience.push(jid);
    }
  }
  if (phoneAudience.length === 0) {
    return normalizedAudience;
  }
  const validatedAudience = new Set(lidAudience);
  for (const chunk of chunkStatusAudience(phoneAudience, 250)) {
    const results = await socket.onWhatsApp(...chunk);
    for (const entry of results || []) {
      if (!entry?.exists) {
        continue;
      }
      const normalizedJid = normalizeStatusAudienceCandidate(entry.jid);
      if (normalizedJid && isPersonalWhatsAppJid(normalizedJid)) {
        validatedAudience.add(normalizedJid);
      }
    }
  }
  return Array.from(validatedAudience);
}
function buildStatusAudienceCandidates(entries) {
  const personSignals = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const personKey = buildAudiencePersonKey(entry.primaryId) || buildAudiencePersonKey(entry.lid) || buildAudiencePersonKey(entry.phoneNumber);
    if (!personKey) {
      continue;
    }
    const current = personSignals.get(personKey) || {
      hasLidIdentity: false,
      hasExplicitPhoneJid: false
    };
    if (isLidWhatsAppJid(entry.primaryId) || isLidWhatsAppJid(entry.lid)) {
      current.hasLidIdentity = true;
    }
    if (isExplicitPersonalWhatsAppJid(entry.phoneNumber)) {
      current.hasExplicitPhoneJid = true;
    }
    personSignals.set(personKey, current);
  }
  const personMap = /* @__PURE__ */ new Map();
  for (const entry of entries) {
    const primaryId = String(entry.primaryId || "").trim();
    const lid = String(entry.lid || "").trim();
    const phoneNumber = String(entry.phoneNumber || "").trim();
    const normalizedPrimary = normalizeStatusAudienceCandidate(primaryId);
    const normalizedLid = normalizeStatusAudienceCandidate(lid);
    const normalizedPhone = normalizeStatusAudienceCandidate(phoneNumber);
    const personKey = buildAudiencePersonKey(primaryId) || buildAudiencePersonKey(lid) || buildAudiencePersonKey(phoneNumber);
    if (!personKey) {
      continue;
    }
    const candidates = [
      {
        value: normalizedPrimary,
        priority: getAudienceCandidatePriority(
          "primary",
          primaryId,
          personSignals.get(personKey)
        )
      },
      {
        value: normalizedLid,
        priority: getAudienceCandidatePriority(
          "lid",
          lid,
          personSignals.get(personKey)
        )
      },
      {
        value: normalizedPhone,
        priority: getAudienceCandidatePriority(
          "phone",
          phoneNumber,
          personSignals.get(personKey)
        )
      }
    ];
    for (const candidate of candidates) {
      if (!candidate.value || candidate.priority <= 0) {
        continue;
      }
      const existing = personMap.get(personKey);
      if (!existing || candidate.priority > existing.priority) {
        personMap.set(personKey, {
          candidate: candidate.value,
          priority: candidate.priority
        });
      }
    }
  }
  return Array.from(personMap.values()).map((entry) => entry.candidate);
}
function normalizeStatusPrivacyValue(rawValue) {
  const value = String(rawValue || "").trim().toLowerCase();
  if (value === "all" || value === "contacts" || value === "contact_blacklist" || value === "none") {
    return value;
  }
  return null;
}
function describeStatusPrivacyValue(value) {
  if (value === "all") {
    return "todos";
  }
  if (value === "contacts") {
    return "meus contatos";
  }
  if (value === "contact_blacklist") {
    return "meus contatos, exceto alguns";
  }
  if (value === "none") {
    return "lista restrita";
  }
  return "privacidade desconhecida";
}
function normalizeStatusPostPayload(payload) {
  return {
    kind: STATUS_POST_KIND,
    version: 2,
    connectionId: String(payload.connectionId || "").trim() || null,
    contentType: payload.contentType || "text",
    text: String(payload.text || "").trim(),
    caption: String(payload.caption || "").trim() || null,
    mediaUrl: String(payload.mediaUrl || "").trim() || null,
    mimeType: String(payload.mimeType || "").trim() || null,
    fileName: String(payload.fileName || "").trim() || null,
    storagePath: String(payload.storagePath || "").trim() || null,
    selectedWeekdays: normalizeSelectedWeekdays(payload.selectedWeekdays),
    aiVariationEnabled: Boolean(payload.aiVariationEnabled),
    aiVariationPrompt: String(payload.aiVariationPrompt || "").trim() || null,
    requestedAction: payload.requestedAction === "now" || payload.requestedAction === "daily" || payload.requestedAction === "weekdays" || payload.requestedAction === "schedule" ? payload.requestedAction : null,
    sendRetryCount: Math.max(0, Number(payload.sendRetryCount || 0))
  };
}
function serializeStatusPostPayload(payload) {
  return JSON.stringify(normalizeStatusPostPayload(payload));
}
function parseStatusPostPayload(rawValue) {
  if (!rawValue) {
    return normalizeStatusPostPayload({ contentType: "text", text: "" });
  }
  try {
    const parsed = JSON.parse(rawValue);
    if (parsed?.kind === STATUS_POST_KIND) {
      return normalizeStatusPostPayload(parsed);
    }
  } catch {
  }
  return normalizeStatusPostPayload({ contentType: "text", text: rawValue });
}
async function resolveMediaBuffer(mediaUrl) {
  const response = await fetch(mediaUrl);
  if (!response.ok) {
    throw new Error(`Falha ao baixar a midia (${response.status})`);
  }
  const arrayBuffer = await response.arrayBuffer();
  return {
    buffer: Buffer.from(arrayBuffer),
    mimeType: response.headers.get("content-type") || "application/octet-stream"
  };
}
async function buildStatusMessageContent(payload) {
  const caption = payload.caption || payload.text || void 0;
  if (payload.contentType === "text") {
    const text = String(payload.text || "").trim();
    if (!text) {
      throw new Error("Digite o texto do status");
    }
    return { text };
  }
  const mediaUrl = String(payload.mediaUrl || "").trim();
  if (!mediaUrl) {
    throw new Error("Midia ausente para o status");
  }
  const media = await resolveMediaBuffer(mediaUrl);
  const mimeType = payload.mimeType || media.mimeType;
  if (payload.contentType === "image") {
    return {
      image: media.buffer,
      mimetype: mimeType || "image/png",
      caption
    };
  }
  if (payload.contentType === "video") {
    return {
      video: media.buffer,
      mimetype: mimeType || "video/mp4",
      caption
    };
  }
  return {
    audio: media.buffer,
    mimetype: mimeType || "audio/ogg; codecs=opus",
    ptt: false
  };
}
async function sendStatusPostToSocket(socket, payload, statusJidList2) {
  if (statusJidList2.length === 0) {
    throw new Error("Nenhum contato sincronizado para receber o status");
  }
  const reachableAudience = await resolveReachableStatusJidList(
    socket,
    statusJidList2
  );
  if (reachableAudience.length === 0) {
    throw new Error("Nenhum contato v\xE1lido para receber o status");
  }
  const content = await buildStatusMessageContent(payload);
  return socket.sendMessage(STATUS_JID, content, {
    broadcast: true,
    statusJidList: reachableAudience,
    useUserDevicesCache: false
  });
}

// server/statusPublishJobState.ts
var RETRY_DELAY_MINUTES = 15;
function addMinutes(date, minutes) {
  return new Date(date.getTime() + minutes * 60 * 1e3);
}
function getStatusJobFailureState(params) {
  if (params.recurrenceType === "once") {
    return {
      lastError: params.errorMessage,
      nextRunAt: null,
      status: "failed",
      isActive: false,
      updatedAt: params.now
    };
  }
  return {
    lastError: params.errorMessage,
    nextRunAt: addMinutes(params.now, RETRY_DELAY_MINUTES),
    status: "active",
    isActive: true,
    updatedAt: params.now
  };
}

// server/statusPostingService.ts
var STATUS_JID2 = "status@broadcast";
var SAO_PAULO_OFFSET_MS = -3 * 60 * 60 * 1e3;
var ROTATION_DEFAULT_INTERVAL_MINUTES = 1440;
var RETRY_DELAY_MINUTES2 = 15;
async function resolveStatusGatewayCandidate(userId, preferredConnectionId) {
  const userConnections = await db.select().from(whatsappConnections).where(eq(whatsappConnections.userId, userId)).orderBy(
    desc(whatsappConnections.isPrimary),
    asc(whatsappConnections.createdAt)
  );
  if (preferredConnectionId) {
    const specific = userConnections.find(
      (connection) => connection.id === preferredConnectionId
    );
    if (!specific) {
      throw new Error("Conex\xE3o informada n\xE3o pertence ao usu\xE1rio");
    }
    return specific;
  }
  return userConnections.find((connection) => connection.isConnected === true) || null;
}
var STATUS_POST_KIND2 = "status-post";
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function normalizeSelectedWeekdays2(days) {
  const unique = /* @__PURE__ */ new Set();
  for (const value of days || []) {
    if (!Number.isInteger(value)) {
      continue;
    }
    const weekday = Number(value);
    if (weekday >= 0 && weekday <= 6) {
      unique.add(weekday);
    }
  }
  return Array.from(unique).sort((left, right) => left - right);
}
function normalizeStatusPostPayload2(payload) {
  const contentType = payload.contentType || "text";
  return {
    kind: STATUS_POST_KIND2,
    version: 2,
    connectionId: String(payload.connectionId || "").trim() || null,
    contentType,
    text: payload.text?.trim() || "",
    caption: payload.caption?.trim() || null,
    mediaUrl: payload.mediaUrl || null,
    mimeType: payload.mimeType || null,
    fileName: payload.fileName || null,
    storagePath: payload.storagePath || null,
    selectedWeekdays: normalizeSelectedWeekdays2(payload.selectedWeekdays),
    aiVariationEnabled: Boolean(payload.aiVariationEnabled),
    aiVariationPrompt: payload.aiVariationPrompt?.trim() || null,
    requestedAction: payload.requestedAction === "now" || payload.requestedAction === "daily" || payload.requestedAction === "weekdays" || payload.requestedAction === "schedule" ? payload.requestedAction : null,
    sendRetryCount: Math.max(0, Number(payload.sendRetryCount || 0))
  };
}
function serializeStatusPostPayload2(payload) {
  return JSON.stringify(normalizeStatusPostPayload2(payload));
}
function parseStatusPostPayload2(rawValue) {
  if (!rawValue) {
    return normalizeStatusPostPayload2({ contentType: "text", text: "" });
  }
  try {
    const parsed = JSON.parse(rawValue);
    if (parsed && parsed.kind === STATUS_POST_KIND2) {
      return normalizeStatusPostPayload2(parsed);
    }
  } catch {
  }
  return normalizeStatusPostPayload2({ contentType: "text", text: rawValue });
}
function getStatusPostSummary(payload) {
  if (payload.contentType === "text") {
    return payload.text || "Texto";
  }
  return payload.caption || payload.fileName || payload.mediaUrl || "Midia";
}
function stripWrappingQuotes(value) {
  const trimmed = value.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1).trim();
  }
  return trimmed;
}
async function buildPayloadForSend(payload) {
  if (!payload.aiVariationEnabled || payload.contentType !== "text") {
    return payload;
  }
  const sourceText = String(
    payload.contentType === "text" ? payload.text : payload.caption || payload.text || ""
  ).trim();
  if (!sourceText) {
    return payload;
  }
  try {
    const weekdayLabel = new Intl.DateTimeFormat("pt-BR", {
      weekday: "long",
      timeZone: "America/Sao_Paulo"
    }).format(/* @__PURE__ */ new Date());
    const systemPrompt = [
      "Voce cria variacoes curtas para status de WhatsApp.",
      "Mantenha a intencao comercial da mensagem original.",
      "Escreva em portugues do Brasil.",
      "Nao use aspas, hashtags, listas ou explicacoes.",
      "Entregue apenas a versao final pronta para postar."
    ].join(" ");
    const userPrompt = [
      `Mensagem base: ${sourceText}`,
      payload.aiVariationPrompt ? `Instrucao extra: ${payload.aiVariationPrompt}` : "",
      `Crie uma nova versao para postar hoje (${weekdayLabel}) sem repetir exatamente a mensagem base.`
    ].filter(Boolean).join("\n");
    const generatedText = stripWrappingQuotes(
      await generateWithLLM(systemPrompt, userPrompt, {
        maxTokens: 220,
        temperature: 0.9
      })
    );
    if (!generatedText) {
      return payload;
    }
    if (payload.contentType === "text") {
      return {
        ...payload,
        text: generatedText
      };
    }
    return {
      ...payload,
      caption: generatedText
    };
  } catch (error) {
    console.warn(
      "[STATUS POSTS] Failed to generate AI variation:",
      error?.message || error
    );
    return payload;
  }
}
function toPseudoSaoPauloDate(date) {
  return new Date(date.getTime() + SAO_PAULO_OFFSET_MS);
}
function fromSaoPauloParts(year, month, day, hour = 0, minute = 0, second = 0) {
  return new Date(
    Date.UTC(year, month - 1, day, hour, minute, second) - SAO_PAULO_OFFSET_MS
  );
}
function getSaoPauloParts(date) {
  const pseudo = toPseudoSaoPauloDate(date);
  return {
    year: pseudo.getUTCFullYear(),
    month: pseudo.getUTCMonth() + 1,
    day: pseudo.getUTCDate(),
    hour: pseudo.getUTCHours(),
    minute: pseudo.getUTCMinutes(),
    weekday: pseudo.getUTCDay()
  };
}
function parseTimeOfDay(value) {
  const safe = String(value || "09:00");
  const [hourRaw, minuteRaw] = safe.split(":");
  return {
    hour: Math.max(0, Math.min(23, Number(hourRaw || 0))),
    minute: Math.max(0, Math.min(59, Number(minuteRaw || 0)))
  };
}
function getLastDayOfMonth(year, month) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}
function normalizeDaysOfWeek(daysOfWeek, fallback) {
  const normalized = Array.from(
    new Set((daysOfWeek || []).filter((day) => day >= 0 && day <= 6))
  ).sort();
  if (normalized.length > 0) {
    return normalized;
  }
  return typeof fallback === "number" ? [fallback] : [];
}
function computeNextRunAt(params) {
  const now = params.now || /* @__PURE__ */ new Date();
  const recurrenceType = params.recurrenceType || "once";
  if (recurrenceType === "once") {
    return params.scheduledFor || null;
  }
  const time = parseTimeOfDay(params.timeOfDay);
  const currentParts = getSaoPauloParts(now);
  if (recurrenceType === "daily") {
    let candidate = fromSaoPauloParts(
      currentParts.year,
      currentParts.month,
      currentParts.day,
      time.hour,
      time.minute
    );
    if (candidate <= now) {
      const pseudo = toPseudoSaoPauloDate(now);
      pseudo.setUTCDate(pseudo.getUTCDate() + 1);
      candidate = fromSaoPauloParts(
        pseudo.getUTCFullYear(),
        pseudo.getUTCMonth() + 1,
        pseudo.getUTCDate(),
        time.hour,
        time.minute
      );
    }
    return candidate;
  }
  if (recurrenceType === "weekdays" || recurrenceType === "weekly") {
    const baseWeekday = params.scheduledFor ? getSaoPauloParts(params.scheduledFor).weekday : currentParts.weekday;
    const allowedDays = normalizeDaysOfWeek(
      params.daysOfWeek,
      recurrenceType === "weekly" ? baseWeekday : void 0
    );
    for (let offset = 0; offset <= 14; offset += 1) {
      const pseudo = toPseudoSaoPauloDate(now);
      pseudo.setUTCDate(pseudo.getUTCDate() + offset);
      const weekday = pseudo.getUTCDay();
      if (allowedDays.length > 0 && !allowedDays.includes(weekday)) {
        continue;
      }
      const candidate = fromSaoPauloParts(
        pseudo.getUTCFullYear(),
        pseudo.getUTCMonth() + 1,
        pseudo.getUTCDate(),
        time.hour,
        time.minute
      );
      if (candidate > now) {
        return candidate;
      }
    }
    return null;
  }
  if (recurrenceType === "monthly") {
    const baseDay = params.dayOfMonth || (params.scheduledFor ? getSaoPauloParts(params.scheduledFor).day : currentParts.day);
    let year = currentParts.year;
    let month = currentParts.month;
    for (let attempt = 0; attempt < 24; attempt += 1) {
      const safeDay = Math.min(baseDay, getLastDayOfMonth(year, month));
      const candidate = fromSaoPauloParts(
        year,
        month,
        safeDay,
        time.hour,
        time.minute
      );
      if (candidate > now) {
        return candidate;
      }
      month += 1;
      if (month > 12) {
        month = 1;
        year += 1;
      }
    }
  }
  return null;
}
function addMinutes2(date, minutes) {
  return new Date(date.getTime() + minutes * 60 * 1e3);
}
function getPreviewText(item) {
  const raw = item.type === "text" ? item.text : item.caption || item.text;
  const trimmed = String(raw || "").trim();
  if (!trimmed) {
    return item.type === "text" ? "[Texto]" : `[${item.type}]`;
  }
  return trimmed.slice(0, 200);
}
async function resolveMediaBuffer2(storageUrl) {
  if (/^data:/i.test(storageUrl)) {
    const match = storageUrl.match(/^data:([^;]+);base64,(.+)$/);
    if (!match) {
      throw new Error("Data URL inv\xE1lida");
    }
    return {
      mimeType: match[1],
      buffer: Buffer.from(match[2], "base64")
    };
  }
  const response = await fetch(storageUrl);
  if (!response.ok) {
    throw new Error(`Falha ao baixar m\xEDdia (${response.status})`);
  }
  const arrayBuffer = await response.arrayBuffer();
  return {
    mimeType: response.headers.get("content-type") || "application/octet-stream",
    buffer: Buffer.from(arrayBuffer)
  };
}
async function buildStatusPayload(item) {
  if (item.type === "text") {
    const text = String(item.text || "").trim();
    if (!text) {
      throw new Error("Digite o texto do status");
    }
    return { text };
  }
  const storageUrl = String(item.storageUrl || "").trim();
  if (!storageUrl) {
    throw new Error("M\xEDdia ausente para envio do status");
  }
  const media = await resolveMediaBuffer2(storageUrl);
  const caption = String(item.caption || "").trim() || void 0;
  const mimeType = item.mimeType || media.mimeType;
  if (item.type === "image") {
    return { image: media.buffer, mimetype: mimeType || "image/jpeg", caption };
  }
  if (item.type === "video") {
    return { video: media.buffer, mimetype: mimeType || "video/mp4", caption };
  }
  if (item.type === "audio") {
    return {
      audio: media.buffer,
      mimetype: mimeType || "audio/ogg; codecs=opus",
      ptt: false
    };
  }
  throw new Error(`Tipo de item n\xE3o suportado: ${item.type}`);
}
async function resolveStatusSocket(userId, preferredConnectionId) {
  const userConnections = await db.select().from(whatsappConnections).where(eq(whatsappConnections.userId, userId)).orderBy(
    desc(whatsappConnections.isPrimary),
    asc(whatsappConnections.createdAt)
  );
  if (preferredConnectionId) {
    const specific = userConnections.find(
      (connection) => connection.id === preferredConnectionId
    );
    if (!specific) {
      throw new Error("Conex\xE3o informada n\xE3o pertence ao usu\xE1rio");
    }
    const session = await ensureUserSessionOperational(userId, specific.id, {
      source: "status_publish_preferred",
      waitMs: 3e3
    });
    if (!session?.socket || specific.isConnected !== true) {
      throw new Error("WhatsApp n\xE3o conectado na conex\xE3o selecionada");
    }
    return { connectionId: specific.id, session, socket: session.socket };
  }
  const activeConnections = userConnections.filter(
    (connection) => connection.isConnected === true
  );
  if (activeConnections.length === 0) {
    throw new Error("WhatsApp n\xE3o conectado");
  }
  for (const connection of activeConnections) {
    const session = await ensureUserSessionOperational(userId, connection.id, {
      source: connection.isPrimary ? "status_publish_primary" : "status_publish_fallback",
      waitMs: connection.isPrimary ? 3e3 : 1500,
      allowPersistedAuthRecovery: false
    });
    if (session?.socket) {
      return { connectionId: connection.id, session, socket: session.socket };
    }
  }
  if (activeConnections.length === 1) {
    throw new Error("WhatsApp n\xE3o conectado");
  }
  throw new Error(
    "Nenhuma conex\xE3o operacional dispon\xEDvel para publicar o status"
  );
}
async function resolveStatusAudience(userId, connectionId, session) {
  const [connection] = await db.select({
    id: whatsappConnections.id
  }).from(whatsappConnections).where(
    and(
      eq(whatsappConnections.userId, userId),
      eq(whatsappConnections.id, connectionId)
    )
  ).limit(1);
  if (!connection) {
    return {
      statusJidList: [],
      audienceCount: 0,
      audienceSource: "none",
      statusPrivacy: null,
      statusPrivacyLabel: null
    };
  }
  const dbAudience = await db.select({
    phoneNumber: whatsappContacts.phoneNumber,
    contactId: whatsappContacts.contactId,
    lid: whatsappContacts.lid
  }).from(whatsappContacts).where(eq(whatsappContacts.connectionId, connection.id));
  const sessionAudience = session.contactsCache ? Array.from(session.contactsCache.values()) : [];
  const savedContactsAudience = buildStatusAudienceCandidates(
    dbAudience.map((contact) => ({
      phoneNumber: contact.phoneNumber,
      primaryId: contact.contactId,
      lid: contact.lid
    }))
  );
  if (savedContactsAudience.length > 0) {
    return {
      statusJidList: savedContactsAudience,
      audienceCount: savedContactsAudience.length,
      audienceSource: "saved_contacts",
      statusPrivacy: null,
      statusPrivacyLabel: null
    };
  }
  const sessionContactsAudience = buildStatusAudienceCandidates(
    sessionAudience.map((contact) => ({
      phoneNumber: contact.phoneNumber,
      primaryId: contact.id,
      lid: contact.lid
    }))
  );
  if (sessionContactsAudience.length > 0) {
    return {
      statusJidList: sessionContactsAudience,
      audienceCount: sessionContactsAudience.length,
      audienceSource: "session_contacts",
      statusPrivacy: null,
      statusPrivacyLabel: null
    };
  }
  return {
    statusJidList: [],
    audienceCount: 0,
    audienceSource: "none",
    statusPrivacy: null,
    statusPrivacyLabel: null
  };
}
async function resolveStatusPrivacyDiagnostics(socket) {
  if (!socket?.fetchPrivacySettings) {
    return {
      statusPrivacy: null,
      statusPrivacyLabel: null
    };
  }
  try {
    const privacySettings = await socket.fetchPrivacySettings();
    const statusPrivacy = normalizeStatusPrivacyValue(privacySettings?.status);
    return {
      statusPrivacy,
      statusPrivacyLabel: statusPrivacy ? describeStatusPrivacyValue(statusPrivacy) : null
    };
  } catch (error) {
    console.warn(
      "[STATUS POSTS] Failed to read status privacy settings:",
      error
    );
    return {
      statusPrivacy: null,
      statusPrivacyLabel: null
    };
  }
}
async function previewStatusAudienceForUser(userId, preferredConnectionId) {
  const candidate = await resolveStatusGatewayCandidate(
    userId,
    preferredConnectionId
  );
  if (candidate) {
    const owner = await resolveAppVisibleConnectionOwner(candidate);
    if (owner === "gateway" && !isWhatsAppGatewayRuntime()) {
      return previewGatewayStatusAudience(candidate.id);
    }
  }
  let resolved;
  try {
    resolved = await resolveStatusSocket(userId, preferredConnectionId);
  } catch {
    return {
      audienceCount: 0,
      connectionId: null,
      isConnected: false,
      audienceSource: "none",
      statusPrivacy: null,
      statusPrivacyLabel: null
    };
  }
  const [audience, privacy] = await Promise.all([
    resolveStatusAudience(userId, resolved.connectionId, resolved.session),
    resolveStatusPrivacyDiagnostics(resolved.socket)
  ]);
  return {
    audienceCount: audience.audienceCount,
    connectionId: resolved.connectionId,
    isConnected: true,
    audienceSource: audience.audienceSource,
    statusPrivacy: privacy.statusPrivacy,
    statusPrivacyLabel: privacy.statusPrivacyLabel
  };
}
async function getPostWithItems(userId, postId) {
  const [post] = await db.select().from(statusPosts).where(and(eq(statusPosts.id, postId), eq(statusPosts.userId, userId))).limit(1);
  if (!post) {
    throw new Error("Postagem n\xE3o encontrada");
  }
  const items = await db.select().from(statusPostItems).where(
    and(
      eq(statusPostItems.postId, postId),
      eq(statusPostItems.isActive, true)
    )
  ).orderBy(asc(statusPostItems.displayOrder), asc(statusPostItems.createdAt));
  if (items.length === 0) {
    throw new Error("A postagem n\xE3o possui itens ativos");
  }
  return { post, items };
}
async function publishStatusPost(params) {
  const { post, items } = await getPostWithItems(params.userId, params.postId);
  const [run] = await db.insert(statusPublishRuns).values({
    userId: params.userId,
    postId: params.postId,
    jobId: params.jobId || null,
    rotationId: params.rotationId || null,
    connectionId: params.connectionId || post.connectionId || null,
    runType: params.runType,
    triggeredBy: params.triggeredBy || "system",
    status: "running",
    startedAt: /* @__PURE__ */ new Date()
  }).returning();
  let resolved;
  try {
    resolved = await resolveStatusSocket(
      params.userId,
      params.connectionId || post.connectionId
    );
  } catch (error) {
    await db.update(statusPublishRuns).set({
      status: "failed",
      errorMessage: error?.message || "Falha ao localizar conex\xE3o do WhatsApp",
      completedAt: /* @__PURE__ */ new Date(),
      connectionId: params.connectionId || post.connectionId || null
    }).where(eq(statusPublishRuns.id, run.id));
    throw error;
  }
  let failed = false;
  let lastError = null;
  const audience = await resolveStatusAudience(
    params.userId,
    resolved.connectionId,
    resolved.session
  );
  if (audience.statusJidList.length === 0) {
    await db.update(statusPublishRuns).set({
      status: "failed",
      errorMessage: "Nenhum contato sincronizado para receber o status",
      completedAt: /* @__PURE__ */ new Date(),
      connectionId: resolved.connectionId
    }).where(eq(statusPublishRuns.id, run.id));
    throw new Error("Nenhum contato sincronizado para receber o status");
  }
  for (const item of items) {
    const [runItem] = await db.insert(statusPublishRunItems).values({
      runId: run.id,
      postItemId: item.id,
      displayOrder: item.displayOrder,
      type: item.type,
      textPreview: getPreviewText(item),
      storageUrl: item.storageUrl || null,
      caption: item.caption || null,
      status: "pending"
    }).returning();
    try {
      const payload = await buildStatusPayload(item);
      await messageQueueService.executeWithDelay(
        params.userId,
        `status ${item.type}`,
        async () => {
          return await resolved.socket.sendMessage(STATUS_JID2, payload, {
            broadcast: true,
            statusJidList: audience.statusJidList
          });
        }
      );
      await db.update(statusPublishRunItems).set({
        status: "sent",
        sentAt: /* @__PURE__ */ new Date(),
        errorMessage: null
      }).where(eq(statusPublishRunItems.id, runItem.id));
      await sleep(5e3);
    } catch (error) {
      failed = true;
      lastError = error?.message || "Falha ao publicar item do status";
      await db.update(statusPublishRunItems).set({
        status: "failed",
        errorMessage: lastError
      }).where(eq(statusPublishRunItems.id, runItem.id));
      break;
    }
  }
  await db.update(statusPublishRuns).set({
    status: failed ? "partial_failed" : "sent",
    errorMessage: lastError,
    completedAt: /* @__PURE__ */ new Date(),
    connectionId: resolved.connectionId
  }).where(eq(statusPublishRuns.id, run.id));
  if (failed) {
    throw new Error(lastError || "Falha ao publicar status");
  }
  return {
    ...run,
    audienceCount: statusJidList.length,
    connectionId: resolved.connectionId,
    status: failed ? "partial_failed" : "sent"
  };
}
async function processStatusPublishJobs() {
  const now = /* @__PURE__ */ new Date();
  const jobs = await db.select().from(statusPublishJobs).where(
    and(
      eq(statusPublishJobs.isActive, true),
      eq(statusPublishJobs.status, "active"),
      or(
        isNull(statusPublishJobs.nextRunAt),
        lte(statusPublishJobs.nextRunAt, now)
      )
    )
  ).orderBy(
    asc(statusPublishJobs.nextRunAt),
    asc(statusPublishJobs.createdAt)
  );
  for (const job of jobs) {
    try {
      await publishStatusPost({
        userId: job.userId,
        postId: job.postId,
        connectionId: job.connectionId,
        jobId: job.id,
        runType: "job",
        triggeredBy: "scheduler"
      });
      const nextRunAt = computeNextRunAt({
        recurrenceType: job.recurrenceType,
        scheduledFor: job.scheduledFor,
        timeOfDay: job.timeOfDay,
        daysOfWeek: job.daysOfWeek,
        dayOfMonth: job.dayOfMonth,
        now: addMinutes2(now, 1)
      });
      await db.update(statusPublishJobs).set({
        lastRunAt: now,
        nextRunAt,
        lastError: null,
        status: nextRunAt ? "active" : "completed",
        isActive: !!nextRunAt,
        updatedAt: now
      }).where(eq(statusPublishJobs.id, job.id));
    } catch (error) {
      await db.update(statusPublishJobs).set(
        getStatusJobFailureState({
          recurrenceType: job.recurrenceType,
          now,
          errorMessage: error?.message || "Falha ao publicar status agendado"
        })
      ).where(eq(statusPublishJobs.id, job.id));
    }
  }
}
function pickRotationPost(items, selectionMode, lastPostId) {
  if (items.length === 0) {
    throw new Error("Nenhuma postagem configurada na rota\xE7\xE3o");
  }
  if (selectionMode === "random") {
    const pool2 = items.length > 1 ? items.filter((item) => item.id !== lastPostId) : items;
    const total = pool2.reduce(
      (acc, item) => acc + Math.max(1, item.weight || 1),
      0
    );
    let random = Math.random() * total;
    for (const item of pool2) {
      random -= Math.max(1, item.weight || 1);
      if (random <= 0) {
        return item;
      }
    }
    return pool2[0];
  }
  if (!lastPostId) {
    return items[0];
  }
  const index = items.findIndex((item) => item.id === lastPostId);
  if (index === -1) {
    return items[0];
  }
  return items[(index + 1) % items.length];
}
async function processStatusRotations() {
  const now = /* @__PURE__ */ new Date();
  const rotations = await db.select().from(statusRotations).where(
    and(
      eq(statusRotations.isActive, true),
      or(
        isNull(statusRotations.nextRunAt),
        lte(statusRotations.nextRunAt, now)
      )
    )
  ).orderBy(asc(statusRotations.nextRunAt), asc(statusRotations.createdAt));
  for (const rotation of rotations) {
    const items = await db.select().from(statusRotationPosts).where(
      and(
        eq(statusRotationPosts.rotationId, rotation.id),
        eq(statusRotationPosts.isActive, true)
      )
    ).orderBy(
      asc(statusRotationPosts.displayOrder),
      asc(statusRotationPosts.createdAt)
    );
    if (items.length === 0) {
      await db.update(statusRotations).set({
        lastError: "Nenhuma postagem ativa configurada na rota\xE7\xE3o",
        nextRunAt: addMinutes2(now, RETRY_DELAY_MINUTES2),
        updatedAt: now
      }).where(eq(statusRotations.id, rotation.id));
      continue;
    }
    try {
      const selected = pickRotationPost(
        items.map((item) => ({ id: item.postId, weight: item.weight })),
        rotation.selectionMode,
        rotation.lastPostId
      );
      await publishStatusPost({
        userId: rotation.userId,
        postId: selected.id,
        connectionId: rotation.connectionId,
        rotationId: rotation.id,
        runType: "rotation",
        triggeredBy: "rotation"
      });
      await db.update(statusRotations).set({
        lastPostId: selected.id,
        lastRunAt: now,
        nextRunAt: addMinutes2(
          now,
          Math.max(
            5,
            rotation.intervalMinutes || ROTATION_DEFAULT_INTERVAL_MINUTES
          )
        ),
        lastError: null,
        updatedAt: now
      }).where(eq(statusRotations.id, rotation.id));
      await db.update(statusRotationPosts).set({
        lastPublishedAt: now,
        updatedAt: now
      }).where(
        and(
          eq(statusRotationPosts.rotationId, rotation.id),
          eq(statusRotationPosts.postId, selected.id)
        )
      );
    } catch (error) {
      await db.update(statusRotations).set({
        lastError: error?.message || "Falha ao executar rota\xE7\xE3o de status",
        nextRunAt: addMinutes2(now, RETRY_DELAY_MINUTES2),
        updatedAt: now
      }).where(eq(statusRotations.id, rotation.id));
    }
  }
}
async function sendStatusPostForUser(userId, payload, options) {
  const candidate = await resolveStatusGatewayCandidate(
    userId,
    options?.preferredConnectionId
  );
  if (candidate) {
    const owner = await resolveAppVisibleConnectionOwner(candidate);
    if (owner === "gateway" && !isWhatsAppGatewayRuntime()) {
      return sendGatewayStatusPost(candidate.id, payload);
    }
  }
  const resolved = await resolveStatusSocket(
    userId,
    options?.preferredConnectionId
  );
  const [audience, privacy] = await Promise.all([
    resolveStatusAudience(userId, resolved.connectionId, resolved.session),
    resolveStatusPrivacyDiagnostics(resolved.socket)
  ]);
  if (audience.statusJidList.length === 0) {
    throw new Error("Nenhum contato sincronizado para receber o status");
  }
  const resolvedPayload = await buildPayloadForSend(payload);
  const timeoutMs = getStatusSendTimeoutMs();
  console.log(
    `[STATUS POSTS] Sending status for ${userId.slice(0, 8)}... conn=${resolved.connectionId.slice(0, 8)} audience=${audience.audienceCount} source=${audience.audienceSource} privacy=${privacy.statusPrivacy || "unknown"} timeoutMs=${timeoutMs}`
  );
  const result = await withStatusSendTimeout(
    messageQueueService.executeWithDelay(
      userId,
      "status post",
      async () => sendStatusPostToSocket(
        resolved.socket,
        resolvedPayload,
        audience.statusJidList
      ),
      { yieldQueue: true }
    ),
    timeoutMs
  );
  console.log(
    `[STATUS POSTS] Status send finished for ${userId.slice(0, 8)}... conn=${resolved.connectionId.slice(0, 8)} audience=${audience.audienceCount} source=${audience.audienceSource} privacy=${privacy.statusPrivacy || "unknown"}`
  );
  return {
    result,
    statusJidList: audience.statusJidList,
    audienceCount: audience.audienceCount,
    connectionId: resolved.connectionId,
    audienceSource: audience.audienceSource,
    statusPrivacy: privacy.statusPrivacy,
    statusPrivacyLabel: privacy.statusPrivacyLabel
  };
}

export {
  generateGatewayAccountToken,
  hashGatewayAccountToken,
  buildGatewayAccountTokenPreview,
  parseGatewayAccountToken,
  verifyGatewayAccountToken,
  serializeStatusPostPayload,
  parseStatusPostPayload,
  parseStatusBrazilDateTime,
  formatStatusBrazilTime,
  startOfStatusBrazilMinute,
  getStatusBrazilWeekday,
  addStatusBrazilDays,
  addStatusBrazilMonths,
  shouldRecoverInterruptedScheduledStatus,
  shouldExpireInterruptedImmediateStatus,
  buildInterruptedScheduledStatusMessage,
  buildExpiredImmediateScheduledStatusMessage,
  getScheduledStatusPresentation,
  serializeStatusPostPayload2,
  parseStatusPostPayload2,
  getStatusPostSummary,
  previewStatusAudienceForUser,
  processStatusPublishJobs,
  processStatusRotations,
  sendStatusPostForUser,
  ensureWhatsAppRuntimeSchema
};
