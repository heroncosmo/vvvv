// shared/mojibake.ts
var WINDOWS_1252_CODEPOINT_TO_BYTE = /* @__PURE__ */ new Map([
  [8364, 128],
  [8218, 130],
  [402, 131],
  [8222, 132],
  [8230, 133],
  [8224, 134],
  [8225, 135],
  [710, 136],
  [8240, 137],
  [352, 138],
  [8249, 139],
  [338, 140],
  [381, 142],
  [8216, 145],
  [8217, 146],
  [8220, 147],
  [8221, 148],
  [8226, 149],
  [8211, 150],
  [8212, 151],
  [732, 152],
  [8482, 153],
  [353, 154],
  [8250, 155],
  [339, 156],
  [382, 158],
  [376, 159]
]);
var SUSPICIOUS_FRAGMENTS = [
  "\xC3\u0192\xC2",
  "\xC3\u0192",
  "\xC3\xB0\xC5\xB8",
  "\xF0\u0178",
  "\xE2\u20AC",
  "\xE2\u2020",
  "\xEF\xBF\xBD",
  "\uFFFD",
  "\xC2\xA0",
  "\xC3\xA7",
  "\xC3\xA3",
  "\xC3\xA9",
  "\xC3\xAA",
  "\xC3\xA1",
  "\xC3\xAD",
  "\xC3\xB3",
  "\xC3\xBA",
  "\xC3\xB4",
  "\xC3\xB5",
  "\xC3 ",
  "\xC3\u2030",
  "\xC3\u201C",
  "\xC3\u0161"
];
var EXPLICIT_REPAIRS = [
  ["[\xEF\xBF\xBDudio enviado]", "[\xE1udio enviado]"],
  ["[\uFFFDudio enviado]", "[\xE1udio enviado]"],
  ["[Mensagem nao suportada:", "[Mensagem n\xE3o suportada:"],
  ["[mensagem nao suportada:", "[Mensagem n\xE3o suportada:"],
  ["[Mensagem nao suportada]", "[Mensagem n\xE3o suportada]"],
  ["[mensagem nao suportada]", "[Mensagem n\xE3o suportada]"],
  ["\xC2\xA0", " "],
  ["\xC3\xA0", "\xE0"],
  ["\xC3\xA1", "\xE1"],
  ["\xC3\xA2", "\xE2"],
  ["\xC3\xA3", "\xE3"],
  ["\xC3\xA7", "\xE7"],
  ["\xC3\xA8", "\xE8"],
  ["\xC3\xA9", "\xE9"],
  ["\xC3\xAA", "\xEA"],
  ["\xC3\xAD", "\xED"],
  ["\xC3\xB3", "\xF3"],
  ["\xC3\xB4", "\xF4"],
  ["\xC3\xB5", "\xF5"],
  ["\xC3\xBA", "\xFA"],
  ["\xC3\x80", "\xC0"],
  ["\xC3\x81", "\xC1"],
  ["\xC3\x82", "\xC2"],
  ["\xC3\x83", "\xC3"],
  ["\xC3\x87", "\xC7"],
  ["\xC3\x88", "\xC8"],
  ["\xC3\x89", "\xC9"],
  ["\xC3\x8A", "\xCA"],
  ["\xC3\x8D", "\xCD"],
  ["\xC3\x93", "\xD3"],
  ["\xC3\x94", "\xD4"],
  ["\xC3\x95", "\xD5"],
  ["\xC3\x9A", "\xDA"],
  ["\xE2\x80\x8B", ""],
  ["\xE2\x80\x8C", ""],
  ["\xE2\x80\x8D", ""],
  ["\xE2\u2020\u2019", "\u2192"]
];
function countOccurrences(value, fragment) {
  if (!fragment) {
    return 0;
  }
  let count = 0;
  let index = 0;
  while (index < value.length) {
    const nextIndex = value.indexOf(fragment, index);
    if (nextIndex === -1) {
      break;
    }
    count += 1;
    index = nextIndex + fragment.length;
  }
  return count;
}
function scoreLikelyMojibake(value) {
  if (!value) {
    return 0;
  }
  return SUSPICIOUS_FRAGMENTS.reduce(
    (total, fragment) => total + countOccurrences(value, fragment),
    0
  );
}
function applyExplicitRepairs(value) {
  let repaired = String(value || "");
  for (const [from, to] of EXPLICIT_REPAIRS) {
    repaired = repaired.split(from).join(to);
  }
  return repaired;
}
function decodeWindows1252Utf8(value) {
  const bytes = [];
  for (const char of value) {
    const codePoint = char.codePointAt(0);
    if (codePoint === void 0) {
      continue;
    }
    if (codePoint <= 255) {
      bytes.push(codePoint);
      continue;
    }
    const mappedByte = WINDOWS_1252_CODEPOINT_TO_BYTE.get(codePoint);
    if (mappedByte === void 0) {
      return null;
    }
    bytes.push(mappedByte);
  }
  return new TextDecoder("utf-8").decode(Uint8Array.from(bytes));
}
function isLikelyMojibake(value) {
  return scoreLikelyMojibake(String(value || "")) > 0;
}
function repairMojibakeToken(value, maxPasses = 3) {
  let best = applyExplicitRepairs(value);
  let bestScore = scoreLikelyMojibake(best);
  if (!best || bestScore === 0) {
    return best;
  }
  for (let round = 0; round < maxPasses; round += 1) {
    const decoded = decodeWindows1252Utf8(best);
    if (!decoded || decoded === best || decoded.includes("\uFFFD")) {
      break;
    }
    const cleaned = applyExplicitRepairs(decoded);
    const cleanedScore = scoreLikelyMojibake(cleaned);
    if (cleanedScore > bestScore) {
      break;
    }
    best = cleaned;
    bestScore = cleanedScore;
    if (bestScore === 0) {
      break;
    }
  }
  return best;
}
function repairMojibakeText(value, maxPasses = 3) {
  const original = applyExplicitRepairs(String(value || ""));
  if (!original || !isLikelyMojibake(original)) {
    return original;
  }
  return original.split(/(\s+)/).map((part) => /\s+/.test(part) ? part : repairMojibakeToken(part, maxPasses)).join("");
}
function repairMojibakeDeep(value) {
  if (typeof value === "string") {
    return repairMojibakeText(value);
  }
  if (Array.isArray(value)) {
    return value.map((item) => repairMojibakeDeep(item));
  }
  if (!value || typeof value !== "object" || value instanceof Date) {
    return value;
  }
  let changed = false;
  const repaired = {};
  for (const [key, entryValue] of Object.entries(value)) {
    const nextValue = repairMojibakeDeep(entryValue);
    repaired[key] = nextValue;
    if (nextValue !== entryValue) {
      changed = true;
    }
  }
  return changed ? repaired : value;
}

export {
  repairMojibakeText,
  repairMojibakeDeep
};
