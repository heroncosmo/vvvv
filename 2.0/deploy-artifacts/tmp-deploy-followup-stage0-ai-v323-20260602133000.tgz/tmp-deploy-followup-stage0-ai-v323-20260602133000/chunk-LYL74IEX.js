import {
  buildGatewayTextSendBody,
  centralizedMessageSender,
  normalizeOutboundTextForCustomer
} from "./chunk-GXAKLONY.js";
import {
  createSupabaseServiceClient,
  storage
} from "./chunk-7SPF5OKO.js";
import {
  buildWhatsAppJidFromPhone,
  normalizeBrazilWhatsAppPhone
} from "./chunk-YB77ZB3P.js";
import {
  db
} from "./chunk-R6CXRQMB.js";
import {
  messages,
  whatsappConnections
} from "./chunk-JC6URYU5.js";

// server/metaCloudApi.ts
import crypto2 from "crypto";
import { and, eq, gte, sql } from "drizzle-orm";

// server/messageDeduplicationService.ts
import crypto from "crypto";

// server/outgoingMessageSimilarity.ts
function stripDiacritics(value) {
  const normalized = value.normalize("NFD");
  let result = "";
  for (const char of normalized) {
    const code = char.codePointAt(0) || 0;
    const isCombiningMark = code >= 768 && code <= 879;
    if (!isCombiningMark) {
      result += char;
    }
  }
  return result;
}
function isAsciiLetterOrDigit(code) {
  return code >= 48 && code <= 57 || code >= 65 && code <= 90 || code >= 97 && code <= 122;
}
function tokenizeNormalizedMessage(value) {
  const tokens = [];
  let current = "";
  for (const char of value) {
    if (char === " ") {
      if (current) {
        tokens.push(current);
        current = "";
      }
      continue;
    }
    current += char;
  }
  if (current) {
    tokens.push(current);
  }
  return tokens;
}
function normalizeOutgoingMessageText(value) {
  const base = stripDiacritics(String(value || "")).toLowerCase();
  let result = "";
  let lastWasSpace = true;
  for (const char of base) {
    const code = char.codePointAt(0) || 0;
    if (isAsciiLetterOrDigit(code)) {
      result += char;
      lastWasSpace = false;
      continue;
    }
    if (!lastWasSpace) {
      result += " ";
      lastWasSpace = true;
    }
  }
  return result.trim();
}
function buildOutgoingMessageFingerprint(value) {
  return normalizeOutgoingMessageText(value);
}
function calculateOutgoingMessageSimilarity(left, right) {
  const leftFingerprint = buildOutgoingMessageFingerprint(left);
  const rightFingerprint = buildOutgoingMessageFingerprint(right);
  if (!leftFingerprint || !rightFingerprint) {
    return 0;
  }
  if (leftFingerprint === rightFingerprint) {
    return 1;
  }
  const shorter = leftFingerprint.length <= rightFingerprint.length ? leftFingerprint : rightFingerprint;
  const longer = leftFingerprint.length > rightFingerprint.length ? leftFingerprint : rightFingerprint;
  if (shorter.length >= 24 && longer.includes(shorter)) {
    return 0.96;
  }
  const leftTokens = tokenizeNormalizedMessage(leftFingerprint);
  const rightTokens = tokenizeNormalizedMessage(rightFingerprint);
  if (leftTokens.length === 0 || rightTokens.length === 0) {
    return 0;
  }
  const rightTokenSet = new Set(rightTokens);
  let matches = 0;
  for (const token of new Set(leftTokens)) {
    if (rightTokenSet.has(token)) {
      matches += 1;
    }
  }
  const overlap = matches / Math.max(new Set(leftTokens).size, rightTokenSet.size);
  let prefixMatches = 0;
  const prefixLimit = Math.min(leftTokens.length, rightTokens.length, 8);
  while (prefixMatches < prefixLimit && leftTokens[prefixMatches] === rightTokens[prefixMatches]) {
    prefixMatches += 1;
  }
  const prefixScore = prefixLimit > 0 ? prefixMatches / prefixLimit : 0;
  const lengthScore = Math.min(leftTokens.length, rightTokens.length) / Math.max(leftTokens.length, rightTokens.length);
  return Math.max(overlap * lengthScore, prefixScore * 0.9);
}
function isOutgoingMessageNearDuplicate(left, right, threshold = 0.82) {
  return calculateOutgoingMessageSimilarity(left, right) >= threshold;
}

// server/messageDeduplicationService.ts
var CONFIG = {
  // Cache em memória
  MEMORY_CACHE_TTL_MS: 2 * 60 * 60 * 1e3,
  // 2 horas em memória
  MEMORY_CACHE_MAX_SIZE: 5e4,
  // Máximo de registros em memória
  // Banco de dados
  DB_EXPIRY_HOURS: 48,
  // 48 horas no banco
  // Deduplicação
  SAME_MESSAGE_WINDOW_MS: 60 * 1e3,
  // 60 segundos - janela para considerar "mesma mensagem"
  SIMILAR_MESSAGE_WINDOW_MS: 5 * 60 * 1e3,
  // 5 minutos - janela para mensagens similares
  AUTOMATED_REPEAT_LOOKBACK_HOURS: 12,
  // 12 horas - bloqueia automações que repetem exatamente o mesmo texto
  // Cleanup
  CLEANUP_INTERVAL_MS: 30 * 60 * 1e3
  // Limpar cache a cada 30 minutos
};
var MessageDeduplicationService = class {
  constructor() {
    // Cache em memória para mensagens enviadas (rápido)
    this.outgoingCache = /* @__PURE__ */ new Map();
    // Cache em memória para mensagens recebidas (evita reprocessamento)
    this.incomingCache = /* @__PURE__ */ new Map();
    // Estatísticas
    this.stats = {
      outgoingBlocked: 0,
      outgoingAllowed: 0,
      incomingBlocked: 0,
      incomingAllowed: 0,
      dbErrors: 0,
      lastCleanup: Date.now()
    };
    // Flag de inicialização
    this.initialized = false;
    this.supabase = createSupabaseServiceClient();
    console.log("\u{1F6E1}\uFE0F [ANTI-REENVIO] MessageDeduplicationService inicializado");
    setInterval(() => this.cleanupExpiredCache(), CONFIG.CLEANUP_INTERVAL_MS);
    setInterval(() => this.cleanupDatabase(), 6 * 60 * 60 * 1e3);
    this.initialized = true;
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  FUNÇÕES DE HASH
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * Gera hash MD5 de uma string
   */
  generateHash(text) {
    return crypto.createHash("md5").update(text).digest("hex").substring(0, 16);
  }
  /**
   * Gera chave única de deduplicação para mensagens enviadas
   * Formato: {userId}:{contactNumber}:{contentHash}:{timestamp_bucket}
   */
  generateOutgoingDedupKey(userId, contactNumber, content, windowMs = CONFIG.SAME_MESSAGE_WINDOW_MS) {
    const contentHash = this.generateHash(content);
    const timestampBucket = Math.floor(Date.now() / windowMs);
    return `out:${userId}:${contactNumber}:${contentHash}:${timestampBucket}`;
  }
  /**
   * Gera chave para verificar mensagens similares (janela maior)
   */
  generateSimilarMessageKey(userId, contactNumber, content) {
    const contentHash = this.generateHash(content);
    const timestampBucket = Math.floor(Date.now() / CONFIG.SIMILAR_MESSAGE_WINDOW_MS);
    return `similar:${userId}:${contactNumber}:${contentHash}:${timestampBucket}`;
  }
  isAutomatedMessage(messageType, source) {
    return messageType === "ai_response" || messageType === "followup" || source === "userFollowUpService";
  }
  buildAutomatedRepeatFingerprint(content) {
    const fingerprint = buildOutgoingMessageFingerprint(content);
    if (!fingerprint) return fingerprint;
    const hasPaymentOptions = fingerprint.includes("opcoes disponiveis") && fingerprint.includes("pix") && fingerprint.includes("link de pagamento") && fingerprint.includes("pagamento em dinheiro") && fingerprint.includes("cartao");
    if (hasPaymentOptions) {
      return "semantic:payment-options";
    }
    const hasCartFinalizationPrompt = fingerprint.includes("total geral") && fingerprint.includes("posso seguir") && fingerprint.includes("finalizacao");
    if (hasCartFinalizationPrompt) {
      return "semantic:cart-finalization-confirm";
    }
    return fingerprint;
  }
  generateAutomationRepeatHash(content) {
    return this.generateHash(this.buildAutomatedRepeatFingerprint(content));
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  VERIFICAÇÃO DE MENSAGENS ENVIADAS (OUTGOING)
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * 🛡️ VERIFICAÇÃO PRINCIPAL - Checa se pode enviar uma mensagem
   * 
   * Retorna TRUE se pode enviar, FALSE se é duplicata
   * 
   * IMPORTANTE: Esta função DEVE ser chamada ANTES de qualquer envio!
   */
  async canSendMessage(params) {
    const { userId, contactNumber, content, conversationId, messageType = "unknown", source = "unknown" } = params;
    const dedupKey = this.generateOutgoingDedupKey(userId, contactNumber, content);
    const similarKey = this.generateSimilarMessageKey(userId, contactNumber, content);
    const contentHash = this.generateHash(content);
    const isAutomated = this.isAutomatedMessage(messageType, source);
    const automationRepeatHash = isAutomated ? this.generateAutomationRepeatHash(content) : contentHash;
    if (this.outgoingCache.has(dedupKey)) {
      console.log(`\u{1F6E1}\uFE0F [ANTI-REENVIO] \u274C BLOQUEADO (cache mem\xF3ria): ${contactNumber} - "${content.substring(0, 30)}..."`);
      console.log(`   \u{1F4CD} Source: ${source} | Type: ${messageType}`);
      this.stats.outgoingBlocked++;
      return false;
    }
    if (this.outgoingCache.has(similarKey)) {
      console.log(`\u{1F6E1}\uFE0F [ANTI-REENVIO] \u274C BLOQUEADO (similar em 5min): ${contactNumber} - "${content.substring(0, 30)}..."`);
      this.stats.outgoingBlocked++;
      return false;
    }
    if (isAutomated) {
      const automatedRepeatCacheKey = `auto:${userId}:${contactNumber}:${automationRepeatHash}`;
      if (this.outgoingCache.has(automatedRepeatCacheKey)) {
        console.log(`\xF0\u0178\u203A\xA1\xEF\xB8\x8F [ANTI-REENVIO] \xE2\x9D\u0152 BLOQUEADO (automacao repetida em cache): ${contactNumber} - "${content.substring(0, 30)}..."`);
        console.log(`   \xF0\u0178\u201C\x8D Source: ${source} | Type: ${messageType}`);
        this.stats.outgoingBlocked++;
        return false;
      }
    }
    try {
      const { data: existing, error } = await this.supabase.from("message_deduplication").select("id").eq("dedup_key", dedupKey).single();
      if (existing) {
        console.log(`\u{1F6E1}\uFE0F [ANTI-REENVIO] \u274C BLOQUEADO (banco): ${contactNumber} - "${content.substring(0, 30)}..."`);
        console.log(`   \u{1F4CD} Source: ${source} | Type: ${messageType}`);
        this.stats.outgoingBlocked++;
        this.addToOutgoingCache(dedupKey, {
          dedupKey,
          userId,
          conversationId,
          contactNumber,
          messageType,
          source,
          contentHash,
          createdAt: Date.now()
        });
        return false;
      }
      if (isAutomated) {
        const lookbackDate = new Date(
          Date.now() - CONFIG.AUTOMATED_REPEAT_LOOKBACK_HOURS * 60 * 60 * 1e3
        ).toISOString();
        const { data: repeatedAutomation, error: repeatedAutomationError } = await this.supabase.from("message_deduplication").select("id").eq("user_id", userId).eq("contact_number", contactNumber).eq("content_hash", automationRepeatHash).in("message_type", ["ai_response", "followup"]).gte("created_at", lookbackDate).limit(1);
        if (repeatedAutomation && repeatedAutomation.length > 0) {
          console.log(`\xF0\u0178\u203A\xA1\xEF\xB8\x8F [ANTI-REENVIO] \xE2\x9D\u0152 BLOQUEADO (automacao repetida no banco): ${contactNumber} - "${content.substring(0, 30)}..."`);
          console.log(`   \xF0\u0178\u201C\x8D Source: ${source} | Type: ${messageType}`);
          this.stats.outgoingBlocked++;
          this.addToOutgoingCache(`auto:${userId}:${contactNumber}:${automationRepeatHash}`, {
            dedupKey: `auto:${userId}:${contactNumber}:${automationRepeatHash}`,
            userId,
            conversationId,
            contactNumber,
            messageType,
            source,
            contentHash: automationRepeatHash,
            createdAt: Date.now()
          });
          return false;
        }
        if (repeatedAutomationError) {
          console.error("\xF0\u0178\u203A\xA1\xEF\xB8\x8F [ANTI-REENVIO] Erro ao verificar automacao repetida:", repeatedAutomationError);
          this.stats.dbErrors++;
        }
      }
      if (error && error.code !== "PGRST116") {
        console.error("\u{1F6E1}\uFE0F [ANTI-REENVIO] Erro ao verificar banco:", error);
        this.stats.dbErrors++;
      }
    } catch (err) {
      console.error("\u{1F6E1}\uFE0F [ANTI-REENVIO] Exce\xE7\xE3o ao verificar banco:", err);
      this.stats.dbErrors++;
    }
    await this.registerOutgoingMessage({
      userId,
      contactNumber,
      content,
      conversationId,
      messageType,
      source,
      contentHashOverride: isAutomated ? automationRepeatHash : void 0
    });
    this.stats.outgoingAllowed++;
    return true;
  }
  /**
   * Registra uma mensagem como enviada (cache + banco)
   */
  async registerOutgoingMessage(params) {
    const { userId, contactNumber, content, conversationId, messageType, source, contentHashOverride } = params;
    const dedupKey = this.generateOutgoingDedupKey(userId, contactNumber, content);
    const similarKey = this.generateSimilarMessageKey(userId, contactNumber, content);
    const contentHash = contentHashOverride || this.generateHash(content);
    const isAutomated = this.isAutomatedMessage(messageType, source);
    const record = {
      dedupKey,
      userId,
      conversationId,
      contactNumber,
      messageType,
      source,
      contentHash,
      createdAt: Date.now()
    };
    this.addToOutgoingCache(dedupKey, record);
    this.addToOutgoingCache(similarKey, { ...record, dedupKey: similarKey });
    if (isAutomated) {
      this.addToOutgoingCache(`auto:${userId}:${contactNumber}:${contentHash}`, {
        ...record,
        dedupKey: `auto:${userId}:${contactNumber}:${contentHash}`
      });
    }
    this.persistOutgoingMessage(record).catch((err) => {
      console.error("\u{1F6E1}\uFE0F [ANTI-REENVIO] Erro ao persistir no banco:", err);
      this.stats.dbErrors++;
    });
    if (isAutomated) {
      this.persistOutgoingMessage({
        ...record,
        dedupKey: `auto:${userId}:${contactNumber}:${contentHash}`
      }).catch((err) => {
        console.error("\xF0\u0178\u203A\xA1\xEF\xB8\x8F [ANTI-REENVIO] Erro ao persistir chave de automacao:", err);
        this.stats.dbErrors++;
      });
    }
  }
  /**
   * Adiciona registro ao cache com limite de tamanho
   */
  addToOutgoingCache(key, record) {
    if (this.outgoingCache.size >= CONFIG.MEMORY_CACHE_MAX_SIZE) {
      const toRemove = Math.floor(CONFIG.MEMORY_CACHE_MAX_SIZE * 0.1);
      const keys = Array.from(this.outgoingCache.keys()).slice(0, toRemove);
      keys.forEach((k) => this.outgoingCache.delete(k));
      console.log(`\u{1F6E1}\uFE0F [ANTI-REENVIO] Cache cheio, removidas ${toRemove} entradas antigas`);
    }
    this.outgoingCache.set(key, record);
  }
  /**
   * Persiste mensagem no banco Supabase
   */
  async persistOutgoingMessage(record) {
    const expiresAt = new Date(Date.now() + CONFIG.DB_EXPIRY_HOURS * 60 * 60 * 1e3);
    await this.supabase.from("message_deduplication").upsert({
      dedup_key: record.dedupKey,
      user_id: record.userId,
      conversation_id: record.conversationId,
      contact_number: record.contactNumber,
      message_type: record.messageType,
      source: record.source,
      content_hash: record.contentHash,
      created_at: new Date(record.createdAt).toISOString(),
      expires_at: expiresAt.toISOString()
    }, {
      onConflict: "dedup_key"
    });
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  VERIFICAÇÃO DE MENSAGENS RECEBIDAS (INCOMING)
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * 🛡️ Verifica se uma mensagem recebida já foi processada
   * 
   * Retorna TRUE se pode processar, FALSE se já foi processada
   */
  async checkIncomingMessageProcessed(params) {
    const { whatsappMessageId, userId, contactNumber, conversationId } = params;
    if (this.incomingCache.has(whatsappMessageId)) {
      return { processed: true, source: "cache" };
    }
    try {
      const { data: existing } = await this.supabase.from("incoming_message_log").select("id").eq("whatsapp_message_id", whatsappMessageId).single();
      if (existing) {
        this.incomingCache.set(whatsappMessageId, {
          whatsappMessageId,
          userId,
          contactNumber,
          conversationId,
          processed: true,
          receivedAt: Date.now()
        });
        return { processed: true, source: "db" };
      }
    } catch (err) {
      console.error("??????? [ANTI-REENVIO] Erro ao verificar incoming:", err);
    }
    return { processed: false, source: "none" };
  }
  /**
   * ??????? Verifica se uma mensagem recebida ja foi processada
   * 
   * Retorna TRUE se pode processar, FALSE se ja foi processada
   */
  async canProcessIncomingMessage(params) {
    const { whatsappMessageId, userId, contactNumber, conversationId } = params;
    const check = await this.checkIncomingMessageProcessed({
      whatsappMessageId,
      userId,
      contactNumber,
      conversationId
    });
    if (check.processed) {
      if (check.source === "cache") {
        console.log(`??????? [ANTI-REENVIO] ??? Mensagem ja processada (cache): ${whatsappMessageId}`);
      } else {
        console.log(`??????? [ANTI-REENVIO] ??? Mensagem ja processada (banco): ${whatsappMessageId}`);
      }
      this.stats.incomingBlocked++;
      return false;
    }
    await this.registerIncomingMessage({
      whatsappMessageId,
      userId,
      contactNumber,
      conversationId
    });
    this.stats.incomingAllowed++;
    return true;
  }
  /**
   * ??????? Check-only: TRUE se ja foi processada (nao registra).
   */
  async isIncomingMessageProcessed(params) {
    const check = await this.checkIncomingMessageProcessed(params);
    return check.processed;
  }
  /**
   * Registra uma mensagem recebida como processada
   */
  async registerIncomingMessage(params) {
    const { whatsappMessageId, userId, contactNumber, conversationId } = params;
    this.incomingCache.set(whatsappMessageId, {
      whatsappMessageId,
      userId,
      contactNumber,
      conversationId,
      processed: true,
      receivedAt: Date.now()
    });
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1e3);
    this.supabase.from("incoming_message_log").upsert({
      whatsapp_message_id: whatsappMessageId,
      user_id: userId,
      contact_number: contactNumber,
      conversation_id: conversationId,
      processed: true,
      processed_at: (/* @__PURE__ */ new Date()).toISOString(),
      received_at: (/* @__PURE__ */ new Date()).toISOString(),
      expires_at: expiresAt.toISOString()
    }, {
      onConflict: "whatsapp_message_id"
    }).then(({ error }) => {
      if (error) {
        console.error("\u{1F6E1}\uFE0F [ANTI-REENVIO] Erro ao persistir incoming:", error);
      }
    });
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  LIMPEZA E MANUTENÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * Limpa registros expirados do cache em memória
   */
  cleanupExpiredCache() {
    const now = Date.now();
    const expiryTime = now - CONFIG.MEMORY_CACHE_TTL_MS;
    let cleaned = 0;
    const keysToDelete = [];
    this.outgoingCache.forEach((record, key) => {
      if (record.createdAt < expiryTime) {
        keysToDelete.push(key);
      }
    });
    keysToDelete.forEach((key) => {
      this.outgoingCache.delete(key);
      cleaned++;
    });
    const incomingKeysToDelete = [];
    this.incomingCache.forEach((record, key) => {
      if (record.receivedAt < expiryTime) {
        incomingKeysToDelete.push(key);
      }
    });
    incomingKeysToDelete.forEach((key) => {
      this.incomingCache.delete(key);
      cleaned++;
    });
    if (cleaned > 0) {
      console.log(`\u{1F6E1}\uFE0F [ANTI-REENVIO] Limpeza de cache: ${cleaned} registros removidos`);
    }
    this.stats.lastCleanup = now;
  }
  /**
   * Limpa registros expirados do banco de dados
   */
  async cleanupDatabase() {
    try {
      const { data, error } = await this.supabase.rpc("cleanup_expired_deduplication");
      if (error) {
        console.error("\u{1F6E1}\uFE0F [ANTI-REENVIO] Erro ao limpar banco:", error);
      } else {
        console.log(`\u{1F6E1}\uFE0F [ANTI-REENVIO] Limpeza de banco conclu\xEDda: ${data || 0} registros removidos`);
      }
    } catch (err) {
      console.error("\u{1F6E1}\uFE0F [ANTI-REENVIO] Exce\xE7\xE3o ao limpar banco:", err);
    }
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  ESTATÍSTICAS E DEBUG
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * Retorna estatísticas do serviço
   */
  getStats() {
    return {
      outgoingCacheSize: this.outgoingCache.size,
      incomingCacheSize: this.incomingCache.size,
      ...this.stats,
      lastCleanup: new Date(this.stats.lastCleanup).toISOString()
    };
  }
  /**
   * Força limpeza de todos os caches (usar com cuidado!)
   */
  clearAllCaches() {
    this.outgoingCache.clear();
    this.incomingCache.clear();
    console.log("\u{1F6E1}\uFE0F [ANTI-REENVIO] \u26A0\uFE0F Todos os caches foram limpos!");
  }
  /**
   * Remove registros de um usuário específico dos caches
   */
  clearUserCache(userId) {
    let removed = 0;
    const keysToDelete = [];
    this.outgoingCache.forEach((record, key) => {
      if (record.userId === userId) {
        keysToDelete.push(key);
      }
    });
    keysToDelete.forEach((key) => {
      this.outgoingCache.delete(key);
      removed++;
    });
    const incomingKeysToDelete = [];
    this.incomingCache.forEach((record, key) => {
      if (record.userId === userId) {
        incomingKeysToDelete.push(key);
      }
    });
    incomingKeysToDelete.forEach((key) => {
      this.incomingCache.delete(key);
      removed++;
    });
    console.log(`\u{1F6E1}\uFE0F [ANTI-REENVIO] Cache do usu\xE1rio ${userId.substring(0, 8)}... limpo: ${removed} registros`);
  }
  clearConversationOutgoingCache(params) {
    const conversationId = String(params.conversationId || "").trim();
    const userId = String(params.userId || "").trim();
    const contactNumber = String(params.contactNumber || "").replace(/\D/g, "");
    if (!conversationId && (!userId || !contactNumber)) {
      return 0;
    }
    const keysToDelete = [];
    this.outgoingCache.forEach((record, key) => {
      const matchesConversation = Boolean(conversationId && record.conversationId === conversationId);
      const recordContact = String(record.contactNumber || "").replace(/\D/g, "");
      const matchesContact = Boolean(
        userId && contactNumber && record.userId === userId && recordContact === contactNumber
      );
      if (matchesConversation || matchesContact) {
        keysToDelete.push(key);
      }
    });
    keysToDelete.forEach((key) => this.outgoingCache.delete(key));
    if (keysToDelete.length > 0) {
      console.log(
        `[ANTI-REENVIO] Cache de saida limpo para conversa ${conversationId || "(sem id)"}: ${keysToDelete.length} registros`
      );
    }
    return keysToDelete.length;
  }
};
var messageDeduplicationService = new MessageDeduplicationService();
async function canSendMessage(params) {
  return messageDeduplicationService.canSendMessage(params);
}
async function isIncomingMessageProcessed(params) {
  return messageDeduplicationService.isIncomingMessageProcessed(params);
}
async function markIncomingMessageProcessed(params) {
  return messageDeduplicationService.registerIncomingMessage(params);
}
function clearOutgoingDeduplicationCacheForConversation(params) {
  return messageDeduplicationService.clearConversationOutgoingCache(params);
}

// server/whatsappCoexistence.ts
var WHATSAPP_CONNECTION_PROVIDERS = {
  BAILEYS: "baileys",
  META_CLOUD_API: "meta_cloud_api"
};
var WHATSAPP_CONNECTION_METHODS = {
  QR: "qr",
  PAIRING: "pairing",
  COEXISTENCE: "coexistence"
};
var WHATSAPP_PROVIDER_STATUS = {
  INACTIVE: "inactive",
  PENDING_SETUP: "pending_setup",
  AWAITING_WEBHOOK: "awaiting_webhook",
  CONNECTED: "connected",
  DISCONNECTED: "disconnected",
  ERROR: "error"
};
var DEFAULT_BETA_EMAILS = ["rodrigo4@gmail.com"];
var DEFAULT_ONBOARDING_DOC_URL = "https://developers.facebook.com/documentation/business-messaging/whatsapp/embedded-signup/onboarding-business-app-users/";
function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}
function getWhatsappCoexistenceBetaEmails() {
  const raw = process.env.WHATSAPP_COEXISTENCE_BETA_EMAILS;
  if (!raw?.trim()) {
    return DEFAULT_BETA_EMAILS;
  }
  return raw.split(",").map((item) => normalizeEmail(item)).filter(Boolean);
}
function getWhatsappCoexistenceLaunchConfig() {
  const appId = String(process.env.WHATSAPP_COEXISTENCE_APP_ID || "").trim();
  const configId = String(process.env.WHATSAPP_COEXISTENCE_CONFIG_ID || "").trim();
  const setupUrl = String(process.env.WHATSAPP_COEXISTENCE_SETUP_URL || "").trim();
  const redirectUri = String(process.env.WHATSAPP_COEXISTENCE_REDIRECT_URI || "").trim();
  return {
    appId,
    configId,
    setupUrl,
    redirectUri,
    docsUrl: DEFAULT_ONBOARDING_DOC_URL,
    isConfigured: !!appId && !!configId
  };
}
function buildPendingCoexistenceProviderConfig(existingConfig, extras) {
  return {
    ...existingConfig || {},
    onboardingSource: "embedded_signup_business_app_users",
    betaOnly: true,
    launchConfig: getWhatsappCoexistenceLaunchConfig(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    ...extras || {}
  };
}
async function getWhatsappCoexistenceBetaStatus(userId) {
  const user = await storage.getUser(userId);
  const userEmail = normalizeEmail(user?.email);
  const enabled = !!userEmail && getWhatsappCoexistenceBetaEmails().includes(userEmail);
  return {
    enabled,
    userEmail: userEmail || null,
    launchConfig: getWhatsappCoexistenceLaunchConfig()
  };
}
async function assertWhatsappCoexistenceBetaAccess(userId) {
  const status = await getWhatsappCoexistenceBetaStatus(userId);
  if (!status.enabled) {
    const error = new Error("Coexist\xEAncia Oficial dispon\xEDvel apenas para a beta allowlist.");
    error.statusCode = 403;
    throw error;
  }
  return status;
}
function isOfficialCoexistenceConnection(connection) {
  return connection?.provider === WHATSAPP_CONNECTION_PROVIDERS.META_CLOUD_API || connection?.connectionMethod === WHATSAPP_CONNECTION_METHODS.COEXISTENCE;
}
function isWhatsAppProviderStatusConnected(providerStatus) {
  return String(providerStatus || "").trim().toLowerCase() === WHATSAPP_PROVIDER_STATUS.CONNECTED;
}
function isPersistedWhatsAppConnectionOperational(connection) {
  if (!connection) {
    return false;
  }
  if (!isOfficialCoexistenceConnection(connection)) {
    const normalizedStatus = String(connection.providerStatus || "").trim().toLowerCase();
    return connection.isConnected === true && (!normalizedStatus || normalizedStatus === WHATSAPP_PROVIDER_STATUS.CONNECTED);
  }
  return connection.isConnected === true || isWhatsAppProviderStatusConnected(connection.providerStatus);
}

// server/metaCloudApi.ts
var GRAPH_VERSION = String(process.env.WHATSAPP_CLOUD_API_VERSION || "v23.0").trim();
var OFFICIAL_AUTOMATED_REPEAT_LOOKBACK_MS = 12 * 60 * 60 * 1e3;
function cleanDigits(value) {
  return String(value || "").replace(/\D/g, "");
}
function getGraphBaseUrl() {
  return `https://graph.facebook.com/${GRAPH_VERSION}`;
}
function getMetaProviderConfig(connection) {
  return connection.providerConfig || {};
}
function getMetaAccessToken(connection) {
  const token = getMetaProviderConfig(connection)?.credentials?.accessToken;
  if (!token) {
    throw new Error("Access token da Cloud API n\xE3o configurado para esta conex\xE3o.");
  }
  return token;
}
function getMetaPhoneNumberId(connection) {
  const phoneNumberId = getMetaProviderConfig(connection)?.embeddedSignup?.phoneNumberId;
  if (!phoneNumberId) {
    throw new Error("phoneNumberId da Cloud API n\xE3o configurado para esta conex\xE3o.");
  }
  return phoneNumberId;
}
function getRecipientPhone(conversation) {
  const digits = cleanDigits(conversation.contactNumber || conversation.remoteJid);
  if (!digits) {
    throw new Error("N\xFAmero do contato inv\xE1lido para envio via Cloud API.");
  }
  return digits;
}
async function parseGraphError(response) {
  try {
    const payload = await response.json();
    return payload?.error?.message || payload?.message || `${response.status} ${response.statusText}`;
  } catch {
    return `${response.status} ${response.statusText}`;
  }
}
async function graphRequest(connection, path, init) {
  const accessToken = getMetaAccessToken(connection);
  const response = await fetch(`${getGraphBaseUrl()}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      ...init?.headers || {}
    }
  });
  if (!response.ok) {
    throw new Error(await parseGraphError(response));
  }
  return response.json();
}
async function maybeCheckDeduplication(options) {
  if (!options) return;
  const allowed = await canSendMessage(options);
  if (!allowed) {
    const error = new Error("Mensagem bloqueada por deduplica\xE7\xE3o");
    error.blocked = true;
    throw error;
  }
}
async function maybeBlockRepeatedAutomatedOfficialText(connection, conversation, text, options) {
  if (options?.dedupe) return;
  if (!connection.userId || !conversation.id) return;
  const currentFingerprint = buildOutgoingMessageFingerprint(text);
  if (!currentFingerprint) return;
  const lookbackDate = new Date(Date.now() - OFFICIAL_AUTOMATED_REPEAT_LOOKBACK_MS);
  const recentMessages = await db.query.messages.findMany({
    where: and(
      eq(messages.conversationId, conversation.id),
      gte(messages.timestamp, lookbackDate)
    ),
    orderBy: (message, { desc }) => [desc(message.timestamp)],
    columns: {
      text: true,
      fromMe: true,
      isFromAgent: true,
      timestamp: true
    },
    limit: 40
  });
  let customerRepliedAfterPreviousAutomation = false;
  for (const recentMessage of recentMessages) {
    if (!recentMessage.fromMe) {
      customerRepliedAfterPreviousAutomation = true;
      continue;
    }
    if (recentMessage.isFromAgent !== true) {
      continue;
    }
    if (buildOutgoingMessageFingerprint(recentMessage.text || "") !== currentFingerprint) {
      continue;
    }
    if (!customerRepliedAfterPreviousAutomation) {
      const error = new Error("Mensagem autom\xE1tica oficial repetida sem resposta do cliente");
      error.blocked = true;
      throw error;
    }
    return;
  }
}
async function uploadMediaToMeta(connection, media) {
  const phoneNumberId = getMetaPhoneNumberId(connection);
  const formData = new FormData();
  formData.append("messaging_product", "whatsapp");
  let buffer;
  if (media.data.startsWith("data:")) {
    const [, base64Part = ""] = media.data.split(",", 2);
    buffer = Buffer.from(base64Part, "base64");
  } else if (media.data.startsWith("http://") || media.data.startsWith("https://")) {
    const mediaResponse = await fetch(media.data);
    if (!mediaResponse.ok) {
      throw new Error(`Falha ao baixar m\xEDdia remota: ${mediaResponse.status}`);
    }
    buffer = Buffer.from(await mediaResponse.arrayBuffer());
  } else {
    buffer = Buffer.from(media.data, "base64");
  }
  const blob = new Blob([buffer], {
    type: media.mimetype || "application/octet-stream"
  });
  formData.append("file", blob, media.filename || `upload-${Date.now()}`);
  formData.append("type", media.mimetype || "application/octet-stream");
  const uploadResponse = await fetch(`${getGraphBaseUrl()}/${phoneNumberId}/media`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getMetaAccessToken(connection)}`
    },
    body: formData
  });
  if (!uploadResponse.ok) {
    throw new Error(await parseGraphError(uploadResponse));
  }
  const uploadPayload = await uploadResponse.json();
  if (!uploadPayload?.id) {
    throw new Error("Meta n\xE3o retornou media id para o upload.");
  }
  return uploadPayload.id;
}
async function sendMetaCloudTextMessage(connection, conversation, text, options) {
  if (!isOfficialCoexistenceConnection(connection)) {
    throw new Error("Conex\xE3o n\xE3o usa provider oficial Meta Cloud API.");
  }
  await maybeCheckDeduplication(options?.dedupe);
  const normalizedText = normalizeOutboundTextForCustomer(text);
  await maybeBlockRepeatedAutomatedOfficialText(connection, conversation, normalizedText, options);
  const payload = await graphRequest(connection, `/${getMetaPhoneNumberId(connection)}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: getRecipientPhone(conversation),
      type: "text",
      text: { body: normalizedText, preview_url: false }
    })
  });
  return { messageId: payload?.messages?.[0]?.id };
}
async function sendMetaCloudButtonsMessage(connection, conversation, payload, options) {
  await maybeCheckDeduplication(options?.dedupe);
  await maybeBlockRepeatedAutomatedOfficialText(connection, conversation, payload.body, options);
  const response = await graphRequest(connection, `/${getMetaPhoneNumberId(connection)}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: getRecipientPhone(conversation),
      type: "interactive",
      interactive: {
        type: "button",
        body: { text: payload.body },
        ...payload.header?.text ? { header: { type: "text", text: payload.header.text } } : {},
        ...payload.footer?.text ? { footer: { text: payload.footer.text } } : {},
        action: {
          buttons: payload.buttons.slice(0, 3).map((button) => ({
            type: "reply",
            reply: button.reply
          }))
        }
      }
    })
  });
  return { messageId: response?.messages?.[0]?.id };
}
async function sendMetaCloudListMessage(connection, conversation, payload, options) {
  await maybeCheckDeduplication(options?.dedupe);
  await maybeBlockRepeatedAutomatedOfficialText(connection, conversation, payload.body, options);
  const response = await graphRequest(connection, `/${getMetaPhoneNumberId(connection)}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: getRecipientPhone(conversation),
      type: "interactive",
      interactive: {
        type: "list",
        body: { text: payload.body },
        action: {
          button: payload.buttonText,
          sections: payload.sections
        }
      }
    })
  });
  return { messageId: response?.messages?.[0]?.id };
}
async function sendMetaCloudMediaMessage(connection, conversation, media) {
  const mediaId = await uploadMediaToMeta(connection, media);
  const recipient = getRecipientPhone(conversation);
  let body;
  if (media.type === "audio") {
    body = { messaging_product: "whatsapp", recipient_type: "individual", to: recipient, type: "audio", audio: { id: mediaId } };
  } else if (media.type === "image") {
    body = { messaging_product: "whatsapp", recipient_type: "individual", to: recipient, type: "image", image: { id: mediaId, ...media.caption ? { caption: media.caption } : {} } };
  } else if (media.type === "video") {
    body = { messaging_product: "whatsapp", recipient_type: "individual", to: recipient, type: "video", video: { id: mediaId, ...media.caption ? { caption: media.caption } : {} } };
  } else {
    body = { messaging_product: "whatsapp", recipient_type: "individual", to: recipient, type: "document", document: { id: mediaId, filename: media.filename || "documento", ...media.caption ? { caption: media.caption } : {} } };
  }
  const response = await graphRequest(connection, `/${getMetaPhoneNumberId(connection)}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  return { messageId: response?.messages?.[0]?.id, uploadedMediaId: mediaId };
}
async function exchangeMetaEmbeddedSignupCode(params) {
  const appId = String(process.env.WHATSAPP_COEXISTENCE_APP_ID || "").trim();
  const appSecret = String(process.env.WHATSAPP_COEXISTENCE_APP_SECRET || "").trim();
  if (!appId || !appSecret) {
    throw new Error("WHATSAPP_COEXISTENCE_APP_ID e WHATSAPP_COEXISTENCE_APP_SECRET s\xE3o obrigat\xF3rios para trocar o code por token.");
  }
  const url = new URL(`${getGraphBaseUrl()}/oauth/access_token`);
  url.searchParams.set("client_id", appId);
  url.searchParams.set("client_secret", appSecret);
  url.searchParams.set("code", params.code);
  if (params.redirectUri) {
    url.searchParams.set("redirect_uri", params.redirectUri);
  }
  const response = await fetch(url.toString(), { method: "GET" });
  if (!response.ok) {
    throw new Error(await parseGraphError(response));
  }
  const payload = await response.json();
  if (!payload?.access_token) {
    throw new Error("Meta n\xE3o retornou access_token na troca do code.");
  }
  return {
    accessToken: payload.access_token,
    expiresIn: payload.expires_in,
    tokenType: payload.token_type
  };
}
function buildOfficialWebhookUrl() {
  const baseUrl = String(process.env.BASE_URL || "").trim();
  if (!baseUrl) {
    return "/api/webhooks/whatsapp/cloud-api";
  }
  return `${baseUrl.replace(/\/$/, "")}/api/webhooks/whatsapp/cloud-api`;
}
function createWebhookVerifyToken() {
  return crypto2.randomBytes(24).toString("hex");
}
async function findOfficialConnectionByPhoneNumberId(phoneNumberId) {
  if (!phoneNumberId) return void 0;
  const [connection] = await db.select().from(whatsappConnections).where(
    and(
      eq(whatsappConnections.provider, WHATSAPP_CONNECTION_PROVIDERS.META_CLOUD_API),
      sql`${whatsappConnections.providerConfig} -> 'embeddedSignup' ->> 'phoneNumberId' = ${phoneNumberId}`
    )
  ).limit(1);
  return connection;
}
async function findOfficialConnectionByVerifyToken(verifyToken) {
  if (!verifyToken) return void 0;
  const [connection] = await db.select().from(whatsappConnections).where(
    and(
      eq(whatsappConnections.provider, WHATSAPP_CONNECTION_PROVIDERS.META_CLOUD_API),
      sql`${whatsappConnections.providerConfig} -> 'credentials' ->> 'webhookVerifyToken' = ${verifyToken}`
    )
  ).limit(1);
  return connection;
}
async function markOfficialConnectionWebhookVerified(connection, extras) {
  const providerConfig = getMetaProviderConfig(connection);
  const updatedProviderConfig = {
    ...providerConfig,
    webhook: {
      ...providerConfig.webhook || {},
      url: buildOfficialWebhookUrl(),
      verifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
      ...extras || {}
    }
  };
  const [updated] = await db.update(whatsappConnections).set({
    providerStatus: WHATSAPP_PROVIDER_STATUS.CONNECTED,
    isConnected: true,
    providerConfig: updatedProviderConfig
  }).where(eq(whatsappConnections.id, connection.id)).returning();
  return updated;
}
async function updateOfficialMessageStatus(messageId, status) {
  const [message] = await db.select().from(messages).where(eq(messages.messageId, messageId)).limit(1);
  if (!message) return;
  await db.update(messages).set({ status }).where(eq(messages.id, message.id));
}

// server/whatsappGatewayClient.ts
var DEFAULT_GATEWAY_URL = "http://127.0.0.1:5001";
var DEFAULT_INTERNAL_TOKEN = "agentezap-internal-wa-gateway";
var DEFAULT_GATEWAY_REQUEST_TIMEOUT_MS = 9e4;
function isMonolithRuntime() {
  return String(process.env.SERVICE_MODE || "").trim().toLowerCase() === "monolith";
}
function isGatewayClientEnabled() {
  if (String(process.env.WA_GATEWAY_URL || "").trim()) {
    return true;
  }
  return !isMonolithRuntime();
}
function getGatewayBaseUrl() {
  const explicitUrl = String(process.env.WA_GATEWAY_URL || "").trim();
  if (!explicitUrl && isMonolithRuntime()) {
    throw new Error("WA gateway client is disabled in monolith runtime");
  }
  return (explicitUrl || DEFAULT_GATEWAY_URL).trim().replace(/\/+$/, "");
}
function getInternalToken() {
  return (process.env.WA_GATEWAY_INTERNAL_TOKEN || DEFAULT_INTERNAL_TOKEN).trim();
}
function getGatewayRequestTimeoutMs() {
  const parsed = Number(process.env.WA_GATEWAY_REQUEST_TIMEOUT_MS || "");
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return DEFAULT_GATEWAY_REQUEST_TIMEOUT_MS;
  }
  return Math.max(1e3, Math.floor(parsed));
}
async function requestGateway(method, path, body, timeoutOverrideMs) {
  return requestGatewayWithHeaders(method, path, void 0, body, timeoutOverrideMs);
}
async function requestGatewayWithHeaders(method, path, extraHeaders, body, timeoutOverrideMs) {
  const timeoutMs = timeoutOverrideMs ?? getGatewayRequestTimeoutMs();
  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  let text;
  try {
    response = await fetch(`${getGatewayBaseUrl()}${path}`, {
      method,
      headers: {
        "content-type": "application/json",
        "x-wa-gateway-token": getInternalToken(),
        ...extraHeaders || {}
      },
      body: body === void 0 ? void 0 : JSON.stringify(body),
      signal: controller.signal
    });
    text = await response.text();
  } catch (error) {
    if (error?.name === "AbortError" || controller.signal.aborted) {
      throw new Error(`Gateway request timed out after ${timeoutMs}ms: ${method} ${path}`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutHandle);
  }
  let payload = null;
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      const preview = text.trim().slice(0, 180);
      throw new Error(`Gateway returned non-JSON response (${response.status}): ${preview}`);
    }
  }
  if (!response.ok) {
    const message = payload?.message || payload?.error || `Gateway request failed (${response.status})`;
    throw new Error(message);
  }
  return payload;
}
async function getGatewayInstanceStatus(connectionId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/status`);
}
async function getGatewayBulkInstanceStatuses(connectionIds) {
  return requestGateway("POST", "/api/integration/instances/status/bulk", {
    instanceIds: connectionIds
  });
}
async function getGatewayInstanceDevice(connectionId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/device`);
}
async function connectGatewayInstance(connectionId, timeoutOverrideMs) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/connect`, {}, timeoutOverrideMs);
}
async function disconnectGatewayInstance(connectionId) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/disconnect`, {});
}
async function resetGatewayInstance(connectionId, body, timeoutOverrideMs) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/reset`, body || {}, timeoutOverrideMs);
}
async function listGatewayInstanceConversations(connectionId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/conversations`);
}
async function listGatewayInstanceMessages(connectionId, conversationId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/conversations/${conversationId}/messages`);
}
async function getGatewayInstanceMessageMedia(connectionId, conversationId, messageId) {
  return requestGateway(
    "GET",
    `/api/integration/instances/${connectionId}/conversations/${conversationId}/messages/${messageId}/media`
  );
}
async function redownloadGatewayInstanceMessageMedia(connectionId, conversationId, messageId) {
  return requestGateway(
    "POST",
    `/api/integration/instances/${connectionId}/conversations/${conversationId}/messages/${messageId}/media/redownload`,
    {}
  );
}
async function syncGatewayInstanceGroupHistory(connectionId, conversationId) {
  return requestGateway(
    "POST",
    `/api/integration/instances/${connectionId}/conversations/${conversationId}/group-history-sync`,
    {}
  );
}
async function listGatewayInstanceContacts(connectionId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/contacts`);
}
async function validateGatewayInstanceContact(connectionId, phoneNumber) {
  const query = new URLSearchParams({ phoneNumber });
  return requestGateway("GET", `/api/integration/instances/${connectionId}/contacts/validate?${query.toString()}`);
}
async function validateGatewayInstanceContactsBatch(connectionId, phoneNumbers) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/contacts/validate-bulk`, {
    phoneNumbers
  });
}
async function getGatewayInstanceContactProfilePicture(connectionId, phoneNumber, type = "preview") {
  const query = new URLSearchParams({ phoneNumber, type });
  return requestGateway(
    "GET",
    `/api/integration/instances/${connectionId}/contacts/profile-picture?${query.toString()}`
  );
}
async function updateGatewayInstanceContactBlockStatus(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/contacts/block`, body);
}
async function sendGatewayInstanceContactPresence(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/contacts/presence`, body);
}
async function listGatewayInstanceGroups(connectionId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/groups`);
}
async function createGatewayInstanceGroup(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/groups`, body);
}
async function joinGatewayInstanceGroupByInvite(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/groups/join-by-invite`, body);
}
async function getGatewayInstanceGroupDetails(connectionId, groupId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}`);
}
async function listGatewayInstanceGroupParticipants(connectionId, groupId) {
  return requestGateway(
    "GET",
    `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}/participants`
  );
}
async function updateGatewayInstanceGroupSubject(connectionId, groupId, body) {
  return requestGateway(
    "PATCH",
    `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}/subject`,
    body
  );
}
async function updateGatewayInstanceGroupDescription(connectionId, groupId, body) {
  return requestGateway(
    "PATCH",
    `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}/description`,
    body
  );
}
async function updateGatewayInstanceGroupParticipants(connectionId, groupId, body) {
  return requestGateway(
    "POST",
    `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}/participants`,
    body
  );
}
async function getGatewayInstanceGroupInviteCode(connectionId, groupId) {
  return requestGateway(
    "GET",
    `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}/invite-code`
  );
}
async function revokeGatewayInstanceGroupInviteCode(connectionId, groupId) {
  return requestGateway(
    "POST",
    `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}/invite-code/revoke`,
    {}
  );
}
async function leaveGatewayInstanceGroup(connectionId, groupId) {
  return requestGateway(
    "POST",
    `/api/integration/instances/${connectionId}/groups/${encodeURIComponent(groupId)}/leave`,
    {}
  );
}
async function getGatewayInstanceQueue(connectionId) {
  return requestGateway("GET", `/api/integration/instances/${connectionId}/queue`);
}
async function clearGatewayInstanceQueue(connectionId) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/queue/clear`, {});
}
async function previewGatewayStatusAudience(connectionId) {
  return requestGateway(
    "GET",
    `/api/integration/instances/${connectionId}/status-posts/preview-audience`
  );
}
async function sendGatewayStatusPost(connectionId, body) {
  return requestGateway(
    "POST",
    `/api/integration/instances/${connectionId}/status-posts/send`,
    body
  );
}
async function sendGatewayInstanceText(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/messages/send`, buildGatewayTextSendBody(body));
}
async function sendGatewayInstanceMedia(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/messages/send-media`, body);
}
async function sendGatewayInstanceContact(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/messages/send-contact`, body);
}
async function sendGatewayInstanceLocation(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/messages/send-location`, body);
}
async function sendGatewayInstanceButtons(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/messages/send-buttons`, body);
}
async function sendGatewayInstanceList(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/messages/send-list`, body);
}
async function sendGatewayInstanceReaction(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/messages/send-reaction`, body);
}
async function sendGatewayInstanceGroupBulk(connectionId, body) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/groups/send-bulk`, body);
}
async function createGatewayManagedInstance(userId, body) {
  return requestGatewayWithHeaders(
    "POST",
    "/api/integration/instances",
    { "x-gateway-user-id": userId },
    body
  );
}
async function deleteGatewayManagedInstance(connectionId) {
  return requestGateway("DELETE", `/api/integration/instances/${connectionId}`);
}
async function requestGatewayInstancePairingCode(connectionId, phoneNumber) {
  return requestGateway("POST", `/api/integration/instances/${connectionId}/pairing-code`, {
    phoneNumber
  });
}

// server/whatsappGatewayAppOwnership.ts
import { eq as eq2 } from "drizzle-orm";

// server/whatsappGatewayOwnership.ts
var EMAIL_CACHE_TTL_MS = 6e4;
var userEmailCache = /* @__PURE__ */ new Map();
function normalizeEmail2(value) {
  return value.trim().toLowerCase();
}
function parseEmailList(raw) {
  return Array.from(
    new Set(
      String(raw || "").split(",").map((item) => normalizeEmail2(item)).filter(Boolean)
    )
  );
}
function isWhatsAppGatewayRuntime() {
  return (process.env.SERVICE_MODE || "").trim() === "wa-gateway";
}
function isMonolithRuntime2() {
  return (process.env.SERVICE_MODE || "").trim().toLowerCase() === "monolith";
}
function getWhatsAppGatewayAllowedEmails() {
  return parseEmailList(process.env.WA_GATEWAY_ALLOWED_EMAILS);
}
function getWhatsAppGatewayRoutedEmails() {
  return parseEmailList(process.env.WA_GATEWAY_ROUTED_EMAILS);
}
function isTruthyFlag(value) {
  const normalized = String(value || "").trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}
function hasRemoteGatewayConfigured() {
  return Boolean(String(process.env.WA_GATEWAY_URL || "").trim());
}
function shouldForceGatewayForDisabledLocalRuntime() {
  if (isWhatsAppGatewayRuntime() || !hasRemoteGatewayConfigured()) {
    return false;
  }
  return isTruthyFlag(process.env.DISABLE_WHATSAPP_PROCESSING) || isTruthyFlag(process.env.DISABLE_LOCAL_WHATSAPP_RUNTIME) || isTruthyFlag(process.env.DISABLE_LEGACY_WHATSAPP_RUNTIME) || isTruthyFlag(process.env.DISABLE_CUSTOMER_BAILEYS_LOCAL_RUNTIME) || isTruthyFlag(process.env.SKIP_WHATSAPP_RESTORE);
}
function shouldRouteAllBaileysConnectionsToGateway() {
  return isTruthyFlag(process.env.WA_GATEWAY_ROUTE_ALL_BAILEYS);
}
function shouldEnablePublicInstanceApiForAllBaileys() {
  return isTruthyFlag(process.env.WA_PUBLIC_INSTANCE_API_ENABLE_ALL_BAILEYS);
}
function getPublicInstanceApiCanaryEmails() {
  const configured = parseEmailList(process.env.WA_PUBLIC_INSTANCE_API_CANARY_EMAILS);
  if (configured.length > 0) {
    return configured;
  }
  const routed = getWhatsAppGatewayRoutedEmails();
  if (routed.length > 0) {
    return routed;
  }
  return getWhatsAppGatewayAllowedEmails();
}
async function getCachedUserEmail(userId) {
  const cached = userEmailCache.get(userId);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.email;
  }
  const user = await storage.getUser(userId);
  const email = user?.email ? normalizeEmail2(user.email) : null;
  userEmailCache.set(userId, {
    email,
    expiresAt: Date.now() + EMAIL_CACHE_TTL_MS
  });
  return email;
}
async function resolveConnectionRecord(connectionOrId) {
  if (typeof connectionOrId !== "string") {
    return connectionOrId;
  }
  return storage.getConnectionById(connectionOrId);
}
function isGatewayEligibleConnection(connection) {
  if (!connection) {
    return false;
  }
  const provider = String(connection.provider || "baileys").trim().toLowerCase();
  const method = String(connection.connectionMethod || "qr").trim().toLowerCase();
  return provider === "baileys" && method !== "coexistence";
}
async function isPublicInstanceApiCanaryEnabledForUser(userId) {
  const canaryEmails = getPublicInstanceApiCanaryEmails();
  if (canaryEmails.length === 0) {
    return false;
  }
  const email = await getCachedUserEmail(userId);
  return !!email && canaryEmails.includes(email);
}
async function isPublicInstanceApiCanaryEnabledForConnection(connectionOrId) {
  const connection = await resolveConnectionRecord(connectionOrId);
  if (!connection?.userId || !isGatewayEligibleConnection(connection)) {
    return false;
  }
  if (shouldEnablePublicInstanceApiForAllBaileys()) {
    return true;
  }
  return isPublicInstanceApiCanaryEnabledForUser(connection.userId);
}
async function resolveWhatsAppConnectionOwner(connectionOrId) {
  const connection = await resolveConnectionRecord(connectionOrId);
  if (!connection?.userId || !isGatewayEligibleConnection(connection)) {
    return "local";
  }
  if (shouldForceGatewayForDisabledLocalRuntime()) {
    return "gateway";
  }
  if (isMonolithRuntime2() && !hasRemoteGatewayConfigured()) {
    return "local";
  }
  if (shouldRouteAllBaileysConnectionsToGateway()) {
    return "gateway";
  }
  const canaryEmails = /* @__PURE__ */ new Set([
    ...getWhatsAppGatewayAllowedEmails(),
    ...getWhatsAppGatewayRoutedEmails()
  ]);
  if (canaryEmails.size === 0) {
    return "local";
  }
  const email = await getCachedUserEmail(connection.userId);
  if (email && canaryEmails.has(email)) {
    return "gateway";
  }
  return "local";
}
async function isConnectionOwnedByCurrentProcess(connectionOrId) {
  const owner = await resolveWhatsAppConnectionOwner(connectionOrId);
  return isWhatsAppGatewayRuntime() ? owner === "gateway" : owner === "local";
}

// server/whatsappGatewayAppOwnership.ts
function isTruthyFlag2(value) {
  const normalized = String(value || "").trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes" || normalized === "on";
}
function hasRemoteGatewayConfigured2() {
  return Boolean(String(process.env.WA_GATEWAY_URL || "").trim());
}
function shouldForceGatewayForCustomerBaileysInApp(connection) {
  if (!connection || isWhatsAppGatewayRuntime()) {
    return false;
  }
  if (!isTruthyFlag2(process.env.DISABLE_CUSTOMER_BAILEYS_LOCAL_RUNTIME) && !hasRemoteGatewayConfigured2()) {
    return false;
  }
  const provider = String(connection.provider || "baileys").trim().toLowerCase();
  const method = String(connection.connectionMethod || "qr").trim().toLowerCase();
  return provider === "baileys" && method !== "coexistence";
}
async function resolveConnectionRecord2(connectionOrId) {
  if (typeof connectionOrId !== "string") {
    if (connectionOrId.provider !== void 0 && connectionOrId.providerStatus !== void 0 && connectionOrId.connectionMethod !== void 0) {
      return connectionOrId;
    }
    const [fullConnection2] = await db.select().from(whatsappConnections).where(eq2(whatsappConnections.id, connectionOrId.id)).limit(1);
    return fullConnection2 || connectionOrId;
  }
  const [fullConnection] = await db.select().from(whatsappConnections).where(eq2(whatsappConnections.id, connectionOrId)).limit(1);
  if (fullConnection) {
    return fullConnection;
  }
  return storage.getConnectionById(connectionOrId);
}
async function resolveAppVisibleConnectionOwner(connectionOrId) {
  const connection = await resolveConnectionRecord2(connectionOrId);
  if (shouldForceGatewayForCustomerBaileysInApp(connection)) {
    return "gateway";
  }
  return resolveWhatsAppConnectionOwner(connectionOrId);
}

// server/whatsappSender.ts
var activeSessions = /* @__PURE__ */ new Map();
var activeSessionConnectionsByUserId = /* @__PURE__ */ new Map();
function mapOriginToGatewaySource(origin) {
  if (origin === "manual_admin") {
    return "owner";
  }
  if (origin === "follow_up" || origin === "user_follow_up") {
    return "followup";
  }
  if (origin === "ai_agent" || origin === "chatbot_flow" || origin === "conversation") {
    return "agent";
  }
  return "system";
}
function getFileNameFromUrl(value) {
  try {
    const url = new URL(value);
    const fileName = url.pathname.split("/").pop();
    return fileName || void 0;
  } catch {
    const fileName = value.split("?")[0].split("/").pop();
    return fileName || void 0;
  }
}
function inferMediaTypeFromUrlAndMime(mediaUrl, mimeType) {
  const lowerMimeType = String(mimeType || "").toLowerCase();
  if (lowerMimeType.startsWith("image/")) return "image";
  if (lowerMimeType.startsWith("video/")) return "video";
  if (lowerMimeType.startsWith("audio/")) return "audio";
  if (mediaUrl.match(/\.(jpg|jpeg|png|gif|webp)$/i)) return "image";
  if (mediaUrl.match(/\.(mp4|mov|avi|webm)$/i)) return "video";
  if (mediaUrl.match(/\.(mp3|ogg|wav|m4a|opus)$/i)) return "audio";
  return "document";
}
function normalizeRemoteMediaMimeType(mediaUrl, mimeType) {
  const trimmedMimeType = String(mimeType || "").trim();
  if (trimmedMimeType) {
    if (trimmedMimeType.toLowerCase().startsWith("audio/") && mediaUrl.match(/\.(ogg|opus)$/i)) {
      return "audio/ogg; codecs=opus";
    }
    return trimmedMimeType;
  }
  if (mediaUrl.match(/\.(jpg|jpeg)$/i)) return "image/jpeg";
  if (mediaUrl.match(/\.(png)$/i)) return "image/png";
  if (mediaUrl.match(/\.(gif)$/i)) return "image/gif";
  if (mediaUrl.match(/\.(webp)$/i)) return "image/webp";
  if (mediaUrl.match(/\.(mp4)$/i)) return "video/mp4";
  if (mediaUrl.match(/\.(webm)$/i)) return "video/webm";
  if (mediaUrl.match(/\.(mp3)$/i)) return "audio/mpeg";
  if (mediaUrl.match(/\.(m4a|mp4)$/i)) return "audio/mp4";
  if (mediaUrl.match(/\.(wav)$/i)) return "audio/wav";
  if (mediaUrl.match(/\.(ogg|opus)$/i)) return "audio/ogg; codecs=opus";
  if (mediaUrl.match(/\.(pdf)$/i)) return "application/pdf";
  return void 0;
}
function registerWhatsAppSession(userId, connectionId, socket) {
  activeSessions.set(connectionId, socket);
  if (!activeSessionConnectionsByUserId.has(userId)) {
    activeSessionConnectionsByUserId.set(userId, /* @__PURE__ */ new Set());
  }
  activeSessionConnectionsByUserId.get(userId).add(connectionId);
  console.log(`?? [WhatsApp Sender] Sessao registrada para connectionId: ${connectionId}`);
}
function unregisterWhatsAppSession(userId, connectionId) {
  if (connectionId) {
    activeSessions.delete(connectionId);
    const connectionIds2 = activeSessionConnectionsByUserId.get(userId);
    connectionIds2?.delete(connectionId);
    if (!connectionIds2 || connectionIds2.size === 0) {
      activeSessionConnectionsByUserId.delete(userId);
    }
    console.log(`?? [WhatsApp Sender] Sessao removida para connectionId: ${connectionId}`);
    return;
  }
  const connectionIds = activeSessionConnectionsByUserId.get(userId);
  if (connectionIds) {
    for (const activeConnectionId of connectionIds) {
      activeSessions.delete(activeConnectionId);
    }
    activeSessionConnectionsByUserId.delete(userId);
  }
  console.log(`?? [WhatsApp Sender] Todas as sessoes removidas para userId: ${userId}`);
}
function hasActiveWhatsAppSession(userId, connectionId) {
  if (connectionId) {
    return activeSessions.has(connectionId);
  }
  const connectionIds = activeSessionConnectionsByUserId.get(userId);
  if (!connectionIds || connectionIds.size === 0) {
    return false;
  }
  for (const activeConnectionId of connectionIds) {
    if (activeSessions.has(activeConnectionId)) {
      return true;
    }
  }
  return false;
}
async function resolveSocketSendContext(userId, options) {
  if (options?.conversationId) {
    const conversation = await storage.getConversation(options.conversationId);
    if (!conversation) {
      return null;
    }
    const connection2 = await storage.getConnectionById(conversation.connectionId);
    if (!connection2 || connection2.userId !== userId) {
      return null;
    }
    const socket2 = activeSessions.get(connection2.id);
    if (!socket2) {
      return null;
    }
    return { socket: socket2, connectionId: connection2.id };
  }
  const connection = await storage.getConnectionByUserId(userId);
  if (!connection) {
    return null;
  }
  const socket = activeSessions.get(connection.id);
  if (!socket) {
    return null;
  }
  return { socket, connectionId: connection.id };
}
async function resolveTargetConnection(userId, options) {
  if (options?.conversationId) {
    const conversation = await storage.getConversation(options.conversationId);
    if (!conversation) {
      return null;
    }
    const connection2 = await storage.getConnectionById(conversation.connectionId);
    if (!connection2 || connection2.userId !== userId) {
      return null;
    }
    return connection2;
  }
  const connection = await storage.getConnectionByUserId(userId);
  if (!connection || connection.userId !== userId) {
    return null;
  }
  return connection;
}
async function resolveOfficialSendContext(userId, phoneNumber, options) {
  const cleanNumber = normalizeBrazilWhatsAppPhone(phoneNumber);
  if (!cleanNumber) {
    return null;
  }
  const conversation = options?.conversationId ? await storage.getConversation(options.conversationId) : void 0;
  if (conversation) {
    const connection2 = await storage.getConnectionById(conversation.connectionId);
    if (!connection2 || connection2.userId !== userId || !isOfficialCoexistenceConnection(connection2)) {
      return null;
    }
    return { connection: connection2, conversation };
  }
  const connection = await storage.getConnectionByUserId(userId);
  if (!connection || !isOfficialCoexistenceConnection(connection)) {
    return null;
  }
  return {
    connection,
    conversation: {
      id: options?.conversationId || `official-${cleanNumber}`,
      connectionId: connection.id,
      contactNumber: cleanNumber,
      remoteJid: buildWhatsAppJidFromPhone(cleanNumber) || `${cleanNumber}@s.whatsapp.net`,
      contactName: cleanNumber,
      unreadCount: 0,
      lastMessageText: null,
      lastMessageTime: null,
      lastMessageFromMe: null,
      isClosed: false,
      hasReplied: false,
      isGroup: false,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    }
  };
}
async function sendWhatsAppMessageFromUser(userId, phoneNumber, message, origin = "whatsapp_sender", options) {
  try {
    const officialContext = await resolveOfficialSendContext(userId, phoneNumber, options);
    if (officialContext) {
      const result2 = await sendMetaCloudTextMessage(
        officialContext.connection,
        officialContext.conversation,
        message
      );
      console.log(`? [WhatsApp Sender] Mensagem enviada via Cloud API oficial (${result2.messageId || "sem-id"})`);
      return true;
    }
    const targetConnection = await resolveTargetConnection(userId, options);
    if (targetConnection && await resolveAppVisibleConnectionOwner(targetConnection) === "gateway") {
      const cleanNumber2 = normalizeBrazilWhatsAppPhone(phoneNumber);
      if (!cleanNumber2) {
        throw new Error("Numero de telefone invalido");
      }
      const result2 = await sendGatewayInstanceText(targetConnection.id, buildGatewayTextSendBody({
        conversationId: options?.conversationId,
        to: cleanNumber2,
        contactName: cleanNumber2,
        text: message,
        isFromAgent: true,
        source: mapOriginToGatewaySource(origin)
      }));
      console.log(`? [WhatsApp Sender] Mensagem enviada via gateway (${result2?.messageId || "sem-id"})`);
      return Boolean(result2?.success ?? true);
    }
    const socketContext = await resolveSocketSendContext(userId, options);
    if (!socketContext?.socket) {
      console.log(`?? [WhatsApp Sender] Nenhuma sessao ativa para envio (userId=${userId}, conversationId=${options?.conversationId || "sem_conversa"})`);
      return false;
    }
    const socket = socketContext.socket;
    const cleanNumber = normalizeBrazilWhatsAppPhone(phoneNumber);
    const jid = buildWhatsAppJidFromPhone(phoneNumber);
    if (!cleanNumber || !jid) {
      throw new Error("Numero de telefone invalido");
    }
    const result = await centralizedMessageSender.sendText(
      userId,
      jid,
      normalizeOutboundTextForCustomer(message),
      socket,
      origin,
      options
    );
    if (result.success) {
      console.log(`? [WhatsApp Sender] Mensagem enviada para ${cleanNumber} via sistema anti-ban (aguardou ${Math.ceil((result.waitedMs || 0) / 1e3)}s)`);
    } else {
      console.error(`? [WhatsApp Sender] Falha no envio: ${result.error}`);
    }
    return result.success;
  } catch (error) {
    console.error(`? [WhatsApp Sender] Erro ao enviar mensagem:`, error);
    return false;
  }
}
async function sendWhatsAppMediaFromUser(userId, phoneNumber, mediaUrl, caption, mimeType, origin = "whatsapp_sender", options) {
  try {
    const officialContext = await resolveOfficialSendContext(userId, phoneNumber, options);
    if (officialContext) {
      const lowerMimeType = String(mimeType || "").toLowerCase();
      const officialType = lowerMimeType.startsWith("image/") || mediaUrl.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? "image" : lowerMimeType.startsWith("video/") || mediaUrl.match(/\.(mp4|mov|avi|webm)$/i) ? "video" : lowerMimeType.startsWith("audio/") || mediaUrl.match(/\.(mp3|ogg|wav|m4a|opus)$/i) ? "audio" : "document";
      const result2 = await sendMetaCloudMediaMessage(officialContext.connection, officialContext.conversation, {
        type: officialType,
        data: mediaUrl,
        mimetype: mimeType,
        filename: mediaUrl.split("/").pop() || "arquivo",
        caption
      });
      console.log(`? [WhatsApp Sender] M?dia enviada via Cloud API oficial (${result2.messageId || "sem-id"})`);
      return true;
    }
    const targetConnection = await resolveTargetConnection(userId, options);
    if (targetConnection && await resolveAppVisibleConnectionOwner(targetConnection) === "gateway") {
      const cleanNumber2 = normalizeBrazilWhatsAppPhone(phoneNumber);
      if (!cleanNumber2) {
        throw new Error("Numero de telefone invalido");
      }
      const normalizedMimeType = normalizeRemoteMediaMimeType(mediaUrl, mimeType);
      const mediaType = inferMediaTypeFromUrlAndMime(mediaUrl, normalizedMimeType);
      const result2 = await sendGatewayInstanceMedia(targetConnection.id, {
        conversationId: options?.conversationId,
        to: cleanNumber2,
        contactName: cleanNumber2,
        type: mediaType,
        data: mediaUrl,
        mimetype: normalizedMimeType,
        filename: mediaType === "document" ? getFileNameFromUrl(mediaUrl) : void 0,
        caption,
        ptt: mediaType === "audio" ? false : void 0
      });
      console.log(`? [WhatsApp Sender] Midia enviada via gateway (${result2?.messageId || "sem-id"})`);
      return Boolean(result2?.success ?? true);
    }
    const socketContext = await resolveSocketSendContext(userId, options);
    if (!socketContext?.socket) {
      console.log(`?? [WhatsApp Sender] Nenhuma sessao ativa para envio de midia (userId=${userId}, conversationId=${options?.conversationId || "sem_conversa"})`);
      return false;
    }
    const socket = socketContext.socket;
    const cleanNumber = normalizeBrazilWhatsAppPhone(phoneNumber);
    const jid = buildWhatsAppJidFromPhone(phoneNumber);
    if (!cleanNumber || !jid) {
      throw new Error("Numero de telefone invalido");
    }
    const isImage = mimeType?.startsWith("image/") || mediaUrl.match(/\.(jpg|jpeg|png|gif|webp)$/i);
    const isVideo = mimeType?.startsWith("video/") || mediaUrl.match(/\.(mp4|mov|avi|webm)$/i);
    const isAudio = mimeType?.startsWith("audio/") || mediaUrl.match(/\.(mp3|ogg|wav|m4a)$/i);
    let result;
    if (isImage) {
      result = await centralizedMessageSender.sendImage(userId, jid, mediaUrl, caption, socket, origin, options);
    } else if (isVideo) {
      result = await centralizedMessageSender.sendVideo(userId, jid, mediaUrl, caption, socket, origin, options);
    } else if (isAudio) {
      result = await centralizedMessageSender.sendAudio(userId, jid, mediaUrl, false, socket, origin, { ...options, mimetype: mimeType });
    } else {
      result = await centralizedMessageSender.sendDocument(userId, jid, mediaUrl, mediaUrl.split("/").pop() || "arquivo", mimeType || "application/octet-stream", socket, origin, options);
    }
    if (result.success) {
      console.log(`? [WhatsApp Sender] M?dia enviada para ${cleanNumber} via sistema anti-ban (aguardou ${Math.ceil((result.waitedMs || 0) / 1e3)}s)`);
    } else {
      console.error(`? [WhatsApp Sender] Falha no envio de m?dia: ${result.error}`);
    }
    return result.success;
  } catch (error) {
    console.error(`? [WhatsApp Sender] Erro ao enviar m?dia:`, error);
    return false;
  }
}
async function sendWhatsAppButtonsFromUser(userId, phoneNumber, payload, origin = "chatbot_flow", options) {
  try {
    const officialContext = await resolveOfficialSendContext(userId, phoneNumber, options);
    if (officialContext) {
      const result2 = await sendMetaCloudButtonsMessage(officialContext.connection, officialContext.conversation, payload);
      console.log(`? [WhatsApp Sender] Bot?es enviados via Cloud API oficial (${result2.messageId || "sem-id"})`);
      return true;
    }
    const targetConnection = await resolveTargetConnection(userId, options);
    if (targetConnection && await resolveAppVisibleConnectionOwner(targetConnection) === "gateway") {
      const cleanNumber2 = normalizeBrazilWhatsAppPhone(phoneNumber);
      if (!cleanNumber2) {
        throw new Error("Numero de telefone invalido");
      }
      const result2 = await sendGatewayInstanceButtons(targetConnection.id, {
        conversationId: options?.conversationId,
        to: cleanNumber2,
        contactName: cleanNumber2,
        ...payload
      });
      console.log(`? [WhatsApp Sender] Botoes enviados via gateway (${result2?.messageId || "sem-id"})`);
      return Boolean(result2?.success ?? true);
    }
    const socketContext = await resolveSocketSendContext(userId, options);
    if (!socketContext?.socket) {
      console.log(`?? [WhatsApp Sender] Nenhuma sessao ativa para envio de botoes (userId=${userId}, conversationId=${options?.conversationId || "sem_conversa"})`);
      return false;
    }
    const socket = socketContext.socket;
    const cleanNumber = normalizeBrazilWhatsAppPhone(phoneNumber);
    const jid = buildWhatsAppJidFromPhone(phoneNumber);
    if (!cleanNumber || !jid) {
      throw new Error("Numero de telefone invalido");
    }
    const result = await centralizedMessageSender.sendButtons(userId, jid, payload, socket, origin, options);
    if (result.success) {
      console.log(`? [WhatsApp Sender] Bot?es enviados para ${cleanNumber} via sistema anti-ban`);
    } else {
      console.error(`? [WhatsApp Sender] Falha no envio de bot?es: ${result.error}`);
    }
    return result.success;
  } catch (error) {
    console.error(`? [WhatsApp Sender] Erro ao enviar bot?es:`, error);
    return false;
  }
}
async function sendWhatsAppListFromUser(userId, phoneNumber, payload, origin = "chatbot_flow", options) {
  try {
    const officialContext = await resolveOfficialSendContext(userId, phoneNumber, options);
    if (officialContext) {
      const result2 = await sendMetaCloudListMessage(officialContext.connection, officialContext.conversation, payload);
      console.log(`? [WhatsApp Sender] Lista enviada via Cloud API oficial (${result2.messageId || "sem-id"})`);
      return true;
    }
    const targetConnection = await resolveTargetConnection(userId, options);
    if (targetConnection && await resolveAppVisibleConnectionOwner(targetConnection) === "gateway") {
      const cleanNumber2 = normalizeBrazilWhatsAppPhone(phoneNumber);
      if (!cleanNumber2) {
        throw new Error("Numero de telefone invalido");
      }
      const result2 = await sendGatewayInstanceList(targetConnection.id, {
        conversationId: options?.conversationId,
        to: cleanNumber2,
        contactName: cleanNumber2,
        ...payload
      });
      console.log(`? [WhatsApp Sender] Lista enviada via gateway (${result2?.messageId || "sem-id"})`);
      return Boolean(result2?.success ?? true);
    }
    const socketContext = await resolveSocketSendContext(userId, options);
    if (!socketContext?.socket) {
      console.log(`?? [WhatsApp Sender] Nenhuma sessao ativa para envio de lista (userId=${userId}, conversationId=${options?.conversationId || "sem_conversa"})`);
      return false;
    }
    const socket = socketContext.socket;
    const cleanNumber = normalizeBrazilWhatsAppPhone(phoneNumber);
    const jid = buildWhatsAppJidFromPhone(phoneNumber);
    if (!cleanNumber || !jid) {
      throw new Error("Numero de telefone invalido");
    }
    const result = await centralizedMessageSender.sendList(userId, jid, payload, socket, origin, options);
    if (result.success) {
      console.log(`? [WhatsApp Sender] Lista enviada para ${cleanNumber} via sistema anti-ban`);
    } else {
      console.error(`? [WhatsApp Sender] Falha no envio de lista: ${result.error}`);
    }
    return result.success;
  } catch (error) {
    console.error(`? [WhatsApp Sender] Erro ao enviar lista:`, error);
    return false;
  }
}

export {
  buildOutgoingMessageFingerprint,
  calculateOutgoingMessageSimilarity,
  isOutgoingMessageNearDuplicate,
  canSendMessage,
  isIncomingMessageProcessed,
  markIncomingMessageProcessed,
  clearOutgoingDeduplicationCacheForConversation,
  WHATSAPP_CONNECTION_PROVIDERS,
  WHATSAPP_CONNECTION_METHODS,
  WHATSAPP_PROVIDER_STATUS,
  buildPendingCoexistenceProviderConfig,
  getWhatsappCoexistenceBetaStatus,
  assertWhatsappCoexistenceBetaAccess,
  isOfficialCoexistenceConnection,
  isPersistedWhatsAppConnectionOperational,
  sendMetaCloudTextMessage,
  sendMetaCloudMediaMessage,
  exchangeMetaEmbeddedSignupCode,
  buildOfficialWebhookUrl,
  createWebhookVerifyToken,
  findOfficialConnectionByPhoneNumberId,
  findOfficialConnectionByVerifyToken,
  markOfficialConnectionWebhookVerified,
  updateOfficialMessageStatus,
  isGatewayClientEnabled,
  getGatewayInstanceStatus,
  getGatewayBulkInstanceStatuses,
  getGatewayInstanceDevice,
  connectGatewayInstance,
  disconnectGatewayInstance,
  resetGatewayInstance,
  listGatewayInstanceConversations,
  listGatewayInstanceMessages,
  getGatewayInstanceMessageMedia,
  redownloadGatewayInstanceMessageMedia,
  syncGatewayInstanceGroupHistory,
  listGatewayInstanceContacts,
  validateGatewayInstanceContact,
  validateGatewayInstanceContactsBatch,
  getGatewayInstanceContactProfilePicture,
  updateGatewayInstanceContactBlockStatus,
  sendGatewayInstanceContactPresence,
  listGatewayInstanceGroups,
  createGatewayInstanceGroup,
  joinGatewayInstanceGroupByInvite,
  getGatewayInstanceGroupDetails,
  listGatewayInstanceGroupParticipants,
  updateGatewayInstanceGroupSubject,
  updateGatewayInstanceGroupDescription,
  updateGatewayInstanceGroupParticipants,
  getGatewayInstanceGroupInviteCode,
  revokeGatewayInstanceGroupInviteCode,
  leaveGatewayInstanceGroup,
  getGatewayInstanceQueue,
  clearGatewayInstanceQueue,
  previewGatewayStatusAudience,
  sendGatewayStatusPost,
  sendGatewayInstanceText,
  sendGatewayInstanceMedia,
  sendGatewayInstanceContact,
  sendGatewayInstanceLocation,
  sendGatewayInstanceButtons,
  sendGatewayInstanceList,
  sendGatewayInstanceReaction,
  sendGatewayInstanceGroupBulk,
  createGatewayManagedInstance,
  deleteGatewayManagedInstance,
  requestGatewayInstancePairingCode,
  isWhatsAppGatewayRuntime,
  isPublicInstanceApiCanaryEnabledForConnection,
  resolveWhatsAppConnectionOwner,
  isConnectionOwnedByCurrentProcess,
  resolveAppVisibleConnectionOwner,
  registerWhatsAppSession,
  unregisterWhatsAppSession,
  hasActiveWhatsAppSession,
  sendWhatsAppMessageFromUser,
  sendWhatsAppMediaFromUser,
  sendWhatsAppButtonsFromUser,
  sendWhatsAppListFromUser
};
