import {
  getAgendamento2RuntimeState,
  getCourseSchedulingRuntimeState,
  getModuleSchedulingSettings,
  getSessions,
  init_textUtils,
  messageQueueService,
  processResponsePlaceholders
} from "./chunk-JDBD3TU2.js";
import {
  parseCalendarDateTimeWithTimeZone
} from "./chunk-QCEDG5RZ.js";
import {
  shouldBlockAutomatedConversationSend
} from "./chunk-R2H3ZHAP.js";
import {
  storage,
  supabase
} from "./chunk-7SPF5OKO.js";
import {
  formatBrazilWallClockDate
} from "./chunk-XZFDVJYL.js";
import {
  getLLMClient
} from "./chunk-M7TXNZTC.js";
import {
  db
} from "./chunk-R6CXRQMB.js";
import {
  businessAgentConfigs,
  conversations,
  messages
} from "./chunk-JC6URYU5.js";

// server/appointmentReminderService.ts
import { eq, and, desc } from "drizzle-orm";
init_textUtils();

// shared/courseReminderFlow.ts
var DEFAULT_COURSE_REMINDER_HOURS_BEFORE = 1;
function getDefaultCourseReminderFlowItems() {
  return [
    {
      id: "course-reminder-step-1",
      order: 0,
      type: "text",
      text: "Ol\xE1 {nome}! Eu sou a Vit\xF3ria da coordena\xE7\xE3o do Instituto Mix, tudo bem?"
    },
    {
      id: "course-reminder-step-2",
      order: 1,
      type: "text",
      text: "Estou mandando mensagem s\xF3 para te avisar que a coordena\xE7\xE3o j\xE1 est\xE1 te aguardando para realizar sua inscri\xE7\xE3o no curso gratuito.\n{referencia_agendamento}, \xE0s {hora_agendamento}.\nPosso confirmar sua inscri\xE7\xE3o?"
    },
    {
      id: "course-reminder-step-3",
      order: 2,
      type: "text",
      text: "Parab\xE9ns pela oportunidade, sucesso em sua carreira profissional \u2728"
    }
  ];
}
function normalizeCourseReminderFlowItems(rawValue) {
  if (!Array.isArray(rawValue)) {
    return getDefaultCourseReminderFlowItems();
  }
  const normalized = rawValue.map((entry, index) => {
    if (!entry || typeof entry !== "object") {
      return null;
    }
    const record = entry;
    const text = String(record.text || "").trim();
    if (!text) {
      return null;
    }
    return {
      id: String(record.id || `course-reminder-step-${index + 1}`),
      order: Number.isFinite(Number(record.order)) ? Number(record.order) : index,
      type: "text",
      text
    };
  }).filter((entry) => Boolean(entry)).sort((left, right) => left.order - right.order).map((entry, index) => ({
    ...entry,
    order: index
  }));
  return normalized.length > 0 ? normalized : getDefaultCourseReminderFlowItems();
}

// shared/agendamento2ReminderFlow.ts
var DEFAULT_AGENDAMENTO2_REMINDER_HOURS_BEFORE = 1;
function getDefaultAgendamento2ReminderFlowItems() {
  return [
    {
      id: "agendamento2-reminder-step-1",
      order: 0,
      type: "text",
      text: "Oi {nome}! Passando para lembrar do seu atendimento {referencia_agendamento}."
    },
    {
      id: "agendamento2-reminder-step-2",
      order: 1,
      type: "text",
      text: "Seu horario esta confirmado para {data_agendamento_extenso}, as {hora_agendamento}. Se precisar ajustar algo, me avise por aqui."
    }
  ];
}
function normalizeAgendamento2ReminderFlowItems(rawValue) {
  if (!Array.isArray(rawValue)) {
    return getDefaultAgendamento2ReminderFlowItems();
  }
  const normalized = rawValue.map((entry, index) => {
    if (!entry || typeof entry !== "object") {
      return null;
    }
    const record = entry;
    const text = String(record.text || "").trim();
    if (!text) {
      return null;
    }
    return {
      id: String(record.id || `agendamento2-reminder-step-${index + 1}`),
      order: Number.isFinite(Number(record.order)) ? Number(record.order) : index,
      type: "text",
      text
    };
  }).filter((entry) => Boolean(entry)).sort((left, right) => left.order - right.order).map((entry, index) => ({
    ...entry,
    order: index
  }));
  return normalized.length > 0 ? normalized : getDefaultAgendamento2ReminderFlowItems();
}

// server/appointmentReminderService.ts
var CHECK_INTERVAL_MS = 60 * 1e3;
var sentRemindersCache = /* @__PURE__ */ new Map();
setInterval(() => {
  const now = Date.now();
  const ONE_DAY = 24 * 60 * 60 * 1e3;
  for (const [key, timestamp] of sentRemindersCache.entries()) {
    if (now - timestamp > ONE_DAY) {
      sentRemindersCache.delete(key);
    }
  }
}, 60 * 60 * 1e3);
async function getUserConnectionAndSession(userId) {
  const connection = await storage.getConnectionByUserId(userId);
  if (!connection) {
    return { connection: null, session: null };
  }
  const sessions = getSessions();
  return {
    connection,
    session: sessions.get(connection.id) || null
  };
}
function parseAppointmentDateTime(appointmentDate, startTime) {
  return parseCalendarDateTimeWithTimeZone(`${appointmentDate}T${String(startTime).slice(0, 8)}`);
}
function getBrazilNow() {
  return /* @__PURE__ */ new Date();
}
function getBrazilIsoDate(date = getBrazilNow()) {
  return formatBrazilWallClockDate(date) || date.toISOString().slice(0, 10);
}
function calculateHoursUntilReminderAppointment(appointmentDate, startTime, reference = /* @__PURE__ */ new Date()) {
  const scheduledAt = parseAppointmentDateTime(appointmentDate, startTime);
  return (scheduledAt.getTime() - reference.getTime()) / (1e3 * 60 * 60);
}
function applyLiteralToken(source, token, value) {
  if (!source || !token) {
    return source;
  }
  return source.split(token).join(value);
}
function buildCourseReminderReferenceLabel(appointmentDate) {
  const now = getBrazilNow();
  const appointmentDateKey = getBrazilIsoDate(appointmentDate);
  const todayKey = getBrazilIsoDate(now);
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowKey = getBrazilIsoDate(tomorrow);
  const weekdayLabel = appointmentDate.toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    weekday: "long"
  });
  const dateLabel = appointmentDate.toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "numeric",
    month: "long"
  });
  if (appointmentDateKey === todayKey) {
    return `Hoje, ${dateLabel}`;
  }
  if (appointmentDateKey === tomorrowKey) {
    return `Amanh\xE3, ${dateLabel}`;
  }
  return `${weekdayLabel}, ${dateLabel}`;
}
function hydrateCourseReminderText(params) {
  const appointmentDate = parseAppointmentDateTime(params.scheduledDate, params.scheduledTime);
  const dateLabel = appointmentDate.toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  });
  const timeLabel = params.scheduledTime.slice(0, 5);
  const weekdayLabel = appointmentDate.toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    weekday: "long"
  });
  const extendedDateLabel = `${weekdayLabel}, ${appointmentDate.toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "numeric",
    month: "long",
    year: "numeric"
  })}`;
  let hydrated = processResponsePlaceholders(params.text, params.contactName || void 0);
  hydrated = applyLiteralToken(hydrated, "{hora_agendamento}", timeLabel);
  hydrated = applyLiteralToken(hydrated, "{data_agendamento}", dateLabel);
  hydrated = applyLiteralToken(hydrated, "{dia_semana}", weekdayLabel);
  hydrated = applyLiteralToken(hydrated, "{data_agendamento_extenso}", extendedDateLabel);
  hydrated = applyLiteralToken(
    hydrated,
    "{referencia_agendamento}",
    buildCourseReminderReferenceLabel(appointmentDate)
  );
  return hydrated.trim();
}
function hydrateReminderText(params) {
  const appointmentDate = parseAppointmentDateTime(params.scheduledDate, params.scheduledTime);
  const dateLabel = formatBrazilWallClockDate(appointmentDate, {
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  });
  const timeLabel = params.scheduledTime.slice(0, 5);
  const weekdayLabel = formatBrazilWallClockDate(appointmentDate, { weekday: "long" });
  const extendedDateLabel = `${weekdayLabel}, ${formatBrazilWallClockDate(appointmentDate, {
    day: "numeric",
    month: "long",
    year: "numeric"
  })}`;
  let hydrated = processResponsePlaceholders(params.text, params.contactName || void 0);
  hydrated = applyLiteralToken(hydrated, "{hora_agendamento}", timeLabel);
  hydrated = applyLiteralToken(hydrated, "{data_agendamento}", dateLabel);
  hydrated = applyLiteralToken(hydrated, "{dia_semana}", weekdayLabel);
  hydrated = applyLiteralToken(hydrated, "{data_agendamento_extenso}", extendedDateLabel);
  hydrated = applyLiteralToken(
    hydrated,
    "{referencia_agendamento}",
    buildCourseReminderReferenceLabel(appointmentDate)
  );
  return hydrated.trim();
}
function shouldSendReminderForHoursUntilAppointment(hoursUntilAppointment, reminderHour, checkIntervalMs = CHECK_INTERVAL_MS) {
  if (!Number.isFinite(hoursUntilAppointment) || !Number.isFinite(reminderHour) || reminderHour <= 0) {
    return false;
  }
  const intervalHours = checkIntervalMs / (1e3 * 60 * 60);
  return hoursUntilAppointment <= reminderHour && hoursUntilAppointment > reminderHour - intervalHours;
}
var AppointmentReminderService = class {
  constructor() {
    this.checkInterval = null;
    this.isRunning = false;
  }
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    console.log("\u{1F4C5} [APPOINTMENT-REMINDER] Servi\xE7o de lembretes iniciado");
    this.checkInterval = setInterval(() => this.processReminders(), CHECK_INTERVAL_MS);
    void this.processReminders();
  }
  stop() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    this.isRunning = false;
    console.log("\u{1F6D1} [APPOINTMENT-REMINDER] Servi\xE7o parado");
  }
  async processCourseUserReminders(config) {
    try {
      const now = getBrazilNow();
      const today = getBrazilIsoDate(now);
      const lastRelevantDate = getBrazilIsoDate(
        new Date(now.getTime() + (config.reminder_hours_before + 24) * 60 * 60 * 1e3)
      );
      const { data: insights, error } = await supabase.from("course_scheduling_insights").select(
        "id, user_id, connection_id, conversation_id, contact_name, contact_number, agreed_schedule, scheduled_date, scheduled_time, reminder_times_sent"
      ).eq("user_id", config.user_id).eq("status", "scheduled").eq("reminder_sent", false).not("scheduled_date", "is", null).not("scheduled_time", "is", null).gte("scheduled_date", today).lte("scheduled_date", lastRelevantDate).order("scheduled_date", { ascending: true }).order("scheduled_time", { ascending: true });
      if (error || !insights || insights.length === 0) {
        return;
      }
      for (const insight of insights) {
        if (!insight.scheduled_date || !insight.scheduled_time) {
          continue;
        }
        const hoursUntilAppointment = calculateHoursUntilReminderAppointment(
          insight.scheduled_date,
          insight.scheduled_time,
          now
        );
        if (hoursUntilAppointment <= 0) {
          continue;
        }
        const reminderHour = config.reminder_hours_before || DEFAULT_COURSE_REMINDER_HOURS_BEFORE;
        const sentTimes = Array.isArray(insight.reminder_times_sent) ? insight.reminder_times_sent : [];
        if (sentTimes.includes(reminderHour)) {
          continue;
        }
        const cacheKey = `course_${insight.id}_${reminderHour}h`;
        if (sentRemindersCache.has(cacheKey)) {
          continue;
        }
        if (!shouldSendReminderForHoursUntilAppointment(hoursUntilAppointment, reminderHour)) {
          continue;
        }
        const sent = await this.sendCourseReminderFlow(insight, config.reminder_flow);
        if (!sent) {
          continue;
        }
        const updatedSentTimes = [...sentTimes, reminderHour];
        await supabase.from("course_scheduling_insights").update({
          reminder_times_sent: updatedSentTimes,
          reminder_sent: true,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("id", insight.id);
        sentRemindersCache.set(cacheKey, Date.now());
      }
    } catch (error) {
      console.error(`Erro ao processar lembretes de cursos para ${config.user_id}:`, error);
    }
  }
  async sendCourseReminderFlow(insight, reminderFlow) {
    if (!insight.scheduled_date || !insight.scheduled_time) {
      return false;
    }
    const flowItems = normalizeCourseReminderFlowItems(reminderFlow);
    if (flowItems.length === 0) {
      return false;
    }
    try {
      const connection = await storage.getConnectionByUserId(insight.user_id, insight.connection_id);
      const session = connection ? getSessions().get(connection.id) || null : null;
      if (!connection || !session?.socket) {
        console.log(`Conexao de curso indisponivel para ${insight.user_id}`);
        return false;
      }
      const conversation = await db.query.conversations.findFirst({
        where: and(
          eq(conversations.id, insight.conversation_id),
          eq(conversations.connectionId, connection.id)
        )
      });
      if (!conversation) {
        console.log(`Conversa de curso nao encontrada: ${insight.conversation_id}`);
        return false;
      }
      const jid = conversation.remoteJid || `${insight.contact_number}@s.whatsapp.net`;
      const pauseCheck = await shouldBlockAutomatedConversationSend({
        userId: insight.user_id,
        jid,
        conversationId: conversation.id,
        origin: "course_scheduling"
      });
      if (pauseCheck.blocked) {
        console.log(`Lembrete de curso bloqueado para conversa ${conversation.id}`);
        return false;
      }
      let lastSentText = "";
      for (let index = 0; index < flowItems.length; index++) {
        const item = flowItems[index];
        const text = hydrateCourseReminderText({
          text: item.text,
          contactName: insight.contact_name,
          scheduledDate: insight.scheduled_date,
          scheduledTime: insight.scheduled_time
        });
        if (!text) {
          continue;
        }
        if (index > 0) {
          await new Promise((resolve) => setTimeout(resolve, 1200));
        }
        const sentMessage = await messageQueueService.executeWithDelay(connection.id, "lembrete de curso", async () => {
          const recheck = await shouldBlockAutomatedConversationSend({
            userId: insight.user_id,
            jid,
            conversationId: conversation.id,
            origin: "course_scheduling"
          });
          if (recheck.blocked) {
            throw new Error("AUTOMATION_PAUSE_BLOCKED");
          }
          return await session.socket.sendMessage(jid, { text });
        });
        if (sentMessage?.key.id) {
          await storage.createMessage({
            conversationId: conversation.id,
            messageId: sentMessage.key.id,
            fromMe: true,
            text,
            timestamp: /* @__PURE__ */ new Date(),
            status: "sent"
          });
        }
        lastSentText = text;
      }
      if (lastSentText) {
        await storage.updateConversation(conversation.id, {
          lastMessageText: lastSentText,
          lastMessageTime: /* @__PURE__ */ new Date(),
          lastMessageFromMe: true
        });
      }
      return Boolean(lastSentText);
    } catch (error) {
      console.error("Erro ao enviar lembrete de curso:", error);
      return false;
    }
  }
  /**
   * Processa todos os agendamentos que precisam de lembrete
   */
  async processReminders() {
    try {
      console.log("\u{1F50D} [APPOINTMENT-REMINDER] Verificando agendamentos...");
      const { data: configs, error: configError } = await supabase.from("scheduling_config").select("*").eq("is_enabled", true).eq("send_reminder", true);
      if (configError && !configs) {
        console.log("\u{1F4C5} [APPOINTMENT-REMINDER] Nenhum usu\xE1rio com lembretes ativos");
        return;
      }
      for (const config of configs || []) {
        await this.processUserReminders(config);
      }
      await this.processEmbeddedModuleReminders("salon", "salon_config", "appointments");
      await this.processEmbeddedModuleReminders("provider", "provider_config", "provider_appointments");
      await this.processEmbeddedModuleReminders("clinic", "clinic_config", "clinic_appointments");
      await this.processCourseModuleReminders();
      await this.processAgendamento2ModuleReminders();
      await this.processAgendamento3ModuleReminders();
    } catch (error) {
      console.error("\u274C [APPOINTMENT-REMINDER] Erro ao processar lembretes:", error);
    }
  }
  /**
   * Processa lembretes para um usuário específico
   * Suporta múltiplos tempos de lembrete (ex: 24h, 2h, 30min antes)
   */
  async processEmbeddedModuleReminders(moduleName, configTable, appointmentsTable) {
    const { data: rawConfigs, error } = await supabase.from(configTable).select("user_id, opening_hours, reminder_message, salon_name, service_name, address").eq("is_active", true);
    if (error || !rawConfigs) {
      if (error) {
        console.error(`\xE2\x9D\u0152 [APPOINTMENT-REMINDER] Erro ao buscar configs de ${moduleName}:`, error);
      }
      return;
    }
    for (const rawConfig of rawConfigs) {
      const settings = getModuleSchedulingSettings(rawConfig.opening_hours);
      if (!settings.send_reminder) {
        continue;
      }
      await this.processModuleUserReminders(
        {
          user_id: rawConfig.user_id,
          is_enabled: true,
          send_reminder: settings.send_reminder,
          reminder_hours_before: settings.reminder_hours_before,
          reminder_times: settings.reminder_times,
          reminder_message: rawConfig.reminder_message || "",
          service_name: rawConfig.service_name || rawConfig.salon_name || moduleName,
          location: rawConfig.address || ""
        },
        appointmentsTable,
        moduleName
      );
    }
  }
  async processUserReminders(config) {
    await this.processModuleUserReminders(config, "appointments", "scheduling");
  }
  async processCourseModuleReminders() {
    const { data: rawConfigs, error } = await supabase.from("course_config").select(
      "user_id, is_active, scheduling_tracker_enabled, course_reminder_enabled, course_reminder_hours_before, course_reminder_flow"
    ).eq("is_active", true).eq("course_reminder_enabled", true);
    if (error || !rawConfigs) {
      if (error) {
        console.error("\xE2\x9D\u0152 [APPOINTMENT-REMINDER] Erro ao buscar configs de cursos:", error);
      }
      return;
    }
    for (const rawConfig of rawConfigs) {
      const runtimeState = await getCourseSchedulingRuntimeState(rawConfig.user_id);
      if (!runtimeState.trackingEnabled) {
        continue;
      }
      await this.processCourseUserReminders({
        user_id: rawConfig.user_id,
        reminder_hours_before: Number(rawConfig.course_reminder_hours_before) > 0 ? Number(rawConfig.course_reminder_hours_before) : DEFAULT_COURSE_REMINDER_HOURS_BEFORE,
        reminder_flow: normalizeCourseReminderFlowItems(rawConfig.course_reminder_flow)
      });
    }
  }
  async processAgendamento2UserReminders(config) {
    try {
      const now = getBrazilNow();
      const today = getBrazilIsoDate(now);
      const lastRelevantDate = getBrazilIsoDate(
        new Date(now.getTime() + (config.reminder_hours_before + 24) * 60 * 60 * 1e3)
      );
      const { data: insights, error } = await supabase.from("agendamento2_insights").select(
        "id, user_id, connection_id, conversation_id, contact_name, contact_number, agreed_schedule, scheduled_date, scheduled_time, reminder_times_sent"
      ).eq("user_id", config.user_id).eq("status", "scheduled").eq("reminder_sent", false).not("scheduled_date", "is", null).not("scheduled_time", "is", null).gte("scheduled_date", today).lte("scheduled_date", lastRelevantDate).order("scheduled_date", { ascending: true }).order("scheduled_time", { ascending: true });
      if (error || !insights || insights.length === 0) {
        return;
      }
      for (const insight of insights) {
        if (!insight.scheduled_date || !insight.scheduled_time) {
          continue;
        }
        const hoursUntilAppointment = calculateHoursUntilReminderAppointment(
          insight.scheduled_date,
          insight.scheduled_time,
          now
        );
        if (hoursUntilAppointment <= 0) {
          continue;
        }
        const reminderHour = config.reminder_hours_before || DEFAULT_AGENDAMENTO2_REMINDER_HOURS_BEFORE;
        const sentTimes = Array.isArray(insight.reminder_times_sent) ? insight.reminder_times_sent : [];
        if (sentTimes.includes(reminderHour)) {
          continue;
        }
        const cacheKey = `agendamento2_${insight.id}_${reminderHour}h`;
        if (sentRemindersCache.has(cacheKey)) {
          continue;
        }
        if (!shouldSendReminderForHoursUntilAppointment(hoursUntilAppointment, reminderHour)) {
          continue;
        }
        const sent = await this.sendAgendamento2ReminderFlow(insight, config.reminder_flow);
        if (!sent) {
          continue;
        }
        const updatedSentTimes = [...sentTimes, reminderHour];
        await supabase.from("agendamento2_insights").update({
          reminder_times_sent: updatedSentTimes,
          reminder_sent: true,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("id", insight.id);
        sentRemindersCache.set(cacheKey, Date.now());
      }
    } catch (error) {
      console.error(`Erro ao processar lembretes do Agendamento 2.0 para ${config.user_id}:`, error);
    }
  }
  async sendAgendamento2ReminderFlow(insight, reminderFlow) {
    if (!insight.scheduled_date || !insight.scheduled_time) {
      return false;
    }
    const flowItems = normalizeAgendamento2ReminderFlowItems(reminderFlow);
    if (flowItems.length === 0) {
      return false;
    }
    try {
      const connection = await storage.getConnectionByUserId(insight.user_id, insight.connection_id);
      const session = connection ? getSessions().get(connection.id) || null : null;
      if (!connection || !session?.socket) {
        console.log(`Conexao do Agendamento 2.0 indisponivel para ${insight.user_id}`);
        return false;
      }
      const conversation = await db.query.conversations.findFirst({
        where: and(
          eq(conversations.id, insight.conversation_id),
          eq(conversations.connectionId, connection.id)
        )
      });
      if (!conversation) {
        console.log(`Conversa do Agendamento 2.0 nao encontrada: ${insight.conversation_id}`);
        return false;
      }
      const jid = conversation.remoteJid || `${insight.contact_number}@s.whatsapp.net`;
      const pauseCheck = await shouldBlockAutomatedConversationSend({
        userId: insight.user_id,
        jid,
        conversationId: conversation.id,
        origin: "agendamento2"
      });
      if (pauseCheck.blocked) {
        console.log(`Lembrete do Agendamento 2.0 bloqueado para conversa ${conversation.id}`);
        return false;
      }
      let lastSentText = "";
      for (let index = 0; index < flowItems.length; index++) {
        const item = flowItems[index];
        const text = hydrateReminderText({
          text: item.text,
          contactName: insight.contact_name,
          scheduledDate: insight.scheduled_date,
          scheduledTime: insight.scheduled_time
        });
        if (!text) {
          continue;
        }
        const sentMessage = await messageQueueService.executeWithDelay(
          connection.id,
          "lembrete do agendamento 2.0",
          async () => {
            const recheck = await shouldBlockAutomatedConversationSend({
              userId: insight.user_id,
              jid,
              conversationId: conversation.id,
              origin: "agendamento2"
            });
            if (recheck.blocked) {
              throw new Error("AUTOMATION_PAUSE_BLOCKED");
            }
            return session.socket.sendMessage(jid, { text });
          }
        );
        if (sentMessage?.key?.id) {
          await storage.createMessage({
            conversationId: conversation.id,
            messageId: sentMessage.key.id,
            fromMe: true,
            text,
            timestamp: /* @__PURE__ */ new Date(),
            status: "sent"
          });
        }
        lastSentText = text;
      }
      if (!lastSentText) {
        return false;
      }
      await storage.updateConversation(conversation.id, {
        lastMessageText: lastSentText,
        lastMessageTime: /* @__PURE__ */ new Date()
      });
      return true;
    } catch (error) {
      console.error(`Erro ao enviar lembrete do Agendamento 2.0 para ${insight.contact_number}:`, error);
      return false;
    }
  }
  async processAgendamento2ModuleReminders() {
    const { data: rawConfigs, error } = await supabase.from("agendamento2_config").select(
      "user_id, is_active, scheduling_tracker_enabled, reminder_enabled, reminder_hours_before, reminder_flow"
    ).eq("reminder_enabled", true);
    if (error || !rawConfigs) {
      if (error) {
        console.error("\u274C [APPOINTMENT-REMINDER] Erro ao buscar configs do Agendamento 2.0:", error);
      }
      return;
    }
    for (const rawConfig of rawConfigs) {
      const runtimeState = await getAgendamento2RuntimeState(rawConfig.user_id);
      if (!runtimeState.trackingEnabled) {
        continue;
      }
      await this.processAgendamento2UserReminders({
        user_id: rawConfig.user_id,
        reminder_hours_before: Number(rawConfig.reminder_hours_before) > 0 ? Number(rawConfig.reminder_hours_before) : DEFAULT_AGENDAMENTO2_REMINDER_HOURS_BEFORE,
        reminder_flow: normalizeAgendamento2ReminderFlowItems(rawConfig.reminder_flow)
      });
    }
  }
  async processAgendamento3UserReminders(config) {
    try {
      const now = getBrazilNow();
      const today = getBrazilIsoDate(now);
      const lastRelevantDate = getBrazilIsoDate(
        new Date(now.getTime() + (config.reminder_hours_before + 24) * 60 * 60 * 1e3)
      );
      const { data: appointments, error } = await supabase.from("appointments").select("id, user_id, conversation_id, client_name, client_phone, service_name, appointment_date, start_time, reminder_times_sent").eq("user_id", config.user_id).in("status", ["pending", "confirmed"]).eq("internal_notes", "agendamento3_agentic").not("appointment_date", "is", null).not("start_time", "is", null).gte("appointment_date", today).lte("appointment_date", lastRelevantDate).order("appointment_date", { ascending: true }).order("start_time", { ascending: true });
      if (error || !appointments || appointments.length === 0) {
        return;
      }
      for (const appointment of appointments) {
        if (!appointment.appointment_date || !appointment.start_time) {
          continue;
        }
        const hoursUntilAppointment = calculateHoursUntilReminderAppointment(
          appointment.appointment_date,
          appointment.start_time,
          now
        );
        if (hoursUntilAppointment <= 0) {
          continue;
        }
        const reminderHour = config.reminder_hours_before || DEFAULT_AGENDAMENTO2_REMINDER_HOURS_BEFORE;
        const sentTimes = Array.isArray(appointment.reminder_times_sent) ? appointment.reminder_times_sent : [];
        if (sentTimes.includes(reminderHour)) {
          continue;
        }
        const cacheKey = `agendamento3_${appointment.id}_${reminderHour}h`;
        if (sentRemindersCache.has(cacheKey)) {
          continue;
        }
        if (!shouldSendReminderForHoursUntilAppointment(hoursUntilAppointment, reminderHour)) {
          continue;
        }
        const sent = await this.sendAgendamento3ReminderFlow(appointment, config.reminder_flow);
        if (!sent) {
          continue;
        }
        const updatedSentTimes = [...sentTimes, reminderHour];
        await supabase.from("appointments").update({
          reminder_times_sent: updatedSentTimes,
          reminder_sent: true,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("id", appointment.id);
        sentRemindersCache.set(cacheKey, Date.now());
      }
    } catch (error) {
      console.error(`Erro ao processar lembretes do Agendamento 3.0 para ${config.user_id}:`, error);
    }
  }
  async sendAgendamento3ReminderFlow(appointment, reminderFlow) {
    if (!appointment.appointment_date || !appointment.start_time || !appointment.client_phone) {
      return false;
    }
    const flowItems = normalizeAgendamento2ReminderFlowItems(reminderFlow);
    if (flowItems.length === 0) {
      return false;
    }
    try {
      let conversation = appointment.conversation_id ? await db.query.conversations.findFirst({
        where: eq(conversations.id, appointment.conversation_id)
      }) : null;
      const connection = conversation?.connectionId ? await storage.getConnectionByUserId(appointment.user_id, conversation.connectionId) : await storage.getConnectionByUserId(appointment.user_id);
      const session = connection ? getSessions().get(connection.id) || null : null;
      if (!connection || !session?.socket) {
        console.log(`Conexao do Agendamento 3.0 indisponivel para ${appointment.user_id}`);
        return false;
      }
      if (!conversation) {
        conversation = await db.query.conversations.findFirst({
          where: and(
            eq(conversations.connectionId, connection.id),
            eq(conversations.contactNumber, appointment.client_phone)
          )
        });
      }
      if (!conversation) {
        console.log(`Conversa do Agendamento 3.0 nao encontrada para ${appointment.client_phone}`);
        return false;
      }
      const jid = conversation.remoteJid || `${appointment.client_phone}@s.whatsapp.net`;
      const pauseCheck = await shouldBlockAutomatedConversationSend({
        userId: appointment.user_id,
        jid,
        conversationId: conversation.id,
        origin: "agendamento3"
      });
      if (pauseCheck.blocked) {
        console.log(`Lembrete do Agendamento 3.0 bloqueado para conversa ${conversation.id}`);
        return false;
      }
      let lastSentText = "";
      for (const item of flowItems) {
        const text = hydrateReminderText({
          text: item.text,
          contactName: appointment.client_name || void 0,
          scheduledDate: appointment.appointment_date,
          scheduledTime: appointment.start_time
        });
        if (!text) {
          continue;
        }
        const sentMessage = await messageQueueService.executeWithDelay(
          connection.id,
          "lembrete do agendamento 3.0",
          async () => {
            const recheck = await shouldBlockAutomatedConversationSend({
              userId: appointment.user_id,
              jid,
              conversationId: conversation.id,
              origin: "agendamento3"
            });
            if (recheck.blocked) {
              throw new Error("AUTOMATION_PAUSE_BLOCKED");
            }
            return session.socket.sendMessage(jid, { text });
          }
        );
        if (sentMessage?.key?.id) {
          await storage.createMessage({
            conversationId: conversation.id,
            messageId: sentMessage.key.id,
            fromMe: true,
            text,
            timestamp: /* @__PURE__ */ new Date(),
            status: "sent"
          });
        }
        lastSentText = text;
      }
      if (!lastSentText) {
        return false;
      }
      await storage.updateConversation(conversation.id, {
        lastMessageText: lastSentText,
        lastMessageTime: /* @__PURE__ */ new Date()
      });
      return true;
    } catch (error) {
      console.error(`Erro ao enviar lembrete do Agendamento 3.0 para ${appointment.client_phone}:`, error);
      return false;
    }
  }
  async processAgendamento3ModuleReminders() {
    const { data: rawConfigs, error } = await supabase.from("agendamento3_config").select("user_id, is_active, reminder_enabled, reminder_hours_before, reminder_flow").eq("is_active", true).eq("reminder_enabled", true);
    if (error || !rawConfigs) {
      if (error) {
        console.error("\u274C [APPOINTMENT-REMINDER] Erro ao buscar configs do Agendamento 3.0:", error);
      }
      return;
    }
    for (const rawConfig of rawConfigs) {
      await this.processAgendamento3UserReminders({
        user_id: rawConfig.user_id,
        reminder_hours_before: Number(rawConfig.reminder_hours_before) > 0 ? Number(rawConfig.reminder_hours_before) : DEFAULT_AGENDAMENTO2_REMINDER_HOURS_BEFORE,
        reminder_flow: normalizeAgendamento2ReminderFlowItems(rawConfig.reminder_flow)
      });
    }
  }
  async processModuleUserReminders(config, appointmentsTable, moduleName) {
    try {
      const now = /* @__PURE__ */ new Date();
      const brazilNow = getBrazilNow();
      const reminderTimes = config.reminder_times && Array.isArray(config.reminder_times) && config.reminder_times.length > 0 ? [...config.reminder_times].sort((a, b) => b - a) : [config.reminder_hours_before || 24];
      const maxReminder = Math.max(...reminderTimes);
      const today = formatBrazilWallClockDate(brazilNow) || "";
      const dayAfterTomorrow = formatBrazilWallClockDate(
        new Date(brazilNow.getTime() + maxReminder * 60 * 60 * 1e3 + 24 * 60 * 60 * 1e3)
      ) || "";
      const { data: appointments, error } = await supabase.from(appointmentsTable).select("*, reminder_times_sent").eq("user_id", config.user_id).in("status", ["confirmed", "pending"]).gte("appointment_date", today).lte("appointment_date", dayAfterTomorrow).order("appointment_date", { ascending: true }).order("start_time", { ascending: true });
      if (error || !appointments || appointments.length === 0) {
        return;
      }
      console.log(`\u{1F4C5} [APPOINTMENT-REMINDER] ${appointments.length} agendamentos encontrados para user ${config.user_id}`);
      for (const appointment of appointments) {
        const appointmentDateTime = parseAppointmentDateTime(appointment.appointment_date, appointment.start_time);
        const hoursUntilAppointment = (appointmentDateTime.getTime() - now.getTime()) / (1e3 * 60 * 60);
        if (hoursUntilAppointment <= 0) continue;
        const sentTimes = appointment.reminder_times_sent || [];
        for (const reminderHour of reminderTimes) {
          if (sentTimes.includes(reminderHour)) continue;
          const cacheKey = `${appointment.id}_${reminderHour}h`;
          if (sentRemindersCache.has(cacheKey)) continue;
          if (shouldSendReminderForHoursUntilAppointment(hoursUntilAppointment, reminderHour)) {
            console.log(`\u{1F4E4} [APPOINTMENT-REMINDER] Enviando lembrete ${reminderHour}h para ${appointment.client_name} (${cacheKey})`);
            await this.sendReminderViaAI(appointment, config, reminderHour, appointmentsTable);
            const updatedSentTimes = [...sentTimes, reminderHour];
            await supabase.from(appointmentsTable).update({
              reminder_times_sent: updatedSentTimes,
              // Manter compatibilidade: marcar reminder_sent=true quando todos foram enviados
              reminder_sent: updatedSentTimes.length >= reminderTimes.length
            }).eq("id", appointment.id);
            sentRemindersCache.set(cacheKey, Date.now());
            break;
          }
        }
      }
    } catch (error) {
      console.error(`\u274C [APPOINTMENT-REMINDER] Erro ao processar user ${config.user_id}:`, error);
    }
  }
  /**
   * Envia lembrete usando a IA do agente (mensagem natural, não automática)
   */
  async sendReminderViaAI(appointment, config, reminderHour, appointmentsTable = "appointments") {
    const userId = config.user_id;
    const clientPhone = appointment.client_phone;
    console.log(`\u{1F4E4} [APPOINTMENT-REMINDER] Preparando lembrete para ${clientPhone} - ${appointment.client_name}`);
    try {
      const { connection, session } = await getUserConnectionAndSession(userId);
      if (!session?.socket) {
        console.log(`\u26A0\uFE0F [APPOINTMENT-REMINDER] WhatsApp n\xE3o conectado para user ${userId}`);
        return;
      }
      if (!connection) {
        console.log(`\u26A0\uFE0F [APPOINTMENT-REMINDER] Conex\xE3o n\xE3o encontrada para user ${userId}`);
        return;
      }
      const conversation = await db.query.conversations.findFirst({
        where: and(
          eq(conversations.connectionId, connection.id),
          eq(conversations.contactNumber, clientPhone)
        )
      });
      if (!conversation) {
        console.log(`\u26A0\uFE0F [APPOINTMENT-REMINDER] Conversa n\xE3o encontrada com ${clientPhone}`);
        return;
      }
      const agentConfig = await db.query.businessAgentConfigs.findFirst({
        where: eq(businessAgentConfigs.userId, userId)
      });
      const recentMessages = await db.query.messages.findMany({
        where: eq(messages.conversationId, conversation.id),
        orderBy: [desc(messages.timestamp)],
        limit: 10
      });
      const reminderMessage = await this.generateReminderWithAI(
        appointment,
        config,
        agentConfig,
        recentMessages.reverse()
      );
      if (!reminderMessage) {
        console.log(`\u26A0\uFE0F [APPOINTMENT-REMINDER] IA n\xE3o gerou mensagem de lembrete`);
        return;
      }
      const jid = conversation.remoteJid || `${clientPhone}@s.whatsapp.net`;
      console.log(`\u{1F4E4} [APPOINTMENT-REMINDER] Enviando para ${jid}: ${reminderMessage.substring(0, 50)}...`);
      const pauseCheck = await shouldBlockAutomatedConversationSend({
        userId,
        jid,
        conversationId: conversation.id,
        origin: "scheduling"
      });
      if (pauseCheck.blocked) {
        console.log(`\u23F8\uFE0F [APPOINTMENT-REMINDER] Lembrete bloqueado para conversa ${conversation.id} porque a IA est\xE1 pausada`);
        return;
      }
      const sentMessage = await messageQueueService.executeWithDelay(connection.id, "lembrete de agendamento", async () => {
        const recheck = await shouldBlockAutomatedConversationSend({
          userId,
          jid,
          conversationId: conversation.id,
          origin: "scheduling"
        });
        if (recheck.blocked) {
          throw new Error("AUTOMATION_PAUSE_BLOCKED");
        }
        return await session.socket.sendMessage(jid, { text: reminderMessage });
      });
      if (sentMessage?.key.id) {
        await storage.createMessage({
          conversationId: conversation.id,
          messageId: sentMessage.key.id,
          fromMe: true,
          text: reminderMessage,
          timestamp: /* @__PURE__ */ new Date(),
          status: "sent"
        });
      }
      await storage.updateConversation(conversation.id, {
        lastMessageText: reminderMessage,
        lastMessageTime: /* @__PURE__ */ new Date()
      });
      if (!reminderHour) {
        await supabase.from(appointmentsTable).update({ reminder_sent: true }).eq("id", appointment.id);
        sentRemindersCache.set(appointment.id, Date.now());
      }
      console.log(`\u2705 [APPOINTMENT-REMINDER] Lembrete ${reminderHour ? reminderHour + "h" : ""} enviado com sucesso para ${clientPhone}`);
    } catch (error) {
      console.error(`\u274C [APPOINTMENT-REMINDER] Erro ao enviar lembrete:`, error);
    }
  }
  /**
   * Gera mensagem de lembrete usando a IA do agente
   * A mensagem será NATURAL e adaptada ao estilo do negócio
   */
  async generateReminderWithAI(appointment, config, agentConfig, conversationHistory) {
    try {
      const mistral = await getLLMClient();
      if (!mistral) {
        console.error("\u274C [APPOINTMENT-REMINDER] Mistral n\xE3o dispon\xEDvel");
        return config.reminder_message || null;
      }
      const appointmentDate = parseAppointmentDateTime(appointment.appointment_date, appointment.start_time);
      const dayNames = ["domingo", "segunda-feira", "ter\xE7a-feira", "quarta-feira", "quinta-feira", "sexta-feira", "s\xE1bado"];
      const dayName = dayNames[appointmentDate.getDay()];
      const formattedDate = `${appointmentDate.getDate().toString().padStart(2, "0")}/${(appointmentDate.getMonth() + 1).toString().padStart(2, "0")}`;
      const formattedTime = appointment.start_time.substring(0, 5);
      const historyContext = conversationHistory.map((m) => `${m.fromMe ? "Atendente" : "Cliente"}: ${m.text || "[m\xEDdia]"}`).join("\n");
      const systemPrompt = `Voc\xEA \xE9 o assistente de atendimento de um neg\xF3cio.
${agentConfig?.prompt ? `
Contexto do neg\xF3cio:
${agentConfig.prompt.substring(0, 500)}...` : ""}

Voc\xEA precisa enviar uma mensagem de LEMBRETE para o cliente sobre um agendamento.
A mensagem deve ser:
- NATURAL e amig\xE1vel (como se voc\xEA estivesse conversando normalmente)
- Adaptada ao estilo do neg\xF3cio (formal/informal conforme configurado)
- Curta e objetiva (1-3 frases)
- N\xC3O deve parecer autom\xE1tica ou rob\xF3tica
- Pode usar emojis se for um neg\xF3cio mais descontra\xEDdo

Informa\xE7\xF5es do agendamento:
- Cliente: ${appointment.client_name}
- Servi\xE7o: ${appointment.service_name}
- Data: ${dayName}, ${formattedDate}
- Hor\xE1rio: ${formattedTime}
${appointment.location ? `- Local: ${appointment.location}` : ""}

${historyContext ? `
\xDAltimas mensagens da conversa:
${historyContext}` : ""}

${config.reminder_message ? `
Modelo de refer\xEAncia (adapte naturalmente): ${config.reminder_message}` : ""}

Gere apenas a mensagem de lembrete, sem explica\xE7\xF5es adicionais.`;
      const response = await mistral.chat.complete({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: "Gere a mensagem de lembrete de agendamento para o cliente." }
        ],
        temperature: 0.7,
        maxTokens: 150
      });
      const message = response.choices?.[0]?.message?.content;
      if (typeof message === "string" && message.trim()) {
        return message.trim();
      }
      return config.reminder_message || `Oi ${appointment.client_name}! \u{1F60A} Passando para lembrar do seu ${appointment.service_name} ${dayName} \xE0s ${formattedTime}. Te esperamos!`;
    } catch (error) {
      console.error("\u274C [APPOINTMENT-REMINDER] Erro ao gerar mensagem com IA:", error);
      return config.reminder_message || null;
    }
  }
  /**
   * Força envio de lembrete para um agendamento específico (uso manual)
   */
  async sendManualReminder(appointmentId) {
    try {
      const { data: appointment, error } = await supabase.from("appointments").select("*").eq("id", appointmentId).single();
      if (error || !appointment) {
        return { success: false, error: "Agendamento n\xE3o encontrado" };
      }
      const { data: config } = await supabase.from("scheduling_config").select("*").eq("user_id", appointment.user_id).single();
      if (!config) {
        return { success: false, error: "Configura\xE7\xE3o de agendamento n\xE3o encontrada" };
      }
      await this.sendReminderViaAI(appointment, { ...config, user_id: appointment.user_id }, void 0, "appointments");
      return { success: true, message: "Lembrete enviado com sucesso" };
    } catch (error) {
      return { success: false, error: error.message || "Erro ao enviar lembrete" };
    }
  }
};
var appointmentReminderService = new AppointmentReminderService();
async function sendCustomMessageToClient(appointment, userId, customMessage) {
  const clientPhone = appointment.client_phone;
  const finalMessage = (customMessage || "").trim();
  if (!finalMessage) return;
  try {
    const { connection, session } = await getUserConnectionAndSession(userId);
    if (!session?.socket) {
      console.log(`[CUSTOM CONFIRMATION] WhatsApp nao conectado para user ${userId}`);
      return;
    }
    if (!connection) {
      console.log(`[CUSTOM CONFIRMATION] Conexao nao encontrada para user ${userId}`);
      return;
    }
    let conversation = await storage.getConversationByContactNumber(connection.id, clientPhone);
    if (!conversation) {
      conversation = await storage.createConversation({
        connectionId: connection.id,
        contactNumber: clientPhone,
        contactName: appointment.client_name,
        lastMessageText: null,
        lastMessageTime: null,
        lastMessageFromMe: true
      });
    }
    const jid = conversation.remoteJid || `${clientPhone}@s.whatsapp.net`;
    const sentMessage = await messageQueueService.executeWithDelay(connection.id, "custom confirmation", async () => {
      return await session.socket.sendMessage(jid, { text: finalMessage });
    });
    if (sentMessage?.key.id) {
      await storage.createMessage({
        conversationId: conversation.id,
        messageId: sentMessage.key.id,
        fromMe: true,
        text: finalMessage,
        timestamp: /* @__PURE__ */ new Date(),
        status: "sent"
      });
    }
    await storage.updateConversation(conversation.id, {
      lastMessageText: finalMessage,
      lastMessageTime: /* @__PURE__ */ new Date(),
      lastMessageFromMe: true,
      hasReplied: true
    });
  } catch (error) {
    console.error("[CUSTOM CONFIRMATION] Erro ao enviar mensagem personalizada:", error);
  }
}
async function sendConfirmationToClientViaAI(appointment, userId) {
  const clientPhone = appointment.client_phone;
  console.log(`\u{1F4E4} [CONFIRMATION] Enviando confirma\xE7\xE3o para ${clientPhone} - ${appointment.client_name}`);
  try {
    const { data: config } = await supabase.from("scheduling_config").select("*").eq("user_id", userId).single();
    if (!config?.is_enabled) {
      console.log(`\u26A0\uFE0F [CONFIRMATION] Agendamento desativado para user ${userId}`);
      return;
    }
    const { connection, session } = await getUserConnectionAndSession(userId);
    if (!session?.socket) {
      console.log(`\u26A0\uFE0F [CONFIRMATION] WhatsApp n\xE3o conectado para user ${userId}`);
      return;
    }
    if (!connection) {
      console.log(`\u26A0\uFE0F [CONFIRMATION] Conex\xE3o n\xE3o encontrada para user ${userId}`);
      return;
    }
    const conversation = await db.query.conversations.findFirst({
      where: and(
        eq(conversations.connectionId, connection.id),
        eq(conversations.contactNumber, clientPhone)
      )
    });
    if (!conversation) {
      console.log(`\u26A0\uFE0F [CONFIRMATION] Conversa n\xE3o encontrada com ${clientPhone}`);
      return;
    }
    const agentConfig = await db.query.businessAgentConfigs.findFirst({
      where: eq(businessAgentConfigs.userId, userId)
    });
    const recentMessages = await db.query.messages.findMany({
      where: eq(messages.conversationId, conversation.id),
      orderBy: [desc(messages.timestamp)],
      limit: 10
    });
    const confirmationMessage = await generateConfirmationWithAI(
      appointment,
      config,
      agentConfig,
      recentMessages.reverse()
    );
    if (!confirmationMessage) {
      console.log(`\u26A0\uFE0F [CONFIRMATION] IA n\xE3o gerou mensagem de confirma\xE7\xE3o`);
      return;
    }
    const jid = conversation.remoteJid || `${clientPhone}@s.whatsapp.net`;
    console.log(`\u{1F4E4} [CONFIRMATION] Enviando para ${jid}: ${confirmationMessage.substring(0, 50)}...`);
    const sentMessage = await messageQueueService.executeWithDelay(connection.id, "confirma\xE7\xE3o de agendamento", async () => {
      const recheck = await shouldBlockAutomatedConversationSend({
        userId: appointment.user_id,
        jid,
        conversationId: conversation.id,
        origin: "scheduling"
      });
      if (recheck.blocked) {
        throw new Error("AUTOMATION_PAUSE_BLOCKED");
      }
      return await session.socket.sendMessage(jid, { text: confirmationMessage });
    });
    if (sentMessage?.key.id) {
      await storage.createMessage({
        conversationId: conversation.id,
        messageId: sentMessage.key.id,
        fromMe: true,
        text: confirmationMessage,
        timestamp: /* @__PURE__ */ new Date(),
        status: "sent"
      });
    }
    await storage.updateConversation(conversation.id, {
      lastMessageText: confirmationMessage,
      lastMessageTime: /* @__PURE__ */ new Date()
    });
    console.log(`\u2705 [CONFIRMATION] Confirma\xE7\xE3o enviada para ${clientPhone}`);
  } catch (error) {
    console.error(`\u274C [CONFIRMATION] Erro ao enviar confirma\xE7\xE3o:`, error);
  }
}
async function generateConfirmationWithAI(appointment, config, agentConfig, conversationHistory) {
  try {
    const mistral = await getLLMClient();
    if (!mistral) {
      console.error("\u274C [CONFIRMATION] Mistral n\xE3o dispon\xEDvel");
      return config?.confirmation_message || null;
    }
    const appointmentDate = parseAppointmentDateTime(appointment.appointment_date, appointment.start_time);
    const dayNames = ["domingo", "segunda-feira", "ter\xE7a-feira", "quarta-feira", "quinta-feira", "sexta-feira", "s\xE1bado"];
    const dayName = dayNames[appointmentDate.getDay()];
    const formattedDate = `${appointmentDate.getDate().toString().padStart(2, "0")}/${(appointmentDate.getMonth() + 1).toString().padStart(2, "0")}`;
    const formattedTime = appointment.start_time.substring(0, 5);
    const historyContext = conversationHistory.map((m) => `${m.fromMe ? "Atendente" : "Cliente"}: ${m.text || "[m\xEDdia]"}`).join("\n");
    const systemPrompt = `Voc\xEA \xE9 o assistente de atendimento de um neg\xF3cio.
${agentConfig?.prompt ? `
Contexto do neg\xF3cio:
${agentConfig.prompt.substring(0, 500)}...` : ""}

O neg\xF3cio acabou de CONFIRMAR um agendamento do cliente.
Voc\xEA precisa enviar uma mensagem informando que o agendamento foi CONFIRMADO.

A mensagem deve ser:
- NATURAL e amig\xE1vel (como se voc\xEA estivesse conversando normalmente)
- Adaptada ao estilo do neg\xF3cio (formal/informal conforme configurado)
- Curta e objetiva (1-3 frases)
- N\xC3O deve parecer autom\xE1tica ou rob\xF3tica
- Pode usar emojis se for um neg\xF3cio mais descontra\xEDdo
- Reafirmar os detalhes do agendamento

Informa\xE7\xF5es do agendamento CONFIRMADO:
- Cliente: ${appointment.client_name}
- Servi\xE7o: ${appointment.service_name}
- Data: ${dayName}, ${formattedDate}
- Hor\xE1rio: ${formattedTime}
${appointment.location ? `- Local: ${appointment.location}` : ""}

${historyContext ? `
\xDAltimas mensagens da conversa:
${historyContext}` : ""}

${config?.confirmation_message ? `
Modelo de refer\xEAncia (adapte naturalmente): ${config.confirmation_message}` : ""}

Gere apenas a mensagem de confirma\xE7\xE3o, sem explica\xE7\xF5es adicionais.`;
    const response = await mistral.chat.complete({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Gere a mensagem informando que o agendamento foi confirmado." }
      ],
      temperature: 0.7,
      maxTokens: 150
    });
    const message = response.choices?.[0]?.message?.content;
    if (typeof message === "string" && message.trim()) {
      return message.trim();
    }
    return config?.confirmation_message || `Oi ${appointment.client_name}! \u{1F60A} Seu ${appointment.service_name} para ${dayName} (${formattedDate}) \xE0s ${formattedTime} est\xE1 confirmado! Te esperamos!`;
  } catch (error) {
    console.error("\u274C [CONFIRMATION] Erro ao gerar mensagem com IA:", error);
    return config?.confirmation_message || null;
  }
}
async function sendCancellationToClientViaAI(appointment, userId, reason) {
  const clientPhone = appointment.client_phone;
  console.log(`\u{1F4E4} [CANCELLATION] Enviando notifica\xE7\xE3o de cancelamento para ${clientPhone}`);
  try {
    const { data: config } = await supabase.from("scheduling_config").select("*").eq("user_id", userId).single();
    if (!config?.is_enabled) {
      return;
    }
    const { connection, session } = await getUserConnectionAndSession(userId);
    if (!session?.socket) {
      console.log(`\u26A0\uFE0F [CANCELLATION] WhatsApp n\xE3o conectado para user ${userId}`);
      return;
    }
    if (!connection) {
      return;
    }
    const conversation = await db.query.conversations.findFirst({
      where: and(
        eq(conversations.connectionId, connection.id),
        eq(conversations.contactNumber, clientPhone)
      )
    });
    if (!conversation) {
      return;
    }
    const agentConfig = await db.query.businessAgentConfigs.findFirst({
      where: eq(businessAgentConfigs.userId, userId)
    });
    const cancellationMessage = await generateCancellationWithAI(
      appointment,
      config,
      agentConfig,
      reason
    );
    if (!cancellationMessage) {
      return;
    }
    const jid = conversation.remoteJid || `${clientPhone}@s.whatsapp.net`;
    const sentMessage = await messageQueueService.executeWithDelay(connection.id, "cancelamento de agendamento", async () => {
      const recheck = await shouldBlockAutomatedConversationSend({
        userId,
        jid,
        conversationId: conversation.id,
        origin: "scheduling"
      });
      if (recheck.blocked) {
        throw new Error("AUTOMATION_PAUSE_BLOCKED");
      }
      return await session.socket.sendMessage(jid, { text: cancellationMessage });
    });
    if (sentMessage?.key.id) {
      await storage.createMessage({
        conversationId: conversation.id,
        messageId: sentMessage.key.id,
        fromMe: true,
        text: cancellationMessage,
        timestamp: /* @__PURE__ */ new Date(),
        status: "sent"
      });
    }
    await storage.updateConversation(conversation.id, {
      lastMessageText: cancellationMessage,
      lastMessageTime: /* @__PURE__ */ new Date()
    });
    console.log(`\u2705 [CANCELLATION] Notifica\xE7\xE3o enviada para ${clientPhone}`);
  } catch (error) {
    console.error(`\u274C [CANCELLATION] Erro:`, error);
  }
}
async function generateCancellationWithAI(appointment, config, agentConfig, reason) {
  try {
    const mistral = await getLLMClient();
    if (!mistral) {
      return config?.cancellation_message || null;
    }
    const appointmentDate = parseAppointmentDateTime(appointment.appointment_date, appointment.start_time);
    const dayNames = ["domingo", "segunda-feira", "ter\xE7a-feira", "quarta-feira", "quinta-feira", "sexta-feira", "s\xE1bado"];
    const dayName = dayNames[appointmentDate.getDay()];
    const formattedDate = `${appointmentDate.getDate().toString().padStart(2, "0")}/${(appointmentDate.getMonth() + 1).toString().padStart(2, "0")}`;
    const formattedTime = appointment.start_time.substring(0, 5);
    const systemPrompt = `Voc\xEA \xE9 o assistente de atendimento de um neg\xF3cio.
${agentConfig?.prompt ? `
Contexto do neg\xF3cio:
${agentConfig.prompt.substring(0, 500)}...` : ""}

O neg\xF3cio precisou CANCELAR um agendamento do cliente.
Voc\xEA precisa enviar uma mensagem informando o cancelamento de forma gentil.

A mensagem deve ser:
- NATURAL e emp\xE1tica (pedindo desculpas pelo inconveniente)
- Adaptada ao estilo do neg\xF3cio
- Curta e objetiva (1-3 frases)
- Oferecer remarcar para outro hor\xE1rio
- N\xC3O deve parecer autom\xE1tica ou rob\xF3tica

Agendamento CANCELADO:
- Cliente: ${appointment.client_name}
- Servi\xE7o: ${appointment.service_name}
- Data: ${dayName}, ${formattedDate}
- Hor\xE1rio: ${formattedTime}
${reason ? `- Motivo: ${reason}` : ""}

${config?.cancellation_message ? `
Modelo de refer\xEAncia: ${config.cancellation_message}` : ""}

Gere apenas a mensagem de cancelamento, sem explica\xE7\xF5es.`;
    const response = await mistral.chat.complete({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: "Gere a mensagem informando o cancelamento do agendamento." }
      ],
      temperature: 0.7,
      maxTokens: 150
    });
    const message = response.choices?.[0]?.message?.content;
    if (typeof message === "string" && message.trim()) {
      return message.trim();
    }
    return config?.cancellation_message || `Oi ${appointment.client_name}, precisamos cancelar seu ${appointment.service_name} de ${dayName} \xE0s ${formattedTime}. Desculpe o inconveniente! Podemos remarcar para outro hor\xE1rio?`;
  } catch (error) {
    console.error("\u274C [CANCELLATION] Erro ao gerar mensagem:", error);
    return config?.cancellation_message || null;
  }
}

export {
  calculateHoursUntilReminderAppointment,
  shouldSendReminderForHoursUntilAppointment,
  AppointmentReminderService,
  appointmentReminderService,
  sendCustomMessageToClient,
  sendConfirmationToClientViaAI,
  sendCancellationToClientViaAI
};
