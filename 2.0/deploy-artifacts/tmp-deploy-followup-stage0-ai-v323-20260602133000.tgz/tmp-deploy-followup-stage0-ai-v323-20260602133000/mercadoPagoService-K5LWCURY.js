import {
  mercadoPagoService
} from "./chunk-PFJ2VEG2.js";
import "./chunk-7SPF5OKO.js";
import "./chunk-YB77ZB3P.js";
import "./chunk-XZFDVJYL.js";
import "./chunk-LIK4OWWG.js";
import "./chunk-K6J2PMOD.js";
import "./chunk-M7TXNZTC.js";
import "./chunk-UKCWWGWI.js";
import "./chunk-R6CXRQMB.js";
import "./chunk-JC6URYU5.js";
import "./chunk-KFQGP6VL.js";
export {
  mercadoPagoService
};
