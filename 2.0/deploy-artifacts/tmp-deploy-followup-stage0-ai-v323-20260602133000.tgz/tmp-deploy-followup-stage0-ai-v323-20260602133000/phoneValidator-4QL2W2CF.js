import "./chunk-KFQGP6VL.js";

// shared/phone.ts
function asTrimmedString(value) {
  return String(value ?? "").trim();
}
function extractPhoneDigits(value) {
  const raw = String(value ?? "");
  let digits = "";
  for (const char of raw) {
    if (char >= "0" && char <= "9") {
      digits += char;
    }
  }
  return digits;
}
function normalizeCallingCode(value, fallback = "55") {
  const digits = extractPhoneDigits(value);
  if (digits) return digits;
  return extractPhoneDigits(fallback);
}
function isValidCountryCallingCode(value) {
  return value.length >= 1 && value.length <= 3 && !value.startsWith("0");
}
function isValidE164Digits(value) {
  return value.length >= 8 && value.length <= 15 && !value.startsWith("0");
}
function parseInternationalPhone(rawValue) {
  const raw = asTrimmedString(rawValue);
  if (!raw) return null;
  if (raw.startsWith("+")) {
    const digits = extractPhoneDigits(raw.slice(1));
    return isValidE164Digits(digits) ? `+${digits}` : null;
  }
  if (raw.startsWith("00")) {
    const digits = extractPhoneDigits(raw.slice(2));
    return isValidE164Digits(digits) ? `+${digits}` : null;
  }
  return null;
}
function buildPhoneFromParts(phoneCountryCode, phoneNationalNumber) {
  const callingCode = normalizeCallingCode(phoneCountryCode, "");
  const nationalNumber = extractPhoneDigits(phoneNationalNumber);
  if (!isValidCountryCallingCode(callingCode) || !nationalNumber) {
    return null;
  }
  const combinedDigits = `${callingCode}${nationalNumber}`;
  if (!isValidE164Digits(combinedDigits)) {
    return null;
  }
  return `+${combinedDigits}`;
}
function normalizeSignupPhone(options) {
  const {
    phone,
    phoneCountryCode,
    phoneNationalNumber,
    defaultCallingCode = "55"
  } = options;
  const nationalRaw = asTrimmedString(phoneNationalNumber);
  if (nationalRaw) {
    const internationalFromNational = parseInternationalPhone(nationalRaw);
    if (internationalFromNational) {
      return internationalFromNational;
    }
    return buildPhoneFromParts(phoneCountryCode || defaultCallingCode, nationalRaw);
  }
  const phoneRaw = asTrimmedString(phone);
  if (!phoneRaw) return null;
  const internationalPhone = parseInternationalPhone(phoneRaw);
  if (internationalPhone) {
    return internationalPhone;
  }
  const digits = extractPhoneDigits(phoneRaw);
  if (!digits) {
    return null;
  }
  const explicitCallingCode = normalizeCallingCode(phoneCountryCode, "");
  if (explicitCallingCode) {
    return buildPhoneFromParts(explicitCallingCode, digits);
  }
  if (isValidE164Digits(digits) && digits.length >= 12) {
    return `+${digits}`;
  }
  return buildPhoneFromParts(defaultCallingCode, digits);
}
function formatSignupPhoneForDisplay(value) {
  const normalized = normalizeSignupPhone({ phone: value });
  if (!normalized) return value;
  const digits = extractPhoneDigits(normalized);
  if (digits.startsWith("55")) {
    const national = digits.slice(2);
    if (national.length === 10) {
      return `(${national.slice(0, 2)}) ${national.slice(2, 6)}-${national.slice(6)}`;
    }
    if (national.length === 11) {
      return `(${national.slice(0, 2)}) ${national.slice(2, 7)}-${national.slice(7)}`;
    }
  }
  return normalized;
}

// server/phoneValidator.ts
function validateAndFormatPhone(phone, options) {
  return normalizeSignupPhone({
    phone,
    ...options
  });
}
function isValidPhone(phone) {
  return validateAndFormatPhone(phone) !== null;
}
function formatPhoneForDisplay(phone) {
  return formatSignupPhoneForDisplay(phone);
}
export {
  formatPhoneForDisplay,
  isValidPhone,
  validateAndFormatPhone
};
