import {
  shouldBlockAutomatedConversationSend
} from "./chunk-R2H3ZHAP.js";
import {
  db
} from "./chunk-R6CXRQMB.js";
import {
  conversations,
  messages,
  plans,
  subscriptions,
  whatsappConnections
} from "./chunk-JC6URYU5.js";

// server/antiBanProtectionService.ts
import { and, desc, eq, gte, sql } from "drizzle-orm";
var ANTI_BAN_CONFIG = {
  // ═══════════════════════════════════════════════════════════════════════════
  // DELAYS ENTRE MENSAGENS (valores realistas - 5 a 15 segundos)
  // ═══════════════════════════════════════════════════════════════════════════
  MIN_DELAY_MS: 5e3,
  // 5 segundos mínimo
  MAX_DELAY_MS: 15e3,
  // 15 segundos máximo
  // Delay após mensagem manual do DONO
  OWNER_MESSAGE_DELAY_MS: 5e3,
  // 5 segundos após dono enviar manualmente
  // ═══════════════════════════════════════════════════════════════════════════
  // SISTEMA DE LOTES - Pausa após 10 mensagens consecutivas
  // ═══════════════════════════════════════════════════════════════════════════
  BATCH_SIZE: 10,
  // Após 10 envios consecutivos
  BATCH_PAUSE_MS: 6e4,
  // Pausa de 1 MINUTO (60 segundos)
  BATCH_PAUSE_SEQUENCE_MS: [6e4, 12e4, 18e4, 3e5],
  // 1m → 2m → 3m → 5m em tráfego sustentado
  // ═══════════════════════════════════════════════════════════════════════════
  // JANELAS DE VAZÃO - evita campanha contínua quando existir backlog grande
  // ═══════════════════════════════════════════════════════════════════════════
  MAX_MESSAGES_PER_MINUTE: 8,
  // Proteção adicional para rajadas curtas
  MAX_MESSAGES_PER_HOUR: 160,
  // Proteção para backlog sustentado por muito tempo
  RATE_WINDOW_MINUTE_MS: 6e4,
  RATE_WINDOW_HOUR_MS: 60 * 60 * 1e3,
  // ═══════════════════════════════════════════════════════════════════════════
  // DIGITANDO (typing indicator) - Simula digitação antes de enviar
  // ═══════════════════════════════════════════════════════════════════════════
  TYPING_ENABLED: true,
  // Habilitar simulação de digitação
  TYPING_MIN_MS: 1500,
  // 1.5 segundos mínimo digitando
  TYPING_MAX_MS: 4e3,
  // 4 segundos máximo digitando
  TYPING_CHARS_PER_SECOND: 35
  // Velocidade simulada de digitação
};
var HIGH_VOLUME_CONTACT_THRESHOLD = 100;
var HIGH_VOLUME_DELAY_MIN_MS = 6e4;
var HIGH_VOLUME_DELAY_MAX_MS = 24e4;
var ADAPTIVE_DELAY_CACHE_TTL_MS = 15e3;
var DEDICATED_AI_PLAN_ID = "d0cb4b21-f795-4b2f-bb8c-fb5be5118f6e";
var AntiBanProtectionService = class {
  constructor() {
    this.channelStats = /* @__PURE__ */ new Map();
    this.adaptiveDelayPolicies = /* @__PURE__ */ new Map();
    this.adaptiveDelayInflight = /* @__PURE__ */ new Map();
    console.log("\u{1F6E1}\uFE0F [ANTI-BAN v5.0] Sistema SIMPLIFICADO inicializado");
    console.log(`   \u{1F4CA} Delay entre msgs: ${ANTI_BAN_CONFIG.MIN_DELAY_MS / 1e3}-${ANTI_BAN_CONFIG.MAX_DELAY_MS / 1e3}s`);
    console.log(`   \u{1F4CA} Ap\xF3s msg do dono: +${ANTI_BAN_CONFIG.OWNER_MESSAGE_DELAY_MS / 1e3}s`);
    console.log(`   \u{1F4CA} Lote: ${ANTI_BAN_CONFIG.BATCH_SIZE} msgs \u2192 pausa ${ANTI_BAN_CONFIG.BATCH_PAUSE_MS / 1e3}s`);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  OBTER STATS DO CANAL
  // ═══════════════════════════════════════════════════════════════════════════
  getChannelStats(userId) {
    if (!this.channelStats.has(userId)) {
      this.channelStats.set(userId, {
        userId,
        consecutiveMessages: 0,
        lastMessageAt: 0,
        lastOwnerMessageAt: 0,
        lastOwnerMessageContact: null,
        isPaused: false,
        pauseEndAt: 0,
        messageTimestamps: [],
        batchPauseLevel: 0,
        lastBatchPauseAt: 0,
        currentPauseDurationMs: ANTI_BAN_CONFIG.BATCH_PAUSE_MS
      });
    }
    return this.channelStats.get(userId);
  }
  clearExpiredPause(stats, now) {
    if (!stats.isPaused || now < stats.pauseEndAt) {
      return;
    }
    stats.isPaused = false;
    stats.consecutiveMessages = 0;
    stats.currentPauseDurationMs = ANTI_BAN_CONFIG.BATCH_PAUSE_MS;
    console.log(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u25B6\uFE0F Pausa de lote FINALIZADA - retomando`);
  }
  pruneMessageTimestamps(stats, now) {
    const oldestAllowed = now - ANTI_BAN_CONFIG.RATE_WINDOW_HOUR_MS;
    stats.messageTimestamps = stats.messageTimestamps.filter((timestamp) => timestamp > oldestAllowed);
  }
  resolveRateWindowWait(stats, now) {
    this.pruneMessageTimestamps(stats, now);
    const minuteCutoff = now - ANTI_BAN_CONFIG.RATE_WINDOW_MINUTE_MS;
    const minuteTimestamps = stats.messageTimestamps.filter((timestamp) => timestamp > minuteCutoff);
    let waitMs = 0;
    let reason = "OK";
    if (stats.messageTimestamps.length >= ANTI_BAN_CONFIG.MAX_MESSAGES_PER_HOUR) {
      const oldestHourTimestamp = stats.messageTimestamps[0];
      const hourWait = Math.max(0, oldestHourTimestamp + ANTI_BAN_CONFIG.RATE_WINDOW_HOUR_MS - now);
      if (hourWait > waitMs) {
        waitMs = hourWait;
        reason = `Janela hor\xE1ria (${stats.messageTimestamps.length}/${ANTI_BAN_CONFIG.MAX_MESSAGES_PER_HOUR})`;
      }
    }
    if (minuteTimestamps.length >= ANTI_BAN_CONFIG.MAX_MESSAGES_PER_MINUTE) {
      const oldestMinuteTimestamp = minuteTimestamps[0];
      const minuteWait = Math.max(0, oldestMinuteTimestamp + ANTI_BAN_CONFIG.RATE_WINDOW_MINUTE_MS - now);
      if (minuteWait > waitMs) {
        waitMs = minuteWait;
        reason = `Janela por minuto (${minuteTimestamps.length}/${ANTI_BAN_CONFIG.MAX_MESSAGES_PER_MINUTE})`;
      }
    }
    return { waitMs, reason };
  }
  resolveBatchPauseDuration(stats, now) {
    const sequence = ANTI_BAN_CONFIG.BATCH_PAUSE_SEQUENCE_MS;
    const sustainedTraffic = stats.lastBatchPauseAt > 0 && now - stats.lastBatchPauseAt <= ANTI_BAN_CONFIG.RATE_WINDOW_HOUR_MS;
    if (!sustainedTraffic) {
      stats.batchPauseLevel = 0;
    } else {
      stats.batchPauseLevel = Math.min(stats.batchPauseLevel + 1, sequence.length - 1);
    }
    const pauseDuration = sequence[stats.batchPauseLevel] || ANTI_BAN_CONFIG.BATCH_PAUSE_MS;
    stats.lastBatchPauseAt = now;
    stats.currentPauseDurationMs = pauseDuration;
    return pauseDuration;
  }
  getCachedAdaptiveDelayPolicy(userId) {
    const cached = this.adaptiveDelayPolicies.get(userId);
    if (!cached) {
      return null;
    }
    if (Date.now() - cached.fetchedAt > ADAPTIVE_DELAY_CACHE_TTL_MS) {
      this.adaptiveDelayPolicies.delete(userId);
      return null;
    }
    return cached;
  }
  setAdaptiveDelayPolicy(userId, policy) {
    const resolvedPolicy = {
      ...policy,
      fetchedAt: Date.now()
    };
    this.adaptiveDelayPolicies.set(userId, resolvedPolicy);
    return resolvedPolicy;
  }
  normalizePlanText(value) {
    return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  }
  isDedicatedAiPlan(plan) {
    if (!plan) {
      return false;
    }
    if (plan.id === DEDICATED_AI_PLAN_ID) {
      return true;
    }
    if (this.normalizePlanText(plan.nome) === "ia dedicada") {
      return true;
    }
    return Array.isArray(plan.caracteristicas) && plan.caracteristicas.some((feature) => this.normalizePlanText(feature).includes("ia dedicada"));
  }
  async getActivePlanSnapshot(userId) {
    const [activePlan] = await db.select({
      id: plans.id,
      nome: plans.nome,
      caracteristicas: plans.caracteristicas
    }).from(subscriptions).innerJoin(plans, eq(subscriptions.planId, plans.id)).where(
      and(
        eq(subscriptions.userId, userId),
        eq(subscriptions.status, "active")
      )
    ).orderBy(desc(subscriptions.createdAt)).limit(1);
    return activePlan ?? null;
  }
  async getTodayUniqueInboundContactsCount(userId) {
    const todayStart = /* @__PURE__ */ new Date();
    todayStart.setHours(0, 0, 0, 0);
    const [result] = await db.select({
      count: sql`cast(count(distinct ${conversations.contactNumber}) as integer)`
    }).from(messages).innerJoin(conversations, eq(messages.conversationId, conversations.id)).innerJoin(whatsappConnections, eq(conversations.connectionId, whatsappConnections.id)).where(
      and(
        eq(whatsappConnections.userId, userId),
        eq(messages.fromMe, false),
        gte(messages.timestamp, todayStart)
      )
    );
    return result?.count ?? 0;
  }
  async prepareAdaptiveDelayPolicy(userId) {
    const cached = this.getCachedAdaptiveDelayPolicy(userId);
    if (cached) {
      return cached;
    }
    const inflight = this.adaptiveDelayInflight.get(userId);
    if (inflight) {
      return inflight;
    }
    const promise = (async () => {
      try {
        const [activePlan, uniqueInboundContactsToday] = await Promise.all([
          this.getActivePlanSnapshot(userId),
          this.getTodayUniqueInboundContactsCount(userId)
        ]);
        const isDedicatedAiPlan = this.isDedicatedAiPlan(activePlan);
        return this.setAdaptiveDelayPolicy(userId, {
          appliesHighVolumeDelay: !isDedicatedAiPlan && uniqueInboundContactsToday >= HIGH_VOLUME_CONTACT_THRESHOLD,
          isDedicatedAiPlan,
          uniqueInboundContactsToday
        });
      } catch (error) {
        console.error(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] Falha ao atualizar pol\xEDtica adaptativa para ${userId.substring(0, 8)}...`, error);
        return this.setAdaptiveDelayPolicy(userId, {
          appliesHighVolumeDelay: false,
          isDedicatedAiPlan: false,
          uniqueInboundContactsToday: 0
        });
      } finally {
        this.adaptiveDelayInflight.delete(userId);
      }
    })();
    this.adaptiveDelayInflight.set(userId, promise);
    return promise;
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  REGISTRAR MENSAGEM MANUAL DO DONO
  // ═══════════════════════════════════════════════════════════════════════════
  registerOwnerManualMessage(userId, contactNumber, _messageType) {
    const stats = this.getChannelStats(userId);
    const now = Date.now();
    stats.lastOwnerMessageAt = now;
    stats.lastOwnerMessageContact = contactNumber;
    stats.consecutiveMessages = 0;
    stats.batchPauseLevel = 0;
    stats.currentPauseDurationMs = ANTI_BAN_CONFIG.BATCH_PAUSE_MS;
    console.log(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u{1F464} Mensagem MANUAL do DONO detectada`);
    console.log(`   \u{1F4F1} Contato: ${contactNumber}`);
    console.log(`   \u{1F504} Contador de lote reiniciado`);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  CALCULAR DELAY ANTES DE ENVIAR
  // ═══════════════════════════════════════════════════════════════════════════
  calculateDelay(userId, contactNumber, options) {
    const stats = this.getChannelStats(userId);
    const now = Date.now();
    this.clearExpiredPause(stats, now);
    if (stats.isPaused && now < stats.pauseEndAt) {
      const remainingPause = stats.pauseEndAt - now;
      console.log(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u23F8\uFE0F Canal em PAUSA de lote por mais ${Math.ceil(remainingPause / 1e3)}s`);
      return remainingPause;
    }
    let delay = this.randomBetween(
      ANTI_BAN_CONFIG.MIN_DELAY_MS,
      ANTI_BAN_CONFIG.MAX_DELAY_MS
    );
    const adaptivePolicy = this.getCachedAdaptiveDelayPolicy(userId);
    if (options?.applyHighVolumeDelay !== false && adaptivePolicy?.appliesHighVolumeDelay) {
      const highVolumeDelay = this.randomBetween(HIGH_VOLUME_DELAY_MIN_MS, HIGH_VOLUME_DELAY_MAX_MS);
      delay = Math.max(delay, highVolumeDelay);
      console.log(
        `\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u{1F422} Alto volume ativo (${adaptivePolicy.uniqueInboundContactsToday} contatos hoje) - delay ${Math.ceil(highVolumeDelay / 1e3)}s`
      );
    }
    const timeSinceOwnerMessage = now - stats.lastOwnerMessageAt;
    if (timeSinceOwnerMessage < ANTI_BAN_CONFIG.OWNER_MESSAGE_DELAY_MS && stats.lastOwnerMessageContact === contactNumber) {
      const extraDelay = ANTI_BAN_CONFIG.OWNER_MESSAGE_DELAY_MS - timeSinceOwnerMessage;
      delay += extraDelay;
      console.log(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u{1F464} Dono enviou msg h\xE1 ${Math.ceil(timeSinceOwnerMessage / 1e3)}s - delay extra: ${Math.ceil(extraDelay / 1e3)}s`);
    }
    const timeSinceLastMessage = now - stats.lastMessageAt;
    if (timeSinceLastMessage < delay) {
      delay = Math.max(delay - timeSinceLastMessage, ANTI_BAN_CONFIG.MIN_DELAY_MS);
    }
    const rateWindow = this.resolveRateWindowWait(stats, now);
    if (rateWindow.waitMs > 0) {
      console.log(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u{1F6A6} ${rateWindow.reason} - aguardando ${Math.ceil(rateWindow.waitMs / 1e3)}s`);
    }
    return Math.max(delay, rateWindow.waitMs);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  REGISTRAR ENVIO DE MENSAGEM
  // ═══════════════════════════════════════════════════════════════════════════
  registerMessageSent(userId, contactNumber) {
    const stats = this.getChannelStats(userId);
    const now = Date.now();
    this.clearExpiredPause(stats, now);
    this.pruneMessageTimestamps(stats, now);
    stats.lastMessageAt = now;
    stats.consecutiveMessages++;
    stats.messageTimestamps.push(now);
    if (stats.consecutiveMessages >= ANTI_BAN_CONFIG.BATCH_SIZE) {
      const pauseDuration = this.resolveBatchPauseDuration(stats, now);
      stats.isPaused = true;
      stats.pauseEndAt = now + pauseDuration;
      console.log(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u{1F4E6} LOTE DE ${ANTI_BAN_CONFIG.BATCH_SIZE} MSGS ATINGIDO`);
      console.log(`   \u23F8\uFE0F Iniciando pausa de ${pauseDuration / 1e3} segundos (n\xEDvel ${stats.batchPauseLevel + 1})`);
      return {
        shouldPause: true,
        pauseDuration
      };
    }
    const minuteCutoff = now - ANTI_BAN_CONFIG.RATE_WINDOW_MINUTE_MS;
    const minuteCount = stats.messageTimestamps.filter((timestamp) => timestamp > minuteCutoff).length;
    const hourCount = stats.messageTimestamps.length;
    console.log(
      `\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u2705 Msg enviada - Lote: ${stats.consecutiveMessages}/${ANTI_BAN_CONFIG.BATCH_SIZE} | 1m: ${minuteCount}/${ANTI_BAN_CONFIG.MAX_MESSAGES_PER_MINUTE} | 1h: ${hourCount}/${ANTI_BAN_CONFIG.MAX_MESSAGES_PER_HOUR}`
    );
    return { shouldPause: false, pauseDuration: 0 };
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  VERIFICAR SE PODE ENVIAR
  // ═══════════════════════════════════════════════════════════════════════════
  canSendMessage(userId) {
    const stats = this.getChannelStats(userId);
    const now = Date.now();
    this.clearExpiredPause(stats, now);
    if (stats.isPaused && now < stats.pauseEndAt) {
      const waitMs = stats.pauseEndAt - now;
      return {
        canSend: false,
        waitMs,
        reason: `Pausa de lote (${Math.ceil(waitMs / 1e3)}s restantes)`
      };
    }
    const rateWindow = this.resolveRateWindowWait(stats, now);
    if (rateWindow.waitMs > 0) {
      return {
        canSend: false,
        waitMs: rateWindow.waitMs,
        reason: `${rateWindow.reason} - aguarde ${Math.ceil(rateWindow.waitMs / 1e3)}s`
      };
    }
    return { canSend: true, waitMs: 0, reason: "OK" };
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  CALCULAR DURAÇÃO DA DIGITAÇÃO
  // ═══════════════════════════════════════════════════════════════════════════
  calculateTypingDuration(messageLength) {
    const typingTime = messageLength / ANTI_BAN_CONFIG.TYPING_CHARS_PER_SECOND * 1e3;
    return Math.min(
      Math.max(typingTime, ANTI_BAN_CONFIG.TYPING_MIN_MS),
      ANTI_BAN_CONFIG.TYPING_MAX_MS
    );
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  UTILITÁRIOS
  // ═══════════════════════════════════════════════════════════════════════════
  randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  OBTER ESTATÍSTICAS
  // ═══════════════════════════════════════════════════════════════════════════
  getStats(userId) {
    const stats = this.getChannelStats(userId);
    const now = Date.now();
    this.clearExpiredPause(stats, now);
    this.pruneMessageTimestamps(stats, now);
    const minuteCutoff = now - ANTI_BAN_CONFIG.RATE_WINDOW_MINUTE_MS;
    const minuteCount = stats.messageTimestamps.filter((timestamp) => timestamp > minuteCutoff).length;
    const dayCutoff = now - 24 * 60 * 60 * 1e3;
    const dayCount = stats.messageTimestamps.filter((timestamp) => timestamp > dayCutoff).length;
    return {
      consecutiveMessages: stats.consecutiveMessages,
      isPaused: stats.isPaused && now < stats.pauseEndAt,
      pauseRemainingMs: stats.isPaused ? Math.max(0, stats.pauseEndAt - now) : 0,
      minuteCount,
      hourCount: stats.messageTimestamps.length,
      dayCount,
      batchPauseLevel: stats.batchPauseLevel,
      currentPauseDurationMs: stats.currentPauseDurationMs
    };
  }
  // Método para resetar contador (útil quando há interação do cliente)
  resetBatchCounter(userId) {
    const stats = this.getChannelStats(userId);
    stats.consecutiveMessages = 0;
    stats.batchPauseLevel = 0;
    stats.currentPauseDurationMs = ANTI_BAN_CONFIG.BATCH_PAUSE_MS;
    console.log(`\u{1F6E1}\uFE0F [ANTI-BAN v5.0] \u{1F504} Contador de lote resetado para ${userId.substring(0, 8)}...`);
  }
};
var GroupMetadataCache = class {
  constructor() {
    this.cache = /* @__PURE__ */ new Map();
    this.TTL_MS = 30 * 60 * 1e3;
  }
  // 30 minutos
  set(groupId, metadata) {
    this.cache.set(groupId, {
      ...metadata,
      fetchedAt: Date.now()
    });
    console.log(`\u{1F4E6} [GROUP-CACHE] Metadados cacheados para grupo ${groupId.substring(0, 20)}...`);
  }
  get(groupId) {
    const cached = this.cache.get(groupId);
    if (!cached) return null;
    if (Date.now() - cached.fetchedAt > this.TTL_MS) {
      this.cache.delete(groupId);
      return null;
    }
    return cached;
  }
  has(groupId) {
    const cached = this.get(groupId);
    return cached !== null;
  }
  delete(groupId) {
    this.cache.delete(groupId);
  }
  clear() {
    this.cache.clear();
  }
  // Limpar entradas expiradas periodicamente
  cleanup() {
    const now = Date.now();
    const keysToDelete = [];
    this.cache.forEach((value, key) => {
      if (now - value.fetchedAt > this.TTL_MS) {
        keysToDelete.push(key);
      }
    });
    keysToDelete.forEach((key) => this.cache.delete(key));
  }
};
var groupMetadataCache = new GroupMetadataCache();
setInterval(() => groupMetadataCache.cleanup(), 10 * 60 * 1e3);
async function simulateTyping(socket, jid, messageLength = 100) {
  if (!ANTI_BAN_CONFIG.TYPING_ENABLED || !socket) return;
  try {
    const duration = antiBanProtectionService.calculateTypingDuration(messageLength);
    await socket.sendPresenceUpdate("composing", jid);
    await new Promise((resolve) => setTimeout(resolve, duration));
    await socket.sendPresenceUpdate("paused", jid);
    console.log(`\u2328\uFE0F [TYPING] Simula\xE7\xE3o de digita\xE7\xE3o: ${Math.ceil(duration / 1e3)}s para ${jid.substring(0, 15)}...`);
  } catch (error) {
    console.warn(`\u26A0\uFE0F [TYPING] Erro ao simular digita\xE7\xE3o:`, error);
  }
}
var antiBanProtectionService = new AntiBanProtectionService();

// server/channelDispatchLock.ts
function getOrCreateState(map, key) {
  const existing = map.get(key);
  if (existing) return existing;
  const created = {
    activeReason: null,
    activeStartedAt: null,
    lastCompletedAt: null,
    waitingCount: 0,
    totalRuns: 0
  };
  map.set(key, created);
  return created;
}
var ChannelDispatchLock = class {
  constructor() {
    this.states = /* @__PURE__ */ new Map();
  }
  async runExclusive(channelKey, reason, task) {
    const state = getOrCreateState(this.states, channelKey);
    const previous = state.chain || Promise.resolve();
    const hadPendingChain = Boolean(state.chain);
    let release;
    const current = new Promise((resolve) => {
      release = resolve;
    });
    const chain = previous.catch(() => void 0).then(() => current);
    state.chain = chain;
    if (hadPendingChain || state.activeReason) {
      state.waitingCount += 1;
      console.log(`\u{1F512} [CHANNEL-DISPATCH] ${channelKey.substring(0, 8)} aguardando vez para ${reason}`);
    }
    await previous.catch(() => void 0);
    if (hadPendingChain || state.activeReason) {
      state.waitingCount = Math.max(0, state.waitingCount - 1);
    }
    state.activeReason = reason;
    state.activeStartedAt = Date.now();
    try {
      return await task();
    } finally {
      state.totalRuns += 1;
      state.activeReason = null;
      state.activeStartedAt = null;
      state.lastCompletedAt = Date.now();
      release();
      if (state.chain === chain) {
        state.chain = void 0;
      }
      if (!state.chain && !state.activeReason && state.waitingCount === 0) {
        this.states.set(channelKey, state);
      }
    }
  }
  getSnapshot(channelKey) {
    const state = getOrCreateState(this.states, channelKey);
    const now = Date.now();
    return {
      isActive: Boolean(state.activeReason),
      activeReason: state.activeReason,
      activeForMs: state.activeStartedAt ? Math.max(0, now - state.activeStartedAt) : 0,
      waitingCount: state.waitingCount,
      lastCompletedAt: state.lastCompletedAt,
      totalRuns: state.totalRuns
    };
  }
};
var channelDispatchLock = new ChannelDispatchLock();

// server/outboundPriorityGuard.ts
import { and as and2, eq as eq2, gt, gte as gte2, ne, or, sql as sql2 } from "drizzle-orm";
var EXPLICIT_PRIORITY_RANK = {
  low: 100,
  normal: 200,
  high: 300,
  urgent: 400
};
var ORIGIN_FLOOR_RANK = {
  follow_up: 90,
  user_follow_up: 80,
  broadcast: 70,
  recovery: 85,
  notification: 85,
  conversation: 340,
  ai_agent: 320,
  manual_admin: 340,
  whatsapp_sender: 260,
  chatbot_flow: 260,
  delivery: 250,
  catalog: 240,
  scheduling: 250,
  media: 220,
  unknown: 200
};
var DEFERRED_ORIGINS = /* @__PURE__ */ new Set([
  "follow_up",
  "user_follow_up"
]);
var DEFAULT_PENDING_PRIORITY_WINDOW_MINUTES = 60;
function resolvePendingPriorityWindowMinutes() {
  const configured = Number(process.env.PENDING_REPLY_PRIORITY_WINDOW_MINUTES || "");
  if (Number.isFinite(configured) && configured > 0) {
    return Math.min(24 * 60, Math.max(5, configured));
  }
  return DEFAULT_PENDING_PRIORITY_WINDOW_MINUTES;
}
function resolveDispatchPriorityRank(params) {
  const explicit = EXPLICIT_PRIORITY_RANK[params.priority || "normal"];
  const floor = ORIGIN_FLOOR_RANK[params.origin] || explicit;
  const ownerBoost = params.isOwnerInitiated ? 380 : 0;
  return Math.max(explicit, floor, ownerBoost);
}
function shouldDeferAutomatedOrigin(origin) {
  return DEFERRED_ORIGINS.has(origin);
}
function resolvePendingPriorityWaitMs(pendingCount) {
  const safePendingCount = Math.max(1, pendingCount);
  const baseMs = 2 * 60 * 1e3;
  const steppedMs = Math.min(5 * 60 * 1e3, baseMs + safePendingCount * 30 * 1e3);
  return steppedMs;
}
function buildPendingPriorityConversationFilters() {
  return [
    gte2(conversations.lastMessageTime, new Date(Date.now() - resolvePendingPriorityWindowMinutes() * 60 * 1e3)),
    eq2(conversations.lastMessageFromMe, false),
    or(
      eq2(conversations.needsHumanAttention, true),
      gt(conversations.unreadCount, 0)
    )
  ];
}
async function countPendingPriorityConversations(userId, excludeConversationId) {
  const conversationFilters = [
    eq2(whatsappConnections.userId, userId),
    ...buildPendingPriorityConversationFilters()
  ];
  if (excludeConversationId) {
    conversationFilters.push(ne(conversations.id, excludeConversationId));
  }
  const [result] = await db.select({
    total: sql2`cast(count(*) as integer)`
  }).from(conversations).innerJoin(whatsappConnections, eq2(whatsappConnections.id, conversations.connectionId)).where(and2(...conversationFilters));
  return Number(result?.total || 0);
}
async function isConversationPendingPriority(conversationId) {
  if (!conversationId) {
    return false;
  }
  const [result] = await db.select({
    id: conversations.id
  }).from(conversations).where(and2(
    eq2(conversations.id, conversationId),
    ...buildPendingPriorityConversationFilters()
  )).limit(1);
  return Boolean(result?.id);
}

// server/whatsappMessageSplit.ts
function normalizeInlineNumberedListBreaks(message) {
  return String(message || "").replace(/\r\n/g, "\n").replace(/([:;])\s+(\d{1,2}[.)]\s+)/g, "$1\n$2").replace(/([^\n])\s+(\d{1,2}[.)]\s+(?=[*A-Z]))/g, "$1\n$2");
}
var BUBBLE_MARKER = "[BOLHA]";
function matchesBubbleMarker(source, startIndex) {
  if (startIndex + BUBBLE_MARKER.length > source.length) {
    return false;
  }
  for (let offset = 0; offset < BUBBLE_MARKER.length; offset += 1) {
    const current = source[startIndex + offset];
    const expected = BUBBLE_MARKER[offset];
    if (!current || current.toUpperCase() !== expected) {
      return false;
    }
  }
  return true;
}
function parseExplicitBubbleMessages(message) {
  const source = normalizeInlineNumberedListBreaks(message);
  const parts = [];
  let cursor = 0;
  let segmentStart = 0;
  let foundMarker = false;
  while (cursor < source.length) {
    if (matchesBubbleMarker(source, cursor)) {
      foundMarker = true;
      const part = source.slice(segmentStart, cursor).trim();
      if (part) {
        parts.push(part);
      }
      cursor += BUBBLE_MARKER.length;
      segmentStart = cursor;
      continue;
    }
    cursor += 1;
  }
  if (!foundMarker) {
    const trimmed = source.trim();
    return {
      hasExplicitBubbles: false,
      parts: trimmed ? [trimmed] : []
    };
  }
  const tail = source.slice(segmentStart).trim();
  if (tail) {
    parts.push(tail);
  }
  return {
    hasExplicitBubbles: true,
    parts
  };
}
function joinBubbleMessages(parts) {
  return parts.map((part) => String(part || "").trim()).filter((part) => part.length > 0).join("\n\n");
}

// server/outboundTextPolicy.ts
var URL_PATTERN = /\bhttps?:\/\/[^\s<>"')\]]+/gi;
function shouldPrefixWww(hostname) {
  const lower = hostname.toLowerCase();
  if (!lower || lower.startsWith("www.")) return false;
  if (lower === "localhost") return false;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(lower)) return false;
  const labels = lower.split(".").filter(Boolean);
  return labels.length === 2;
}
function normalizeUrlForCustomer(rawUrl) {
  let trailing = "";
  let candidate = rawUrl;
  while (/[.,;:!?]$/.test(candidate)) {
    trailing = candidate.slice(-1) + trailing;
    candidate = candidate.slice(0, -1);
  }
  try {
    const parsed = new URL(candidate);
    if (parsed.protocol === "http:") {
      parsed.protocol = "https:";
    }
    if (shouldPrefixWww(parsed.hostname)) {
      parsed.hostname = `www.${parsed.hostname}`;
    }
    return parsed.toString() + trailing;
  } catch {
    return rawUrl;
  }
}
function normalizeOutboundTextForCustomer(text) {
  const explicitBubbles = parseExplicitBubbleMessages(text || "");
  const safeText = explicitBubbles.hasExplicitBubbles ? joinBubbleMessages(explicitBubbles.parts) : text;
  if (!safeText || !URL_PATTERN.test(safeText)) {
    URL_PATTERN.lastIndex = 0;
    return safeText;
  }
  URL_PATTERN.lastIndex = 0;
  return safeText.replace(URL_PATTERN, (url) => normalizeUrlForCustomer(url));
}
function buildPlainTextWhatsAppPayload(text) {
  return {
    text: normalizeOutboundTextForCustomer(text),
    linkPreview: false,
    detectLinks: false
  };
}
function buildGatewayTextSendBody(body) {
  const text = typeof body.text === "string" ? body.text : "";
  return {
    ...body,
    text: normalizeOutboundTextForCustomer(text),
    linkPreview: false,
    preview: false,
    detectLinks: false
  };
}

// server/centralizedMessageSender.ts
var USE_POLLS_FOR_BUTTONS = false;
var SEND_CONTEXT_BEFORE_POLL = false;
var pollMappings = /* @__PURE__ */ new Map();
setInterval(() => {
  const oneHourAgo = Date.now() - 60 * 60 * 1e3;
  const entries = Array.from(pollMappings.entries());
  for (const [msgId, mapping] of entries) {
    if (mapping.createdAt < oneHourAgo) {
      pollMappings.delete(msgId);
    }
  }
}, 10 * 60 * 1e3);
function getPollMapping(pollMsgId) {
  return pollMappings.get(pollMsgId);
}
function getButtonIdFromPollVote(pollMsgId, votedText) {
  const mapping = pollMappings.get(pollMsgId);
  if (!mapping) return null;
  const button = mapping.buttons.find((btn) => {
    const btnTitle = btn.reply?.title || btn.title || "";
    return btnTitle.toLowerCase() === votedText.toLowerCase();
  });
  if (button) {
    return button.reply?.id || button.id || votedText;
  }
  return votedText;
}
var CentralizedMessageSender = class {
  constructor() {
    this.stats = /* @__PURE__ */ new Map();
    this.processing = /* @__PURE__ */ new Map();
    this.queues = /* @__PURE__ */ new Map();
    console.log("\u{1F680} [CENTRALIZED-SENDER v3.0] Sistema com ENQUETES inicializado");
    console.log(`   \u{1F5F3}\uFE0F Polls: ${USE_POLLS_FOR_BUTTONS ? "ATIVADO" : "DESATIVADO"}`);
    console.log(`   \u23F1\uFE0F Delays: ${ANTI_BAN_CONFIG.MIN_DELAY_MS / 1e3}s - ${ANTI_BAN_CONFIG.MAX_DELAY_MS / 1e3}s`);
    console.log(`   \u2328\uFE0F Typing: ${ANTI_BAN_CONFIG.TYPING_ENABLED ? "ATIVADO" : "DESATIVADO"}`);
    console.log(`   \u{1F4E6} Batch: ${ANTI_BAN_CONFIG.BATCH_SIZE} msgs, pausa ${ANTI_BAN_CONFIG.BATCH_PAUSE_MS / 1e3}s`);
  }
  shouldApplyAdaptiveDelay(options) {
    return options.isOwnerInitiated !== true && options.origin !== "manual_admin";
  }
  async runExclusivePerUser(userId, reason, task) {
    return channelDispatchLock.runExclusive(userId, reason, task);
  }
  insertByPriority(queue, item) {
    const index = queue.findIndex((queued) => queued.priorityRank < item.priorityRank);
    if (index === -1) {
      queue.push(item);
      return;
    }
    queue.splice(index, 0, item);
  }
  async maybeDeferAutomatedSend(options) {
    const origin = options.origin;
    if (!shouldDeferAutomatedOrigin(origin)) {
      return null;
    }
    const pendingCount = await countPendingPriorityConversations(options.userId, options.conversationId);
    if (pendingCount <= 0) {
      return null;
    }
    const retryAfterMs = resolvePendingPriorityWaitMs(pendingCount);
    console.log(
      `\u23F3 [CENTRALIZED-SENDER] Adiando [${origin}] para priorizar ${pendingCount} conversa(s) aguardando resposta`
    );
    return {
      success: false,
      deferred: true,
      retryAfterMs,
      error: `H\xE1 ${pendingCount} conversa(s) aguardando resposta antes do follow-up`
    };
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  🗳️ REGISTRO DE POLL MAPPING
  // ═══════════════════════════════════════════════════════════════════════════
  async getPausedConversationBlockResult(options, stage) {
    const pauseCheck = await shouldBlockAutomatedConversationSend({
      userId: options.userId,
      jid: options.jid,
      conversationId: options.conversationId,
      origin: options.origin,
      isOwnerInitiated: options.isOwnerInitiated
    });
    if (!pauseCheck.blocked) {
      return null;
    }
    console.log(
      `\u23F8\uFE0F [CENTRALIZED-SENDER] Envio autom\xE1tico bloqueado (${stage}) para ${options.jid} - conversa ${pauseCheck.conversationId} est\xE1 pausada`
    );
    return {
      success: false,
      error: pauseCheck.reason || "Conversa pausada por resposta manual do dono"
    };
  }
  registerPollMapping(pollMsgId, jid, buttons) {
    pollMappings.set(pollMsgId, {
      pollMsgId,
      jid,
      buttons,
      createdAt: Date.now()
    });
    console.log(`\u{1F5F3}\uFE0F [POLL-MAPPING] Registrado poll ${pollMsgId.substring(0, 10)}... com ${buttons.length} op\xE7\xF5es`);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  📤 MÉTODO PRINCIPAL DE ENVIO
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * Envia uma mensagem através do sistema anti-ban
   * ESTE É O ÚNICO MÉTODO QUE DEVE SER USADO PARA ENVIAR MENSAGENS
   */
  async sendMessage(options) {
    const { userId, jid, socket, origin, priority = "normal" } = options;
    if (!socket) {
      console.error(`\u274C [CENTRALIZED-SENDER] Socket n\xE3o fornecido para ${origin}`);
      return { success: false, error: "Socket n\xE3o dispon\xEDvel" };
    }
    if (!jid) {
      console.error(`\u274C [CENTRALIZED-SENDER] JID n\xE3o fornecido para ${origin}`);
      return { success: false, error: "JID n\xE3o fornecido" };
    }
    console.log(`\u{1F4E5} [CENTRALIZED-SENDER] Nova mensagem de [${origin}] para ${jid.substring(0, 15)}...`);
    const pausedBeforeQueue = await this.getPausedConversationBlockResult(options, "before_queue");
    if (pausedBeforeQueue) {
      this.recordSent(userId, origin, false);
      return pausedBeforeQueue;
    }
    if (options.isOwnerInitiated || priority === "urgent") {
      return this.sendImmediateWithMinimalDelay(options);
    }
    return this.enqueueAndProcess(options);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  🔥 ENVIO IMEDIATO (para mensagens do dono)
  // ═══════════════════════════════════════════════════════════════════════════
  async sendImmediateWithMinimalDelay(options) {
    const { userId, jid, content, socket, origin, quotedMessage, skipTyping } = options;
    const contactNumber = this.getContactNumber(jid);
    return this.runExclusivePerUser(userId, `envio prioritario [${origin}]`, async () => {
      try {
        const pausedBeforeDelay = await this.getPausedConversationBlockResult(options, "immediate_before_delay");
        if (pausedBeforeDelay) {
          this.recordSent(userId, origin, false);
          return pausedBeforeDelay;
        }
        const antiBanCheck = antiBanProtectionService.canSendMessage(userId);
        if (!antiBanCheck.canSend) {
          console.log(
            `\u26A1 [CENTRALIZED-SENDER] Prote\xE7\xE3o anti-ban ativa para envio priorit\xE1rio [${origin}] - aguardando ${Math.ceil(antiBanCheck.waitMs / 1e3)}s`
          );
          await new Promise((resolve) => setTimeout(resolve, antiBanCheck.waitMs));
        }
        await antiBanProtectionService.prepareAdaptiveDelayPolicy(userId);
        const delay = Math.max(
          ANTI_BAN_CONFIG.OWNER_MESSAGE_DELAY_MS,
          antiBanProtectionService.calculateDelay(userId, contactNumber, {
            applyHighVolumeDelay: this.shouldApplyAdaptiveDelay({ origin, isOwnerInitiated: options.isOwnerInitiated })
          })
        );
        console.log(`\u26A1 [CENTRALIZED-SENDER] Envio priorit\xE1rio de [${origin}] - delay ${delay / 1e3}s`);
        if (!skipTyping && ANTI_BAN_CONFIG.TYPING_ENABLED) {
          await simulateTyping(socket, jid, this.getMessageLength(content));
        }
        await new Promise((resolve) => setTimeout(resolve, delay));
        const pausedBeforeSend = await this.getPausedConversationBlockResult(options, "immediate_before_send");
        if (pausedBeforeSend) {
          this.recordSent(userId, origin, false);
          return pausedBeforeSend;
        }
        const result = await socket.sendMessage(jid, content, {
          quoted: quotedMessage
        });
        antiBanProtectionService.registerMessageSent(userId, contactNumber);
        this.recordSent(userId, origin, true);
        return {
          success: true,
          messageId: result?.key?.id || void 0,
          waitedMs: delay
        };
      } catch (error) {
        console.error(`\u274C [CENTRALIZED-SENDER] Erro no envio priorit\xE1rio:`, error);
        this.recordSent(userId, origin, false);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Erro desconhecido"
        };
      }
    });
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  📋 SISTEMA DE FILA
  // ═══════════════════════════════════════════════════════════════════════════
  async enqueueAndProcess(options) {
    const { userId } = options;
    const priorityRank = resolveDispatchPriorityRank({
      origin: options.origin,
      priority: options.priority,
      isOwnerInitiated: options.isOwnerInitiated
    });
    return new Promise((resolve) => {
      if (!this.queues.has(userId)) {
        this.queues.set(userId, []);
      }
      const queue = this.queues.get(userId);
      this.insertByPriority(queue, {
        options,
        resolve,
        queuedAt: Date.now(),
        priorityRank
      });
      console.log(`\u{1F4CB} [CENTRALIZED-SENDER] Mensagem enfileirada. Fila de ${userId.substring(0, 8)}: ${queue.length} msgs`);
      if (!this.processing.get(userId)) {
        this.processQueue(userId);
      }
    });
  }
  async processQueue(userId) {
    if (this.processing.get(userId)) return;
    this.processing.set(userId, true);
    const queue = this.queues.get(userId) || [];
    console.log(`\u{1F504} [CENTRALIZED-SENDER] Iniciando processamento da fila de ${userId.substring(0, 8)}...`);
    while (queue.length > 0) {
      const item = queue.shift();
      const { options, resolve } = item;
      const { jid, content, socket, origin, quotedMessage, skipTyping } = options;
      try {
        const sendResult = await this.runExclusivePerUser(userId, `fila [${origin}]`, async () => {
          const deferredSend = await this.maybeDeferAutomatedSend(options);
          if (deferredSend) {
            this.recordSent(userId, origin, false);
            return deferredSend;
          }
          const pausedBeforeDelay = await this.getPausedConversationBlockResult(options, "queue_before_delay");
          if (pausedBeforeDelay) {
            this.recordSent(userId, origin, false);
            return pausedBeforeDelay;
          }
          const contactNumber = this.getContactNumber(jid);
          await antiBanProtectionService.prepareAdaptiveDelayPolicy(userId);
          const delay = antiBanProtectionService.calculateDelay(userId, contactNumber, {
            applyHighVolumeDelay: this.shouldApplyAdaptiveDelay({ origin, isOwnerInitiated: options.isOwnerInitiated })
          });
          console.log(`\u23F1\uFE0F [CENTRALIZED-SENDER] Aguardando ${Math.ceil(delay / 1e3)}s antes de enviar [${origin}]...`);
          if (!skipTyping && ANTI_BAN_CONFIG.TYPING_ENABLED) {
            await simulateTyping(socket, jid, this.getMessageLength(content));
          }
          await new Promise((r) => setTimeout(r, delay));
          const pausedBeforeSend = await this.getPausedConversationBlockResult(options, "queue_before_send");
          if (pausedBeforeSend) {
            this.recordSent(userId, origin, false);
            return pausedBeforeSend;
          }
          const result = await socket.sendMessage(jid, content, {
            quoted: quotedMessage
          });
          antiBanProtectionService.registerMessageSent(userId, contactNumber);
          this.recordSent(userId, origin, true);
          console.log(`\u2705 [CENTRALIZED-SENDER] Mensagem enviada [${origin}] \u2192 ${jid.substring(0, 15)}...`);
          return {
            success: true,
            messageId: result?.key?.id || void 0,
            waitedMs: delay
          };
        });
        resolve(sendResult);
      } catch (error) {
        console.error(`\u274C [CENTRALIZED-SENDER] Erro ao enviar [${origin}]:`, error);
        this.recordSent(userId, origin, false);
        resolve({
          success: false,
          error: error instanceof Error ? error.message : "Erro desconhecido"
        });
      }
    }
    this.processing.set(userId, false);
    console.log(`\u2705 [CENTRALIZED-SENDER] Fila de ${userId.substring(0, 8)} processada`);
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  🛠️ MÉTODOS AUXILIARES
  // ═══════════════════════════════════════════════════════════════════════════
  isGroupJid(jid) {
    return jid.endsWith("@g.us");
  }
  getMessageLength(content) {
    if ("text" in content && typeof content.text === "string") {
      return content.text.length;
    }
    if ("caption" in content && typeof content.caption === "string") {
      return content.caption.length;
    }
    return 100;
  }
  getContactNumber(jid) {
    const separatorIndex = jid.indexOf("@");
    return separatorIndex >= 0 ? jid.slice(0, separatorIndex) : jid;
  }
  recordSent(userId, origin, success) {
    if (!this.stats.has(userId)) {
      this.stats.set(userId, {
        totalSent: 0,
        totalFailed: 0,
        byOrigin: {},
        lastSentAt: 0
      });
    }
    const stats = this.stats.get(userId);
    if (success) {
      stats.totalSent++;
    } else {
      stats.totalFailed++;
    }
    stats.byOrigin[origin] = (stats.byOrigin[origin] || 0) + 1;
    stats.lastSentAt = Date.now();
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  📊 ESTATÍSTICAS
  // ═══════════════════════════════════════════════════════════════════════════
  getStats(userId) {
    return this.stats.get(userId) || null;
  }
  getQueueSize(userId) {
    return this.queues.get(userId)?.length || 0;
  }
  getQueueSnapshot(userId) {
    const queue = this.queues.get(userId) || [];
    const byOrigin = {};
    for (const item of queue) {
      const origin = item.options.origin || "unknown";
      byOrigin[origin] = (byOrigin[origin] || 0) + 1;
    }
    return {
      queueSize: queue.length,
      byOrigin
    };
  }
  // ═══════════════════════════════════════════════════════════════════════════
  //  ⚡ MÉTODOS DE CONVENIÊNCIA
  // ═══════════════════════════════════════════════════════════════════════════
  /**
   * Envia mensagem de texto
   */
  async sendText(userId, jid, text, socket, origin, options) {
    return this.sendMessage({
      userId,
      jid,
      content: buildPlainTextWhatsAppPayload(text),
      socket,
      origin,
      ...options
    });
  }
  /**
   * Envia imagem
   */
  async sendImage(userId, jid, image, caption, socket, origin, options) {
    const content = typeof image === "string" ? { image: { url: image }, caption } : { image, caption };
    return this.sendMessage({
      userId,
      jid,
      content,
      socket,
      origin,
      ...options
    });
  }
  /**
   * Envia vídeo
   */
  async sendVideo(userId, jid, video, caption, socket, origin, options) {
    const content = typeof video === "string" ? { video: { url: video }, caption } : { video, caption };
    return this.sendMessage({
      userId,
      jid,
      content,
      socket,
      origin,
      ...options
    });
  }
  /**
   * Envia áudio
   */
  async sendAudio(userId, jid, audio, ptt, socket, origin, options) {
    const mimetype = options?.mimetype;
    const content = typeof audio === "string" ? { audio: { url: audio }, ptt, mimetype } : { audio, ptt, mimetype };
    return this.sendMessage({
      userId,
      jid,
      content,
      socket,
      origin,
      ...options
    });
  }
  /**
   * Envia documento
   */
  async sendDocument(userId, jid, document, filename, mimetype, socket, origin, options) {
    const content = typeof document === "string" ? { document: { url: document }, fileName: filename, mimetype } : { document, fileName: filename, mimetype };
    return this.sendMessage({
      userId,
      jid,
      content,
      socket,
      origin,
      ...options
    });
  }
  /**
   * Envia botões usando ENQUETES (polls) do WhatsApp
   * @param payload - Pode ser objeto completo {body, buttons, header?, footer?} ou text simples
   * 
   * v3.0: Usa ENQUETES para simular botões interativos
   * FUNCIONA EM TODOS OS DISPOSITIVOS (Android, iOS, Web)
   */
  async sendButtons(userId, jid, payload, socket, origin, options) {
    if (typeof payload === "string") {
      return this.sendMessage({
        userId,
        jid,
        content: { text: payload },
        socket,
        origin,
        ...options
      });
    }
    if (!payload.body || !payload.buttons?.length) {
      return this.sendMessage({
        userId,
        jid,
        content: payload,
        socket,
        origin,
        ...options
      });
    }
    if (USE_POLLS_FOR_BUTTONS) {
      try {
        console.log(`\u{1F5F3}\uFE0F [POLL-BUTTONS] Enviando ${payload.buttons.length} op\xE7\xF5es como enquete para ${jid.substring(0, 15)}...`);
        if (SEND_CONTEXT_BEFORE_POLL) {
          let contextText = payload.body;
          if (payload.footer?.text) {
            contextText += `

${payload.footer.text}`;
          }
          const contactNumber = jid.replace(/@.*$/, "");
          const canSendResult = antiBanProtectionService.canSendMessage(userId);
          if (canSendResult.canSend) {
            await antiBanProtectionService.prepareAdaptiveDelayPolicy(userId);
            const delay = antiBanProtectionService.calculateDelay(userId, contactNumber);
            await new Promise((r) => setTimeout(r, delay));
            await socket.sendMessage(jid, { text: contextText });
            antiBanProtectionService.registerMessageSent(userId, contactNumber);
            console.log(`\u{1F4DD} [POLL-BUTTONS] Texto de contexto enviado`);
            await new Promise((r) => setTimeout(r, 500));
          }
        }
        const pollOptions = payload.buttons.map(
          (btn) => btn.reply?.title || btn.title || `Op\xE7\xE3o`
        );
        const pollName = payload.header?.text || "Selecione uma op\xE7\xE3o:";
        const pollResult = await socket.sendMessage(jid, {
          poll: {
            name: pollName,
            values: pollOptions,
            selectableCount: 1
            // Usuário só pode votar em UMA opção
          }
        });
        console.log(`\u2705 [POLL-BUTTONS] Enquete enviada com sucesso! ID: ${pollResult?.key?.id}`);
        if (pollResult?.key?.id) {
          this.registerPollMapping(pollResult.key.id, jid, payload.buttons);
        }
        this.recordSent(userId, origin, true);
        return {
          success: true,
          messageId: pollResult?.key?.id || void 0,
          waitedMs: 500
        };
      } catch (pollError) {
        console.error(`\u26A0\uFE0F [POLL-BUTTONS] Falha ao enviar enquete, usando fallback texto:`, pollError);
      }
    }
    let formattedText = payload.body;
    if (payload.footer?.text) {
      formattedText += `

${payload.footer.text}`;
    }
    if (payload.buttons && payload.buttons.length > 0) {
      formattedText += "\n\n*\u{1F4CB} Escolha uma op\xE7\xE3o:*\n";
      payload.buttons.forEach((btn, index) => {
        const number = index + 1;
        const title = btn.reply?.title || btn.title || `Op\xE7\xE3o ${number}`;
        formattedText += `
*${number}.* ${title}`;
      });
      formattedText += "\n\n_\u{1F446} Digite o n\xFAmero ou escreva sua escolha_";
    }
    console.log(`\u{1F522} [MENU-NUMERICO] Enviando ${payload.buttons?.length || 0} op\xE7\xF5es como texto numerado`);
    const content = { text: formattedText };
    console.log(`\u{1F4F1} [BUTTONS\u2192TEXT] Enviando ${payload.buttons?.length || 0} bot\xF5es como texto para ${jid.substring(0, 15)}...`);
    return this.sendMessage({
      userId,
      jid,
      content,
      socket,
      origin,
      ...options
    });
  }
  /**
   * Envia lista usando ENQUETES (polls) do WhatsApp
   * @param payload - Pode ser objeto completo {body, buttonText, sections, header?, footer?} ou text simples
   * 
   * v3.0: Usa ENQUETES para simular listas interativas
   * FUNCIONA EM TODOS OS DISPOSITIVOS (Android, iOS, Web)
   */
  async sendList(userId, jid, payload, socket, origin, options) {
    if (typeof payload === "string") {
      return this.sendMessage({
        userId,
        jid,
        content: { text: payload },
        socket,
        origin,
        ...options
      });
    }
    if (!payload.body || !payload.sections?.length) {
      return this.sendMessage({
        userId,
        jid,
        content: payload,
        socket,
        origin,
        ...options
      });
    }
    if (USE_POLLS_FOR_BUTTONS) {
      try {
        const totalItems2 = payload.sections.reduce((acc, s) => acc + (s.rows?.length || 0), 0);
        console.log(`\u{1F5F3}\uFE0F [POLL-LIST] Enviando lista com ${totalItems2} itens como enquete para ${jid.substring(0, 15)}...`);
        if (SEND_CONTEXT_BEFORE_POLL) {
          let contextText = payload.body;
          if (payload.footer?.text) {
            contextText += `

${payload.footer.text}`;
          }
          const contactNumber = jid.replace(/@.*$/, "");
          const canSendResult = antiBanProtectionService.canSendMessage(userId);
          if (canSendResult.canSend) {
            await antiBanProtectionService.prepareAdaptiveDelayPolicy(userId);
            const delay = antiBanProtectionService.calculateDelay(userId, contactNumber);
            await new Promise((r) => setTimeout(r, delay));
            await socket.sendMessage(jid, { text: contextText });
            antiBanProtectionService.registerMessageSent(userId, contactNumber);
            console.log(`\u{1F4DD} [POLL-LIST] Texto de contexto enviado`);
            await new Promise((r) => setTimeout(r, 500));
          }
        }
        const allItems = [];
        const buttonMappings = [];
        for (const section of payload.sections) {
          for (const row of section.rows || []) {
            allItems.push(row.title || "Op\xE7\xE3o");
            buttonMappings.push({
              reply: { id: row.id, title: row.title },
              id: row.id,
              title: row.title
            });
          }
        }
        const pollOptions = allItems.slice(0, 12);
        const limitedMappings = buttonMappings.slice(0, 12);
        const pollName = payload.header?.text || payload.buttonText || "Selecione uma op\xE7\xE3o:";
        const pollResult = await socket.sendMessage(jid, {
          poll: {
            name: pollName,
            values: pollOptions,
            selectableCount: 1
            // Usuário só pode votar em UMA opção
          }
        });
        console.log(`\u2705 [POLL-LIST] Enquete enviada com sucesso! ID: ${pollResult?.key?.id}`);
        if (pollResult?.key?.id) {
          this.registerPollMapping(pollResult.key.id, jid, limitedMappings);
        }
        this.recordSent(userId, origin, true);
        return {
          success: true,
          messageId: pollResult?.key?.id || void 0,
          waitedMs: 500
        };
      } catch (pollError) {
        console.error(`\u26A0\uFE0F [POLL-LIST] Falha ao enviar enquete, usando fallback texto:`, pollError);
      }
    }
    let formattedText = payload.body;
    if (payload.footer?.text) {
      formattedText += `

${payload.footer.text}`;
    }
    if (payload.sections && payload.sections.length > 0) {
      let itemIndex = 1;
      payload.sections.forEach((section) => {
        if (section.title) {
          formattedText += `

*\u{1F4C2} ${section.title}*`;
        }
        if (section.rows && section.rows.length > 0) {
          section.rows.forEach((row) => {
            formattedText += `
*${itemIndex}.* ${row.title}`;
            if (row.description) {
              formattedText += `
   _${row.description}_`;
            }
            itemIndex++;
          });
        }
      });
      formattedText += "\n\n_\u{1F446} Digite o n\xFAmero ou escreva sua escolha_";
    }
    const content = { text: formattedText };
    const totalItems = payload.sections?.reduce((acc, s) => acc + (s.rows?.length || 0), 0) || 0;
    console.log(`\u{1F4CB} [LIST\u2192TEXT] Enviando lista com ${totalItems} itens como texto para ${jid.substring(0, 15)}...`);
    return this.sendMessage({
      userId,
      jid,
      content,
      socket,
      origin,
      ...options
    });
  }
  /**
   * Reseta contador de batch (quando cliente interage)
   */
  resetBatchCounter(userId) {
    antiBanProtectionService.resetBatchCounter(userId);
  }
};
var centralizedMessageSender = new CentralizedMessageSender();
var centralizedMessageSender_default = centralizedMessageSender;

export {
  ANTI_BAN_CONFIG,
  groupMetadataCache,
  simulateTyping,
  antiBanProtectionService,
  channelDispatchLock,
  resolvePendingPriorityWaitMs,
  countPendingPriorityConversations,
  isConversationPendingPriority,
  parseExplicitBubbleMessages,
  joinBubbleMessages,
  normalizeOutboundTextForCustomer,
  buildPlainTextWhatsAppPayload,
  buildGatewayTextSendBody,
  getPollMapping,
  getButtonIdFromPollVote,
  centralizedMessageSender,
  centralizedMessageSender_default
};
