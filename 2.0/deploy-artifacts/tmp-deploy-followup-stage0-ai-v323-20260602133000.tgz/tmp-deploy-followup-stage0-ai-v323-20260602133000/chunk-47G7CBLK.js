import {
  repairMojibakeDeep,
  repairMojibakeText
} from "./chunk-K6J2PMOD.js";
import {
  chatComplete,
  getLLMConfig
} from "./chunk-M7TXNZTC.js";
import {
  getMistralClient,
  runWithLLMUserContext
} from "./chunk-UKCWWGWI.js";
import {
  pool
} from "./chunk-R6CXRQMB.js";

// server/promptEditService.ts
import { responseFormatFromZodObject } from "@mistralai/mistralai/extra/structChat.js";
import { z } from "zod";

// server/promptEditEngine.ts
import OpenAI from "openai";
function parseDocumentSections(doc) {
  const sections = [];
  const lines = doc.split("\n");
  let currentSection = null;
  let lineStart = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const isHeader = /^#{1,4}\s+/.test(line) || /^[•\-\*]\s+\*\*/.test(line);
    if (isHeader) {
      if (currentSection) {
        currentSection.endIndex = lineStart - 1;
        sections.push(currentSection);
      }
      currentSection = {
        name: line.replace(/^[#•\-\*\s]+\*?\*?/, "").replace(/\*?\*?$/, "").trim(),
        content: line,
        startIndex: lineStart,
        endIndex: doc.length
      };
    } else if (currentSection) {
      currentSection.content += "\n" + line;
    }
    lineStart += line.length + 1;
  }
  if (currentSection) {
    currentSection.endIndex = doc.length;
    sections.push(currentSection);
  }
  return sections;
}
function findRelevantSection(doc, keywords) {
  const sections = parseDocumentSections(doc);
  for (const section of sections) {
    const sectionLower = section.name.toLowerCase() + " " + section.content.toLowerCase();
    const matchCount = keywords.filter((kw) => sectionLower.includes(kw.toLowerCase())).length;
    if (matchCount >= 2 || keywords.length === 1 && matchCount === 1) {
      return section;
    }
  }
  return null;
}
function stringSimilarity(str1, str2) {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  if (s1 === s2) return 1;
  if (s1.length === 0 || s2.length === 0) return 0;
  const longer = s1.length > s2.length ? s1 : s2;
  const shorter = s1.length > s2.length ? s2 : s1;
  if (longer.length === 0) return 1;
  if (longer.includes(shorter)) {
    return shorter.length / longer.length;
  }
  const tokens1 = s1.split(/[^a-z0-9]+/g).filter((t) => t.length > 0);
  const tokens2 = s2.split(/[^a-z0-9]+/g).filter((t) => t.length > 0);
  const set1 = new Set(tokens1);
  const set2 = new Set(tokens2);
  let common = 0;
  set1.forEach((w) => {
    if (set2.has(w)) common++;
  });
  if (set1.size === 0 && set2.size === 0) {
    const w1 = new Set(s1.split(/\s+/));
    const w2 = new Set(s2.split(/\s+/));
    let c = 0;
    w1.forEach((w) => {
      if (w2.has(w)) c++;
    });
    return c / Math.max(w1.size, w2.size);
  }
  return common / Math.max(set1.size, set2.size);
}
function fuzzyFind(doc, search, threshold = 0.6) {
  const exactIndex = doc.indexOf(search);
  if (exactIndex !== -1) {
    return { found: search, index: exactIndex, similarity: 1 };
  }
  const lowerDoc = doc.toLowerCase();
  const lowerSearch = search.toLowerCase();
  const caseInsensitiveIndex = lowerDoc.indexOf(lowerSearch);
  if (caseInsensitiveIndex !== -1) {
    return {
      found: doc.substring(caseInsensitiveIndex, caseInsensitiveIndex + search.length),
      index: caseInsensitiveIndex,
      similarity: 0.95
    };
  }
  const docLines = doc.split("\n");
  const searchLines = search.split("\n");
  if (searchLines.length === 1) {
    let bestMatch = { found: "", index: -1, similarity: 0 };
    let currentIndex = 0;
    for (const line of docLines) {
      const sim = stringSimilarity(line, search);
      if (sim > bestMatch.similarity && sim >= threshold) {
        bestMatch = { found: line, index: currentIndex, similarity: sim };
      }
      currentIndex += line.length + 1;
    }
    return bestMatch.index !== -1 ? bestMatch : null;
  }
  for (let i = 0; i <= docLines.length - searchLines.length; i++) {
    const block = docLines.slice(i, i + searchLines.length).join("\n");
    const sim = stringSimilarity(block, search);
    if (sim >= threshold) {
      const index = doc.indexOf(docLines[i]);
      return { found: block, index, similarity: sim };
    }
  }
  return null;
}
function applySearchReplace(doc, search, replace, replaceAll = false) {
  if (doc.includes(search)) {
    return {
      success: true,
      result: replaceAll ? doc.split(search).join(replace) : doc.replace(search, replace),
      message: replaceAll ? `Substitu\xEDdas todas as ocorr\xEAncias` : `Substitu\xEDdo com sucesso`
    };
  }
  const fuzzyResult = fuzzyFind(doc, search, 0.7);
  if (fuzzyResult) {
    let result = doc.substring(0, fuzzyResult.index) + replace + doc.substring(fuzzyResult.index + fuzzyResult.found.length);
    if (replaceAll) {
      while (result.includes(fuzzyResult.found)) {
        result = result.replace(fuzzyResult.found, replace);
      }
    }
    return {
      success: true,
      result,
      message: `Encontrado texto similar (${Math.round(fuzzyResult.similarity * 100)}% match) e substitu\xEDdo`
    };
  }
  return {
    success: false,
    result: doc,
    message: `N\xE3o encontrei "${search.substring(0, 50)}..." no documento`
  };
}
function applyInsert(doc, content, position, anchor) {
  if (position === "start") {
    return { success: true, result: content + "\n" + doc, message: "Inserido no in\xEDcio" };
  }
  if (position === "end") {
    return { success: true, result: doc + "\n" + content, message: "Inserido no final" };
  }
  if (!anchor) {
    return { success: false, result: doc, message: "\xC2ncora necess\xE1ria para inser\xE7\xE3o before/after" };
  }
  const fuzzyResult = fuzzyFind(doc, anchor, 0.7);
  if (!fuzzyResult) {
    return {
      success: true,
      result: doc + "\n" + content,
      message: `N\xE3o encontrei "${anchor.substring(0, 30)}...", adicionado no final`
    };
  }
  if (position === "before") {
    const result = doc.substring(0, fuzzyResult.index) + content + "\n" + doc.substring(fuzzyResult.index);
    return { success: true, result, message: "Inserido antes do ponto encontrado" };
  }
  if (position === "after") {
    const endPos = fuzzyResult.index + fuzzyResult.found.length;
    const result = doc.substring(0, endPos) + "\n" + content + doc.substring(endPos);
    return { success: true, result, message: "Inserido depois do ponto encontrado" };
  }
  return { success: false, result: doc, message: "Posi\xE7\xE3o inv\xE1lida" };
}
function applyDelete(doc, search) {
  const fuzzyResult = fuzzyFind(doc, search, 0.7);
  if (fuzzyResult) {
    let result = doc.substring(0, fuzzyResult.index) + doc.substring(fuzzyResult.index + fuzzyResult.found.length);
    result = result.replace(/\n{3,}/g, "\n\n");
    return { success: true, result, message: "Removido com sucesso" };
  }
  return { success: false, result: doc, message: `N\xE3o encontrei para remover: "${search.substring(0, 50)}..."` };
}
function parseUserIntent(instruction) {
  const instr = instruction.toLowerCase().trim();
  const changePatterns = [
    // Padrão específico para nome com "da/do" opcional: "mude o nome da pizzaria para X"
    /(?:mude?|altere?|troque?|substitua?|modifique?)\s+(?:o\s+)?nome\s+(?:d[aoe]s?\s+\w+\s+)?(?:para|por|:)\s*(.+)/i,
    // Padrão genérico
    /(?:mude?|altere?|troque?|substitua?|modifique?)\s+(?:o|a|os|as)?\s*(.+?)\s+(?:para|por|:)\s*(.+)/i,
    /(?:o|a)\s+(.+?)\s+(?:agora\s+)?(?:é|será?|deve\s+ser)\s+(.+)/i,
    /(.+?)\s*(?:->|→|=>)\s*(.+)/i,
    /(?:nome|preço|valor|horário|telefone|endereço)\s*(?:novo|:)\s*(.+)/i,
    // Padrão para "a empresa/loja chama X"
    /(?:a?\s*empresa|o?\s*estabelecimento|a?\s*loja|o?\s*restaurante)\s+(?:se\s+)?chama\s+(.+)/i,
    // Padrão para "X aumentou/diminuiu/mudou para Y"
    /(.+?)\s+(?:aumentou|diminuiu|mudou|passou)\s+para\s+(.+)/i
  ];
  for (const pattern of changePatterns) {
    const match = instruction.match(pattern);
    if (match) {
      const target = match[1]?.trim() || "";
      const newValue = match[2]?.trim() || match[1]?.trim();
      return {
        action: "change",
        target,
        newValue,
        keywords: extractKeywords(target + " " + newValue),
        confidence: 0.9
      };
    }
  }
  const removePatterns = [
    // Padrão para "remova isso/aquilo" (contexto anterior) - tenta pegar o que vem antes
    /(.+?)[,.]\s*(?:remova?|tire?|delete?|exclua?|apague?)\s+(?:isso|aquilo|ele|ela)/i,
    // Padrões normais
    /(?:remova?|tire?|delete?|exclua?|apague?)\s+(?:a\s+)?(?:parte|seção|menção|info(?:rmação)?|texto)?\s*(?:de|sobre|do|da)?\s*(.+)/i,
    /(?:não|nao)\s+(?:mais\s+)?(?:mencione?|fale?|diga|tenha|precisa|quero)\s+(?:sobre|de|a|o)?\s*(.+)/i,
    /(?:sem|tire?)\s+(.+)/i
  ];
  for (const pattern of removePatterns) {
    const match = instruction.match(pattern);
    if (match) {
      return {
        action: "remove",
        target: match[1]?.trim() || "",
        keywords: extractKeywords(match[1] || ""),
        confidence: 0.85
      };
    }
  }
  return {
    action: "describe",
    target: instruction,
    keywords: extractKeywords(instruction),
    confidence: 0.5
  };
}
function extractKeywords(text) {
  const stopWords = /* @__PURE__ */ new Set(["o", "a", "os", "as", "um", "uma", "de", "da", "do", "para", "por", "com", "em", "no", "na", "que", "e", "\xE9", "ser", "ter", "mais", "muito", "seu", "sua"]);
  return text.toLowerCase().split(/\s+/).filter((w) => w.length > 2 && !stopWords.has(w)).slice(0, 10);
}
function editPromptAdvanced(currentPrompt, userInstruction) {
  const operations = [];
  let workingDoc = currentPrompt;
  const feedbackParts = [];
  const intent = parseUserIntent(userInstruction);
  console.log(`[EditEngine] Inten\xE7\xE3o detectada: ${intent.action}, target: "${intent.target}", confidence: ${intent.confidence}`);
  switch (intent.action) {
    case "change": {
      const changeResult = processChange(workingDoc, intent, userInstruction);
      if (changeResult.success) {
        workingDoc = changeResult.newDoc;
        operations.push(...changeResult.operations);
        feedbackParts.push(changeResult.feedback);
      } else {
        feedbackParts.push(`\u26A0\uFE0F ${changeResult.feedback}`);
      }
      break;
    }
    case "add": {
      const addResult = processAdd(workingDoc, intent, userInstruction);
      workingDoc = addResult.newDoc;
      operations.push(...addResult.operations);
      feedbackParts.push(addResult.feedback);
      break;
    }
    case "remove": {
      const removeResult = processRemove(workingDoc, intent);
      if (removeResult.success) {
        workingDoc = removeResult.newDoc;
        operations.push(...removeResult.operations);
        feedbackParts.push(removeResult.feedback);
      } else {
        feedbackParts.push(`\u26A0\uFE0F ${removeResult.feedback}`);
      }
      break;
    }
    case "describe":
    default: {
      const descResult = processDescribe(workingDoc, intent, userInstruction);
      workingDoc = descResult.newDoc;
      operations.push(...descResult.operations);
      feedbackParts.push(descResult.feedback);
      break;
    }
  }
  workingDoc = workingDoc.replace(/\n{3,}/g, "\n\n").trim();
  const success = operations.length > 0 && workingDoc !== currentPrompt;
  const summary = operations.map((op) => op.explanation).join("; ");
  return {
    success,
    newPrompt: success ? workingDoc : currentPrompt,
    operations,
    summary: summary || "Nenhuma altera\xE7\xE3o necess\xE1ria",
    feedbackMessage: feedbackParts.join("\n") || "Pronto!"
  };
}
function processChange(doc, intent, rawInstruction) {
  const operations = [];
  let newDoc = doc;
  const namePatterns = [
    // Padrão mais flexível para "nome da X para Y" - permite apóstrofos
    /(?:mude?|troque?|altere?)\s+(?:o\s+)?nome\s+(?:d[aoe]s?\s+\w+\s+)?(?:para|por|:)\s*["""']?([^"""\n.!?]+)/i,
    /(?:nome|empresa|estabelecimento|loja|restaurante)\s*(?:para|:|\s+é)\s*["""']?([^"""\n.!?]+)/i,
    /(?:chama(?:r)?|renomea?r?)\s+(?:para|:)\s*["""']?([^"""\n.!?]+)/i,
    /(?:a?\s*empresa|o?\s*estabelecimento)\s+(?:se\s+)?chama\s*["""']?([^"""\n.!?]+)/i,
    /(?:o?\s*nome\s+)?agora\s+(?:é|sera?)\s*["""']?([^"""\n.!?]+)/i
  ];
  for (const pattern of namePatterns) {
    const match = rawInstruction.match(pattern);
    if (match && match[1]) {
      const newName = match[1].trim();
      const firstLine = doc.split("\n")[0];
      const currentNameMatch = firstLine.match(/^([^-–—\n]+)/);
      if (currentNameMatch && currentNameMatch[1].trim()) {
        const currentName = currentNameMatch[1].trim();
        if (currentName !== newName && currentName.length > 2) {
          const result = applySearchReplace(newDoc, currentName, newName, true);
          if (result.success) {
            newDoc = result.result;
            operations.push({
              type: "replace",
              search: currentName,
              replace: newName,
              explanation: `Nome alterado de "${currentName}" para "${newName}" (todas as ocorr\xEAncias)`
            });
            return {
              success: true,
              newDoc,
              operations,
              feedback: `\u2705 Nome alterado: **${currentName}** \u2192 **${newName}**`
            };
          }
        }
      }
    }
  }
  const directReplacePatterns = [
    /(?:mude?|troque?|substituir?)\s+["""']?([^"""'\n]+?)["""']?\s+(?:para|por|->|→)\s*["""']?([^"""'\n]+)/i,
    /["""']?([^"""'\n]+?)["""']?\s*(?:->|→|=>)\s*["""']?([^"""'\n]+)/i
  ];
  for (const pattern of directReplacePatterns) {
    const match = rawInstruction.match(pattern);
    if (match && match[1] && match[2]) {
      const oldText = match[1].trim();
      const newText = match[2].trim();
      if (doc.includes(oldText) || fuzzyFind(doc, oldText, 0.7)) {
        const result = applySearchReplace(newDoc, oldText, newText, true);
        if (result.success) {
          newDoc = result.result;
          operations.push({
            type: "replace",
            search: oldText,
            replace: newText,
            explanation: `Substitu\xEDdo: "${oldText}" \u2192 "${newText}"`
          });
          return {
            success: true,
            newDoc,
            operations,
            feedback: `\u2705 Substitu\xEDdo: **${oldText}** \u2192 **${newText}**`
          };
        }
      }
    }
  }
  const emojiPattern = /(?:mude?|troque?|substituir?)\s+(?:o\s+)?emoji\s*(?:de\s+\w+\s*)?(?:para|por|:|-|→)\s*(.+)/i;
  const emojiMatch = rawInstruction.match(emojiPattern);
  if (emojiMatch && emojiMatch[1]) {
    const newEmoji = emojiMatch[1].trim();
    const emojiRegex = /[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}]+/gu;
    const existingEmojis = doc.match(emojiRegex);
    if (existingEmojis && existingEmojis.length > 0) {
      const oldEmoji = existingEmojis[0];
      newDoc = newDoc.replace(oldEmoji, newEmoji);
      operations.push({
        type: "replace",
        search: oldEmoji,
        replace: newEmoji,
        explanation: `Emoji alterado: "${oldEmoji}" \u2192 "${newEmoji}"`
      });
      return {
        success: true,
        newDoc,
        operations,
        feedback: `\u2705 Emoji alterado: **${oldEmoji}** \u2192 **${newEmoji}**`
      };
    }
  }
  const contextualValuePattern = /(.+?)\s+(?:aumentou|diminuiu|mudou|passou|agora\s+é)\s+(?:para|por)?\s*(R?\$?\s*[\d.,]+|\d{1,2}h?|final\s+\d+)/i;
  const contextMatch = rawInstruction.match(contextualValuePattern);
  if (contextMatch && contextMatch[1] && contextMatch[2]) {
    let item = contextMatch[1].trim();
    const newValue = contextMatch[2].trim();
    item = item.replace(/^(?:a|o|as|os|um|uma|uns|umas)\s+/i, "");
    let itemFuzzy = fuzzyFind(doc, item, 0.6);
    if (!itemFuzzy) {
      if (item.toLowerCase().includes("telefone") || item.toLowerCase().includes("celular")) {
        itemFuzzy = fuzzyFind(doc, "whatsapp", 0.6) || fuzzyFind(doc, "contato", 0.6);
      }
    }
    if (itemFuzzy) {
      const lineStart = doc.lastIndexOf("\n", itemFuzzy.index);
      const lineEnd = doc.indexOf("\n", itemFuzzy.index);
      const line = doc.substring(lineStart + 1, lineEnd !== -1 ? lineEnd : void 0);
      const valueRegex = /R?\$\s*[\d.,]+|\d{1,2}h|\(?\d{2}\)?[\s\-]?\d{4,5}[\s\-]?\d{4}/g;
      const valuesInLine = line.match(valueRegex);
      if (valuesInLine && valuesInLine.length > 0) {
        const oldValue = valuesInLine[valuesInLine.length - 1];
        const newLine = line.replace(oldValue, newValue);
        const result = applySearchReplace(newDoc, line, newLine);
        if (result.success) {
          newDoc = result.result;
          operations.push({
            type: "replace",
            search: oldValue,
            replace: newValue,
            explanation: `Valor de "${item}" atualizado: "${oldValue}" \u2192 "${newValue}"`
          });
          return {
            success: true,
            newDoc,
            operations,
            feedback: `\u2705 Valor de **${item}** atualizado: **${oldValue}** \u2192 **${newValue}**`
          };
        }
      }
    }
  }
  const valuePatterns = [
    { regex: /preço\s*(?:mínimo\s*)?(?:para|de|:)\s*(R?\$?\s*[\d.,]+)/i, type: "pre\xE7o", searchRegex: /R?\$\s*[\d.,]+/g },
    { regex: /(?:horário|funciona(?:mento)?)\s*(?:de|:)?\s*(\d{1,2}h?\s*(?:às|a|-)\s*\d{1,2}h?)/i, type: "hor\xE1rio", searchRegex: /\d{1,2}h?\s*(?:às|a|-)\s*\d{1,2}h?/g },
    // Telefone: exige pelo menos um dígito para não pegar string vazia
    { regex: /(?:telefone|whatsapp|contato)\s*(?::|para)?\s*([\d\s\(\)\-\+]*\d[\d\s\(\)\-\+]*)/i, type: "telefone", searchRegex: /\(?\d{2}\)?[\s\-]?\d{4,5}[\s\-]?\d{4}/g }
  ];
  for (const { regex, type, searchRegex } of valuePatterns) {
    const match = rawInstruction.match(regex);
    if (match && match[1]) {
      const newValue = match[1].trim();
      const oldMatches = doc.match(searchRegex);
      if (oldMatches && oldMatches[0] !== newValue) {
        const oldValue = oldMatches[0];
        const result = applySearchReplace(newDoc, oldValue, newValue);
        if (result.success) {
          newDoc = result.result;
          operations.push({
            type: "replace",
            search: oldValue,
            replace: newValue,
            explanation: `${type} atualizado: "${oldValue}" \u2192 "${newValue}"`
          });
          return {
            success: true,
            newDoc,
            operations,
            feedback: `\u2705 ${type.charAt(0).toUpperCase() + type.slice(1)} atualizado: **${oldValue}** \u2192 **${newValue}**`
          };
        }
      }
    }
  }
  if (intent.target && intent.newValue) {
    const fuzzyResult = fuzzyFind(doc, intent.target, 0.6);
    if (fuzzyResult) {
      const result = applySearchReplace(newDoc, fuzzyResult.found, intent.newValue);
      if (result.success) {
        newDoc = result.result;
        operations.push({
          type: "replace",
          search: fuzzyResult.found,
          replace: intent.newValue,
          explanation: `Substitu\xEDdo: "${fuzzyResult.found.substring(0, 30)}..." \u2192 "${intent.newValue.substring(0, 30)}..."`
        });
        return {
          success: true,
          newDoc,
          operations,
          feedback: `\u2705 Encontrei e substitu\xED o texto`
        };
      }
    }
  }
  if (rawInstruction.match(/\binformal\b|descontraído|amigável/i)) {
    const replacements = [
      ["o(a) senhor(a)", "voc\xEA"],
      ["O(a) senhor(a)", "Voc\xEA"],
      ["O senhor", "Voc\xEA"],
      ["o senhor", "voc\xEA"],
      ["A senhora", "Voc\xEA"],
      ["a senhora", "voc\xEA"],
      ["prezado", "oi"],
      ["Prezado", "Oi"]
    ];
    let changed = false;
    for (const [from, to] of replacements) {
      if (newDoc.includes(from)) {
        newDoc = newDoc.split(from).join(to);
        changed = true;
        operations.push({
          type: "replace",
          search: from,
          replace: to,
          explanation: `Tom informal: "${from}" \u2192 "${to}"`
        });
      }
    }
    if (changed) {
      return { success: true, newDoc, operations, feedback: "\u2705 Tom alterado para mais informal" };
    }
  }
  if (rawInstruction.match(/(?<![in])\bformal\b|profissional/i)) {
    const replacements = [
      ["voc\xEA", "o(a) senhor(a)"],
      ["Voc\xEA", "O(a) senhor(a)"],
      ["oi", "Ol\xE1"],
      ["Oi", "Ol\xE1"],
      ["t\xE1", "est\xE1"],
      ["pra", "para"],
      ["beleza", "perfeito"],
      ["blz", "perfeito"]
    ];
    let changed = false;
    for (const [from, to] of replacements) {
      if (newDoc.includes(from)) {
        newDoc = newDoc.split(from).join(to);
        changed = true;
        operations.push({
          type: "replace",
          search: from,
          replace: to,
          explanation: `Tom formal: "${from}" \u2192 "${to}"`
        });
      }
    }
    if (changed) {
      return { success: true, newDoc, operations, feedback: "\u2705 Tom alterado para mais formal" };
    }
  }
  return {
    success: false,
    newDoc: doc,
    operations: [],
    feedback: `N\xE3o consegui encontrar o que voc\xEA quer mudar. Tente ser mais espec\xEDfico, ex: "mude o nome para X" ou "pre\xE7o: R$50"`
  };
}
function processAdd(doc, intent, rawInstruction) {
  const operations = [];
  let newDoc = doc;
  const content = intent.target;
  const section = findRelevantSection(doc, intent.keywords);
  if (section) {
    const result = applyInsert(newDoc, content, "after", section.name);
    newDoc = result.result;
    operations.push({
      type: "insert",
      replace: content,
      position: "after",
      anchor: section.name,
      explanation: `Adicionado na se\xE7\xE3o "${section.name}"`
    });
    return { newDoc, operations, feedback: `\u2705 Adicionado na se\xE7\xE3o **${section.name}**` };
  }
  const formattedContent = content.startsWith("#") || content.startsWith("\u2022") ? content : `\u2022 ${content}`;
  newDoc = doc.trim() + "\n\n" + formattedContent;
  operations.push({
    type: "insert",
    replace: formattedContent,
    position: "end",
    explanation: `Adicionado ao final do prompt`
  });
  return { newDoc, operations, feedback: `\u2705 Informa\xE7\xE3o adicionada ao prompt` };
}
function processRemove(doc, intent) {
  const operations = [];
  let newDoc = doc;
  const lines = doc.split("\n");
  const targetLower = intent.target.toLowerCase();
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.toLowerCase().includes(targetLower) && line.trim().length > 3) {
      const result = applyDelete(newDoc, line);
      if (result.success) {
        newDoc = result.result;
        operations.push({
          type: "delete",
          search: line,
          explanation: `Removida linha: "${line.substring(0, 40)}..."`
        });
        return {
          success: true,
          newDoc,
          operations,
          feedback: `\u2705 Removido: "${line.substring(0, 50)}${line.length > 50 ? "..." : ""}"`
        };
      }
    }
  }
  if (intent.keywords && intent.keywords.length > 0) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].toLowerCase();
      const matchCount = intent.keywords.filter((k) => line.includes(k)).length;
      if (intent.keywords.length > 2 && matchCount >= intent.keywords.length * 0.5 || intent.keywords.length === 2 && matchCount === 2 || intent.keywords.length === 1 && matchCount === 1 && line.includes(intent.keywords[0])) {
        const originalLine = lines[i];
        const result = applyDelete(newDoc, originalLine);
        if (result.success) {
          newDoc = result.result;
          operations.push({
            type: "delete",
            search: originalLine,
            explanation: `Removida linha (por keywords): "${originalLine.substring(0, 40)}..."`
          });
          return {
            success: true,
            newDoc,
            operations,
            feedback: `\u2705 Removido: "${originalLine.substring(0, 50)}..."`
          };
        }
      }
    }
  }
  const fuzzyResult = fuzzyFind(doc, intent.target, 0.5);
  if (fuzzyResult) {
    const result = applyDelete(newDoc, fuzzyResult.found);
    if (result.success) {
      newDoc = result.result;
      operations.push({
        type: "delete",
        search: fuzzyResult.found,
        explanation: `Removido (match fuzzy): "${fuzzyResult.found.substring(0, 40)}..."`
      });
      return {
        success: true,
        newDoc,
        operations,
        feedback: `\u2705 Encontrei e removi o texto relacionado`
      };
    }
  }
  return {
    success: false,
    newDoc: doc,
    operations: [],
    feedback: `N\xE3o encontrei "${intent.target}" para remover`
  };
}
function processDescribe(doc, intent, rawInstruction) {
  const operations = [];
  let newDoc = doc;
  if (rawInstruction.match(/\binformal\b|descontraído|amigável|casual/i)) {
    const replacements = [
      // Primeiro as expressões mais longas (ordem importa!)
      ["O(a) senhor(a)", "Voc\xEA"],
      ["o(a) senhor(a)", "voc\xEA"],
      ["Prezado cliente", "Oi"],
      ["prezado cliente", "oi"],
      // Senhor/Senhora - várias formas
      ["O senhor", "Voc\xEA"],
      ["o senhor", "voc\xEA"],
      ["A senhora", "Voc\xEA"],
      ["a senhora", "voc\xEA"],
      // Expressões formais
      ["Prezado", "Oi"],
      ["prezado", "oi"],
      ["Estimado", "Oi"],
      ["estimado", "oi"],
      ["Atenciosamente", "Abra\xE7os"],
      ["atenciosamente", "abra\xE7os"],
      ["Cordialmente", "At\xE9 logo"],
      ["cordialmente", "at\xE9 logo"]
    ];
    let changed = false;
    for (const [from, to] of replacements) {
      if (newDoc.includes(from)) {
        newDoc = newDoc.split(from).join(to);
        changed = true;
        operations.push({
          type: "replace",
          search: from,
          replace: to,
          explanation: `Tom informal: "${from}" \u2192 "${to}"`
        });
      }
    }
    if (changed) {
      return { newDoc, operations, feedback: "\u2705 Tom alterado para mais informal" };
    }
  }
  if (rawInstruction.match(/(?<![in])\bformal\b|profissional/i)) {
    const replacements = [
      ["voc\xEA", "o(a) senhor(a)"],
      ["Voc\xEA", "O(a) senhor(a)"],
      ["oi", "Ol\xE1"],
      ["Oi", "Ol\xE1"],
      ["Oi!", "Ol\xE1!"],
      ["oi!", "Ol\xE1!"],
      // Usa word boundary para não substituir dentro de palavras
      [" t\xE1 ", " est\xE1 "],
      [" pra ", " para "],
      ["beleza", "perfeito"],
      ["Beleza", "Perfeito"],
      ["blz", "perfeito"],
      ["legal", "excelente"],
      ["Legal", "Excelente"],
      ["valeu", "obrigado"],
      ["Valeu", "Obrigado"],
      ["e a\xED", "como posso ajudar"],
      ["E a\xED", "Como posso ajudar"]
    ];
    let changed = false;
    for (const [from, to] of replacements) {
      if (newDoc.includes(from)) {
        newDoc = newDoc.split(from).join(to);
        changed = true;
        operations.push({
          type: "replace",
          search: from,
          replace: to,
          explanation: `Tom formal: "${from}" \u2192 "${to}"`
        });
      }
    }
    if (changed) {
      return { newDoc, operations, feedback: "\u2705 Tom alterado para mais formal" };
    }
  }
  const formattedContent = `
## \u{1F4DD} Instru\xE7\xE3o Adicional
${rawInstruction}`;
  newDoc = doc.trim() + formattedContent;
  operations.push({
    type: "insert",
    replace: formattedContent,
    position: "end",
    explanation: `Adicionada instru\xE7\xE3o: "${rawInstruction.substring(0, 50)}..."`
  });
  return {
    newDoc,
    operations,
    feedback: `\u2705 Instru\xE7\xE3o adicionada como nova regra`
  };
}
async function editPromptWithLLM(currentPrompt, userInstruction, _apiKey) {
  try {
    const { chatComplete: chatComplete2 } = await import("./llm-DNZPNX5V.js");
    const systemPrompt = `Voc\xEA \xE9 um especialista em edi\xE7\xE3o de texto e prompts.
Sua tarefa \xE9 editar o texto fornecido seguindo EXATAMENTE a instru\xE7\xE3o do usu\xE1rio.

IMPORTANTE:
Voc\xEA deve retornar as edi\xE7\xF5es no formato de BLOCOS DE BUSCA E SUBSTITUI\xC7\xC3O.
N\xE3o use JSON. Use exatamente este formato para cada altera\xE7\xE3o:

<<<<<<< SEARCH
(texto exato original que ser\xE1 substitu\xEDdo)
=======
(novo texto que entrar\xE1 no lugar)
>>>>>>> REPLACE

REGRAS CR\xCDTICAS:
1. O bloco SEARCH deve conter texto EXATO do original, incluindo espa\xE7os e quebras de linha.
2. Inclua linhas de contexto suficientes no SEARCH para garantir que seja \xFAnico.
3. Se for adicionar algo novo no final, use o final do texto atual como \xE2ncora no SEARCH.
4. Se for remover, o bloco REPLACE deve estar vazio (ou conter apenas o contexto mantido).
5. Retorne APENAS os blocos de edi\xE7\xE3o. Sem explica\xE7\xF5es extras.`;
    const userMessage = `TEXTO ORIGINAL:
"""
${currentPrompt}
"""

INSTRU\xC7\xC3O DO USU\xC1RIO:
"${userInstruction}"

Gere os blocos de edi\xE7\xE3o SEARCH/REPLACE para aplicar esta instru\xE7\xE3o.`;
    const response = await chatComplete2({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      temperature: 0
      // Determinístico para melhor precisão
    });
    const llmOutput = response.choices?.[0]?.message?.content || "";
    return applyLLMBlocks(currentPrompt, llmOutput);
  } catch (error) {
    console.error("[EditEngine] Erro na edi\xE7\xE3o via LLM:", error);
    return editPromptAdvanced(currentPrompt, userInstruction);
  }
}
function applyLLMBlocks(doc, blocks) {
  const operations = [];
  let newDoc = doc;
  const blockRegex = /<<<<<<< SEARCH\n([\s\S]*?)\n=======\n([\s\S]*?)>>>>>>> REPLACE/g;
  let match;
  while ((match = blockRegex.exec(blocks)) !== null) {
    const searchBlock = match[1];
    const replaceBlock = match[2].replace(/^\n/, "").replace(/\n$/, "");
    if (newDoc.includes(searchBlock)) {
      newDoc = newDoc.replace(searchBlock, replaceBlock);
      operations.push({
        type: "replace",
        search: searchBlock,
        replace: replaceBlock,
        explanation: "Edi\xE7\xE3o aplicada via LLM (Match Exato)"
      });
    } else {
      const fuzzy = fuzzyFind(newDoc, searchBlock, 0.65);
      if (fuzzy) {
        const result = applySearchReplace(newDoc, fuzzy.found, replaceBlock);
        if (result.success) {
          newDoc = result.result;
          operations.push({
            type: "replace",
            search: fuzzy.found,
            replace: replaceBlock,
            explanation: "Edi\xE7\xE3o aplicada via LLM (Fuzzy Match)"
          });
        }
      } else {
        console.warn("[EditEngine] Bloco n\xE3o encontrado:", searchBlock.substring(0, 50) + "...");
      }
    }
  }
  const success = operations.length > 0;
  return {
    success,
    newPrompt: newDoc,
    operations,
    summary: success ? "Edi\xE7\xF5es aplicadas via IA" : "Nenhuma edi\xE7\xE3o aplicada",
    feedbackMessage: success ? "\u2705 Altera\xE7\xF5es aplicadas com intelig\xEAncia artificial" : "\u26A0\uFE0F N\xE3o consegui aplicar as altera\xE7\xF5es sugeridas pela IA"
  };
}
async function editPrompt(currentPrompt, userInstruction, openaiApiKey) {
  if (openaiApiKey && openaiApiKey !== "your-openai-key") {
    try {
      return await editPromptWithLLM(currentPrompt, userInstruction, openaiApiKey);
    } catch (error) {
      console.error("[EditEngine] Fallback para edi\xE7\xE3o local ap\xF3s erro no LLM");
    }
  }
  return editPromptAdvanced(currentPrompt, userInstruction);
}

// server/promptEditService.ts
var plannerSchema = z.object({
  resposta_chat: z.string().min(1).max(320),
  objective: z.string().min(1).max(220),
  editScope: z.enum(["none", "targeted", "broad"]),
  sectionIds: z.array(z.string().min(1)).max(12),
  writerInstructions: z.array(z.string().min(1)).min(1).max(10),
  preserveDirectives: z.array(z.string().min(1)).max(8).default([])
});
var rewriteSchema = z.object({
  resposta_chat: z.string().min(1).max(320),
  edits: z.array(
    z.object({
      sectionId: z.string().min(1),
      updatedContent: z.string().min(1),
      summary: z.string().min(1).max(200)
    })
  ).min(1).max(6)
});
var fullRewriteSchema = z.object({
  resposta_chat: z.string().min(1).max(320),
  summary: z.string().min(1).max(220),
  updatedPrompt: z.string().min(1)
});
var explicitLiteralCuePhrases = [
  "literal exatamente assim:",
  "linha interna literal exatamente assim:",
  "linha final de marcador interno para ficar exatamente assim:",
  "ficar exatamente assim:",
  "exatamente assim:",
  "texto literal:"
];
function dedupeStringList(items) {
  const unique = [];
  for (const item of items) {
    if (!item || unique.includes(item)) {
      continue;
    }
    unique.push(item);
  }
  return unique;
}
function isQuoteChar(char) {
  return char === '"' || char === "'" || char === "\u201C" || char === "\u201D" || char === "\u2018" || char === "\u2019";
}
function trimWrappingQuoteChars(value) {
  let result = value.trim();
  while (result.length >= 2 && isQuoteChar(result[0]) && isQuoteChar(result[result.length - 1])) {
    result = result.slice(1, -1).trim();
  }
  return result;
}
function findNearestStopIndex(text, fromIndex) {
  const normalized = text.toLocaleLowerCase("pt-BR");
  const stopPhrases = [
    "\npreserve",
    "\nmantenha",
    "\nsem ",
    "\nnao ",
    "\nn\xE3o ",
    " preserve todo o restante",
    " preserve todo o resto",
    " preserve regras",
    " preserve modulos",
    " preserve fluxos",
    " mantenha ",
    " sem mudar",
    " sem alter",
    " sem mexer"
  ];
  let endIndex = text.length;
  for (const phrase of stopPhrases) {
    const foundIndex = normalized.indexOf(phrase, fromIndex);
    if (foundIndex !== -1 && foundIndex < endIndex) {
      endIndex = foundIndex;
    }
  }
  return endIndex;
}
function collectQuotedSegments(text) {
  const candidates = [];
  let currentQuote = "";
  let currentValue = "";
  for (const char of text) {
    if (!currentQuote) {
      if (isQuoteChar(char)) {
        currentQuote = char === "\u201C" ? "\u201D" : char === "\u2018" ? "\u2019" : char;
        currentValue = "";
      }
      continue;
    }
    if (char === currentQuote) {
      const normalizedValue = trimWrappingQuoteChars(currentValue);
      if (normalizedValue.length >= 6) {
        candidates.push(normalizedValue);
      }
      currentQuote = "";
      currentValue = "";
      continue;
    }
    currentValue += char;
  }
  return candidates;
}
function extractRequiredLiteralCandidates(instruction) {
  const originalInstruction = String(instruction || "");
  const normalizedInstruction = originalInstruction.toLocaleLowerCase("pt-BR");
  const candidates = [];
  for (const cue of explicitLiteralCuePhrases) {
    const cueIndex = normalizedInstruction.indexOf(cue);
    if (cueIndex === -1) {
      continue;
    }
    let cursor = cueIndex + cue.length;
    while (cursor < originalInstruction.length) {
      const char = originalInstruction[cursor];
      if (char !== " " && char !== "	" && char !== "\n" && char !== "\r") {
        break;
      }
      cursor += 1;
    }
    const endIndex = findNearestStopIndex(originalInstruction, cursor);
    const literalTail = trimWrappingQuoteChars(originalInstruction.slice(cursor, endIndex).trim());
    if (literalTail.length >= 6) {
      candidates.push(literalTail);
    }
    const windowEnd = Math.min(originalInstruction.length, endIndex);
    const nearbyQuotedSegments = collectQuotedSegments(originalInstruction.slice(cursor, windowEnd));
    candidates.push(...nearbyQuotedSegments);
  }
  return dedupeStringList(candidates);
}
function instructionRequestsLiteralAtEnd(instruction) {
  const normalized = String(instruction || "").toLocaleLowerCase("pt-BR");
  const endCues = [
    "linha final",
    "ao final do prompt",
    "final do prompt",
    "no final do prompt",
    "adicione ao final",
    "atualize a linha final"
  ];
  return endCues.some((cue) => normalized.includes(cue));
}
function includesCue(normalizedInstruction, cues) {
  for (const cue of cues) {
    if (normalizedInstruction.includes(cue)) {
      return true;
    }
  }
  return false;
}
function shouldPreferDirectPromptRewrite(instruction, literalRequirements) {
  const normalizedInstruction = String(instruction || "").toLocaleLowerCase("pt-BR");
  const preserveCues = [
    "preserve",
    "mantenha",
    "sem mudar",
    "sem mexer",
    "apenas",
    "somente",
    "todo o restante",
    "tudo igual"
  ];
  const conciseStyleCues = [
    "mais curto",
    "mais curta",
    "mais curtas",
    "mais direto",
    "mais direta",
    "mais diretas",
    "mais objetivo",
    "mais objetiva",
    "mais objetivo",
    "mais concisa",
    "mais conciso",
    "mais profissional",
    "mais formal",
    "redacao mais",
    "redacao",
    "linguagem mais",
    "tom geral",
    "tom mais",
    "estilo",
    "enxuto",
    "secas",
    "claras"
  ];
  if (literalRequirements.length > 0 && instructionRequestsLiteralAtEnd(instruction) && includesCue(normalizedInstruction, preserveCues)) {
    return true;
  }
  return includesCue(normalizedInstruction, preserveCues) && includesCue(normalizedInstruction, conciseStyleCues);
}
function extractLiteralLabel(literal) {
  const normalized = String(literal || "").trim();
  const colonIndex = normalized.indexOf(":");
  if (colonIndex <= 0) {
    return null;
  }
  const label = normalized.slice(0, colonIndex).trim();
  return label || null;
}
function validatePromptInstructionApplication(promptAntes, promptDepois, instrucaoUsuario) {
  const promptOriginal = normalizePrompt(promptAntes).trim();
  const promptAtualizado = normalizePrompt(promptDepois).trim();
  const instruction = String(instrucaoUsuario || "").trim();
  if (!promptAtualizado || promptAtualizado === promptOriginal) {
    return {
      applied: false,
      missingLiteralRequirements: [],
      feedbackMessage: "A edicao nao alterou o prompt final."
    };
  }
  const literalRequirements = extractRequiredLiteralCandidates(instruction);
  const missingLiteralRequirements = literalRequirements.filter((candidate) => !promptAtualizado.includes(candidate));
  if (missingLiteralRequirements.length > 0) {
    return {
      applied: false,
      missingLiteralRequirements,
      feedbackMessage: `A edicao gerada nao manteve requisitos literais obrigatorios: ${missingLiteralRequirements.join(" | ")}`
    };
  }
  if (instructionRequestsLiteralAtEnd(instruction) && literalRequirements.length > 0) {
    const finalLines = promptAtualizado.split("\n").map((line) => line.trim()).filter(Boolean);
    const trailingLines = finalLines.slice(-literalRequirements.length);
    const endsWithLiteralRequirements = literalRequirements.every(
      (literal, index) => trailingLines[index] === literal
    );
    if (!endsWithLiteralRequirements) {
      return {
        applied: false,
        missingLiteralRequirements: [],
        feedbackMessage: "A edicao nao terminou com a linha literal obrigatoria no final do prompt."
      };
    }
  }
  return {
    applied: true,
    missingLiteralRequirements: [],
    feedbackMessage: "A edicao atendeu os requisitos literais verificados."
  };
}
function buildRejectedPromptEditResult(promptAtual, feedbackMessage, detalhes = []) {
  return {
    success: false,
    novoPrompt: promptAtual,
    mensagemChat: feedbackMessage,
    edicoesAplicadas: 0,
    edicoesFalharam: Math.max(1, detalhes.length || 0),
    detalhes
  };
}
function emitProgress(options, message) {
  console.log(`[EditService] ${message}`);
  options?.onProgress?.(message);
}
async function repairPlainTextPromptRewrite(promptGerado, promptAtual, instrucaoUsuario, literalRequirements, options) {
  emitProgress(options, "A reescrita direta ficou quase pronta. Corrigindo os requisitos literais finais.");
  const mustEndWithLiteral = instructionRequestsLiteralAtEnd(instrucaoUsuario);
  const repairResponse = await chatComplete({
    messages: [
      {
        role: "system",
        content: [
          "Voce corrige um prompt final que ficou quase certo.",
          "Mantenha tudo que ja estiver correto.",
          "Ajuste somente o necessario para garantir que os requisitos literais aparecam exatamente como pedidos.",
          mustEndWithLiteral ? "Se a instrucao mencionar linha final ou final do prompt, termine o prompt exatamente com a linha literal obrigatoria, sem adicionar nada depois." : "Insira os literais obrigatorios sem remover o restante do contexto.",
          "Retorne somente o prompt final completo entre as tags <prompt_final> e </prompt_final>."
        ].join("\n")
      },
      {
        role: "user",
        content: [
          `Instrucao original: ${String(instrucaoUsuario || "").trim()}`,
          "",
          "Prompt atual oficial:",
          normalizePrompt(promptAtual),
          "",
          "Rascunho gerado que precisa ser corrigido:",
          normalizePrompt(promptGerado),
          "",
          "Requisitos literais obrigatorios:",
          ...literalRequirements.map((literal) => `- ${literal}`)
        ].join("\n")
      }
    ],
    maxTokens: 7e3,
    temperature: 0.1,
    skipMistralQueue: true
  });
  const repairedRaw = String(repairResponse.choices?.[0]?.message?.content || "").trim();
  const repairedPrompt = normalizePrompt(extractPromptFromPlainTextRewriteResponse(repairedRaw) || "").trim();
  return repairedPrompt || null;
}
function enforceLiteralRequirementsAsFinalLines(promptGerado, instrucaoUsuario, literalRequirements, options) {
  if (!instructionRequestsLiteralAtEnd(instrucaoUsuario) || literalRequirements.length === 0) {
    return normalizePrompt(promptGerado).trim();
  }
  let lines = normalizePrompt(promptGerado).split("\n").map((line) => line.replace("\r", ""));
  while (lines.length > 0 && !lines[lines.length - 1].trim()) {
    lines.pop();
  }
  for (const literal of literalRequirements) {
    const normalizedLiteral = String(literal || "").trim();
    if (!normalizedLiteral) {
      continue;
    }
    const label = extractLiteralLabel(normalizedLiteral);
    const filteredLines = [];
    for (const line of lines) {
      const trimmedLine = line.trim();
      if (trimmedLine === normalizedLiteral) {
        continue;
      }
      if (label && trimmedLine.startsWith(`${label}:`)) {
        continue;
      }
      filteredLines.push(line);
    }
    lines = filteredLines;
    lines.push(normalizedLiteral);
  }
  emitProgress(options, "Salvaguarda final aplicada para consolidar a linha literal obrigatoria no fim do prompt.");
  return lines.join("\n").trimEnd();
}
async function runAdvancedEditFallback(promptAtual, instrucaoUsuario, apiKey, options) {
  emitProgress(options, "Usando fallback de edicao avancada.");
  const advancedResult = await editPrompt(promptAtual, instrucaoUsuario, apiKey);
  const novoPrompt = advancedResult.success ? advancedResult.newPrompt : promptAtual;
  const detalhes = advancedResult.operations.map((operation) => ({
    buscar: operation.search || operation.anchor || operation.section || "",
    substituir: operation.replace || "",
    status: "aplicada",
    matchType: operation.search ? "fuzzy" : void 0
  }));
  if (advancedResult.success && novoPrompt !== promptAtual) {
    const verification = validatePromptInstructionApplication(promptAtual, novoPrompt, instrucaoUsuario);
    if (!verification.applied) {
      emitProgress(
        options,
        `Fallback avancado gerou mudanca parcial. ${verification.feedbackMessage} Tentando reescrita final.`
      );
      return runFullPromptRewriteFallback(promptAtual, instrucaoUsuario, options);
    }
    return {
      success: true,
      novoPrompt,
      mensagemChat: advancedResult.feedbackMessage || advancedResult.summary || "Mudancas aplicadas no prompt.",
      edicoesAplicadas: advancedResult.operations.length,
      edicoesFalharam: 0,
      detalhes
    };
  }
  emitProgress(options, "Fallback avancado nao alterou o prompt. Tentando reescrita guiada.");
  return runFullPromptRewriteFallback(promptAtual, instrucaoUsuario, options);
}
function stripWrappingCodeFence(value) {
  const normalized = normalizePrompt(value).trim();
  if (!normalized.startsWith("```")) {
    return normalized;
  }
  const firstLineBreak = normalized.indexOf("\n");
  if (firstLineBreak === -1) {
    return normalized;
  }
  const inner = normalized.slice(firstLineBreak + 1);
  const closingFenceIndex = inner.lastIndexOf("```");
  if (closingFenceIndex === -1) {
    return inner.trim();
  }
  return inner.slice(0, closingFenceIndex).trim();
}
function extractPromptFromPlainTextRewriteResponse(rawResponse) {
  const normalized = normalizePrompt(rawResponse).trim();
  if (!normalized) {
    return null;
  }
  const lower = normalized.toLocaleLowerCase("pt-BR");
  const startTag = "<prompt_final>";
  const endTag = "</prompt_final>";
  const taggedStart = lower.indexOf(startTag);
  const taggedEnd = lower.indexOf(endTag);
  if (taggedStart !== -1 && taggedEnd > taggedStart) {
    const extracted = normalized.slice(taggedStart + startTag.length, taggedEnd).trim();
    return extracted ? stripWrappingCodeFence(extracted) : null;
  }
  const strippedFence = stripWrappingCodeFence(normalized);
  if (!strippedFence) {
    return null;
  }
  const labeledPrefixes = [
    "prompt final:",
    "prompt final completo:",
    "prompt reescrito:",
    "prompt atualizado:"
  ];
  const strippedLower = strippedFence.toLocaleLowerCase("pt-BR");
  for (const prefix of labeledPrefixes) {
    if (!strippedLower.startsWith(prefix)) {
      continue;
    }
    const candidate = strippedFence.slice(prefix.length).trim();
    return candidate || null;
  }
  return strippedFence;
}
async function runPlainTextPromptRewriteFallback(promptAtual, instrucaoUsuario, options) {
  emitProgress(options, "Tentando reescrita direta sem depender de JSON estruturado.");
  try {
    const literalRequirements = extractRequiredLiteralCandidates(instrucaoUsuario);
    const mustEndWithLiteral = instructionRequestsLiteralAtEnd(instrucaoUsuario);
    const rawResponse = await chatComplete({
      messages: [
        {
          role: "system",
          content: [
            "Voce e um editor especialista em prompts de agentes conversacionais estilo orquestrador com memoria, contexto e continuidade de estado.",
            "Aplique a instrucao do usuario diretamente no prompt completo.",
            "Preserve tudo que nao foi pedido: identidade do agente, regras de negocio, modulos ativos, integracoes, listas, precos, blocos fixos e contexto operacional.",
            "Retorne somente o prompt final completo entre as tags <prompt_final> e </prompt_final>.",
            mustEndWithLiteral ? "Se a instrucao pedir uma linha final literal, termine o prompt exatamente com essa linha, sem adicionar nada depois." : "Garanta que todo requisito literal exigido apareca exatamente como o usuario escreveu.",
            "Nao retorne JSON, markdown, comentarios, checklist ou explicacao externa."
          ].join("\n")
        },
        {
          role: "user",
          content: [
            `Instrucao do usuario: ${String(instrucaoUsuario || "").trim()}`,
            literalRequirements.length > 0 ? [
              "",
              "Requisitos literais obrigatorios. Cada um precisa aparecer exatamente assim no prompt final:",
              ...literalRequirements.map((literal) => `- ${literal}`)
            ].join("\n") : "",
            "",
            "Prompt atual completo:",
            normalizePrompt(promptAtual)
          ].join("\n")
        }
      ],
      maxTokens: 7e3,
      temperature: 0.15,
      skipMistralQueue: true
    });
    const rawContent = String(rawResponse.choices?.[0]?.message?.content || "").trim();
    const novoPrompt = normalizePrompt(extractPromptFromPlainTextRewriteResponse(rawContent) || "").trim();
    const promptOriginal = normalizePrompt(promptAtual).trim();
    if (!novoPrompt || novoPrompt === promptOriginal) {
      return buildRejectedPromptEditResult(promptAtual, "A reescrita direta nao produziu um prompt final valido.");
    }
    const verification = validatePromptInstructionApplication(promptAtual, novoPrompt, instrucaoUsuario);
    if (!verification.applied) {
      emitProgress(options, `Reescrita direta rejeitada na verificacao interna. ${verification.feedbackMessage}`);
      if (literalRequirements.length > 0) {
        const repairedPrompt = await repairPlainTextPromptRewrite(
          novoPrompt,
          promptAtual,
          instrucaoUsuario,
          literalRequirements,
          options
        );
        if (repairedPrompt) {
          const repairedWithLiteralSafeguard = enforceLiteralRequirementsAsFinalLines(
            repairedPrompt,
            instrucaoUsuario,
            literalRequirements,
            options
          );
          const repairedVerification = validatePromptInstructionApplication(
            promptAtual,
            repairedWithLiteralSafeguard,
            instrucaoUsuario
          );
          if (repairedVerification.applied) {
            return {
              success: true,
              novoPrompt: repairedWithLiteralSafeguard,
              mensagemChat: "Alteracoes aplicadas com inteligencia artificial",
              edicoesAplicadas: 1,
              edicoesFalharam: 0,
              detalhes: [
                {
                  buscar: "PROMPT_COMPLETO",
                  substituir: "Reescrita direta com correcao final dos requisitos literais.",
                  status: "aplicada",
                  matchType: "exato"
                }
              ]
            };
          }
        }
      }
      return buildRejectedPromptEditResult(promptAtual, verification.feedbackMessage);
    }
    return {
      success: true,
      novoPrompt,
      mensagemChat: "Altera\xE7\xF5es aplicadas com intelig\xEAncia artificial",
      edicoesAplicadas: 1,
      edicoesFalharam: 0,
      detalhes: [
        {
          buscar: "PROMPT_COMPLETO",
          substituir: "Reescrita direta do prompt completo sem JSON estruturado.",
          status: "aplicada",
          matchType: "exato"
        }
      ]
    };
  } catch (error) {
    console.error("[EditService] Falha na reescrita direta sem JSON:", error);
    return {
      success: false,
      novoPrompt: promptAtual,
      mensagemChat: error?.message || "Nao foi possivel reescrever o prompt completo sem JSON.",
      edicoesAplicadas: 0,
      edicoesFalharam: 1,
      detalhes: []
    };
  }
}
async function runFullPromptRewriteFallback(promptAtual, instrucaoUsuario, options) {
  emitProgress(options, "Usando fallback de reescrita guiada.");
  const plainTextFirstAttempt = await runPlainTextPromptRewriteFallback(promptAtual, instrucaoUsuario, options);
  if (plainTextFirstAttempt.success) {
    return plainTextFirstAttempt;
  }
  emitProgress(
    options,
    "A reescrita direta nao concluiu sozinha. Tentando um full rewrite estruturado como apoio."
  );
  try {
    const systemPrompt = [
      "Voce e um editor especialista em prompts de agentes conversacionais estilo orquestrador com memoria, contexto e continuidade de estado.",
      "Aplique a instrucao do usuario diretamente no prompt completo.",
      "Preserve tudo que nao foi pedido: identidade do agente, regras de negocio, modulos ativos, integracoes, listas, precos, blocos fixos e contexto operacional.",
      "Nao responda com explicacoes extras. Retorne o prompt completo final ja reescrito."
    ].join("\n");
    const userMessage = [
      `Instrucao do usuario: ${String(instrucaoUsuario || "").trim()}`,
      "",
      "Prompt atual completo:",
      normalizePrompt(promptAtual)
    ].join("\n");
    const rewrite = await callStructuredTask({
      taskName: "prompt-edit-full-rewrite",
      systemPrompt,
      userMessage,
      schema: fullRewriteSchema,
      maxTokens: 6e3,
      temperature: 0.2,
      onProgress: options?.onProgress
    });
    const novoPrompt = normalizePrompt(rewrite.updatedPrompt).trim();
    const promptOriginal = normalizePrompt(promptAtual).trim();
    if (!novoPrompt || novoPrompt === promptOriginal) {
      emitProgress(options, "A reescrita guiada estruturada nao gerou mudanca valida. Tentando resposta direta.");
      const plainTextFallback = await runPlainTextPromptRewriteFallback(promptAtual, instrucaoUsuario, options);
      if (plainTextFallback.success) {
        return plainTextFallback;
      }
      return {
        success: false,
        novoPrompt: promptAtual,
        mensagemChat: plainTextFallback.mensagemChat || plainTextFirstAttempt.mensagemChat || rewrite.resposta_chat || "A IA nao sugeriu mudancas aplicaveis no momento.",
        edicoesAplicadas: 0,
        edicoesFalharam: 1,
        detalhes: []
      };
    }
    const verification = validatePromptInstructionApplication(promptAtual, novoPrompt, instrucaoUsuario);
    if (!verification.applied) {
      emitProgress(
        options,
        `A reescrita guiada estruturada ficou incompleta. ${verification.feedbackMessage} Tentando resposta direta.`
      );
      const plainTextFallback = await runPlainTextPromptRewriteFallback(promptAtual, instrucaoUsuario, options);
      if (plainTextFallback.success) {
        return plainTextFallback;
      }
      return buildRejectedPromptEditResult(
        promptAtual,
        plainTextFallback.mensagemChat || plainTextFirstAttempt.mensagemChat || verification.feedbackMessage
      );
    }
    return {
      success: true,
      novoPrompt,
      mensagemChat: rewrite.resposta_chat,
      edicoesAplicadas: 1,
      edicoesFalharam: 0,
      detalhes: [
        {
          buscar: "PROMPT_COMPLETO",
          substituir: rewrite.summary,
          status: "aplicada",
          matchType: "exato"
        }
      ]
    };
  } catch (error) {
    console.error("[EditService] Falha na reescrita guiada:", error);
    const plainTextFallback = await runPlainTextPromptRewriteFallback(promptAtual, instrucaoUsuario, options);
    if (plainTextFallback.success) {
      return plainTextFallback;
    }
    return {
      success: false,
      novoPrompt: promptAtual,
      mensagemChat: plainTextFallback.mensagemChat || plainTextFirstAttempt.mensagemChat || error?.message || "Nao foi possivel aplicar as alteracoes sugeridas pela IA.",
      edicoesAplicadas: 0,
      edicoesFalharam: 1,
      detalhes: []
    };
  }
}
function normalizePrompt(prompt) {
  return String(prompt || "").replaceAll("\r\n", "\n");
}
function isLetter(char) {
  const lower = char.toLocaleLowerCase("pt-BR");
  const upper = char.toLocaleUpperCase("pt-BR");
  return lower !== upper;
}
function isLikelyHeading(line) {
  const trimmed = line.trim();
  if (!trimmed) {
    return false;
  }
  if (trimmed.startsWith("#")) {
    return true;
  }
  if (trimmed.length < 3 || trimmed.length > 120) {
    return false;
  }
  let letters = 0;
  let uppercaseLetters = 0;
  let spaces = 0;
  for (const char of trimmed) {
    if (char === " ") {
      spaces += 1;
      continue;
    }
    if (!isLetter(char)) {
      continue;
    }
    letters += 1;
    if (char === char.toLocaleUpperCase("pt-BR")) {
      uppercaseLetters += 1;
    }
  }
  if (letters === 0) {
    return trimmed.endsWith(":");
  }
  const uppercaseRatio = uppercaseLetters / letters;
  if (uppercaseRatio >= 0.82 && spaces <= 12) {
    return true;
  }
  return trimmed.endsWith(":") && spaces <= 10;
}
function cleanHeadingLine(line) {
  let text = line.trim();
  while (text.startsWith("#") || text.startsWith("-") || text.startsWith("*") || text.startsWith("\u2022")) {
    text = text.slice(1).trimStart();
  }
  while (text.endsWith(":")) {
    text = text.slice(0, -1).trimEnd();
  }
  return text || "SECAO";
}
function splitPromptIntoSections(prompt) {
  const normalized = normalizePrompt(prompt);
  const lines = normalized.split("\n");
  const lineOffsets = [];
  let cursor = 0;
  for (const line of lines) {
    lineOffsets.push(cursor);
    cursor += line.length + 1;
  }
  const startLines = [0];
  for (let i = 1; i < lines.length; i += 1) {
    if (isLikelyHeading(lines[i])) {
      startLines.push(i);
    }
  }
  const sections = [];
  for (let index = 0; index < startLines.length; index += 1) {
    const startLine = startLines[index];
    const nextStartLine = startLines[index + 1];
    const startIndex = lineOffsets[startLine] ?? 0;
    const endIndex = nextStartLine !== void 0 ? lineOffsets[nextStartLine] ?? normalized.length : normalized.length;
    const firstLine = lines[startLine] ?? "";
    const title = isLikelyHeading(firstLine) ? cleanHeadingLine(firstLine) : index === 0 ? "INTRODUCAO" : `SECAO ${index + 1}`;
    sections.push({
      id: `sec-${String(index + 1).padStart(2, "0")}`,
      title,
      content: normalized.slice(startIndex, endIndex),
      startIndex,
      endIndex,
      order: index
    });
  }
  return sections;
}
function compactWhitespace(value) {
  let result = "";
  let sawWhitespace = false;
  for (const char of value) {
    const isWhitespace = char === " " || char === "\n" || char === "\r" || char === "	";
    if (isWhitespace) {
      if (!sawWhitespace) {
        result += " ";
      }
      sawWhitespace = true;
      continue;
    }
    sawWhitespace = false;
    result += char;
  }
  return result.trim();
}
function buildSectionCatalog(sections) {
  return sections.map((section) => {
    const preview = compactWhitespace(section.content).slice(0, 220);
    return `${section.id} | ${section.title} | ${preview}`;
  }).join("\n");
}
function buildGlobalSummary(prompt, sections) {
  const titles = sections.slice(0, 10).map((section) => section.title).join(", ");
  const head = compactWhitespace(prompt).slice(0, 500);
  return `Prompt com ${prompt.length} caracteres e ${sections.length} secoes. Titulos iniciais: ${titles}. Resumo do topo: ${head}`;
}
function safeParseStructuredResponse(raw, schema) {
  const trimmed = String(raw || "").trim();
  if (!trimmed) {
    return null;
  }
  const candidates = buildStructuredParseCandidates(trimmed);
  for (const candidate of candidates) {
    try {
      return schema.parse(JSON.parse(candidate));
    } catch {
    }
  }
  return null;
}
function buildStructuredParseCandidates(raw) {
  const candidates = [];
  const seen = /* @__PURE__ */ new Set();
  const pushCandidate = (value) => {
    const trimmed = String(value || "").trim();
    if (!trimmed || seen.has(trimmed)) {
      return;
    }
    seen.add(trimmed);
    candidates.push(trimmed);
  };
  pushCandidate(raw);
  const balancedObjects = extractBalancedJsonObjects(raw);
  for (const candidate of balancedObjects) {
    pushCandidate(candidate);
  }
  const firstBrace = raw.indexOf("{");
  const lastBrace = raw.lastIndexOf("}");
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    pushCandidate(raw.slice(firstBrace, lastBrace + 1));
  }
  return candidates;
}
function extractBalancedJsonObjects(raw) {
  const results = [];
  let startIndex = -1;
  let depth = 0;
  let insideString = false;
  let escaping = false;
  for (let index = 0; index < raw.length; index += 1) {
    const char = raw[index];
    if (insideString) {
      if (escaping) {
        escaping = false;
        continue;
      }
      if (char === "\\") {
        escaping = true;
        continue;
      }
      if (char === '"') {
        insideString = false;
      }
      continue;
    }
    if (char === '"') {
      insideString = true;
      continue;
    }
    if (char === "{") {
      if (depth === 0) {
        startIndex = index;
      }
      depth += 1;
      continue;
    }
    if (char === "}" && depth > 0) {
      depth -= 1;
      if (depth === 0 && startIndex >= 0) {
        results.push(raw.slice(startIndex, index + 1));
        startIndex = -1;
      }
    }
  }
  return results;
}
async function repairStructuredTaskOutput(input) {
  const schemaJson = describeStructuredSchema(input.schema);
  const repairResponse = await chatComplete({
    messages: [
      {
        role: "system",
        content: [
          "Voce corrige saidas estruturadas de outro modelo.",
          "Transforme a saida bruta abaixo em JSON valido que respeite exatamente o schema informado.",
          "Se a saida bruta ja contiver o conteudo certo em formato ruim, preserve esse conteudo.",
          "Se a saida bruta vier incompleta, execute novamente a intencao original com base no contexto recebido.",
          "Retorne somente JSON valido, sem markdown.",
          "",
          "JSON Schema esperado:",
          schemaJson
        ].join("\n")
      },
      {
        role: "user",
        content: [
          `Tarefa original: ${input.taskName}`,
          "",
          "Instrucoes originais do sistema:",
          input.systemPrompt,
          "",
          "Mensagem original do usuario:",
          input.userMessage,
          "",
          "Saida bruta anterior:",
          String(input.invalidRawResponse || "").trim() || "(vazia)"
        ].join("\n")
      }
    ],
    maxTokens: input.maxTokens,
    temperature: Math.min(input.temperature, 0.2),
    skipMistralQueue: true
  });
  const repairedRaw = String(repairResponse.choices?.[0]?.message?.content || "").trim();
  const repaired = safeParseStructuredResponse(repairedRaw, input.schema);
  if (repaired) {
    return repaired;
  }
  input.onProgress?.("A saida estruturada continuou invalida. Repetindo com schema reforcado.");
  const retryResponse = await chatComplete({
    messages: [
      {
        role: "system",
        content: [
          input.systemPrompt,
          "",
          "Responda somente JSON valido, sem markdown, seguindo exatamente este JSON Schema:",
          schemaJson
        ].join("\n")
      },
      {
        role: "user",
        content: input.userMessage
      }
    ],
    maxTokens: input.maxTokens,
    temperature: input.temperature,
    skipMistralQueue: true
  });
  const retriedRaw = String(retryResponse.choices?.[0]?.message?.content || "").trim();
  return safeParseStructuredResponse(retriedRaw, input.schema);
}
function describeStructuredSchema(schema, depth = 0) {
  const indent = "  ".repeat(depth);
  if (schema instanceof z.ZodDefault) {
    return describeStructuredSchema(schema._def.innerType, depth);
  }
  if (schema instanceof z.ZodOptional || schema instanceof z.ZodNullable) {
    return `${describeStructuredSchema(schema.unwrap(), depth)} (opcional)`;
  }
  if (schema instanceof z.ZodString) {
    const checks = Array.isArray(schema._def.checks) ? schema._def.checks : [];
    const rules = checks.map((check) => {
      if (check.kind === "min") {
        return `min ${check.value}`;
      }
      if (check.kind === "max") {
        return `max ${check.value}`;
      }
      return null;
    }).filter(Boolean);
    return rules.length > 0 ? `string (${rules.join(", ")})` : "string";
  }
  if (schema instanceof z.ZodEnum) {
    return `enum(${schema.options.join(" | ")})`;
  }
  if (schema instanceof z.ZodArray) {
    return `array<${describeStructuredSchema(schema.element, depth)}>`;
  }
  if (schema instanceof z.ZodObject) {
    const shape = schema.shape;
    const lines = Object.entries(shape).map(
      ([key, value]) => `${indent}  "${key}": ${describeStructuredSchema(value, depth + 1)}`
    );
    return `{
${lines.join(",\n")}
${indent}}`;
  }
  return schema._def?.typeName || "valor";
}
async function callStructuredTask(input) {
  const llmConfig = await getLLMConfig();
  const shouldTryDirectMistralStructured = llmConfig.provider === "mistral" && !llmConfig.openrouterApiKey && !llmConfig.groqApiKey && !llmConfig.nvidiaApiKey;
  if (shouldTryDirectMistralStructured) {
    const mistral = await getMistralClient();
    const model = llmConfig.mistralModel || "mistral-medium-latest";
    try {
      const response2 = await mistral.chat.complete({
        model,
        messages: [
          { role: "system", content: input.systemPrompt },
          { role: "user", content: input.userMessage }
        ],
        responseFormat: responseFormatFromZodObject(input.schema),
        maxTokens: input.maxTokens,
        temperature: input.temperature
      });
      const raw2 = String(response2.choices?.[0]?.message?.content || "").trim();
      const parsed2 = safeParseStructuredResponse(raw2, input.schema);
      if (parsed2) {
        return parsed2;
      }
      throw new Error(`Structured output invalido em ${input.taskName}`);
    } catch (structuredError) {
      console.warn(`[EditService] Structured output falhou em ${input.taskName}:`, structuredError);
    }
  } else {
    console.log(
      `[EditService] Structured output direto do Mistral pulado em ${input.taskName} para usar fallback unificado do provider.`
    );
  }
  const response = await chatComplete({
    messages: [
      { role: "system", content: `${input.systemPrompt}
Retorne apenas JSON valido, sem markdown.` },
      { role: "user", content: input.userMessage }
    ],
    maxTokens: input.maxTokens,
    temperature: input.temperature,
    skipMistralQueue: true
  });
  const raw = String(response.choices?.[0]?.message?.content || "").trim();
  const parsed = safeParseStructuredResponse(raw, input.schema);
  if (parsed) {
    return parsed;
  }
  console.warn(`[EditService] JSON invalido retornado em ${input.taskName}. Tentando reparo automatico.`);
  input.onProgress?.("A saida estruturada veio incompleta. Reparando automaticamente.");
  const repaired = await repairStructuredTaskOutput({
    ...input,
    invalidRawResponse: raw
  });
  if (repaired) {
    return repaired;
  }
  throw new Error(`Nao foi possivel obter JSON valido em ${input.taskName}`);
}
function includesAny(text, needles) {
  const lower = text.toLocaleLowerCase("pt-BR");
  return needles.some((needle) => lower.includes(needle));
}
function isBroadInstruction(instruction) {
  return includesAny(instruction, [
    "mais curto",
    "mais curtas",
    "mais direto",
    "mais direta",
    "mais objetiv",
    "mais formal",
    "mais vendedor",
    "tom",
    "estilo",
    "respostas",
    "mensagens",
    "linguagem"
  ]);
}
function rankCoreSections(sections) {
  const priorities = [
    "objetivo",
    "abertura",
    "postura",
    "tom",
    "formato",
    "resposta",
    "regras",
    "fluxo",
    "atendimento",
    "vendas",
    "qualificacao",
    "mensagem"
  ];
  return [...sections].sort((left, right) => {
    const leftText = `${left.title} ${compactWhitespace(left.content).slice(0, 180)}`.toLocaleLowerCase("pt-BR");
    const rightText = `${right.title} ${compactWhitespace(right.content).slice(0, 180)}`.toLocaleLowerCase("pt-BR");
    let leftScore = 0;
    let rightScore = 0;
    for (const keyword of priorities) {
      if (leftText.includes(keyword)) {
        leftScore += 1;
      }
      if (rightText.includes(keyword)) {
        rightScore += 1;
      }
    }
    if (leftScore === rightScore) {
      return left.order - right.order;
    }
    return rightScore - leftScore;
  });
}
function selectSectionsForRewrite(sections, plan, instruction) {
  const byId = new Map(sections.map((section) => [section.id, section]));
  const selected = /* @__PURE__ */ new Map();
  for (const sectionId of plan.sectionIds) {
    const section = byId.get(sectionId);
    if (section) {
      selected.set(section.id, section);
    }
  }
  const broad = plan.editScope === "broad" || isBroadInstruction(instruction);
  if (broad && selected.size < 4) {
    for (const section of rankCoreSections(sections)) {
      selected.set(section.id, section);
      if (selected.size >= 6) {
        break;
      }
    }
  }
  if (selected.size === 0) {
    for (const section of rankCoreSections(sections).slice(0, 4)) {
      selected.set(section.id, section);
    }
  }
  let selectedSections = [...selected.values()];
  if (broad && selectedSections.length > 8) {
    const allowedIds = new Set(
      rankCoreSections(selectedSections).slice(0, 8).map((section) => section.id)
    );
    selectedSections = selectedSections.filter((section) => allowedIds.has(section.id));
  }
  return selectedSections.sort((left, right) => left.order - right.order);
}
function chunkSections(sections, maxSections, maxChars) {
  const chunks = [];
  let currentChunk = [];
  let currentChars = 0;
  for (const section of sections) {
    const sectionChars = section.content.length;
    const mustFlush = currentChunk.length > 0 && (currentChunk.length >= maxSections || currentChars + sectionChars > maxChars);
    if (mustFlush) {
      chunks.push(currentChunk);
      currentChunk = [];
      currentChars = 0;
    }
    currentChunk.push(section);
    currentChars += sectionChars;
  }
  if (currentChunk.length > 0) {
    chunks.push(currentChunk);
  }
  return chunks;
}
function mergeEditedSections(prompt, sections, rewrites) {
  let output = "";
  let lastIndex = 0;
  for (const section of sections) {
    if (section.startIndex > lastIndex) {
      output += prompt.slice(lastIndex, section.startIndex);
    }
    output += rewrites.get(section.id) ?? section.content;
    lastIndex = section.endIndex;
  }
  if (lastIndex < prompt.length) {
    output += prompt.slice(lastIndex);
  }
  return output;
}
function summarizeRewriteMessages(messages, fallback) {
  const deduped = [];
  for (const message of messages) {
    const trimmed = message.trim();
    if (trimmed && !deduped.includes(trimmed)) {
      deduped.push(trimmed);
    }
  }
  if (deduped.length === 0) {
    return fallback;
  }
  return deduped.join(" ");
}
async function editarPromptViaIA(promptAtual, instrucaoUsuario, _apiKey, _modelo, options) {
  const promptNormalizado = normalizePrompt(promptAtual);
  const instrucaoNormalizada = String(instrucaoUsuario || "").trim();
  if (!promptNormalizado || !instrucaoNormalizada) {
    return {
      success: false,
      novoPrompt: promptAtual,
      mensagemChat: "currentPrompt e instruction sao obrigatorios.",
      edicoesAplicadas: 0,
      edicoesFalharam: 0,
      detalhes: []
    };
  }
  const literalRequirements = extractRequiredLiteralCandidates(instrucaoNormalizada);
  if (shouldPreferDirectPromptRewrite(instrucaoNormalizada, literalRequirements)) {
    emitProgress(
      options,
      "Instrucao simples detectada. Priorizando reescrita direta antes da orquestracao estruturada."
    );
    const directFirstAttempt = await runPlainTextPromptRewriteFallback(
      promptAtual,
      instrucaoUsuario,
      options
    );
    if (directFirstAttempt.success) {
      return directFirstAttempt;
    }
    emitProgress(
      options,
      "A reescrita direta priorit\xE1ria nao concluiu sozinha. Voltando para a orquestracao estruturada."
    );
  }
  emitProgress(options, "Mapeando secoes do prompt atual.");
  const sections = splitPromptIntoSections(promptNormalizado);
  if (sections.length === 0) {
    return runAdvancedEditFallback(promptAtual, instrucaoUsuario, _apiKey, options);
  }
  try {
    emitProgress(options, "Planejando quais blocos precisam mudar.");
    const plan = await callStructuredTask({
      taskName: "prompt-edit-plan",
      systemPrompt: [
        "Voce e um planejador de calibracao de prompt para um agente conversacional com memoria e contexto.",
        "Analise a instrucao do usuario e escolha apenas as secoes que realmente precisam mudar.",
        "Preserve identidade, regras de negocio, continuidade de estado, memoria operacional e blocos nao relacionados.",
        "Se a mudanca for ampla de tom, estilo, tamanho das respostas ou fluxo principal, marque editScope=broad e selecione todas as secoes relevantes.",
        "Nunca invente ids de secoes."
      ].join("\n"),
      userMessage: [
        `Instrucao do usuario: ${instrucaoNormalizada}`,
        "",
        `Resumo global: ${buildGlobalSummary(promptNormalizado, sections)}`,
        "",
        "Catalogo de secoes:",
        buildSectionCatalog(sections)
      ].join("\n"),
      schema: plannerSchema,
      maxTokens: 1200,
      temperature: 0.1,
      onProgress: options?.onProgress
    });
    const selectedSections = selectSectionsForRewrite(sections, plan, instrucaoNormalizada);
    if (selectedSections.length === 0) {
      return runAdvancedEditFallback(promptAtual, instrucaoUsuario, _apiKey, options);
    }
    emitProgress(options, `Reescrevendo ${selectedSections.length} secao(oes) relevantes em lotes menores.`);
    const batches = chunkSections(selectedSections, 4, 16e3);
    const rewrites = /* @__PURE__ */ new Map();
    const detalhes = [];
    const feedbackMessages = [plan.resposta_chat];
    for (let batchIndex = 0; batchIndex < batches.length; batchIndex += 1) {
      const batch = batches[batchIndex];
      emitProgress(options, `Processando lote ${batchIndex + 1}/${batches.length}.`);
      const rewrite = await callStructuredTask({
        taskName: `prompt-edit-rewrite-${batchIndex + 1}`,
        systemPrompt: [
          "Voce e um editor de prompt que trabalha por secoes.",
          "Reescreva somente as secoes fornecidas, mantendo a estrutura do agente como um orquestrador com memoria, contexto e continuidade de estado.",
          "Aplique a instrucao do usuario de forma real, sem metacomentarios.",
          "Nao apague placeholders, links, regras fixas, listas de produtos, precos ou integracoes, exceto se o usuario pedir explicitamente.",
          "Cada updatedContent deve ser o texto completo final da secao correspondente."
        ].join("\n"),
        userMessage: [
          `Instrucao do usuario: ${instrucaoNormalizada}`,
          `Objetivo do plano: ${plan.objective}`,
          `Instrucoes de escrita: ${plan.writerInstructions.join(" | ")}`,
          `Preservar: ${plan.preserveDirectives.join(" | ") || "identidade, memoria, regras e contexto"}`,
          "",
          `Resumo global: ${buildGlobalSummary(promptNormalizado, sections)}`,
          "",
          "Secoes para reescrever:",
          batch.map((section) => `[${section.id}] ${section.title}
${section.content}`).join("\n\n")
        ].join("\n"),
        schema: rewriteSchema,
        maxTokens: 2600,
        temperature: 0.2,
        onProgress: options?.onProgress
      });
      feedbackMessages.push(rewrite.resposta_chat);
      for (const edit of rewrite.edits) {
        const originalSection = batch.find((section) => section.id === edit.sectionId);
        if (!originalSection) {
          continue;
        }
        rewrites.set(edit.sectionId, edit.updatedContent);
        detalhes.push({
          buscar: originalSection.title,
          substituir: edit.summary,
          status: edit.updatedContent !== originalSection.content ? "aplicada" : "falhou",
          matchType: "exato"
        });
      }
    }
    emitProgress(options, "Remontando o prompt final.");
    const novoPrompt = mergeEditedSections(promptNormalizado, sections, rewrites);
    const aplicadas = selectedSections.filter((section) => {
      const updated = rewrites.get(section.id);
      return updated !== void 0 && updated !== section.content;
    }).length;
    if (aplicadas === 0 || novoPrompt === promptNormalizado) {
      emitProgress(options, "Nenhuma secao mudou de fato. Tentando fallback de seguranca.");
      return runAdvancedEditFallback(promptAtual, instrucaoUsuario, _apiKey, options);
    }
    const verification = validatePromptInstructionApplication(promptAtual, novoPrompt, instrucaoNormalizada);
    if (!verification.applied) {
      emitProgress(
        options,
        `A edicao estruturada ficou incompleta. ${verification.feedbackMessage} Tentando reescrita final.`
      );
      return runFullPromptRewriteFallback(promptAtual, instrucaoNormalizada, options);
    }
    return {
      success: true,
      novoPrompt,
      mensagemChat: summarizeRewriteMessages(
        feedbackMessages,
        `Atualizei ${aplicadas} secao(oes) do prompt.`
      ),
      edicoesAplicadas: aplicadas,
      edicoesFalharam: Math.max(0, selectedSections.length - aplicadas),
      detalhes
    };
  } catch (error) {
    console.error("[EditService] Falha na orquestracao estruturada:", error);
    emitProgress(options, "A orquestracao estruturada falhou. Executando fallback.");
    return runAdvancedEditFallback(promptAtual, instrucaoUsuario, _apiKey, options);
  }
}

// server/promptHistoryService.ts
function normalizePromptVersion(version) {
  if (!version) return null;
  return repairMojibakeDeep(version);
}
function normalizePromptChatMessage(message) {
  if (!message) return null;
  return repairMojibakeDeep(message);
}
async function salvarVersaoPrompt(params) {
  const {
    userId,
    configType = "ai_agent_config",
    promptContent,
    editSummary = null,
    editType = "manual",
    editDetails = []
  } = params;
  const normalizedPromptContent = repairMojibakeText(promptContent);
  const normalizedEditSummary = editSummary == null ? null : repairMojibakeText(editSummary);
  const normalizedEditDetails = repairMojibakeDeep(editDetails);
  try {
    console.log(`[HistoryService] \u{1F4DD} Salvando nova vers\xE3o para user ${userId}, tipo: ${editType}`);
    const currentVersionResult = await pool.query(
      `SELECT id, version_number, prompt_content 
       FROM prompt_versions 
       WHERE user_id = $1 AND config_type = $2 AND is_current = true
       LIMIT 1`,
      [userId, configType]
    );
    if (currentVersionResult.rows.length > 0) {
      const currentVersion = currentVersionResult.rows[0];
      const currentPromptContent = repairMojibakeText(currentVersion.prompt_content);
      if (currentPromptContent === normalizedPromptContent) {
        console.log(`[HistoryService] \u26A0\uFE0F DUPLICATA EVITADA! Conte\xFAdo id\xEAntico \xE0 vers\xE3o atual v${currentVersion.version_number}`);
        console.log(`[HistoryService] \u2139\uFE0F Retornando vers\xE3o existente (id: ${currentVersion.id})`);
        const existingVersionResult = await pool.query(
          `SELECT * FROM prompt_versions WHERE id = $1`,
          [currentVersion.id]
        );
        return normalizePromptVersion(existingVersionResult.rows[0]);
      }
      console.log(`[HistoryService] \u2713 Conte\xFAdo diferente da v${currentVersion.version_number}, criando nova vers\xE3o`);
    } else {
      console.log(`[HistoryService] \u2139\uFE0F Nenhuma vers\xE3o atual encontrada, criando primeira vers\xE3o`);
    }
    const maxVersionResult = await pool.query(
      `SELECT COALESCE(MAX(version_number), 0) as max_version 
       FROM prompt_versions 
       WHERE user_id = $1 AND config_type = $2`,
      [userId, configType]
    );
    const nextVersion = (maxVersionResult.rows[0]?.max_version || 0) + 1;
    console.log(`[HistoryService] Pr\xF3ximo n\xFAmero de vers\xE3o: ${nextVersion}`);
    const updateResult = await pool.query(
      `UPDATE prompt_versions SET is_current = false 
       WHERE user_id = $1 AND config_type = $2 AND is_current = true
       RETURNING version_number`,
      [userId, configType]
    );
    if (updateResult.rows.length > 0) {
      console.log(`[HistoryService] \u{1F504} Vers\xF5es anteriores desmarcadas: ${updateResult.rows.map((r) => `v${r.version_number}`).join(", ")}`);
    }
    const insertResult = await pool.query(
      `INSERT INTO prompt_versions (
        user_id, config_type, version_number, prompt_content, 
        edit_summary, edit_type, edit_details, is_current
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, true)
      RETURNING *`,
      [userId, configType, nextVersion, normalizedPromptContent, normalizedEditSummary, editType, JSON.stringify(normalizedEditDetails)]
    );
    const newVersion = normalizePromptVersion(insertResult.rows[0]);
    if (!newVersion) {
      return null;
    }
    if (configType === "ai_agent_config") {
      try {
        await pool.query(
          `UPDATE ai_agent_config SET prompt = $1, updated_at = now() WHERE user_id = $2`,
          [normalizedPromptContent, userId]
        );
        console.log(`[HistoryService] Sync ai_agent_config.prompt for user ${userId}`);
      } catch (syncErr) {
        console.error("[HistoryService] Failed to sync ai_agent_config:", syncErr);
      }
    }
    console.log(`[HistoryService] \u2705 Nova vers\xE3o v${nextVersion} salva (id: ${newVersion.id}, is_current: true, prompt length: ${normalizedPromptContent.length})`);
    return newVersion;
  } catch (error) {
    console.error("[HistoryService] \u274C Erro ao salvar vers\xE3o:", error);
    return null;
  }
}
async function listarVersoes(userId, configType = "ai_agent_config", limite = 50) {
  try {
    const result = await pool.query(
      `SELECT * FROM prompt_versions 
       WHERE user_id = $1 AND config_type = $2 
       ORDER BY version_number DESC 
       LIMIT $3`,
      [userId, configType, limite]
    );
    return (result.rows || []).map((row) => normalizePromptVersion(row)).filter((row) => Boolean(row));
  } catch (error) {
    console.error("[HistoryService] Erro ao listar vers\xF5es:", error);
    return [];
  }
}
async function obterVersao(versionId) {
  try {
    const result = await pool.query(
      `SELECT * FROM prompt_versions WHERE id = $1`,
      [versionId]
    );
    return normalizePromptVersion(result.rows[0]);
  } catch (error) {
    console.error("[HistoryService] Erro ao obter vers\xE3o:", error);
    return null;
  }
}
async function obterVersaoAtual(userId, configType = "ai_agent_config") {
  try {
    const result = await pool.query(
      `SELECT * FROM prompt_versions 
       WHERE user_id = $1 AND config_type = $2 AND is_current = true
       ORDER BY version_number DESC, created_at DESC
       LIMIT 1`,
      [userId, configType]
    );
    return normalizePromptVersion(result.rows[0]);
  } catch (error) {
    console.error("[HistoryService] Erro ao obter vers\xE3o atual:", error);
    return null;
  }
}
async function restaurarVersao(versionId, userId) {
  try {
    const versaoOriginal = await obterVersao(versionId);
    if (!versaoOriginal) {
      console.error("[HistoryService] Vers\xE3o n\xE3o encontrada:", versionId);
      return null;
    }
    const novaVersao = await salvarVersaoPrompt({
      userId,
      configType: versaoOriginal.config_type,
      promptContent: versaoOriginal.prompt_content,
      editSummary: `Restaurado da vers\xE3o ${versaoOriginal.version_number}`,
      editType: "restore",
      editDetails: [{ restored_from: versionId, original_version: versaoOriginal.version_number }]
    });
    return novaVersao;
  } catch (error) {
    console.error("[HistoryService] Erro ao restaurar vers\xE3o:", error);
    return null;
  }
}
async function salvarMensagemChat(params) {
  const {
    userId,
    configType = "ai_agent_config",
    role,
    content,
    versionId = null,
    metadata = {}
  } = params;
  const normalizedContent = repairMojibakeText(content);
  const normalizedMetadata = repairMojibakeDeep(metadata);
  try {
    const result = await pool.query(
      `INSERT INTO prompt_edit_chat (
        user_id, config_type, role, content, version_id, metadata
      ) VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *`,
      [userId, configType, role, normalizedContent, versionId, JSON.stringify(normalizedMetadata)]
    );
    return normalizePromptChatMessage(result.rows[0]);
  } catch (error) {
    console.error("[HistoryService] Erro ao salvar mensagem de chat:", error);
    return null;
  }
}
async function listarChatHistory(userId, configType = "ai_agent_config", limite = 100) {
  try {
    console.log(`[HistoryService] \u{1F4DC} Buscando chat history para user ${userId}, limite ${limite}`);
    const result = await pool.query(
      `SELECT * FROM (
         SELECT * FROM prompt_edit_chat 
         WHERE user_id = $1 AND config_type = $2 
         ORDER BY created_at DESC 
         LIMIT $3
       ) sub
       ORDER BY created_at ASC`,
      [userId, configType, limite]
    );
    const normalizedRows = (result.rows || []).map((row) => normalizePromptChatMessage(row)).filter((row) => Boolean(row));
    console.log(`[HistoryService] \u2705 Retornando ${normalizedRows.length} mensagens`);
    if (normalizedRows.length > 0) {
      console.log(`[HistoryService] Primeira: "${normalizedRows[0].content?.substring(0, 50)}..."`);
      console.log(`[HistoryService] \xDAltima: "${normalizedRows[normalizedRows.length - 1].content?.substring(0, 50)}..."`);
    }
    return normalizedRows;
  } catch (error) {
    console.error("[HistoryService] \u274C Erro ao listar chat:", error);
    return [];
  }
}
async function limparChatHistory(userId, configType = "ai_agent_config") {
  try {
    await pool.query(
      `DELETE FROM prompt_edit_chat WHERE user_id = $1 AND config_type = $2`,
      [userId, configType]
    );
    return true;
  } catch (error) {
    console.error("[HistoryService] Erro ao limpar chat:", error);
    return false;
  }
}
async function editarPromptComHistorico(userId, promptAtual, instrucaoUsuario, apiKey, configType = "ai_agent_config") {
  const mensagemUsuario = await salvarMensagemChat({
    userId,
    configType,
    role: "user",
    content: instrucaoUsuario
  });
  const resultado = await runWithLLMUserContext(
    userId,
    () => editarPromptViaIA(
      promptAtual,
      instrucaoUsuario,
      apiKey,
      "mistral"
    )
  );
  let novaVersao = null;
  if (resultado.success && resultado.novoPrompt !== promptAtual) {
    novaVersao = await salvarVersaoPrompt({
      userId,
      configType,
      promptContent: resultado.novoPrompt,
      editSummary: resultado.mensagemChat,
      editType: "ia",
      editDetails: resultado.detalhes
    });
  }
  const mensagemAssistente = await salvarMensagemChat({
    userId,
    configType,
    role: "assistant",
    content: resultado.mensagemChat,
    versionId: novaVersao?.id,
    metadata: {
      edicoes_aplicadas: resultado.edicoesAplicadas,
      edicoes_falharam: resultado.edicoesFalharam,
      success: resultado.success
    }
  });
  return {
    resultado,
    versao: novaVersao,
    mensagensChat: {
      user: mensagemUsuario,
      assistant: mensagemAssistente
    }
  };
}

export {
  editarPromptViaIA,
  salvarVersaoPrompt,
  listarVersoes,
  obterVersao,
  obterVersaoAtual,
  restaurarVersao,
  salvarMensagemChat,
  listarChatHistory,
  limparChatHistory,
  editarPromptComHistorico
};
