// server/audioConverter.ts
import { exec } from "child_process";
import { promisify } from "util";
import { writeFile, unlink, readFile, access } from "fs/promises";
import { join } from "path";
import { tmpdir } from "os";
import { randomUUID } from "crypto";
var execAsync = promisify(exec);
function inferInputExtension(normalizedMime) {
  if (normalizedMime.includes("webm")) return "webm";
  if (normalizedMime.includes("mpeg") || normalizedMime.includes("mp3")) return "mp3";
  if (normalizedMime.includes("mp4") || normalizedMime.includes("m4a")) return "mp4";
  if (normalizedMime.includes("wav")) return "wav";
  if (normalizedMime.includes("ogg") || normalizedMime.includes("opus")) return "ogg";
  return "bin";
}
function isOggContainerMime(normalizedMime) {
  return normalizedMime.includes("audio/ogg") || normalizedMime.includes("application/ogg") || normalizedMime.startsWith("audio/ogg");
}
function hasOggHeader(buffer) {
  return buffer.subarray(0, 4).toString() === "OggS";
}
function isRemoteAudioSource(value) {
  return /^https?:\/\//i.test(value.trim());
}
async function fetchRemoteAudioBuffer(url, fallbackMimeType) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3e4);
  try {
    const response = await fetch(url, {
      redirect: "follow",
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`Falha ao baixar audio remoto (${response.status})`);
    }
    const arrayBuffer = await response.arrayBuffer();
    const mimeType = response.headers.get("content-type") || fallbackMimeType || "application/octet-stream";
    return {
      buffer: Buffer.from(arrayBuffer),
      mimeType
    };
  } finally {
    clearTimeout(timeout);
  }
}
async function convertBufferToWhatsAppAudio(inputBuffer, inputMimeType) {
  const normalizedMime = (inputMimeType || "").toLowerCase();
  const inputExt = inferInputExtension(normalizedMime);
  if (isOggContainerMime(normalizedMime) && hasOggHeader(inputBuffer)) {
    console.log("[AudioConverter] \u2705 Buffer j\xE1 est\xE1 em OGG/Opus, sem convers\xE3o necess\xE1ria");
    return {
      buffer: inputBuffer,
      mimeType: "audio/ogg; codecs=opus",
      extension: "ogg",
      converted: false
    };
  }
  const tempId = randomUUID();
  const inputPath = join(tmpdir(), `audio_input_${tempId}.${inputExt}`);
  const outputPath = join(tmpdir(), `audio_output_${tempId}.ogg`);
  try {
    console.log("[AudioConverter] \u{1F504} Iniciando convers\xE3o de buffer", inputMimeType, "para OGG/Opus");
    await writeFile(inputPath, inputBuffer);
    console.log("[AudioConverter] \u{1F4DD} Buffer de entrada salvo:", inputBuffer.length, "bytes");
    const ffmpegCmd = `ffmpeg -y -fflags +genpts -i "${inputPath}" -avoid_negative_ts make_zero -c:a libopus -b:a 64k -vbr on -vn -ar 48000 -ac 1 -application voip -f ogg "${outputPath}"`;
    let ffmpegExecutionError = null;
    console.log("[AudioConverter] \u{1F3AC} Executando FFmpeg...");
    try {
      await execAsync(ffmpegCmd, { timeout: 3e4 });
    } catch (ffmpegError) {
      ffmpegExecutionError = ffmpegError;
      console.log("[AudioConverter] \u26A0\uFE0F FFmpeg stderr (pode ser normal):", ffmpegError.stderr?.slice(0, 200));
    }
    try {
      await access(outputPath);
    } catch {
      if (ffmpegExecutionError) {
        throw ffmpegExecutionError;
      }
      throw new Error("Arquivo convertido n\xE3o foi gerado pelo FFmpeg");
    }
    const outputBuffer = await readFile(outputPath);
    console.log("[AudioConverter] \u2705 Convers\xE3o conclu\xEDda:", outputBuffer.length, "bytes");
    return {
      buffer: outputBuffer,
      mimeType: "audio/ogg; codecs=opus",
      extension: "ogg",
      converted: true
    };
  } catch (error) {
    console.error("[AudioConverter] \u274C Erro na convers\xE3o do buffer:", error.message);
    console.log("[AudioConverter] \u26A0\uFE0F Fallback: mantendo buffer original");
    return {
      buffer: inputBuffer,
      mimeType: inputMimeType || "application/octet-stream",
      extension: inputExt,
      converted: false
    };
  } finally {
    try {
      await Promise.all([
        unlink(inputPath).catch(() => {
        }),
        unlink(outputPath).catch(() => {
        })
      ]);
    } catch {
    }
  }
}
async function convertToWhatsAppAudio(base64Data, inputMimeType) {
  const trimmedData = base64Data.trim();
  if (isRemoteAudioSource(trimmedData)) {
    const remoteAudio = await fetchRemoteAudioBuffer(trimmedData, inputMimeType);
    const converted2 = await convertBufferToWhatsAppAudio(remoteAudio.buffer, remoteAudio.mimeType);
    return {
      data: converted2.buffer.toString("base64"),
      mimeType: converted2.mimeType
    };
  }
  let pureBase64 = base64Data;
  if (base64Data.startsWith("data:")) {
    pureBase64 = base64Data.split(",")[1];
  }
  const inputBuffer = Buffer.from(pureBase64, "base64");
  const converted = await convertBufferToWhatsAppAudio(inputBuffer, inputMimeType);
  return {
    data: converted.buffer.toString("base64"),
    mimeType: converted.mimeType
  };
}
async function checkFFmpegAvailable() {
  try {
    await execAsync("ffmpeg -version");
    console.log("[AudioConverter] \u2705 FFmpeg dispon\xEDvel");
    return true;
  } catch {
    console.log("[AudioConverter] \u26A0\uFE0F FFmpeg n\xE3o dispon\xEDvel");
    return false;
  }
}

export {
  convertBufferToWhatsAppAudio,
  convertToWhatsAppAudio,
  checkFFmpegAvailable
};
