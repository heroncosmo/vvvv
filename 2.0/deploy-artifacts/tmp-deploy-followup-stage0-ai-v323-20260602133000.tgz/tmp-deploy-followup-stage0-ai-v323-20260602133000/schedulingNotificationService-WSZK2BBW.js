import {
  sendWhatsAppMessageFromUser
} from "./chunk-LYL74IEX.js";
import "./chunk-GXAKLONY.js";
import "./chunk-R2H3ZHAP.js";
import "./chunk-7SPF5OKO.js";
import "./chunk-YB77ZB3P.js";
import "./chunk-XZFDVJYL.js";
import "./chunk-LIK4OWWG.js";
import "./chunk-K6J2PMOD.js";
import "./chunk-M7TXNZTC.js";
import "./chunk-UKCWWGWI.js";
import "./chunk-R6CXRQMB.js";
import "./chunk-JC6URYU5.js";
import "./chunk-KFQGP6VL.js";

// server/schedulingNotificationService.ts
function formatCurrencyBRL(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
function formatAppointmentDate(dateValue) {
  const [year, month, day] = String(dateValue || "").split("-");
  if (!year || !month || !day) {
    return dateValue;
  }
  return `${day}/${month}/${year}`;
}
async function sendSchedulingBookingNotification(userId, phoneNumber, appointment) {
  const targetPhone = String(phoneNumber || "").replace(/\D/g, "");
  if (!targetPhone) {
    return false;
  }
  const serviceLines = (appointment.selectedServices || []).map((service) => {
    const extras = [];
    if (typeof service.durationMinutes === "number" && service.durationMinutes > 0) {
      extras.push(`${service.durationMinutes} min`);
    }
    if (typeof service.price === "number" && Number.isFinite(service.price)) {
      extras.push(formatCurrencyBRL(service.price));
    }
    return `- ${service.name}${extras.length ? ` (${extras.join(" | ")})` : ""}`;
  });
  const lines = [
    "Novo agendamento recebido",
    "",
    `Cliente: ${appointment.clientName}`,
    `Telefone: ${appointment.clientPhone}`,
    `Data: ${formatAppointmentDate(appointment.appointmentDate)}`,
    `Horario: ${appointment.startTime}${appointment.endTime ? ` - ${appointment.endTime}` : ""}`,
    appointment.serviceName ? `Servico: ${appointment.serviceName}` : "",
    appointment.location ? `Endereco: ${appointment.location}` : "",
    serviceLines.length ? "" : "",
    ...serviceLines,
    typeof appointment.totalPrice === "number" && Number.isFinite(appointment.totalPrice) ? `Total: ${formatCurrencyBRL(appointment.totalPrice)}` : "",
    `ID interno: ${appointment.id}`
  ].filter(Boolean);
  return sendWhatsAppMessageFromUser(
    userId,
    targetPhone,
    lines.join("\n"),
    "scheduling_notification"
  );
}
export {
  sendSchedulingBookingNotification
};
