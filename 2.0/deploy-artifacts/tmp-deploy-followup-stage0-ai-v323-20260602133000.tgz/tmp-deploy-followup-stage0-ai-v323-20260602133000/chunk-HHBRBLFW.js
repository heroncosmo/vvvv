import {
  pool
} from "./chunk-R6CXRQMB.js";

// server/autologinService.ts
async function generateAutologinLink(userId, destination = "/conexao") {
  const token = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + 60 * 60 * 1e3);
  await pool.query(
    `INSERT INTO admin_autologin_tokens (token, user_id, expires_at, redirect_to) VALUES ($1, $2, $3, $4)`,
    [token, userId, expiresAt, destination]
  );
  const baseUrl = (process.env.APP_URL || "https://agentezap.online").replace(/\/+$/, "");
  return `${baseUrl}${destination}?token=${token}`;
}
async function generateAutologinLinkWithRetry(userId, destination = "/conexao", maxRetries = 2) {
  let lastError;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await generateAutologinLink(userId, destination);
    } catch (err) {
      lastError = err;
      if (attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
      }
    }
  }
  throw lastError;
}
function buildPublicDestinationUrl(destination = "/conexao") {
  const baseUrl = (process.env.APP_URL || "https://agentezap.online").replace(/\/+$/, "");
  return `${baseUrl}${destination}`;
}

export {
  generateAutologinLink,
  generateAutologinLinkWithRetry,
  buildPublicDestinationUrl
};
