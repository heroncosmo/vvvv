import {
  getSupabaseServiceKey,
  getSupabaseUrl,
  supabase
} from "./chunk-7SPF5OKO.js";
import {
  pool
} from "./chunk-R6CXRQMB.js";

// server/routes_autologin.ts
var supabaseUrl = getSupabaseUrl();
var supabaseServiceKey = getSupabaseServiceKey();
function buildTemporaryAuthPassword() {
  return `AZ-${Math.random().toString(36).slice(2, 10)}!`;
}
function registerAutologinRoutes(app) {
  app.get("/api/autologin/:token", async (req, res) => {
    try {
      const token = req.params.token;
      if (!token) return res.status(400).json({ error: "Token ausente" });
      const { rows } = await pool.query(
        `SELECT user_id, redirect_to
         FROM admin_autologin_tokens
         WHERE token = $1
           AND expires_at > NOW()
         LIMIT 1`,
        [token]
      );
      if (!rows || rows.length === 0) {
        return res.status(401).json({ error: "Link inv\xE1lido ou expirado" });
      }
      const userId = rows[0].user_id;
      const redirectTo = rows[0].redirect_to || "/conexao";
      try {
        await pool.query(
          `UPDATE admin_autologin_tokens
           SET used_at = COALESCE(used_at, NOW())
           WHERE token = $1`,
          [token]
        );
      } catch (e) {
        console.warn("[Autologin] Falha ao marcar primeiro uso do token:", e);
      }
      try {
        await pool.query(
          "DELETE FROM admin_autologin_tokens WHERE user_id = $1 AND expires_at < NOW()",
          [userId]
        );
      } catch (e) {
        console.warn("[Autologin] Falha ao limpar tokens expirados:", e);
      }
      if (!supabaseUrl || !supabaseServiceKey) {
        console.error("[Autologin] SUPABASE_URL ou SUPABASE_SERVICE_ROLE_KEY n\xE3o configurados");
        return res.status(500).json({ error: "Configura\xE7\xE3o de autentica\xE7\xE3o ausente" });
      }
      let userEmail = null;
      const authUserResult = await pool.query(
        "SELECT email FROM auth.users WHERE id = $1::uuid",
        [userId]
      );
      if (authUserResult.rows?.length > 0) {
        userEmail = authUserResult.rows[0].email;
      } else {
        const appUserResult = await pool.query(
          "SELECT email, name, phone FROM users WHERE id = $1",
          [userId]
        );
        if (!appUserResult.rows?.length || !appUserResult.rows[0].email) {
          console.error(`[Autologin] Usu\xE1rio ${userId} n\xE3o encontrado em users/auth.users`);
          return res.status(404).json({ error: "Usu\xE1rio n\xE3o encontrado" });
        }
        userEmail = appUserResult.rows[0].email;
        const userName = appUserResult.rows[0].name || "";
        const userPhone = appUserResult.rows[0].phone || "";
        const authByEmailResult = await pool.query(
          "SELECT id FROM auth.users WHERE lower(email) = lower($1) LIMIT 1",
          [userEmail]
        );
        if (authByEmailResult.rows?.length > 0) {
          const wrongAuthId = authByEmailResult.rows[0].id;
          if (wrongAuthId !== userId) {
            console.warn(`[Autologin] Auth \xF3rf\xE3o encontrado por email ${userEmail}: ${wrongAuthId}. Recriando com id local ${userId}.`);
            const { error: deleteError } = await supabase.auth.admin.deleteUser(wrongAuthId);
            if (deleteError) {
              console.error("[Autologin] Falha ao remover auth \xF3rf\xE3o:", deleteError);
              return res.status(500).json({ error: "Erro ao recuperar autentica\xE7\xE3o" });
            }
          }
        }
        const { data: recreatedUser, error: recreateError } = await supabase.auth.admin.createUser({
          id: userId,
          email: userEmail,
          password: buildTemporaryAuthPassword(),
          email_confirm: true,
          user_metadata: {
            name: userName,
            phone: userPhone
          }
        });
        if (recreateError) {
          console.error("[Autologin] Falha ao recriar auth user ausente:", recreateError);
          return res.status(500).json({ error: "Erro ao recuperar autentica\xE7\xE3o" });
        }
        console.log(`[Autologin] Auth user recriado para userId=${userId} email=${userEmail} authId=${recreatedUser.user?.id || "N/A"}`);
      }
      if (!userEmail) {
        return res.status(404).json({ error: "Usu\xE1rio n\xE3o encontrado" });
      }
      const generateLinkEndpoint = `${supabaseUrl}/auth/v1/admin/generate_link`;
      let generateRes;
      try {
        generateRes = await fetch(generateLinkEndpoint, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${supabaseServiceKey}`,
            "apikey": supabaseServiceKey,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            type: "magiclink",
            email: userEmail
          })
        });
      } catch (fetchErr) {
        console.error("[Autologin] Erro de rede ao gerar link:", fetchErr);
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      if (!generateRes.ok) {
        const body = await generateRes.text().catch(() => "");
        console.error(`[Autologin] generate_link retornou ${generateRes.status}:`, body);
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      let linkData;
      try {
        linkData = await generateRes.json();
      } catch (parseErr) {
        console.error("[Autologin] Resposta do generate_link n\xE3o \xE9 JSON v\xE1lido");
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      const hashedToken = linkData?.properties?.hashed_token || linkData?.hashed_token;
      if (!hashedToken) {
        console.error("[Autologin] generate_link sem hashed_token:", JSON.stringify(linkData).substring(0, 200));
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      const verifyEndpoint = `${supabaseUrl}/auth/v1/verify`;
      let verifyRes;
      try {
        verifyRes = await fetch(verifyEndpoint, {
          method: "POST",
          headers: {
            "apikey": supabaseServiceKey,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            token_hash: hashedToken,
            type: "magiclink"
          })
        });
      } catch (fetchErr) {
        console.error("[Autologin] Erro de rede ao verificar token:", fetchErr);
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      if (!verifyRes.ok) {
        const body = await verifyRes.text().catch(() => "");
        console.error(`[Autologin] verify retornou ${verifyRes.status}:`, body);
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      let sessionData;
      try {
        sessionData = await verifyRes.json();
      } catch (parseErr) {
        console.error("[Autologin] Resposta do verify n\xE3o \xE9 JSON v\xE1lido");
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      const access_token = sessionData?.access_token;
      const refresh_token = sessionData?.refresh_token;
      if (!access_token || !refresh_token) {
        console.error("[Autologin] Resposta do verify sem tokens esperados:", JSON.stringify(sessionData).substring(0, 200));
        return res.status(500).json({ error: "Erro ao criar sess\xE3o" });
      }
      if (req.session) {
        req.session.user = { id: userId, email: userEmail };
        console.log(`[Autologin] Express session sincronizada para userId=${userId} email=${userEmail}`);
      }
      return res.json({ access_token, refresh_token, redirect_to: redirectTo });
    } catch (error) {
      console.error("[Autologin]", error);
      return res.status(500).json({ error: "Erro interno" });
    }
  });
}

export {
  registerAutologinRoutes
};
