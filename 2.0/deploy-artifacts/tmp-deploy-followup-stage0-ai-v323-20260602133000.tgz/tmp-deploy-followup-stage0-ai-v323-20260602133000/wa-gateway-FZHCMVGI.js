import {
  ensureWhatsAppRuntimeSchema,
  parseGatewayAccountToken,
  previewStatusAudienceForUser,
  sendStatusPostForUser,
  verifyGatewayAccountToken
} from "./chunk-JWJQKJCT.js";
import {
  buildLocalInstanceDevice,
  buildLocalInstanceStatus,
  clearInstanceMessageQueue,
  createInstanceGroup,
  getInstanceContactProfilePicture,
  getInstanceGroupDetails,
  getInstanceGroupInviteCode,
  getInstanceMessageMedia,
  getInstanceMessageQueue,
  joinInstanceGroupByInvite,
  leaveInstanceGroup,
  listInstanceContacts,
  listInstanceConversations,
  listInstanceGroupParticipants,
  listInstanceGroups,
  listInstanceMessages,
  redownloadInstanceMessageMedia,
  revokeInstanceGroupInviteCode,
  sendButtonsDirectViaInstance,
  sendButtonsViaInstance,
  sendContactDirectViaInstance,
  sendContactViaInstance,
  sendGroupBulkViaInstance,
  sendInstanceContactPresence,
  sendListDirectViaInstance,
  sendListViaInstance,
  sendLocationDirectViaInstance,
  sendLocationViaInstance,
  sendMediaDirectViaInstance,
  sendMediaViaInstance,
  sendReactionViaInstance,
  sendTextDirectViaInstance,
  sendTextViaInstance,
  syncInstanceGroupHistory,
  updateInstanceContactBlockStatus,
  updateInstanceGroupDescription,
  updateInstanceGroupParticipants,
  updateInstanceGroupSubject,
  validateInstanceContact,
  validateInstanceContactsBatch
} from "./chunk-KWWNRJEF.js";
import {
  closeAllSessions,
  connectWhatsApp,
  createConnectionGatewayWebhook,
  deleteConnectionGatewayWebhook,
  deleteConnectionSafely,
  disconnectWhatsApp,
  findReusableDisconnectedConnectionForCreation,
  flushPendingWhatsAppSessionSnapshots,
  forceResetWhatsApp,
  listConnectionGatewayWebhooks,
  requestClientPairingCode,
  restoreExistingSessions,
  restorePendingAITimers,
  restoreWhatsAppSessionSnapshotsFromStorage,
  runAutoRecoveryCycle,
  runPendingTimersCronCycle,
  startAutoRecoveryCron,
  startConnectionHealthCheck,
  startPendingTimersCron,
  startWhatsAppSessionSnapshotCron,
  stopAutoRecoveryCron,
  stopConnectionHealthCheck,
  stopPendingTimersCron,
  stopWhatsAppSessionSnapshotCron,
  syncAllWhatsAppSessionSnapshots,
  updateConnectionGatewayWebhook
} from "./chunk-JDBD3TU2.js";
import "./chunk-TWJ5LOMY.js";
import "./chunk-HXFUB6FA.js";
import "./chunk-AL4GIH74.js";
import "./chunk-JE2U3KMF.js";
import "./chunk-SFLSWTY7.js";
import "./chunk-DH4QIP4D.js";
import "./chunk-OX43ECVD.js";
import "./chunk-PH437YKV.js";
import {
  isConnectionOwnedByCurrentProcess
} from "./chunk-LYL74IEX.js";
import "./chunk-QCEDG5RZ.js";
import "./chunk-GXAKLONY.js";
import "./chunk-R2H3ZHAP.js";
import {
  storage
} from "./chunk-7SPF5OKO.js";
import "./chunk-YB77ZB3P.js";
import "./chunk-XZFDVJYL.js";
import "./chunk-LIK4OWWG.js";
import "./chunk-K6J2PMOD.js";
import "./chunk-M7TXNZTC.js";
import "./chunk-UKCWWGWI.js";
import {
  closeDbPool
} from "./chunk-R6CXRQMB.js";
import "./chunk-JC6URYU5.js";
import "./chunk-KFQGP6VL.js";

// server/wa-gateway.ts
import express from "express";
import cors from "cors";

// server/gatewayApiReference.ts
var SAMPLE_INSTANCE_ID = "wa_instance_01";
var SAMPLE_CONNECTION_NAME = "Conexao Principal";
var SAMPLE_CONVERSATION_ID = "conv_9f2df5";
var SAMPLE_MESSAGE_ID = "3EB0A1B2C3D4E5F6";
var SAMPLE_GROUP_ID = "120363402211111111@g.us";
var SAMPLE_WEBHOOK_ID = "wh_01JZ7A8B9C";
var sampleInstanceStatus = {
  instanceId: SAMPLE_INSTANCE_ID,
  phoneNumber: "5511999999999",
  isConnected: true,
  qrCode: null,
  provider: "baileys",
  providerStatus: "connected"
};
var sampleInstanceDevice = {
  instanceId: SAMPLE_INSTANCE_ID,
  connectedPhone: "5511999999999",
  name: "AgenteZap Gateway",
  platform: "baileys",
  lid: null,
  profilePictureUrl: null,
  status: "connected",
  isBusiness: null
};
var gatewayApiReference = {
  title: "AgenteZap Gateway API Reference",
  version: "v1",
  auth: {
    scheme: "Authorization: Bearer <gateway_api_key> or x-api-key: <gateway_api_key>",
    note: "A API key mestra da conta enxerga apenas as instancias do proprio tenant."
  },
  webhookEvents: [
    "connection.connected",
    "connection.connecting",
    "connection.disconnected",
    "connection.qr",
    "message.received",
    "message.sent",
    "message.server_ack",
    "message.delivered",
    "message.read",
    "message.played",
    "message.failed",
    "message.updated",
    "message.revoked",
    "presence.updated",
    "conversation.updated",
    "*"
  ],
  categories: [
    {
      id: "meta",
      title: "Meta",
      description: "Pontos de entrada e descoberta da API.",
      endpoints: [
        {
          method: "GET",
          path: "/api/integration",
          summary: "Metadados basicos da API.",
          responseExample: {
            title: "Response 200",
            value: {
              name: "AgenteZap Gateway API",
              version: "v1",
              docsPath: "/api/integration/__intro__",
              referencePath: "/api/integration/__reference__",
              authentication: {
                type: "bearer_or_x_api_key",
                header: "Authorization: Bearer <gateway_api_key> or x-api-key: <gateway_api_key>"
              }
            }
          }
        },
        {
          method: "GET",
          path: "/api/integration/__intro__",
          summary: "Resumo rapido da API, eventos de webhook e endpoints principais.",
          responseExample: {
            title: "Response 200",
            value: {
              title: "AgenteZap Gateway API Integration",
              webhookEvents: ["message.received", "message.read", "conversation.updated"],
              endpointsCount: 54
            }
          }
        },
        {
          method: "GET",
          path: "/api/integration/__reference__",
          summary: "Catalogo completo endpoint por endpoint com exemplos de payload/resposta.",
          responseExample: {
            title: "Response 200",
            value: {
              title: "AgenteZap Gateway API Reference",
              version: "v1",
              categoriesCount: 9,
              endpointsCount: 54
            }
          }
        }
      ]
    },
    {
      id: "instances",
      title: "Instancias",
      description: "Gerenciamento de instancias, status e lifecycle da conexao.",
      endpoints: [
        {
          method: "POST",
          path: "/api/integration/instances/status/bulk",
          summary: "Consultar status em lote de multiplas instancias.",
          requestExample: {
            title: "Request body",
            value: {
              instanceIds: [SAMPLE_INSTANCE_ID, "wa_instance_02"]
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              items: [
                {
                  instanceId: SAMPLE_INSTANCE_ID,
                  status: sampleInstanceStatus,
                  device: sampleInstanceDevice
                }
              ]
            }
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances",
          summary: "Listar instancias da conta.",
          responseExample: {
            title: "Response 200",
            value: {
              items: [
                {
                  instanceId: SAMPLE_INSTANCE_ID,
                  connectionName: SAMPLE_CONNECTION_NAME,
                  connectionType: "baileys",
                  isPrimary: true,
                  publicApiEnabled: true,
                  publicApiTokenPreview: "inst_****************",
                  provider: "baileys",
                  providerStatus: "connected",
                  status: sampleInstanceStatus,
                  device: sampleInstanceDevice
                }
              ]
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances",
          summary: "Criar nova instancia gerenciada.",
          requestExample: {
            title: "Request body",
            value: {
              connectionName: "Conexao Loja Centro",
              isPrimary: false
            }
          },
          responseExample: {
            title: "Response 201",
            value: {
              success: true,
              reusedExistingConnection: false,
              instance: {
                instanceId: SAMPLE_INSTANCE_ID,
                connectionName: "Conexao Loja Centro",
                status: {
                  ...sampleInstanceStatus,
                  isConnected: false,
                  qrCode: "data:image/png;base64,...",
                  providerStatus: "connecting"
                },
                device: {
                  ...sampleInstanceDevice,
                  connectedPhone: null,
                  status: "disconnected"
                }
              }
            }
          }
        },
        {
          method: "DELETE",
          path: "/api/integration/instances/:instanceId",
          summary: "Excluir instancia secundaria.",
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID }
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/status",
          summary: "Status atual da instancia.",
          responseExample: {
            title: "Response 200",
            value: sampleInstanceStatus
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/device",
          summary: "Metadados do device conectado.",
          responseExample: {
            title: "Response 200",
            value: sampleInstanceDevice
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/connect",
          summary: "Iniciar conexao/pairing da instancia.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              status: {
                ...sampleInstanceStatus,
                isConnected: false,
                qrCode: "data:image/png;base64,...",
                providerStatus: "connecting"
              }
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/disconnect",
          summary: "Desconectar a instancia.",
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, disconnected: true }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/reset",
          summary: "Resetar a instancia e limpar runtime dessa conexao.",
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, reset: true }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/pairing-code",
          summary: "Gerar pairing code para login por numero.",
          requestExample: {
            title: "Request body",
            value: { phoneNumber: "5511999999999" }
          },
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, code: "ABCD-EFGH" }
          }
        }
      ]
    },
    {
      id: "conversations",
      title: "Conversas",
      description: "Consulta de chats, mensagens e midia por instancia.",
      endpoints: [
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/conversations",
          summary: "Listar conversas da instancia.",
          responseExample: {
            title: "Response 200",
            value: [
              {
                id: SAMPLE_CONVERSATION_ID,
                contactNumber: "5511999999999",
                remoteJid: "5511999999999@s.whatsapp.net",
                contactName: "Maria",
                lastMessageText: "Oi, quero saber mais",
                unreadCount: 1
              }
            ]
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/conversations/:conversationId/messages",
          summary: "Listar mensagens da conversa.",
          responseExample: {
            title: "Response 200",
            value: [
              {
                id: "msg_local_01",
                conversationId: SAMPLE_CONVERSATION_ID,
                messageId: SAMPLE_MESSAGE_ID,
                fromMe: false,
                text: "Oi, quero saber mais",
                status: "received",
                mediaType: null
              }
            ]
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/conversations/:conversationId/messages/:messageId/media",
          summary: "Consultar metadados da midia salva para uma mensagem.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: SAMPLE_MESSAGE_ID,
              localMessageId: "msg_local_02",
              mediaType: "image",
              mediaUrl: "https://cdn.exemplo.com/uploads/wa/123.jpg",
              mediaMimeType: "image/jpeg",
              mediaCaption: "Catalogo atualizado",
              canRedownload: true,
              redownloaded: false
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/conversations/:conversationId/messages/:messageId/media/redownload",
          summary: "Tentar rebaixar novamente midia expirada.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: SAMPLE_MESSAGE_ID,
              redownloaded: true,
              mediaUrl: "https://cdn.exemplo.com/uploads/wa/123-refreshed.jpg"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/conversations/:conversationId/group-history-sync",
          summary: "Sincronizar historico de um grupo sob demanda.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              conversationId: SAMPLE_CONVERSATION_ID,
              status: "synced",
              importedCount: 42
            }
          }
        }
      ]
    },
    {
      id: "contacts",
      title: "Contatos",
      description: "Validacao, foto, block/unblock e presence.",
      endpoints: [
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/contacts",
          summary: "Listar contatos sincronizados.",
          responseExample: {
            title: "Response 200",
            value: [
              {
                id: "contact_01",
                phone: "5511999999999",
                name: "Maria",
                isBlocked: false
              }
            ]
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/contacts/validate",
          summary: "Validar se um numero tem WhatsApp.",
          queryExample: { to: "5511999999999" },
          responseExample: {
            title: "Response 200",
            value: {
              input: "5511999999999",
              exists: true,
              contactNumber: "5511999999999",
              remoteJid: "5511999999999@s.whatsapp.net",
              jidSuffix: "s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/contacts/validate-bulk",
          summary: "Validar varios numeros de uma vez.",
          requestExample: {
            title: "Request body",
            value: { contacts: ["5511999999999", "5511888888888"] }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              items: [
                {
                  input: "5511999999999",
                  exists: true,
                  contactNumber: "5511999999999",
                  remoteJid: "5511999999999@s.whatsapp.net"
                }
              ]
            }
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/contacts/profile-picture",
          summary: "Buscar foto do contato.",
          queryExample: { to: "5511999999999" },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              phoneNumber: "5511999999999",
              profilePictureUrl: "https://mmg.whatsapp.net/d/f/Abc123.jpg"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/contacts/block",
          summary: "Bloquear ou desbloquear contato.",
          requestExample: {
            title: "Request body",
            value: { to: "5511999999999", blocked: true }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              phoneNumber: "5511999999999",
              blocked: true
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/contacts/presence",
          summary: "Enviar presence/typing para um contato.",
          requestExample: {
            title: "Request body",
            value: { to: "5511999999999", presence: "composing" }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              phoneNumber: "5511999999999",
              presence: "composing"
            }
          }
        }
      ]
    },
    {
      id: "groups",
      title: "Grupos",
      description: "Consulta e operacoes ativas de grupos.",
      endpoints: [
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/groups",
          summary: "Listar grupos.",
          responseExample: {
            title: "Response 200",
            value: [
              { id: SAMPLE_GROUP_ID, name: "Clientes VIP", participantsCount: 12 }
            ]
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/groups",
          summary: "Criar grupo.",
          requestExample: {
            title: "Request body",
            value: {
              subject: "Clientes VIP",
              participants: ["5511999999999", "5511888888888"]
            }
          },
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, groupId: SAMPLE_GROUP_ID }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/groups/join-by-invite",
          summary: "Entrar em grupo por invite code.",
          requestExample: {
            title: "Request body",
            value: { inviteCode: "J0inC0deAbC123" }
          },
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, groupId: SAMPLE_GROUP_ID }
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/groups/:groupId",
          summary: "Detalhes completos de um grupo.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              groupId: SAMPLE_GROUP_ID,
              name: "Clientes VIP",
              description: "Grupo principal de clientes",
              owner: "5511999999999@s.whatsapp.net",
              createdAt: 17138e5,
              announce: false,
              restrict: false,
              participantsCount: 12,
              admins: ["5511999999999@s.whatsapp.net"],
              participants: [
                {
                  id: "5511999999999@s.whatsapp.net",
                  phoneNumber: "5511999999999",
                  isAdmin: true,
                  isSuperAdmin: false
                }
              ]
            }
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/groups/:groupId/participants",
          summary: "Listar participantes do grupo.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              items: [
                {
                  id: "5511999999999@s.whatsapp.net",
                  phoneNumber: "5511999999999",
                  isAdmin: true,
                  isSuperAdmin: false
                }
              ]
            }
          }
        },
        {
          method: "PATCH",
          path: "/api/integration/instances/:instanceId/groups/:groupId/subject",
          summary: "Alterar assunto do grupo.",
          requestExample: {
            title: "Request body",
            value: { subject: "Clientes Premium" }
          },
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, groupId: SAMPLE_GROUP_ID, subject: "Clientes Premium" }
          }
        },
        {
          method: "PATCH",
          path: "/api/integration/instances/:instanceId/groups/:groupId/description",
          summary: "Alterar descricao do grupo.",
          requestExample: {
            title: "Request body",
            value: { description: "Somente avisos oficiais" }
          },
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, groupId: SAMPLE_GROUP_ID, description: "Somente avisos oficiais" }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/groups/:groupId/participants",
          summary: "Adicionar/remover/promover/demover participantes.",
          requestExample: {
            title: "Request body",
            value: {
              action: "add",
              participants: ["5511777777777", "5511666666666"]
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              groupId: SAMPLE_GROUP_ID,
              action: "add",
              items: [
                { jid: "5511777777777@s.whatsapp.net", status: "200" }
              ]
            }
          }
        },
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/groups/:groupId/invite-code",
          summary: "Consultar invite code do grupo.",
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, groupId: SAMPLE_GROUP_ID, inviteCode: "J0inC0deAbC123" }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/groups/:groupId/invite-code/revoke",
          summary: "Revogar invite code do grupo.",
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, groupId: SAMPLE_GROUP_ID, inviteCode: "N3wInv1t3C0de" }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/groups/:groupId/leave",
          summary: "Sair do grupo.",
          responseExample: {
            title: "Response 200",
            value: { success: true, instanceId: SAMPLE_INSTANCE_ID, groupId: SAMPLE_GROUP_ID, left: true }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/groups/send-bulk",
          summary: "Enviar texto em massa para grupos.",
          requestExample: {
            title: "Request body",
            value: {
              groupIds: [SAMPLE_GROUP_ID],
              message: "Aviso geral para o grupo.",
              settings: { delayMin: 5, delayMax: 15, useAI: false }
            }
          },
          responseExample: {
            title: "Response 200",
            value: { sent: 1, failed: 0, errors: [] }
          }
        }
      ]
    },
    {
      id: "queue",
      title: "Fila",
      description: "Diagnostico e limpeza da fila anti-ban do runtime.",
      endpoints: [
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/queue",
          summary: "Consultar fila anti-ban da instancia.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              scope: "account_runtime_shared",
              queueLength: 2,
              isProcessing: true,
              totalSent: 120,
              totalErrors: 1,
              lastSentAt: "2026-04-24T12:30:00.000Z",
              batchCount: 3,
              isPaused: false,
              pauseRemainingMs: 0,
              minuteCount: 4,
              hourCount: 38,
              dayCount: 112,
              batchPauseLevel: 0,
              currentPauseDurationMs: 0,
              canSendNow: true,
              waitMs: 0,
              reason: null
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/queue/clear",
          summary: "Limpar itens pendentes da fila.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              cleared: 2,
              wasPending: true,
              queueLength: 0
            }
          }
        }
      ]
    },
    {
      id: "webhooks",
      title: "Webhooks",
      description: "Cadastro e gerenciamento de webhooks por instancia.",
      endpoints: [
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/webhooks",
          summary: "Listar webhooks cadastrados.",
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              items: [
                {
                  id: SAMPLE_WEBHOOK_ID,
                  url: "https://example.com/webhooks/agentezap",
                  enabled: true,
                  events: ["message.received", "message.read"],
                  secretPreview: "whsec_********"
                }
              ]
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/webhooks",
          summary: "Criar webhook.",
          requestExample: {
            title: "Request body",
            value: {
              url: "https://example.com/webhooks/agentezap",
              enabled: true,
              events: ["message.received", "message.read"],
              secret: "whsec_test_123"
            }
          },
          responseExample: {
            title: "Response 201",
            value: {
              success: true,
              webhook: {
                id: SAMPLE_WEBHOOK_ID,
                url: "https://example.com/webhooks/agentezap",
                enabled: true,
                events: ["message.received", "message.read"]
              }
            }
          }
        },
        {
          method: "PATCH",
          path: "/api/integration/instances/:instanceId/webhooks/:webhookId",
          summary: "Atualizar webhook.",
          requestExample: {
            title: "Request body",
            value: { enabled: false, events: ["message.received"] }
          },
          responseExample: {
            title: "Response 200",
            value: { success: true, webhook: { id: SAMPLE_WEBHOOK_ID, enabled: false } }
          }
        },
        {
          method: "DELETE",
          path: "/api/integration/instances/:instanceId/webhooks/:webhookId",
          summary: "Remover webhook.",
          responseExample: {
            title: "Response 200",
            value: { success: true, webhookId: SAMPLE_WEBHOOK_ID }
          }
        }
      ]
    },
    {
      id: "status-posts",
      title: "Status Posts",
      description: "Previa de audiencia e envio de status/story.",
      endpoints: [
        {
          method: "GET",
          path: "/api/integration/instances/:instanceId/status-posts/preview-audience",
          summary: "Consultar alcance atual dos status.",
          responseExample: {
            title: "Response 200",
            value: {
              audienceCount: 138,
              connectionId: SAMPLE_INSTANCE_ID,
              isConnected: true,
              audienceSource: "contacts",
              statusPrivacy: "all",
              statusPrivacyLabel: "Todos os contatos"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/status-posts/send",
          summary: "Publicar status/story.",
          requestExample: {
            title: "Request body",
            value: {
              type: "text",
              text: "Novidade da semana",
              backgroundColor: "#0ea5e9",
              textColor: "#ffffff"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              connectionId: SAMPLE_INSTANCE_ID,
              audienceCount: 138,
              sentMessageIds: ["BAE5F1C2D3E4"]
            }
          }
        }
      ]
    },
    {
      id: "messages",
      title: "Mensagens",
      description: "Primitives publicas de envio WhatsApp do gateway.",
      endpoints: [
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/text",
          aliases: ["/api/integration/instances/:instanceId/messages/send"],
          summary: "Enviar texto.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              text: "Oi, tudo bem?",
              isFromAgent: false,
              source: "owner"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              messageId: "BAE5F1C2D3E4",
              conversationId: SAMPLE_CONVERSATION_ID,
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/media",
          aliases: ["/api/integration/instances/:instanceId/messages/send-media"],
          summary: "Enviar midia.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              type: "image",
              data: "data:image/jpeg;base64,...",
              mimetype: "image/jpeg",
              caption: "Catalogo atualizado"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3E5",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/image",
          aliases: ["/api/integration/instances/:instanceId/messages/send-image"],
          summary: "Enviar imagem.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              data: "data:image/jpeg;base64,...",
              mimetype: "image/jpeg",
              caption: "Foto do produto"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3EA",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/audio",
          aliases: ["/api/integration/instances/:instanceId/messages/send-audio"],
          summary: "Enviar audio ou PTT.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              data: "data:audio/ogg;base64,...",
              mimetype: "audio/ogg; codecs=opus",
              ptt: true
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3EB",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/video",
          aliases: ["/api/integration/instances/:instanceId/messages/send-video"],
          summary: "Enviar video.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              data: "data:video/mp4;base64,...",
              mimetype: "video/mp4",
              caption: "Demonstracao do produto"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3EC",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/document",
          aliases: ["/api/integration/instances/:instanceId/messages/send-document"],
          summary: "Enviar documento.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              data: "data:application/pdf;base64,...",
              mimetype: "application/pdf",
              filename: "catalogo.pdf",
              caption: "Tabela de precos"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3ED",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/contact",
          aliases: ["/api/integration/instances/:instanceId/messages/send-contact"],
          summary: "Enviar contato/vCard.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              phoneNumber: "5511999999999",
              displayName: "Maria Silva",
              organization: "AgenteZap",
              email: "maria@example.com"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3E6",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/location",
          aliases: ["/api/integration/instances/:instanceId/messages/send-location"],
          summary: "Enviar localizacao.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              latitude: -23.55052,
              longitude: -46.633308,
              name: "Loja Centro",
              address: "Av. Paulista, 1000"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3E7",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/buttons",
          aliases: ["/api/integration/instances/:instanceId/messages/send-buttons"],
          summary: "Enviar menu de botoes.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              body: "Escolha uma opcao:",
              buttons: [
                { id: "catalogo", title: "Ver catalogo" },
                { id: "atendente", title: "Falar com atendente" }
              ],
              footer: { text: "Digite o numero ou toque na opcao" }
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3E8",
              remoteJid: "5511999999999@s.whatsapp.net",
              error: null
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/list",
          aliases: ["/api/integration/instances/:instanceId/messages/send-list"],
          summary: "Enviar lista/menu.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              body: "Selecione o produto:",
              buttonText: "Ver opcoes",
              sections: [
                {
                  title: "Produtos",
                  rows: [
                    { id: "produto_1", title: "Plano Start", description: "A partir de R$49,99" },
                    { id: "produto_2", title: "Plano Pro", description: "Mais recursos" }
                  ]
                }
              ]
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: "BAE5F1C2D3E9",
              remoteJid: "5511999999999@s.whatsapp.net",
              error: null
            }
          }
        },
        {
          method: "POST",
          path: "/api/integration/instances/:instanceId/messages/reaction",
          aliases: ["/api/integration/instances/:instanceId/messages/send-reaction"],
          summary: "Reagir a uma mensagem existente.",
          requestExample: {
            title: "Request body",
            value: {
              conversationId: SAMPLE_CONVERSATION_ID,
              messageId: SAMPLE_MESSAGE_ID,
              emoji: "\u{1F44D}"
            }
          },
          responseExample: {
            title: "Response 200",
            value: {
              success: true,
              instanceId: SAMPLE_INSTANCE_ID,
              conversationId: SAMPLE_CONVERSATION_ID,
              targetMessageId: SAMPLE_MESSAGE_ID,
              messageId: "BAE5F1C2D3F0",
              remoteJid: "5511999999999@s.whatsapp.net"
            }
          }
        }
      ]
    }
  ]
};

// server/routes_gateway_public_api.ts
var DEFAULT_INTERNAL_TOKEN = "agentezap-internal-wa-gateway";
function extractGatewayApiToken(req) {
  const authorization = String(req.header("authorization") || "");
  const bearerToken = authorization.startsWith("Bearer ") ? authorization.slice(7).trim() : "";
  return bearerToken || String(req.header("x-api-key") || "").trim();
}
function getInternalToken() {
  return (process.env.WA_GATEWAY_INTERNAL_TOKEN || DEFAULT_INTERNAL_TOKEN).trim();
}
function isInternalGatewayServiceRequest(req) {
  return String(req.header("x-wa-gateway-token") || "").trim() === getInternalToken();
}
function parseSendSource(source) {
  const value = String(source || "").trim();
  if (value === "owner" || value === "agent" || value === "followup" || value === "system") {
    return value;
  }
  return void 0;
}
async function authenticateGatewayAccountRequest(req) {
  if (isInternalGatewayServiceRequest(req)) {
    const userId = String(req.header("x-gateway-user-id") || "").trim();
    if (!userId) {
      const error = new Error("x-gateway-user-id ausente");
      error.status = 401;
      throw error;
    }
    const user2 = await storage.getUser(userId);
    if (!user2) {
      const error = new Error("Usuario nao encontrado");
      error.status = 404;
      throw error;
    }
    return user2;
  }
  const token = extractGatewayApiToken(req);
  if (!token) {
    const error = new Error("API key ausente");
    error.status = 401;
    throw error;
  }
  const parsed = parseGatewayAccountToken(token);
  if (!parsed?.userId) {
    const error = new Error("API key invalida");
    error.status = 401;
    throw error;
  }
  const user = await storage.getUser(parsed.userId);
  if (!user || !user.gatewayApiEnabled || !verifyGatewayAccountToken(token, user.gatewayApiTokenHash || null)) {
    const error = new Error("API key invalida");
    error.status = 401;
    throw error;
  }
  await storage.updateUser(user.id, {
    gatewayApiLastUsedAt: /* @__PURE__ */ new Date()
  });
  return user;
}
async function listManagedConnectionsForUser(userId) {
  return storage.getConnectionsByUserId(userId);
}
async function resolveManagedConnection(userId, instanceId) {
  const connection = await storage.getConnectionById(instanceId);
  if (!connection || connection.userId !== userId) {
    const error = new Error("Instancia nao encontrada");
    error.status = 404;
    throw error;
  }
  return connection;
}
async function resolveManagedConnectionFromRequest(req) {
  const instanceId = String(req.params.instanceId || "").trim();
  if (!instanceId) {
    const error = new Error("Instancia nao encontrada");
    error.status = 404;
    throw error;
  }
  if (isInternalGatewayServiceRequest(req)) {
    const connection = await storage.getConnectionById(instanceId);
    if (!connection) {
      const error = new Error("Instancia nao encontrada");
      error.status = 404;
      throw error;
    }
    return connection;
  }
  const user = await authenticateGatewayAccountRequest(req);
  return resolveManagedConnection(user.id, instanceId);
}
async function buildGatewayInstanceSummary(connection) {
  const [status, device] = await Promise.all([
    buildLocalInstanceStatus(connection),
    buildLocalInstanceDevice(connection)
  ]);
  return {
    instanceId: connection.id,
    connectionName: connection.connectionName || null,
    connectionType: connection.connectionType || null,
    isPrimary: connection.isPrimary ?? null,
    publicApiEnabled: !!connection.publicApiEnabled,
    publicApiTokenPreview: connection.publicApiTokenPreview || null,
    provider: connection.provider || null,
    providerStatus: connection.providerStatus || null,
    status,
    device
  };
}
async function withGatewayAccount(req, res, handler) {
  try {
    const user = await authenticateGatewayAccountRequest(req);
    await handler(user);
  } catch (error) {
    const status = Number(error?.status) || 500;
    const message = error?.message || "Erro na API do gateway";
    res.status(status).json({ message });
  }
}
async function withGatewayConnection(req, res, handler) {
  try {
    const connection = await resolveManagedConnectionFromRequest(req);
    await handler(connection);
  } catch (error) {
    const status = Number(error?.status) || 500;
    const message = error?.message || "Erro na API do gateway";
    res.status(status).json({ message });
  }
}
function registerGatewayPublicApiRoutes(app) {
  const referenceCategoriesCount = gatewayApiReference.categories.length;
  const referenceEndpointsCount = gatewayApiReference.categories.reduce(
    (total, category) => total + category.endpoints.length,
    0
  );
  const handleTextSend = async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendTextDirectViaInstance({
            connection,
            text: String(body.text || "").trim(),
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendTextViaInstance({
          connection,
          text: String(body.text || "").trim(),
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true,
          isFromAgent: typeof body.isFromAgent === "boolean" ? body.isFromAgent : void 0,
          source: parseSendSource(body.source)
        })
      );
    });
  };
  const handleMediaSend = async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendMediaDirectViaInstance({
            connection,
            type: body.type,
            data: body.data,
            mimetype: body.mimetype,
            filename: body.filename,
            caption: body.caption,
            ptt: body.ptt,
            seconds: body.seconds,
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendMediaViaInstance({
          connection,
          type: body.type,
          data: body.data,
          mimetype: body.mimetype,
          filename: body.filename,
          caption: body.caption,
          ptt: body.ptt,
          seconds: body.seconds,
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true,
          isFromAgent: body.isFromAgent === true,
          source: parseSendSource(body.source)
        })
      );
    });
  };
  const createTypedMediaSendHandler = (type) => async (req, res) => {
    req.body = {
      ...req.body || {},
      type
    };
    await handleMediaSend(req, res);
  };
  const handleImageSend = createTypedMediaSendHandler("image");
  const handleAudioSend = createTypedMediaSendHandler("audio");
  const handleVideoSend = createTypedMediaSendHandler("video");
  const handleDocumentSend = createTypedMediaSendHandler("document");
  const handleContactSend = async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendContactDirectViaInstance({
            connection,
            phoneNumber: String(body.phoneNumber || "").trim(),
            displayName: body.displayName || void 0,
            organization: body.organization || void 0,
            email: body.email || void 0,
            url: body.url || void 0,
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendContactViaInstance({
          connection,
          phoneNumber: String(body.phoneNumber || "").trim(),
          displayName: body.displayName || void 0,
          organization: body.organization || void 0,
          email: body.email || void 0,
          url: body.url || void 0,
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true
        })
      );
    });
  };
  const handleLocationSend = async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendLocationDirectViaInstance({
            connection,
            latitude: Number(body.latitude),
            longitude: Number(body.longitude),
            name: body.name || void 0,
            address: body.address || void 0,
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendLocationViaInstance({
          connection,
          latitude: Number(body.latitude),
          longitude: Number(body.longitude),
          name: body.name || void 0,
          address: body.address || void 0,
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true
        })
      );
    });
  };
  const handleButtonsSend = async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendButtonsDirectViaInstance({
            connection,
            body: String(body.body || "").trim(),
            buttons: Array.isArray(body.buttons) ? body.buttons : [],
            header: body.header || void 0,
            footer: body.footer || void 0,
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendButtonsViaInstance({
          connection,
          body: String(body.body || "").trim(),
          buttons: Array.isArray(body.buttons) ? body.buttons : [],
          header: body.header || void 0,
          footer: body.footer || void 0,
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true
        })
      );
    });
  };
  const handleListSend = async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendListDirectViaInstance({
            connection,
            body: String(body.body || "").trim(),
            buttonText: String(body.buttonText || "").trim(),
            sections: Array.isArray(body.sections) ? body.sections : [],
            header: body.header || void 0,
            footer: body.footer || void 0,
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendListViaInstance({
          connection,
          body: String(body.body || "").trim(),
          buttonText: String(body.buttonText || "").trim(),
          sections: Array.isArray(body.sections) ? body.sections : [],
          header: body.header || void 0,
          footer: body.footer || void 0,
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true
        })
      );
    });
  };
  const handleReactionSend = async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      res.json(
        await sendReactionViaInstance({
          connection,
          messageId: String(body.messageId || "").trim(),
          emoji: body.emoji || void 0,
          conversationId: body.conversationId || void 0
        })
      );
    });
  };
  app.get("/api/integration", (_req, res) => {
    res.json({
      name: "AgenteZap Gateway API",
      version: "v1",
      docsPath: "/api/integration/__intro__",
      referencePath: "/api/integration/__reference__",
      contractPath: "/docs/gateway-wapi-contract.md",
      categoriesCount: referenceCategoriesCount,
      endpointsCount: referenceEndpointsCount,
      authentication: {
        type: "bearer_or_x_api_key",
        header: "Authorization: Bearer <gateway_api_key> or x-api-key: <gateway_api_key>"
      }
    });
  });
  app.get("/api/integration/__reference__", (_req, res) => {
    res.json(gatewayApiReference);
  });
  app.get("/api/integration/__intro__", (_req, res) => {
    res.json({
      title: "AgenteZap Gateway API Integration",
      description: "API publica do runtime WhatsApp do AgenteZap. Use uma API key mestra da conta para listar, criar e operar instancias gerenciadas por este gateway.",
      authentication: {
        type: "bearer_or_x_api_key",
        notes: [
          "Gere sua API key mestra no painel do AgenteZap.",
          "Cada conta enxerga e gerencia apenas as proprias instancias.",
          "As operacoes desta API exigem que a instancia esteja hospedada neste gateway."
        ]
      },
      referencePath: "/api/integration/__reference__",
      categoriesCount: referenceCategoriesCount,
      endpointsCount: referenceEndpointsCount,
      webhookEvents: [
        "connection.connected",
        "connection.connecting",
        "connection.disconnected",
        "connection.qr",
        "message.received",
        "message.sent",
        "message.server_ack",
        "message.delivered",
        "message.read",
        "message.played",
        "message.failed",
        "message.updated",
        "message.revoked",
        "presence.updated",
        "conversation.updated",
        "*"
      ],
      endpoints: [
        { method: "GET", path: "/api/integration/instances", description: "Listar instancias da conta" },
        { method: "POST", path: "/api/integration/instances", description: "Criar uma nova instancia" },
        { method: "DELETE", path: "/api/integration/instances/:instanceId", description: "Excluir uma instancia secundaria" },
        { method: "GET", path: "/api/integration/instances/:instanceId/status", description: "Status da instancia" },
        { method: "GET", path: "/api/integration/instances/:instanceId/device", description: "Dados do device conectado" },
        { method: "POST", path: "/api/integration/instances/:instanceId/connect", description: "Iniciar conexao/pairing" },
        { method: "POST", path: "/api/integration/instances/:instanceId/disconnect", description: "Desconectar instancia" },
        { method: "POST", path: "/api/integration/instances/:instanceId/reset", description: "Resetar instancia" },
        { method: "POST", path: "/api/integration/instances/:instanceId/pairing-code", description: "Gerar pairing code para a instancia" },
        { method: "GET", path: "/api/integration/instances/:instanceId/conversations", description: "Listar conversas" },
        { method: "GET", path: "/api/integration/instances/:instanceId/conversations/:conversationId/messages", description: "Listar mensagens de uma conversa" },
        { method: "GET", path: "/api/integration/instances/:instanceId/conversations/:conversationId/messages/:messageId/media", description: "Consultar midia de uma mensagem" },
        { method: "POST", path: "/api/integration/instances/:instanceId/conversations/:conversationId/messages/:messageId/media/redownload", description: "Tentar rebaixar a midia da mensagem" },
        { method: "GET", path: "/api/integration/instances/:instanceId/contacts", description: "Listar contatos" },
        { method: "GET", path: "/api/integration/instances/:instanceId/contacts/validate", description: "Validar se um numero tem WhatsApp" },
        { method: "POST", path: "/api/integration/instances/:instanceId/contacts/validate-bulk", description: "Validar numeros em lote" },
        { method: "GET", path: "/api/integration/instances/:instanceId/contacts/profile-picture", description: "Buscar foto do contato" },
        { method: "POST", path: "/api/integration/instances/:instanceId/contacts/block", description: "Bloquear ou desbloquear contato" },
        { method: "POST", path: "/api/integration/instances/:instanceId/contacts/presence", description: "Enviar presenca para um contato" },
        { method: "POST", path: "/api/integration/instances/:instanceId/groups", description: "Criar grupo" },
        { method: "POST", path: "/api/integration/instances/:instanceId/groups/join-by-invite", description: "Entrar em grupo por invite code" },
        { method: "GET", path: "/api/integration/instances/:instanceId/groups", description: "Listar grupos" },
        { method: "GET", path: "/api/integration/instances/:instanceId/groups/:groupId", description: "Detalhes de um grupo" },
        { method: "GET", path: "/api/integration/instances/:instanceId/groups/:groupId/participants", description: "Participantes de um grupo" },
        { method: "PATCH", path: "/api/integration/instances/:instanceId/groups/:groupId/subject", description: "Alterar assunto do grupo" },
        { method: "PATCH", path: "/api/integration/instances/:instanceId/groups/:groupId/description", description: "Alterar descricao do grupo" },
        { method: "POST", path: "/api/integration/instances/:instanceId/groups/:groupId/participants", description: "Gerenciar participantes do grupo" },
        { method: "GET", path: "/api/integration/instances/:instanceId/groups/:groupId/invite-code", description: "Consultar invite code do grupo" },
        { method: "POST", path: "/api/integration/instances/:instanceId/groups/:groupId/invite-code/revoke", description: "Revogar invite code do grupo" },
        { method: "POST", path: "/api/integration/instances/:instanceId/groups/:groupId/leave", description: "Sair do grupo" },
        { method: "GET", path: "/api/integration/instances/:instanceId/queue", description: "Status da fila anti-ban da instancia" },
        { method: "POST", path: "/api/integration/instances/:instanceId/queue/clear", description: "Limpar fila pendente da instancia" },
        { method: "GET", path: "/api/integration/instances/:instanceId/webhooks", description: "Listar webhooks da instancia" },
        { method: "POST", path: "/api/integration/instances/:instanceId/webhooks", description: "Criar webhook da instancia" },
        { method: "PATCH", path: "/api/integration/instances/:instanceId/webhooks/:webhookId", description: "Atualizar webhook da instancia" },
        { method: "DELETE", path: "/api/integration/instances/:instanceId/webhooks/:webhookId", description: "Remover webhook da instancia" },
        { method: "POST", path: "/api/integration/instances/:instanceId/groups/send-bulk", description: "Enviar em massa para grupos" },
        { method: "GET", path: "/api/integration/instances/:instanceId/status-posts/preview-audience", description: "Pr\xE9via da audi\xEAncia de status" },
        { method: "POST", path: "/api/integration/instances/:instanceId/status-posts/send", description: "Enviar status/story" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/text", description: "Enviar texto" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/media", description: "Enviar midia" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/image", description: "Enviar imagem" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/audio", description: "Enviar audio/ptt" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/video", description: "Enviar video" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/document", description: "Enviar documento" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/contact", description: "Enviar contato/vCard" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/location", description: "Enviar localizacao" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/buttons", description: "Enviar botoes/menu" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/list", description: "Enviar lista/menu" },
        { method: "POST", path: "/api/integration/instances/:instanceId/messages/reaction", description: "Reagir a uma mensagem" }
      ]
    });
  });
  app.post("/api/integration/instances/status/bulk", async (req, res) => {
    try {
      const requestedIds = Array.from(
        new Set(
          (Array.isArray(req.body?.instanceIds) ? req.body.instanceIds : []).map((value) => String(value || "").trim()).filter(Boolean)
        )
      );
      if (requestedIds.length === 0) {
        return res.json({ items: [] });
      }
      if (isInternalGatewayServiceRequest(req)) {
        const items = await Promise.all(
          requestedIds.map(async (instanceId) => {
            const connection = await storage.getConnectionById(instanceId);
            if (!connection) {
              return null;
            }
            return buildLocalInstanceStatus(connection);
          })
        );
        return res.json({ items: items.filter(Boolean) });
      }
      await withGatewayAccount(req, res, async (user) => {
        const allowedConnections = await storage.getConnectionsByUserId(user.id);
        const allowedMap = new Map(allowedConnections.map((connection) => [connection.id, connection]));
        const items = await Promise.all(
          requestedIds.map(async (instanceId) => {
            const connection = allowedMap.get(instanceId);
            if (!connection) {
              return null;
            }
            return buildLocalInstanceStatus(connection);
          })
        );
        res.json({ items: items.filter(Boolean) });
      });
    } catch (error) {
      const status = Number(error?.status) || 500;
      const message = error?.message || "Erro na API do gateway";
      res.status(status).json({ message });
    }
  });
  app.get("/api/integration/instances", async (req, res) => {
    await withGatewayAccount(req, res, async (user) => {
      const connections = await listManagedConnectionsForUser(user.id);
      const items = await Promise.all(connections.map((connection) => buildGatewayInstanceSummary(connection)));
      res.json({ success: true, items });
    });
  });
  app.post("/api/integration/instances", async (req, res) => {
    await withGatewayAccount(req, res, async (user) => {
      const body = req.body && typeof req.body === "object" ? req.body : {};
      const connectionName = String(body.connectionName || body.name || "").trim();
      const connectionType = String(body.connectionType || "secondary").trim() || "secondary";
      const allowReuse = body.reuseExistingDisconnected !== false;
      if (allowReuse) {
        const reusableConnection = await findReusableDisconnectedConnectionForCreation(user.id);
        if (reusableConnection) {
          return res.json({
            success: true,
            reusedExistingConnection: true,
            instance: await buildGatewayInstanceSummary(reusableConnection)
          });
        }
      }
      const existingConnections = await storage.getConnectionsByUserId(user.id);
      if (existingConnections.length >= 5) {
        return res.status(400).json({ message: "Limite de 5 instancias atingido" });
      }
      const newConnection = await storage.createConnection({
        userId: user.id,
        connectionName: connectionName || `Conexao ${existingConnections.length + 1}`,
        connectionType,
        isPrimary: existingConnections.length === 0,
        isConnected: false
      });
      res.status(201).json({
        success: true,
        instance: await buildGatewayInstanceSummary(newConnection)
      });
    });
  });
  app.delete("/api/integration/instances/:instanceId", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      if (connection.isPrimary) {
        return res.status(400).json({ message: "Nao e possivel excluir a instancia principal" });
      }
      const deleteResult = await deleteConnectionSafely(connection.id);
      if (deleteResult.blockedByHistory) {
        return res.status(400).json({
          message: "Esta instancia possui historico de conversas. Desconecte em vez de excluir para preservar o atendimento.",
          blockedByHistory: true
        });
      }
      res.json({
        success: true,
        instanceId: connection.id,
        mergedIntoConnectionId: deleteResult.mergedIntoConnectionId || null
      });
    });
  });
  app.get("/api/integration/instances/:instanceId/status", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await buildLocalInstanceStatus(connection));
    });
  });
  app.get("/api/integration/instances/:instanceId/device", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await buildLocalInstanceDevice(connection));
    });
  });
  app.post("/api/integration/instances/:instanceId/connect", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      connectWhatsApp(connection.userId, connection.id).catch((error) => {
        console.error("[GATEWAY PUBLIC API] Failed to connect instance:", error);
      });
      res.json({ success: true, instanceId: connection.id, status: "connecting" });
    });
  });
  app.post("/api/integration/instances/:instanceId/disconnect", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      await disconnectWhatsApp(connection.userId, connection.id);
      res.json({ success: true, instanceId: connection.id });
    });
  });
  app.post("/api/integration/instances/:instanceId/reset", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body && typeof req.body === "object" ? req.body : {};
      await forceResetWhatsApp(connection.userId, connection.id, {
        source: typeof body.source === "string" && body.source.trim() ? body.source.trim() : "gateway_public_api_reset"
      });
      res.json({ success: true, instanceId: connection.id });
    });
  });
  app.post("/api/integration/instances/:instanceId/pairing-code", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const phoneNumber = String(req.body?.phoneNumber || "").replace(/\D/g, "");
      if (!phoneNumber) {
        return res.status(400).json({ message: "phoneNumber is required" });
      }
      const code = await requestClientPairingCode(connection.userId, phoneNumber, connection.id);
      if (!code) {
        return res.status(503).json({ message: "Nao foi possivel gerar o pairing code" });
      }
      res.json({ success: true, instanceId: connection.id, pairingCode: code });
    });
  });
  app.get("/api/integration/instances/:instanceId/conversations", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await listInstanceConversations(connection.id));
    });
  });
  app.get("/api/integration/instances/:instanceId/conversations/:conversationId/messages", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await listInstanceMessages(connection.id, String(req.params.conversationId || "")));
    });
  });
  app.get("/api/integration/instances/:instanceId/conversations/:conversationId/messages/:messageId/media", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await getInstanceMessageMedia(
          connection,
          String(req.params.conversationId || ""),
          String(req.params.messageId || "")
        )
      );
    });
  });
  app.post("/api/integration/instances/:instanceId/conversations/:conversationId/messages/:messageId/media/redownload", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await redownloadInstanceMessageMedia(
          connection,
          String(req.params.conversationId || ""),
          String(req.params.messageId || "")
        )
      );
    });
  });
  app.post("/api/integration/instances/:instanceId/conversations/:conversationId/group-history-sync", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await syncInstanceGroupHistory(connection.id, String(req.params.conversationId || "")));
    });
  });
  app.get("/api/integration/instances/:instanceId/contacts", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await listInstanceContacts(connection.id));
    });
  });
  app.get("/api/integration/instances/:instanceId/contacts/validate", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const phoneNumber = String(req.query?.phoneNumber || req.query?.phone || "").trim();
      if (!phoneNumber) {
        return res.status(400).json({ message: "phoneNumber is required" });
      }
      res.json(await validateInstanceContact(connection, phoneNumber));
    });
  });
  app.post("/api/integration/instances/:instanceId/contacts/validate-bulk", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const phoneNumbers = Array.isArray(req.body?.phoneNumbers) ? req.body.phoneNumbers.map((value) => String(value || "").trim()).filter(Boolean) : [];
      if (phoneNumbers.length === 0) {
        return res.status(400).json({ message: "phoneNumbers is required" });
      }
      res.json({
        success: true,
        items: await validateInstanceContactsBatch(connection, phoneNumbers)
      });
    });
  });
  app.get("/api/integration/instances/:instanceId/contacts/profile-picture", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const phoneNumber = String(req.query?.phoneNumber || req.query?.phone || "").trim();
      const type = String(req.query?.type || "preview").trim() === "image" ? "image" : "preview";
      if (!phoneNumber) {
        return res.status(400).json({ message: "phoneNumber is required" });
      }
      res.json(await getInstanceContactProfilePicture(connection, phoneNumber, type));
    });
  });
  app.post("/api/integration/instances/:instanceId/contacts/block", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const phoneNumber = String(req.body?.phoneNumber || req.body?.phone || "").trim();
      const action = String(req.body?.action || "block").trim() === "unblock" ? "unblock" : "block";
      if (!phoneNumber) {
        return res.status(400).json({ message: "phoneNumber is required" });
      }
      res.json(await updateInstanceContactBlockStatus(connection, phoneNumber, action));
    });
  });
  app.post("/api/integration/instances/:instanceId/contacts/presence", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const phoneNumber = String(req.body?.phoneNumber || req.body?.phone || "").trim();
      const rawPresence = String(req.body?.presence || "").trim();
      const presence = rawPresence === "available" || rawPresence === "unavailable" || rawPresence === "composing" || rawPresence === "recording" || rawPresence === "paused" ? rawPresence : null;
      if (!phoneNumber) {
        return res.status(400).json({ message: "phoneNumber is required" });
      }
      if (!presence) {
        return res.status(400).json({ message: "presence invalida" });
      }
      res.json(await sendInstanceContactPresence(connection, phoneNumber, presence));
    });
  });
  app.get("/api/integration/instances/:instanceId/groups", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const groups = await listInstanceGroups(connection);
      res.json(Array.isArray(groups) ? groups : []);
    });
  });
  app.post("/api/integration/instances/:instanceId/groups", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      const subject = String(body.subject || body.name || "").trim();
      const participants = Array.isArray(body.participants) ? body.participants.map((value) => String(value || "").trim()).filter(Boolean) : [];
      res.status(201).json(await createInstanceGroup(connection, subject, participants));
    });
  });
  app.post("/api/integration/instances/:instanceId/groups/join-by-invite", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await joinInstanceGroupByInvite(connection, String(req.body?.inviteCode || "")));
    });
  });
  app.get("/api/integration/instances/:instanceId/groups/:groupId", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await getInstanceGroupDetails(
          connection,
          String(req.params.groupId || "")
        )
      );
    });
  });
  app.get("/api/integration/instances/:instanceId/groups/:groupId/participants", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await listInstanceGroupParticipants(
          connection,
          String(req.params.groupId || "")
        )
      );
    });
  });
  app.patch("/api/integration/instances/:instanceId/groups/:groupId/subject", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await updateInstanceGroupSubject(
          connection,
          String(req.params.groupId || ""),
          String(req.body?.subject || "")
        )
      );
    });
  });
  app.patch("/api/integration/instances/:instanceId/groups/:groupId/description", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await updateInstanceGroupDescription(
          connection,
          String(req.params.groupId || ""),
          req.body?.description
        )
      );
    });
  });
  app.post("/api/integration/instances/:instanceId/groups/:groupId/participants", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      const participants = Array.isArray(body.participants) ? body.participants.map((value) => String(value || "").trim()).filter(Boolean) : [];
      const rawAction = String(body.action || "").trim();
      const action = rawAction === "add" || rawAction === "remove" || rawAction === "promote" || rawAction === "demote" ? rawAction : null;
      if (!action) {
        return res.status(400).json({ message: "action invalida" });
      }
      res.json(
        await updateInstanceGroupParticipants(
          connection,
          String(req.params.groupId || ""),
          participants,
          action
        )
      );
    });
  });
  app.get("/api/integration/instances/:instanceId/groups/:groupId/invite-code", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await getInstanceGroupInviteCode(
          connection,
          String(req.params.groupId || "")
        )
      );
    });
  });
  app.post("/api/integration/instances/:instanceId/groups/:groupId/invite-code/revoke", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await revokeInstanceGroupInviteCode(
          connection,
          String(req.params.groupId || "")
        )
      );
    });
  });
  app.post("/api/integration/instances/:instanceId/groups/:groupId/leave", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await leaveInstanceGroup(
          connection,
          String(req.params.groupId || "")
        )
      );
    });
  });
  app.get("/api/integration/instances/:instanceId/queue", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await getInstanceMessageQueue(connection));
    });
  });
  app.post("/api/integration/instances/:instanceId/queue/clear", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await clearInstanceMessageQueue(connection));
    });
  });
  app.get("/api/integration/instances/:instanceId/webhooks", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json({
        success: true,
        items: listConnectionGatewayWebhooks(connection)
      });
    });
  });
  app.post("/api/integration/instances/:instanceId/webhooks", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const webhook = await createConnectionGatewayWebhook(connection, req.body || {});
      res.status(201).json({
        success: true,
        webhook
      });
    });
  });
  app.patch("/api/integration/instances/:instanceId/webhooks/:webhookId", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const webhookId = String(req.params.webhookId || "").trim();
      if (!webhookId) {
        return res.status(400).json({ message: "Webhook nao encontrado" });
      }
      const webhook = await updateConnectionGatewayWebhook(connection, webhookId, req.body || {});
      res.json({
        success: true,
        webhook
      });
    });
  });
  app.delete("/api/integration/instances/:instanceId/webhooks/:webhookId", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const webhookId = String(req.params.webhookId || "").trim();
      if (!webhookId) {
        return res.status(400).json({ message: "Webhook nao encontrado" });
      }
      const removed = await deleteConnectionGatewayWebhook(connection, webhookId);
      if (!removed) {
        return res.status(404).json({ message: "Webhook nao encontrado" });
      }
      res.json({
        success: true,
        webhookId
      });
    });
  });
  app.post("/api/integration/instances/:instanceId/groups/send-bulk", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      const body = req.body || {};
      const groupIds = Array.isArray(body.groupIds) ? body.groupIds.map((value) => String(value || "").trim()).filter(Boolean) : [];
      const message = String(body.message || "").trim();
      if (groupIds.length === 0) {
        return res.status(400).json({ message: "Lista de grupos e obrigatoria" });
      }
      if (!message) {
        return res.status(400).json({ message: "Mensagem e obrigatoria" });
      }
      res.json(
        await sendGroupBulkViaInstance({
          connection,
          groupIds,
          message,
          settings: body && typeof body === "object" && body.settings && typeof body.settings === "object" ? body.settings : null
        })
      );
    });
  });
  app.get("/api/integration/instances/:instanceId/status-posts/preview-audience", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(await previewStatusAudienceForUser(connection.userId, connection.id));
    });
  });
  app.post("/api/integration/instances/:instanceId/status-posts/send", async (req, res) => {
    await withGatewayConnection(req, res, async (connection) => {
      res.json(
        await sendStatusPostForUser(connection.userId, req.body || {}, {
          preferredConnectionId: connection.id
        })
      );
    });
  });
  app.post("/api/integration/instances/:instanceId/messages/text", handleTextSend);
  app.post("/api/integration/instances/:instanceId/messages/send", handleTextSend);
  app.post("/api/integration/instances/:instanceId/messages/media", handleMediaSend);
  app.post("/api/integration/instances/:instanceId/messages/send-media", handleMediaSend);
  app.post("/api/integration/instances/:instanceId/messages/image", handleImageSend);
  app.post("/api/integration/instances/:instanceId/messages/send-image", handleImageSend);
  app.post("/api/integration/instances/:instanceId/messages/audio", handleAudioSend);
  app.post("/api/integration/instances/:instanceId/messages/send-audio", handleAudioSend);
  app.post("/api/integration/instances/:instanceId/messages/video", handleVideoSend);
  app.post("/api/integration/instances/:instanceId/messages/send-video", handleVideoSend);
  app.post("/api/integration/instances/:instanceId/messages/document", handleDocumentSend);
  app.post("/api/integration/instances/:instanceId/messages/send-document", handleDocumentSend);
  app.post("/api/integration/instances/:instanceId/messages/contact", handleContactSend);
  app.post("/api/integration/instances/:instanceId/messages/send-contact", handleContactSend);
  app.post("/api/integration/instances/:instanceId/messages/location", handleLocationSend);
  app.post("/api/integration/instances/:instanceId/messages/send-location", handleLocationSend);
  app.post("/api/integration/instances/:instanceId/messages/buttons", handleButtonsSend);
  app.post("/api/integration/instances/:instanceId/messages/send-buttons", handleButtonsSend);
  app.post("/api/integration/instances/:instanceId/messages/list", handleListSend);
  app.post("/api/integration/instances/:instanceId/messages/send-list", handleListSend);
  app.post("/api/integration/instances/:instanceId/messages/reaction", handleReactionSend);
  app.post("/api/integration/instances/:instanceId/messages/send-reaction", handleReactionSend);
}

// server/waGatewayRuntimeJobs.ts
var GATEWAY_RUNTIME_JOB_DEFINITIONS = {
  "restore-pending-ai-timers": {
    description: "Restaura imediatamente os timers pendentes da IA no runtime do WhatsApp.",
    run: async () => {
      await restorePendingAITimers();
      return {
        accepted: true,
        details: null
      };
    }
  },
  "pending-timers-recovery": {
    description: "Executa um ciclo unico de recuperacao dos timers pendentes do WhatsApp.",
    run: async () => {
      await runPendingTimersCronCycle();
      return {
        accepted: true,
        details: null
      };
    }
  },
  "auto-recovery": {
    description: "Executa um ciclo unico da safety-net de respostas falhadas do WhatsApp.",
    run: async () => {
      await runAutoRecoveryCycle();
      return {
        accepted: true,
        details: null
      };
    }
  },
  "session-snapshots-sync": {
    description: "Sincroniza snapshots remotos das sessoes auth_* do gateway para o Supabase Storage.",
    run: async () => {
      const result = await syncAllWhatsAppSessionSnapshots({
        includeAdmins: false,
        reason: "runtime-job"
      });
      return {
        accepted: true,
        details: result
      };
    }
  },
  "session-snapshots-restore": {
    description: "Restaura snapshots remotos das sessoes auth_* do gateway para o disco local.",
    run: async () => {
      const result = await restoreWhatsAppSessionSnapshotsFromStorage({
        includeAdmins: false,
        missingOnly: false,
        reason: "runtime-job"
      });
      return {
        accepted: true,
        details: result
      };
    }
  }
};
function listGatewayRuntimeJobs() {
  return Object.entries(GATEWAY_RUNTIME_JOB_DEFINITIONS).map(([name, definition]) => ({
    name,
    description: definition.description
  }));
}
function getGatewayRuntimeJobDefinition(jobName) {
  return GATEWAY_RUNTIME_JOB_DEFINITIONS[jobName] || null;
}
async function runGatewayRuntimeJob(jobName) {
  const definition = getGatewayRuntimeJobDefinition(jobName);
  if (!definition) {
    throw new Error(`Unknown gateway runtime job: ${jobName}`);
  }
  return definition.run();
}

// server/routes_wa_gateway_internal.ts
var DEFAULT_INTERNAL_TOKEN2 = "agentezap-internal-wa-gateway";
function getInternalToken2() {
  return (process.env.WA_GATEWAY_INTERNAL_TOKEN || DEFAULT_INTERNAL_TOKEN2).trim();
}
function isAuthorized(req) {
  return String(req.header("x-wa-gateway-token") || "").trim() === getInternalToken2();
}
function parseSendSource2(source) {
  const value = String(source || "").trim();
  if (value === "owner" || value === "agent" || value === "followup" || value === "system") {
    return value;
  }
  return void 0;
}
async function resolveOwnedConnection(connectionId) {
  const connection = await storage.getConnectionById(connectionId);
  if (!connection) {
    const error = new Error("Instancia nao encontrada");
    error.status = 404;
    throw error;
  }
  const owned = await isConnectionOwnedByCurrentProcess(connection);
  if (!owned) {
    const error = new Error("Instancia nao pertence a este gateway");
    error.status = 404;
    throw error;
  }
  return connection;
}
async function withGatewayConnection2(req, res, handler) {
  try {
    if (!isAuthorized(req)) {
      return res.status(401).json({ message: "Unauthorized gateway request" });
    }
    const connection = await resolveOwnedConnection(String(req.params.instanceId || ""));
    await handler(connection);
  } catch (error) {
    const status = Number(error?.status) || 500;
    const message = error?.message || "Erro interno no gateway";
    res.status(status).json({ message });
  }
}
function requireGatewayAuthorization(req, res) {
  if (isAuthorized(req)) {
    return true;
  }
  res.status(401).json({ message: "Unauthorized gateway request" });
  return false;
}
function registerWhatsAppGatewayInternalRoutes(app) {
  app.get("/health", (_req, res) => {
    res.json({ status: "ok", mode: "wa-gateway" });
  });
  app.get("/internal/runtime/jobs", async (req, res) => {
    if (!requireGatewayAuthorization(req, res)) {
      return;
    }
    res.json({
      success: true,
      jobs: listGatewayRuntimeJobs()
    });
  });
  app.post("/internal/runtime/jobs/:jobName/run", async (req, res) => {
    if (!requireGatewayAuthorization(req, res)) {
      return;
    }
    const jobName = String(req.params.jobName || "").trim();
    const definition = getGatewayRuntimeJobDefinition(jobName);
    if (!definition) {
      return res.status(404).json({
        success: false,
        message: `Unknown gateway runtime job: ${jobName}`
      });
    }
    const startedAt = Date.now();
    try {
      const result = await runGatewayRuntimeJob(jobName);
      return res.json({
        success: true,
        job: jobName,
        durationMs: Date.now() - startedAt,
        ...result
      });
    } catch (error) {
      console.error(`[WA GATEWAY] Runtime job failed job=${jobName}:`, error);
      return res.status(500).json({
        success: false,
        job: jobName,
        message: error?.message || "Failed to run gateway runtime job"
      });
    }
  });
  app.post("/internal/instances/status/bulk", async (req, res) => {
    try {
      if (!isAuthorized(req)) {
        return res.status(401).json({ message: "Unauthorized gateway request" });
      }
      const requestedIds = Array.from(
        new Set(
          (Array.isArray(req.body?.instanceIds) ? req.body.instanceIds : []).map((value) => String(value || "").trim()).filter(Boolean)
        )
      );
      if (requestedIds.length === 0) {
        return res.json({ items: [] });
      }
      const requestedSet = new Set(requestedIds);
      const allConnections = await storage.getAllConnections();
      const ownedConnections = [];
      for (const connection of allConnections) {
        if (!requestedSet.has(connection.id)) {
          continue;
        }
        if (!await isConnectionOwnedByCurrentProcess(connection)) {
          continue;
        }
        ownedConnections.push(connection);
      }
      const items = await Promise.all(
        ownedConnections.map(async (connection) => buildLocalInstanceStatus(connection))
      );
      res.json({ items });
    } catch (error) {
      const status = Number(error?.status) || 500;
      const message = error?.message || "Erro interno no gateway";
      res.status(status).json({ message });
    }
  });
  app.get("/internal/instances/:instanceId/status", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      res.json(await buildLocalInstanceStatus(connection));
    });
  });
  app.get("/internal/instances/:instanceId/device", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      res.json(await buildLocalInstanceDevice(connection));
    });
  });
  app.post("/internal/instances/:instanceId/connect", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      connectWhatsApp(connection.userId, connection.id).catch((error) => {
        console.error("[WA GATEWAY] Failed to connect instance:", error);
      });
      res.json({ success: true, instanceId: connection.id, status: "connecting" });
    });
  });
  app.post("/internal/instances/:instanceId/disconnect", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      await disconnectWhatsApp(connection.userId, connection.id);
      res.json({ success: true, instanceId: connection.id });
    });
  });
  app.post("/internal/instances/:instanceId/reset", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      const body = req.body && typeof req.body === "object" ? req.body : {};
      await forceResetWhatsApp(connection.userId, connection.id, {
        source: typeof body.source === "string" && body.source.trim() ? body.source.trim() : "wa_gateway_internal_reset"
      });
      res.json({ success: true, instanceId: connection.id });
    });
  });
  app.get("/internal/instances/:instanceId/conversations", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      res.json(await listInstanceConversations(connection.id));
    });
  });
  app.get("/internal/instances/:instanceId/conversations/:conversationId/messages", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      res.json(await listInstanceMessages(connection.id, String(req.params.conversationId || "")));
    });
  });
  app.post("/internal/instances/:instanceId/conversations/:conversationId/group-history-sync", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      res.json(
        await syncInstanceGroupHistory(
          connection.id,
          String(req.params.conversationId || "")
        )
      );
    });
  });
  app.get("/internal/instances/:instanceId/contacts", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      res.json(await listInstanceContacts(connection.id));
    });
  });
  app.get("/internal/instances/:instanceId/groups", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      const groups = await listInstanceGroups(connection);
      res.json(Array.isArray(groups) ? groups : []);
    });
  });
  app.get("/internal/instances/:instanceId/status-posts/preview-audience", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      res.json(
        await previewStatusAudienceForUser(connection.userId, connection.id)
      );
    });
  });
  app.post("/internal/instances/:instanceId/status-posts/send", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      const body = req.body || {};
      res.json(
        await sendStatusPostForUser(connection.userId, body, {
          preferredConnectionId: connection.id
        })
      );
    });
  });
  app.post("/internal/instances/:instanceId/messages/send", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendTextDirectViaInstance({
            connection,
            text: String(body.text || "").trim(),
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendTextViaInstance({
          connection,
          text: String(body.text || "").trim(),
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true,
          isFromAgent: body.isFromAgent === true,
          source: parseSendSource2(body.source),
          acceptQueued: body.acceptQueued === true
        })
      );
    });
  });
  app.post("/internal/instances/:instanceId/messages/send-media", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      const body = req.body || {};
      if (body.directByNumber === true) {
        return res.json(
          await sendMediaDirectViaInstance({
            connection,
            type: body.type,
            data: body.data,
            mimetype: body.mimetype,
            filename: body.filename,
            caption: body.caption,
            ptt: body.ptt,
            seconds: body.seconds,
            to: body.to || void 0,
            contactName: body.contactName || void 0,
            validateDestination: body.validateDestination === true
          })
        );
      }
      res.json(
        await sendMediaViaInstance({
          connection,
          type: body.type,
          data: body.data,
          mimetype: body.mimetype,
          filename: body.filename,
          caption: body.caption,
          ptt: body.ptt,
          seconds: body.seconds,
          conversationId: body.conversationId || void 0,
          to: body.to || void 0,
          contactName: body.contactName || void 0,
          validateDestination: body.validateDestination === true,
          isFromAgent: typeof body.isFromAgent === "boolean" ? body.isFromAgent : void 0,
          source: parseSendSource2(body.source),
          acceptQueued: body.acceptQueued === true
        })
      );
    });
  });
  app.post("/internal/instances/:instanceId/groups/send-bulk", async (req, res) => {
    await withGatewayConnection2(req, res, async (connection) => {
      const body = req.body || {};
      const groupIds = Array.isArray(body.groupIds) ? body.groupIds.map((value) => String(value || "").trim()).filter(Boolean) : [];
      const message = String(body.message || "").trim();
      if (groupIds.length === 0) {
        return res.status(400).json({ message: "Lista de grupos \xE9 obrigat\xF3ria" });
      }
      if (!message) {
        return res.status(400).json({ message: "Mensagem \xE9 obrigat\xF3ria" });
      }
      res.json(
        await sendGroupBulkViaInstance({
          connection,
          groupIds,
          message,
          settings: body && typeof body === "object" && body.settings && typeof body.settings === "object" ? body.settings : null
        })
      );
    });
  });
}

// server/wa-gateway.ts
async function startWhatsAppGateway() {
  const app = express();
  app.use(cors({ origin: true, credentials: false }));
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: false }));
  registerWhatsAppGatewayInternalRoutes(app);
  registerGatewayPublicApiRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
  });
  const port = parseInt(process.env.PORT || "5001", 10);
  const server = app.listen(port, "0.0.0.0", async () => {
    console.log(`[WA GATEWAY] Listening on port ${port}`);
    console.log(
      `[WA GATEWAY] Runtime version ${process.env.PWA_VERSION || process.env.VITE_PWA_VERSION || "unknown"}`
    );
    await ensureWhatsAppRuntimeSchema();
    const disableBackgroundJobs = process.env.DISABLE_WHATSAPP_PROCESSING === "true";
    if (!disableBackgroundJobs) {
      try {
        await restoreWhatsAppSessionSnapshotsFromStorage({
          includeAdmins: false,
          missingOnly: true,
          reason: "gateway-boot"
        });
      } catch (error) {
        console.error("[WA GATEWAY] Failed to restore session snapshots:", error);
      }
      try {
        console.log("[WA GATEWAY] Starting blocking restore of customer sessions before jobs...");
        await restoreExistingSessions();
        console.log("[WA GATEWAY] Initial customer session restore finished.");
      } catch (error) {
        console.error("[WA GATEWAY] Failed to restore sessions:", error);
      }
      startConnectionHealthCheck();
      try {
        await restorePendingAITimers();
      } catch (error) {
        console.error("[WA GATEWAY] Failed to restore pending AI timers:", error);
      }
      startPendingTimersCron();
      startAutoRecoveryCron();
      startWhatsAppSessionSnapshotCron(false);
    }
    if (typeof process.send === "function") {
      process.send("ready");
    }
  });
  let shuttingDown = false;
  const gracefulShutdown = async (signal) => {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`[WA GATEWAY] Graceful shutdown via ${signal}`);
    try {
      stopConnectionHealthCheck();
      stopPendingTimersCron();
      stopAutoRecoveryCron();
      stopWhatsAppSessionSnapshotCron();
      server.close();
      await closeAllSessions();
      await flushPendingWhatsAppSessionSnapshots();
      await syncAllWhatsAppSessionSnapshots({
        includeAdmins: false,
        reason: `gateway-shutdown:${signal}`
      });
      await closeDbPool();
    } catch (error) {
      console.error("[WA GATEWAY] Graceful shutdown error:", error);
    }
    process.exit(0);
  };
  process.on("SIGTERM", () => void gracefulShutdown("SIGTERM"));
  process.on("SIGINT", () => void gracefulShutdown("SIGINT"));
  process.on("message", (message) => {
    if (message === "shutdown") {
      void gracefulShutdown("PM2_SHUTDOWN_MESSAGE");
    }
  });
}
export {
  startWhatsAppGateway
};
