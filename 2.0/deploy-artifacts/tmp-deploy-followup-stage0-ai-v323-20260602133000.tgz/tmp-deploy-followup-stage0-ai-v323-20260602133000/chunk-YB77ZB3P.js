import {
  systemConfig
} from "./chunk-JC6URYU5.js";

// server/phoneMatch.ts
function extractDigits(value) {
  const source = String(value || "");
  let digits = "";
  for (const char of source) {
    if (char >= "0" && char <= "9") {
      digits += char;
    }
  }
  return digits;
}
function addKey(target, candidate) {
  if (!candidate) return;
  if (candidate.length < 8) return;
  target.add(candidate);
}
function removeBrazilMobileNine(number) {
  if (number.length !== 11) return null;
  if (number[2] !== "9") return null;
  return `${number.slice(0, 2)}${number.slice(3)}`;
}
function addBrazilMobileNine(number) {
  if (number.length !== 10) return null;
  return `${number.slice(0, 2)}9${number.slice(2)}`;
}
function normalizePhoneForComparison(phoneNumber) {
  const digits = extractDigits(phoneNumber);
  if (!digits) return [];
  const keys = /* @__PURE__ */ new Set();
  addKey(keys, digits);
  for (const size of [11, 10, 9, 8]) {
    if (digits.length >= size) {
      addKey(keys, digits.slice(-size));
    }
  }
  const last11 = digits.length >= 11 ? digits.slice(-11) : "";
  const last10 = digits.length >= 10 ? digits.slice(-10) : "";
  addKey(keys, removeBrazilMobileNine(last11));
  addKey(keys, addBrazilMobileNine(last10));
  if (last11.length === 11) {
    addKey(keys, last11.slice(2));
    addKey(keys, last11.slice(-8));
    const withoutMobileNine = removeBrazilMobileNine(last11);
    if (withoutMobileNine) {
      addKey(keys, withoutMobileNine);
      addKey(keys, withoutMobileNine.slice(2));
      addKey(keys, withoutMobileNine.slice(-8));
    }
  }
  if (last10.length === 10) {
    addKey(keys, last10.slice(2));
    addKey(keys, last10.slice(-8));
    const withMobileNine = addBrazilMobileNine(last10);
    if (withMobileNine) {
      addKey(keys, withMobileNine);
      addKey(keys, withMobileNine.slice(2));
      addKey(keys, withMobileNine.slice(-8));
    }
  }
  return [...keys];
}
function phoneNumbersMatch(left, right) {
  const leftKeys = normalizePhoneForComparison(left);
  const rightKeys = new Set(normalizePhoneForComparison(right));
  return leftKeys.some((key) => rightKeys.has(key));
}
function normalizePhoneToDigits(phoneNumber) {
  return extractDigits(phoneNumber);
}

// server/whatsappPhoneNumber.ts
function digitsOnly(value) {
  return String(value ?? "").split(":")[0].replace(/\D/g, "");
}
function normalizeBrazilWhatsAppPhone(value) {
  const digits = digitsOnly(value);
  if (!digits) return null;
  if (digits.startsWith("55") && (digits.length === 12 || digits.length === 13)) {
    return digits;
  }
  if (digits.length === 10 || digits.length === 11) {
    return `55${digits}`;
  }
  return digits.length >= 8 ? digits : null;
}
function buildBrazilWhatsAppPhoneVariants(value) {
  const normalized = normalizeBrazilWhatsAppPhone(value);
  if (!normalized) return [];
  const variants = /* @__PURE__ */ new Set();
  variants.add(normalized);
  const nationalNumber = normalized.startsWith("55") ? normalized.slice(2) : normalized;
  if (nationalNumber) {
    variants.add(nationalNumber);
  }
  if (nationalNumber.length === 11 && nationalNumber[2] === "9") {
    const withoutMobileNine = `${nationalNumber.slice(0, 2)}${nationalNumber.slice(3)}`;
    variants.add(withoutMobileNine);
    variants.add(`55${withoutMobileNine}`);
  }
  if (nationalNumber.length === 10) {
    const withMobileNine = `${nationalNumber.slice(0, 2)}9${nationalNumber.slice(2)}`;
    variants.add(withMobileNine);
    variants.add(`55${withMobileNine}`);
  }
  return Array.from(variants).filter(Boolean);
}
function buildWhatsAppJidFromPhone(value, suffix = "s.whatsapp.net") {
  const normalized = normalizeBrazilWhatsAppPhone(value);
  if (!normalized) return null;
  return `${normalized}@${suffix}`;
}

// server/mauricioMfcCatalogModule.ts
var MAURICIO_MFC_USER_ID = "a7f1edc1-ae45-45a5-b382-2a1024507355";
var MAURICIO_MFC_EMAIL = "mauriciogomes2650@gmail.com";
var MAURICIO_MFC_READY_50X50_PROMO_LINK = "https://photos.app.goo.gl/sXa7C9AX1BHctpsP7";
function getMauricioMfcReady50x50PromoPriceDescription() {
  return [
    "1 unidade R$ 15,00",
    "3 unidades R$ 12,00 cada",
    "5 unidades R$ 10,00 cada",
    "acima de 10 unidades R$ 8,00 cada a vista",
    "no cartao acrescimo de R$ 1,00 por unidade"
  ].join("; ");
}
function normalizeMauricioMfcCatalogText(value) {
  return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
}
function isMauricioMfcCatalogTenant(params) {
  const userId = String(params.userId || "").trim();
  const userEmail = String(params.userEmail || "").trim().toLowerCase();
  return userId === MAURICIO_MFC_USER_ID || userEmail === MAURICIO_MFC_EMAIL;
}
function buildEntryText(entry) {
  return [
    entry.productName,
    entry.productCategory,
    entry.productDescription,
    entry.variationName,
    entry.variationCaption
  ].filter(Boolean).join(" ");
}
function inferMauricioMfcCatalogItemKind(entry) {
  const normalized = normalizeMauricioMfcCatalogText(buildEntryText(entry));
  if (!normalized) {
    return null;
  }
  if (/\b(lateral|painel lateral)\b/.test(normalized)) {
    return "lateral";
  }
  if (/\b(cilindro|cilindros|capa de cilindro|capa)\b/.test(normalized)) {
    return "cilindro";
  }
  if (/\b(redondo|painel redondo|50x50|1,50x1,50|150x150)\b/.test(normalized) || /\bpain(?:el|eis|eis)\b.{0,30}\b50\b/.test(normalized) || /\b50\b.{0,30}\bpain(?:el|eis|eis)\b/.test(normalized)) {
    return "redondo";
  }
  return null;
}
function inferMauricioMfcContextItemKind(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized) {
    return null;
  }
  if (/\b(lateral|painel lateral)\b/.test(normalized)) {
    return "lateral";
  }
  if (/\b(cilindro|cilindros|capa de cilindro|capa)\b/.test(normalized)) {
    return "cilindro";
  }
  if (/\b(redondo|painel redondo|50x50|1,50x1,50|150x150)\b/.test(normalized) || /\bpain(?:el|eis|eis)\b.{0,30}\b50\b/.test(normalized) || /\b50\b.{0,30}\bpain(?:el|eis|eis)\b/.test(normalized)) {
    return "redondo";
  }
  return null;
}
function inferMauricioMfcSpecificCatalogItemKind(entry) {
  const normalized = normalizeMauricioMfcCatalogText([
    entry.productName,
    entry.productCategory,
    entry.variationName,
    entry.variationCaption
  ].filter(Boolean).join(" "));
  if (!normalized) {
    return null;
  }
  if (/\b(lateral|painel lateral)\b/.test(normalized)) {
    return "lateral";
  }
  if (/\b(cilindro|cilindros|capa de cilindro|capa)\b/.test(normalized)) {
    return "cilindro";
  }
  if (/\b(redondo|painel redondo|50x50|1,50x1,50|150x150)\b/.test(normalized)) {
    return "redondo";
  }
  return null;
}
function resolveMauricioMfcRequestedLineKind(value) {
  return inferMauricioMfcContextItemKind(value);
}
function mauricioMfcCatalogEntryMatchesLineKind(entry, lineKind) {
  if (!lineKind) {
    return true;
  }
  return inferMauricioMfcSpecificCatalogItemKind(entry) === lineKind;
}
function isMauricioMfcGenericArtCatalogEntry(entry) {
  const normalized = normalizeMauricioMfcCatalogText([
    entry.productName,
    entry.productCategory,
    entry.variationName,
    entry.variationCaption
  ].filter(Boolean).join(" "));
  if (!normalized) {
    return false;
  }
  const isCatalogArtReference = /\bcatalogo\b/.test(normalized) && /\b(?:foto|fotos|arte|artes)\b/.test(normalized);
  const alreadySpecificKind = /\b(lateral|cilindro|cilindros|redondo|painel redondo|painel lateral)\b/.test(normalized);
  return isCatalogArtReference && !alreadySpecificKind;
}
function extractMauricioMfcAcabamento(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized) {
    return null;
  }
  if (/\bsem[- ]?costura\b/.test(normalized)) {
    return "sem_costura";
  }
  if (/\b(costurado|costurada|com costura)\b/.test(normalized)) {
    return "costurado";
  }
  return null;
}
function extractMauricioMfcRedondoSize(value) {
  const normalized = normalizeMauricioMfcCatalogText(value).replace(/\s+/g, "");
  if (!normalized) {
    return null;
  }
  if (/50x50/.test(normalized)) {
    return "50x50";
  }
  if (/(1,?50x1,?50|150x150)/.test(normalized)) {
    return "1,50x1,50";
  }
  return null;
}
function formatMauricioMfcCurrency(value) {
  return `R$ ${value.toFixed(2).replace(".", ",")}`;
}
function parseMauricioMfcCurrencyNumber(value) {
  const match = String(value || "").match(/(\d{1,6}(?:[,.]\d{1,2})?)/);
  if (!match?.[1]) return null;
  const raw = match[1];
  const normalized = raw.includes(",") ? raw.replace(/\./g, "").replace(",", ".") : /\.\d{1,2}$/.test(raw) ? raw : raw.replace(/\./g, "");
  const parsed = Number(normalized);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}
function extractMauricioMfcQuantity(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized) return null;
  if (/^\d{1,3}$/.test(normalized)) {
    const parsed = Number(normalized);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }
  const explicit = normalized.match(/\b(?:quantidade|qtd|qtde)\s*:?\s*(\d{1,3})\b/);
  if (explicit?.[1]) {
    const parsed = Number(explicit[1]);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }
  const units = normalized.match(/\b(\d{1,3})\s*(?:unidade|unidades|und|un|peca|pecas|p[ée]ca|p[ée]cas)\b/);
  if (units?.[1]) {
    const parsed = Number(units[1]);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  }
  if (/\b(?:uma|um)\s+de\s+cada\b/.test(normalized)) {
    return 1;
  }
  return null;
}
function readMauricioMfcCartField(block, labelPattern) {
  const fieldNames = [
    "Produto",
    "C[o\xF3]digo",
    "Codigo",
    "Cod",
    "Tamanho",
    "Acabamento",
    "Quantidade",
    "Valor(?:\\s+unit[a\xE1]rio)?",
    "Subtotal",
    "Falta",
    "Total dos itens"
  ].join("|");
  const match = new RegExp(
    `\\b(?:${labelPattern})\\s*:?\\s*([\\s\\S]*?)(?=(?:\\n|\\s+-\\s+)\\s*(?:${fieldNames})\\s*:|(?:\\n|\\s+-\\s+)\\s*(?:\\d+\\.\\s*)?Item\\s+\\d+\\b|$)`,
    "i"
  ).exec(block);
  const text = match?.[1]?.replace(/\*/g, "").replace(/\s+/g, " ").replace(/\s+-\s*$/g, "").trim();
  return text || null;
}
function extractMauricioMfcPriorCartItems(value, options = {}) {
  const limit = Math.max(1, Math.min(10, Number(options.limit || 10)));
  const source = String(value || "").replace(/\r/g, "\n").replace(/\*\*/g, "").replace(/\s+(\d+\.\s*Item\s+\d+\s+-)/gi, "\n$1").replace(/\n{2,}/g, "\n");
  const blocks = source.split(/(?=(?:^|\n)\s*(?:\d+\.\s*)?Item\s+\d+\b)/i).map((part) => part.trim()).filter((part) => /\bItem\s+\d+\b/i.test(part));
  const items = [];
  for (const block of blocks) {
    const codeRaw = readMauricioMfcCartField(block, "C[o\xF3]digo|Codigo|Cod");
    const code = Number(String(codeRaw || "").match(/\d+/)?.[0]);
    if (!Number.isInteger(code) || code <= 0) continue;
    const product = readMauricioMfcCartField(block, "Produto") || `Codigo ${code}`;
    const tamanho = readMauricioMfcCartField(block, "Tamanho");
    const acabamento = readMauricioMfcCartField(block, "Acabamento");
    const quantidadeRaw = readMauricioMfcCartField(block, "Quantidade");
    const quantidadeMatch = String(quantidadeRaw || "").match(/\d{1,3}/);
    const quantidade = quantidadeMatch ? String(Number(quantidadeMatch[0])) : null;
    const unitPrice = parseMauricioMfcCurrencyNumber(
      readMauricioMfcCartField(block, "Valor(?:\\s+unit[a\xE1]rio)?")
    );
    const subtotal = parseMauricioMfcCurrencyNumber(readMauricioMfcCartField(block, "Subtotal")) ?? (unitPrice != null && quantidade ? unitPrice * Number(quantidade) : null);
    if (!quantidade || unitPrice == null) continue;
    items.push({
      code,
      product,
      tamanho,
      acabamento,
      quantidade,
      unitPrice,
      subtotal
    });
    if (items.length >= limit) break;
  }
  return items;
}
function looksLikeMauricioMfcCartResetIntent(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized) return false;
  return /\b(?:limpa|limpar|apaga|apagar|zera|zerar|novo pedido|outro pedido|troca tudo|trocar tudo|substitui|substituir|esquece o carrinho|cancela o carrinho)\b/.test(normalized);
}
function getMauricioMfcPrice(params) {
  if (params.kind === "lateral") {
    return params.acabamento === "sem_costura" ? 65 : 70;
  }
  if (params.kind === "cilindro") {
    return params.acabamento === "sem_costura" ? 80 : 100;
  }
  if (params.kind === "redondo") {
    if (params.tamanho === "50x50") {
      if (params.acabamento === "sem_costura") {
        return 15;
      }
      const quantidade = Number(params.quantidade || 0);
      if (quantidade >= 10) return 8;
      if (quantidade >= 5) return 10;
      if (quantidade >= 3) return 12;
      return 15;
    }
    if (params.tamanho === "1,50x1,50") {
      return params.acabamento === "sem_costura" ? 55 : 60;
    }
  }
  return null;
}
function looksLikeMauricioMfcReady50x50PromoRequest(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized) return false;
  const mentionsPanel = /\b(?:painel|paineis|pain[eé]is)\b/.test(normalized);
  const mentions50x50 = /\b50\s*x\s*50\b/.test(normalized) || /\b50x50\b/.test(normalized) || /\bpain(?:el|eis|eis)\b.{0,30}\b50\b/.test(normalized) || /\b50\b.{0,30}\bpain(?:el|eis|eis)\b/.test(normalized);
  if (!mentionsPanel || !mentions50x50) return false;
  const asksInfoOrPromo = /\b(?:promocao|promo|promocional|pronto|prontos|prontinho|prontinhos|costurado|costurados|tem|temos|quais|qual|preco|precos|valor|valores|link|foto|fotos|tema|temas|catalogo|opcoes|opcao)\b/.test(normalized);
  const asksToMakePanel50 = /\b(?:quero|preciso|vou|fazer|faz|montar|manda|mostra|envia)\b/.test(normalized);
  if (!asksInfoOrPromo && !asksToMakePanel50) return false;
  return !/\b(?:codigo|cod|item|itens|escolhi|vou querer|quero esse|quero essa|separe|separa|fechar|finalizar|pix|pagar|pagamento)\b/.test(normalized);
}
function shouldIncludeMauricioMfcReady50x50Promo(entry) {
  if (!isMauricioMfcCatalogTenant(entry)) {
    return false;
  }
  if (entry.includeReady50x50Promo === true) {
    return true;
  }
  return looksLikeMauricioMfcReady50x50PromoRequest(entry.contextText);
}
function containsMauricioMfcReady50x50PromoText(value) {
  const raw = String(value || "");
  if (!raw.trim()) {
    return false;
  }
  if (raw.includes(MAURICIO_MFC_READY_50X50_PROMO_LINK)) {
    return true;
  }
  const normalized = normalizeMauricioMfcCatalogText(raw);
  return /\b50\s*x\s*50\b.{0,120}\b(?:promocao|promo|promocional|pronto|prontos)\b/.test(normalized) || /\b(?:promocao|promo|promocional|pronto|prontos)\b.{0,120}\b50\s*x\s*50\b/.test(normalized) || /\b3\s+unidades\b.{0,40}\br\$\s*12/.test(normalized) || /\b5\s+unidades\b.{0,40}\br\$\s*10/.test(normalized);
}
function buildMauricioMfcReady50x50PromoReply() {
  return [
    "Temos paineis 50x50 costurados prontos para uso nessa promocao:",
    "1 unidade R$ 15,00",
    "3 unidades R$ 12,00 cada",
    "5 unidades R$ 10,00 cada",
    "Acima de 10 unidades R$ 8,00 cada a vista",
    "No cartao tem acrescimo de R$ 1,00 por unidade.",
    `Fotos e temas: ${MAURICIO_MFC_READY_50X50_PROMO_LINK}`,
    "Tambem posso te enviar as fotos de um tema especifico, como Lilo/Stitch, Girassol, Galaxia, Hulk, Baby Shark, Tres Palavrinhas ou Super Mario."
  ].join("\n");
}
function getMauricioMfcCatalogPriceDescription(entry) {
  if (!isMauricioMfcCatalogTenant(entry)) {
    return null;
  }
  const inferredKind = inferMauricioMfcCatalogItemKind(entry);
  const contextKind = isMauricioMfcGenericArtCatalogEntry(entry) ? inferMauricioMfcContextItemKind(entry.contextText) : null;
  const kind = contextKind || inferredKind;
  if (kind === "lateral") {
    return `costurado ${formatMauricioMfcCurrency(70)}; sem costura ${formatMauricioMfcCurrency(65)}`;
  }
  if (kind === "cilindro") {
    return `costurado ${formatMauricioMfcCurrency(100)}; sem costura ${formatMauricioMfcCurrency(80)}`;
  }
  if (kind === "redondo") {
    const redondoPrices = [
      shouldIncludeMauricioMfcReady50x50Promo(entry) ? `50x50 costurado promocional: ${getMauricioMfcReady50x50PromoPriceDescription()}` : `50x50 costurado ${formatMauricioMfcCurrency(15)}`,
      `50x50 sem costura ${formatMauricioMfcCurrency(15)}`,
      `1,50x1,50 costurado ${formatMauricioMfcCurrency(60)}`,
      `1,50x1,50 sem costura ${formatMauricioMfcCurrency(55)}`
    ];
    return redondoPrices.join("; ");
  }
  return null;
}
function buildMauricioMfcCatalogCaptionPriceLine(entry) {
  const description = getMauricioMfcCatalogPriceDescription(entry);
  return description ? `Valores: ${description}.` : null;
}
function resolveMauricioMfcCatalogUnitPrice(entry) {
  const kind = isMauricioMfcCatalogTenant(entry) ? inferMauricioMfcCatalogItemKind(entry) : null;
  const context = [
    entry.details?.acabamento,
    entry.details?.tamanho,
    entry.contextText,
    entry.variationCaption,
    entry.productDescription
  ].filter(Boolean).join(" ");
  const acabamento = extractMauricioMfcAcabamento(entry.details?.acabamento || context);
  const tamanho = extractMauricioMfcRedondoSize(entry.details?.tamanho || context);
  const quantidade = extractMauricioMfcQuantity(entry.details?.quantidade || context);
  const description = getMauricioMfcCatalogPriceDescription(entry);
  if (!kind || !acabamento) {
    return {
      price: null,
      kind,
      acabamento,
      tamanho,
      description
    };
  }
  return {
    price: getMauricioMfcPrice({ kind, acabamento, tamanho, quantidade }),
    kind,
    acabamento,
    tamanho,
    description
  };
}
function looksLikeMauricioMfcCatalogThemeContinuation(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized) return false;
  const hasContinuationSignal = /^(?:e|mais|tambem|tbm)\b/.test(normalized) || /\b(?:tambem|tbm|mais um|mais uma|outro tema|outra tema|outro modelo|outra arte)\b/.test(normalized);
  if (!hasContinuationSignal) return false;
  return /\b(lilo|sthic|stich|stitch|chito|hulk|girassol|galaxia|galaxy|baby shark|shark|mario|super mario|tres palavrinhas|3 palavrinhas|abelhinha)\b/.test(normalized);
}
function looksLikeMauricioMfcPixNegation(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized || !/\b(pix|pagar|pagamento|fechar|finalizar)\b/.test(normalized)) return false;
  return /\bnao\b.{0,40}\b(?:manda|mande|mandar|envia|envie|enviar|passa|passe)\b.{0,40}\bpix\b/.test(normalized) || /\bpix\b.{0,40}\b(?:nao|ainda nao|agora nao|depois|mais tarde)\b/.test(normalized) || /\b(?:sem|nao)\s+pix\b/.test(normalized) || /\bnao\b.{0,40}\b(?:vou|quero|posso)\b.{0,40}\b(?:pagar|fechar|finalizar)\b/.test(normalized) || /\bainda\s+nao\b.{0,40}\b(?:pagar|fechar|finalizar|pix)\b/.test(normalized);
}
function looksLikeMauricioMfcPixPaymentRequest(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized || looksLikeMauricioMfcPixNegation(value)) return false;
  return /\b(?:pix|chave pix|qr code|qrcode|qr pix)\b/.test(normalized) || /\b(?:pode|quero|vou|vamos)\b.{0,40}\b(?:fechar|finalizar|pagar)\b/.test(normalized) || /\b(?:fechar|finalizar|pagar)\b.{0,40}\b(?:pix|pedido|compra)\b/.test(normalized);
}
function looksLikeMauricioMfcAddressRequest(value) {
  const normalized = normalizeMauricioMfcCatalogText(value);
  if (!normalized) return false;
  return /\b(?:endereco|localizacao|loja|retirada|retirar|como chegar|onde fica|fachada|entrada da loja|ponto de referencia)\b/.test(normalized);
}
function buildMauricioMfcDedicatedAddressReply() {
  return [
    "Claro. O endereco da loja e Estrada da Liberdade, 320, bairro Liberdade, Salvador.",
    "Referencia: em frente ao Magazine Luiza e ao lado da Biju Glamour.",
    "Atendimento da loja: segunda a sabado, das 8h as 17h."
  ].join("\n");
}
function buildMauricioMfcCatalogPromptBlock(params) {
  if (!isMauricioMfcCatalogTenant(params)) {
    return "";
  }
  return `
**CALIBRACAO MFC 50X50 PROMO 2026-05-29:**
- Nao monte carrinho so porque o cliente pediu fotos, valores, promocao ou opcoes. Carrinho comeca quando ele escolher codigos, imagens ou itens.
- Se o cliente pedir painel 50x50, painel de 50, painel pronto, promocao ou link das fotos, informe a promocao dos paineis 50x50 costurados prontos e envie o link ${MAURICIO_MFC_READY_50X50_PROMO_LINK}.
- Promocao painel 50x50 costurado pronto: ${getMauricioMfcReady50x50PromoPriceDescription()}.
- Lilo, Stitch, Stich, Sthic e Chito sao o mesmo tema Lilo/Stitch. Se o cliente pedir Chito ou Stitch, envie o tema Lilo/Stitch.

**REGRAS DO CAT\xC1LOGO MFC SUBLIMA\xC7\xC3O:**
- Quando o cliente pedir um ou mais temas, responda naturalmente e envie todas as fotos cadastradas de cada tema pedido. N\xE3o diga que recebeu fotos se foi o agente que enviou.
- Depois de enviar fotos de tema, pe\xE7a para o cliente informar o c\xF3digo, nome da arte ou reenviar a foto escolhida, junto com acabamento, tamanho quando houver e quantidade.
- N\xE3o monte carrinho s\xF3 porque o cliente pediu para ver fotos. Carrinho come\xE7a quando ele escolher c\xF3digos, imagens ou itens.
- Painel lateral e cilindros precisam de acabamento e quantidade. N\xE3o precisam de tamanho.
- Painel redondo precisa de tamanho, acabamento e quantidade.
- Tabela MFC: painel lateral costurado R$ 70,00 e sem costura R$ 65,00.
- Tabela MFC: cilindro/capa de cilindro costurado R$ 100,00 e sem costura R$ 80,00.
- Tabela MFC: painel redondo 50x50 costurado segue a promocao acima; painel redondo 50x50 sem costura R$ 15,00.
- Tabela MFC: painel redondo 1,50x1,50 costurado R$ 60,00 e sem costura R$ 55,00.
- Se o cliente informar sem costura, use sempre o valor sem costura da tabela MFC, mesmo que a foto tenha um valor base cadastrado.
- S\xF3 envie Pix, QR Code ou formas de pagamento depois que os itens estiverem completos e o cliente escolher ou pedir pagamento.
- S\xF3 envie endere\xE7o ou foto da loja quando o cliente pedir endere\xE7o, localiza\xE7\xE3o, loja, retirada ou como chegar.
- O atendimento da loja e de segunda a sabado, das 08h as 17h. Domingo e fechado. Nao informe retorno apenas na segunda quando o proximo dia de atendimento for sabado.
- Orientacao sobre arte personalizada/designer so entra quando o cliente escolher "catalogo de fotos de artes" ou pedir arte personalizada. Se o cliente escolheu painel, cilindro ou item por codigo/foto, trate como produto do pedido e monte carrinho, nao como pedido de arte.
`;
}

// server/metaConversionsApi.ts
import crypto from "crypto";
import { eq, sql } from "drizzle-orm";
var DEFAULT_GRAPH_VERSION = String(process.env.META_CAPI_GRAPH_VERSION || "v25.0").trim() || "v25.0";
var DEFAULT_EVENT_NAME = String(process.env.META_CAPI_WHATSAPP_EVENT_NAME || "Contact").trim() || "Contact";
var DEFAULT_PAID_EVENT_NAME = String(process.env.META_CAPI_WHATSAPP_PAID_EVENT_NAME || "Purchase").trim() || "Purchase";
var DEFAULT_PAID_ACTION_SOURCE = String(process.env.META_CAPI_WHATSAPP_ACTION_SOURCE || "business_messaging").trim() || "business_messaging";
var DEFAULT_WHATSAPP_MESSAGING_CHANNEL = String(process.env.META_CAPI_WHATSAPP_MESSAGING_CHANNEL || "whatsapp").trim() || "whatsapp";
var RODRIGO_META_CAPI_CONFIG_KEY = "meta_capi_rodrigo_whatsapp_config";
var RODRIGO_META_CAPI_ACCESS_TOKEN_SECRET = "meta_capi_rodrigo_access_token";
var META_CAPI_CONFIG_CACHE_MS = 6e4;
var runtimeConfigCache = /* @__PURE__ */ new Map();
function normalizeDigits(value) {
  return String(value || "").replace(/\D+/g, "");
}
function normalizeText(value) {
  return String(value || "").trim().toLowerCase();
}
function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}
function cleanPlainField(value, maxLength = 512) {
  const text = String(value ?? "").trim();
  if (!text) return "";
  return text.length > maxLength ? text.slice(0, maxLength) : text;
}
function parseConfigJson(rawValue) {
  const raw = String(rawValue || "").trim();
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    console.warn("[Meta CAPI] Configuracao Supabase ignorada: JSON invalido.");
    return {};
  }
}
function configString(config, keys, fallback = "", maxLength = 1024) {
  for (const key of keys) {
    const value = cleanPlainField(config[key], maxLength);
    if (value) return value;
  }
  return fallback;
}
function configBoolean(config, keys, fallback = true) {
  for (const key of keys) {
    const value = config[key];
    if (typeof value === "boolean") return value;
    if (typeof value === "string") {
      const normalized = value.trim().toLowerCase();
      if (["1", "true", "yes", "on", "enabled"].includes(normalized)) return true;
      if (["0", "false", "no", "off", "disabled"].includes(normalized)) return false;
    }
  }
  return fallback;
}
async function getVaultSecretByName(secretName) {
  const safeName = cleanPlainField(secretName, 128);
  if (!safeName) return "";
  try {
    const { db } = await import("./db-JX2B2FPR.js");
    const result = await db.execute(sql`
      SELECT decrypted_secret
      FROM vault.decrypted_secrets
      WHERE name = ${safeName}
      ORDER BY updated_at DESC NULLS LAST, created_at DESC NULLS LAST
      LIMIT 1
    `);
    const row = (result?.rows || [])[0];
    return cleanPlainField(row?.decrypted_secret, 4096);
  } catch (error) {
    console.warn("[Meta CAPI] Nao foi possivel ler segredo no Supabase Vault:", error?.message || error);
    return "";
  }
}
async function readSupabaseMetaCapiConfig(configKey) {
  const key = cleanPlainField(configKey, 100);
  if (!key) return {};
  const cached = runtimeConfigCache.get(key);
  const now = Date.now();
  if (cached && cached.expiresAt > now) {
    return cached.config;
  }
  try {
    const { db } = await import("./db-JX2B2FPR.js");
    const [row] = await db.select({ valor: systemConfig.valor }).from(systemConfig).where(eq(systemConfig.chave, key)).limit(1);
    const parsed = parseConfigJson(row?.valor);
    const accessTokenSecretName = configString(
      parsed,
      ["accessTokenSecretName", "access_token_secret_name", "vaultSecretName", "vault_secret_name"],
      key === RODRIGO_META_CAPI_CONFIG_KEY ? RODRIGO_META_CAPI_ACCESS_TOKEN_SECRET : "",
      128
    );
    const accessTokenFromVault = accessTokenSecretName ? await getVaultSecretByName(accessTokenSecretName) : "";
    const config = {
      enabled: configBoolean(parsed, ["enabled", "ativo", "active"], true),
      pixelId: configString(parsed, ["pixelId", "pixel_id", "datasetId", "dataset_id"], "", 128),
      accessToken: accessTokenFromVault || configString(parsed, ["accessToken", "access_token"], "", 4096),
      graphVersion: configString(parsed, ["graphVersion", "graph_version"], "", 32),
      testEventCode: configString(parsed, ["testEventCode", "test_event_code"], "", 128),
      whatsappBusinessAccountId: configString(
        parsed,
        ["whatsappBusinessAccountId", "whatsapp_business_account_id", "wabaId", "waba_id"],
        "",
        64
      ),
      pageId: configString(parsed, ["pageId", "page_id", "facebookPageId", "facebook_page_id"], "", 64),
      defaultEventName: configString(parsed, ["eventName", "event_name", "defaultEventName", "default_event_name"], "", 64),
      paidEventName: configString(parsed, ["paidEventName", "paid_event_name"], "", 64),
      paidActionSource: configString(parsed, ["actionSource", "action_source", "paidActionSource", "paid_action_source"], "", 64),
      whatsappMessagingChannel: configString(
        parsed,
        ["messagingChannel", "messaging_channel", "whatsappMessagingChannel", "whatsapp_messaging_channel"],
        "",
        64
      )
    };
    runtimeConfigCache.set(key, { expiresAt: now + META_CAPI_CONFIG_CACHE_MS, config });
    return config;
  } catch (error) {
    console.warn("[Meta CAPI] Nao foi possivel ler configuracao Supabase:", error?.message || error);
    runtimeConfigCache.set(key, { expiresAt: now + 1e4, config: {} });
    return {};
  }
}
async function resolveMetaCapiRuntimeConfig(configKey) {
  const supabaseConfig = await readSupabaseMetaCapiConfig(configKey);
  return {
    enabled: supabaseConfig.enabled ?? true,
    pixelId: supabaseConfig.pixelId || getPixelId(),
    accessToken: supabaseConfig.accessToken || getAccessToken(),
    graphVersion: supabaseConfig.graphVersion || DEFAULT_GRAPH_VERSION,
    testEventCode: supabaseConfig.testEventCode || String(process.env.META_CAPI_TEST_EVENT_CODE || "").trim(),
    whatsappBusinessAccountId: supabaseConfig.whatsappBusinessAccountId || cleanPlainField(process.env.META_CAPI_WHATSAPP_BUSINESS_ACCOUNT_ID, 64),
    pageId: supabaseConfig.pageId || cleanPlainField(process.env.META_CAPI_PAGE_ID, 64),
    defaultEventName: supabaseConfig.defaultEventName || DEFAULT_EVENT_NAME,
    paidEventName: supabaseConfig.paidEventName || DEFAULT_PAID_EVENT_NAME,
    paidActionSource: supabaseConfig.paidActionSource || DEFAULT_PAID_ACTION_SOURCE,
    whatsappMessagingChannel: supabaseConfig.whatsappMessagingChannel || DEFAULT_WHATSAPP_MESSAGING_CHANNEL
  };
}
function hasWhatsAppAdClickIdAttribution(attribution) {
  return Boolean(cleanPlainField(attribution?.ctwaClid, 1024));
}
function hasMetaWhatsappClickIdAttribution(attribution) {
  return hasWhatsAppAdClickIdAttribution(attribution);
}
function getPixelId() {
  return String(process.env.META_CAPI_PIXEL_ID || "").trim();
}
function getAccessToken() {
  return String(process.env.META_CAPI_ACCESS_TOKEN || "").trim();
}
function buildMetaConversionUserData(lead, config) {
  const userData = {};
  const phone = normalizeDigits(lead.phone);
  const email = normalizeText(lead.email);
  const name = String(lead.name || "").trim();
  if (phone) {
    userData.ph = [sha256(phone)];
  }
  if (email) {
    userData.em = [sha256(email)];
  }
  if (name) {
    const parts = name.split(/\s+/).filter(Boolean);
    if (parts[0]) {
      userData.fn = [sha256(normalizeText(parts[0]))];
    }
    if (parts.length > 1) {
      userData.ln = [sha256(normalizeText(parts.slice(1).join(" ")))];
    }
  }
  const attribution = lead.whatsappAdsAttribution;
  const ctwaClid = cleanPlainField(attribution?.ctwaClid, 1024);
  if (ctwaClid) {
    userData.ctwa_clid = ctwaClid;
  }
  const whatsappBusinessAccountId = cleanPlainField(config.whatsappBusinessAccountId, 64);
  if (whatsappBusinessAccountId) {
    userData.whatsapp_business_account_id = whatsappBusinessAccountId;
  }
  const pageId = cleanPlainField(config.pageId, 64);
  if (pageId && (!ctwaClid || !whatsappBusinessAccountId)) {
    userData.page_id = pageId;
  }
  return userData;
}
async function sendMetaConversionEvent(lead) {
  const config = await resolveMetaCapiRuntimeConfig(lead.configKey);
  const pixelId = config.pixelId;
  const accessToken = config.accessToken;
  const eventName = String(lead.eventName || config.defaultEventName).trim() || config.defaultEventName;
  const eventId = `${lead.eventId}:${eventName}`;
  if (!config.enabled) {
    return {
      sent: false,
      skipped: true,
      reason: "Meta CAPI desativado na configuracao.",
      eventId,
      eventName
    };
  }
  if (!pixelId || !accessToken) {
    return {
      sent: false,
      skipped: true,
      reason: "Meta CAPI nao configurado.",
      eventId,
      eventName
    };
  }
  const userData = buildMetaConversionUserData(lead, config);
  if (!Object.keys(userData).length) {
    return {
      sent: false,
      skipped: true,
      reason: "Lead sem identificadores suficientes para envio ao Meta CAPI.",
      eventId,
      eventName
    };
  }
  const customData = {
    value: lead.value ?? 0,
    currency: lead.currency || "BRL",
    lead_source: lead.source || "meta_instant_form_google_sheet",
    form_id: lead.formId || void 0,
    company: lead.company || void 0,
    ...lead.customData || {}
  };
  const payload = {
    data: [
      {
        event_name: eventName,
        event_time: Math.floor((lead.submittedAt || /* @__PURE__ */ new Date()).getTime() / 1e3),
        event_id: eventId,
        action_source: lead.actionSource || "system_generated",
        messaging_channel: cleanPlainField(lead.messagingChannel, 64) || void 0,
        user_data: userData,
        custom_data: customData
      }
    ],
    test_event_code: config.testEventCode || void 0
  };
  const response = await fetch(`https://graph.facebook.com/${config.graphVersion}/${pixelId}/events`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });
  const json = await response.json().catch(() => ({}));
  if (!response.ok) {
    const errorPayload = json?.error || {};
    const errorData = errorPayload.error_data && typeof errorPayload.error_data === "object" ? errorPayload.error_data : {};
    const message = [
      errorPayload.message || `Meta CAPI ${response.status}: falha no envio do evento`,
      errorPayload.code ? `code=${errorPayload.code}` : "",
      errorPayload.error_subcode ? `subcode=${errorPayload.error_subcode}` : "",
      errorPayload.error_user_title ? `title=${errorPayload.error_user_title}` : "",
      errorPayload.error_user_msg ? `user_msg=${errorPayload.error_user_msg}` : "",
      errorData.details ? `details=${String(errorData.details)}` : ""
    ].filter(Boolean).join(" | ");
    throw new Error(message);
  }
  return {
    sent: true,
    eventId,
    eventName,
    response: json
  };
}
async function sendMetaLeadWhatsappEvent(lead) {
  return sendMetaConversionEvent({
    ...lead,
    eventName: DEFAULT_EVENT_NAME,
    actionSource: "system_generated",
    value: 0,
    currency: "BRL"
  });
}
async function sendMetaPaidWhatsappConversion(lead) {
  const attribution = lead.whatsappAdsAttribution || null;
  if (!hasWhatsAppAdClickIdAttribution(attribution)) {
    const eventName2 = DEFAULT_PAID_EVENT_NAME;
    return {
      sent: false,
      skipped: true,
      reason: "Lead sem ctwa_clid da campanha WhatsApp para envio ao Meta CAPI.",
      eventId: `${lead.eventId}:${eventName2}`,
      eventName: eventName2
    };
  }
  const config = await resolveMetaCapiRuntimeConfig(RODRIGO_META_CAPI_CONFIG_KEY);
  const eventName = config.paidEventName || DEFAULT_PAID_EVENT_NAME;
  return sendMetaWhatsappBusinessMessagingEvent({
    ...lead,
    eventName,
    value: lead.value ?? 0,
    currency: lead.currency || "BRL",
    contentName: lead.planName || "Assinatura AgenteZap",
    source: lead.source || "rodrigo_whatsapp_paid_subscription",
    whatsappAdsAttribution: attribution,
    customData: {
      subscription_id: lead.subscriptionId || void 0
    }
  });
}
async function sendMetaWhatsappBusinessMessagingEvent(lead) {
  const attribution = lead.whatsappAdsAttribution || null;
  const eventName = String(lead.eventName || "").trim() || DEFAULT_PAID_EVENT_NAME;
  if (!hasWhatsAppAdClickIdAttribution(attribution)) {
    return {
      sent: false,
      skipped: true,
      reason: "Lead sem ctwa_clid da campanha WhatsApp para envio ao Meta CAPI.",
      eventId: `${lead.eventId}:${eventName}`,
      eventName
    };
  }
  const config = await resolveMetaCapiRuntimeConfig(RODRIGO_META_CAPI_CONFIG_KEY);
  return sendMetaConversionEvent({
    ...lead,
    configKey: RODRIGO_META_CAPI_CONFIG_KEY,
    eventName,
    actionSource: config.paidActionSource || DEFAULT_PAID_ACTION_SOURCE,
    messagingChannel: config.whatsappMessagingChannel || DEFAULT_WHATSAPP_MESSAGING_CHANNEL,
    value: lead.value ?? 0,
    currency: lead.currency || "BRL",
    source: lead.source || "rodrigo_whatsapp_business_messaging",
    whatsappAdsAttribution: attribution,
    customData: {
      content_name: lead.contentName || void 0,
      subscription_id: lead.subscriptionId || void 0,
      lead_source: lead.source || "rodrigo_whatsapp_business_messaging",
      ...lead.customData || {}
    }
  });
}

export {
  normalizePhoneForComparison,
  phoneNumbersMatch,
  normalizePhoneToDigits,
  normalizeBrazilWhatsAppPhone,
  buildBrazilWhatsAppPhoneVariants,
  buildWhatsAppJidFromPhone,
  isMauricioMfcCatalogTenant,
  resolveMauricioMfcRequestedLineKind,
  mauricioMfcCatalogEntryMatchesLineKind,
  formatMauricioMfcCurrency,
  extractMauricioMfcPriorCartItems,
  looksLikeMauricioMfcCartResetIntent,
  looksLikeMauricioMfcReady50x50PromoRequest,
  containsMauricioMfcReady50x50PromoText,
  buildMauricioMfcReady50x50PromoReply,
  getMauricioMfcCatalogPriceDescription,
  buildMauricioMfcCatalogCaptionPriceLine,
  resolveMauricioMfcCatalogUnitPrice,
  looksLikeMauricioMfcCatalogThemeContinuation,
  looksLikeMauricioMfcPixNegation,
  looksLikeMauricioMfcPixPaymentRequest,
  looksLikeMauricioMfcAddressRequest,
  buildMauricioMfcDedicatedAddressReply,
  buildMauricioMfcCatalogPromptBlock,
  hasMetaWhatsappClickIdAttribution,
  sendMetaLeadWhatsappEvent,
  sendMetaPaidWhatsappConversion,
  sendMetaWhatsappBusinessMessagingEvent
};
