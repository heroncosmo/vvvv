import {
  buildBrazilWhatsAppPhoneVariants,
  hasMetaWhatsappClickIdAttribution,
  normalizePhoneToDigits,
  sendMetaWhatsappBusinessMessagingEvent
} from "./chunk-YB77ZB3P.js";
import {
  getBrazilTimeParts,
  init_greetingTime
} from "./chunk-LIK4OWWG.js";
import {
  db
} from "./chunk-R6CXRQMB.js";
import {
  conversationLeadIntelligence,
  conversations,
  paymentHistory,
  plans,
  subscriptions,
  users,
  whatsappConnections
} from "./chunk-JC6URYU5.js";

// server/brazilTemporalContext.ts
init_greetingTime();
var BRAZIL_TEMPORAL_TIME_ZONE = "America/Sao_Paulo";
var WEEKDAY_LABELS = [
  "domingo",
  "segunda-feira",
  "ter\xE7a-feira",
  "quarta-feira",
  "quinta-feira",
  "sexta-feira",
  "s\xE1bado"
];
function pad2(value) {
  return String(value).padStart(2, "0");
}
function buildDayFromUtcNoon(baseUtcNoon, offsetDays) {
  const date = new Date(baseUtcNoon + offsetDays * 24 * 60 * 60 * 1e3);
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  const day = date.getUTCDate();
  return {
    dateKey: `${String(year).padStart(4, "0")}-${pad2(month)}-${pad2(day)}`,
    datePtBr: `${pad2(day)}/${pad2(month)}/${String(year).padStart(4, "0")}`,
    weekday: WEEKDAY_LABELS[date.getUTCDay()]
  };
}
function getBrazilTemporalContext(now = /* @__PURE__ */ new Date()) {
  const parts = getBrazilTimeParts(now);
  const baseUtcNoon = Date.UTC(parts.year, parts.month - 1, parts.day, 12, 0, 0);
  const today = buildDayFromUtcNoon(baseUtcNoon, 0);
  const tomorrow = buildDayFromUtcNoon(baseUtcNoon, 1);
  const dayAfterTomorrow = buildDayFromUtcNoon(baseUtcNoon, 2);
  const upcomingDays = Array.from({ length: 7 }, (_, index) => buildDayFromUtcNoon(baseUtcNoon, index));
  const time = `${pad2(parts.hour)}:${pad2(parts.minute)}`;
  return {
    timeZone: BRAZIL_TEMPORAL_TIME_ZONE,
    nowIso: now.toISOString(),
    dateKey: today.dateKey,
    datePtBr: today.datePtBr,
    time,
    weekday: today.weekday,
    today,
    tomorrow,
    dayAfterTomorrow,
    upcomingDays
  };
}
function buildBrazilTemporalPromptBlock(now = /* @__PURE__ */ new Date()) {
  const context = getBrazilTemporalContext(now);
  return [
    "=== DATA E HORA OFICIAL DO BRASIL PARA ESTA RESPOSTA ===",
    `Fuso oficial: ${context.timeZone} (horario de Brasilia).`,
    `Agora no Brasil: ${context.weekday}, ${context.datePtBr}, ${context.time}.`,
    "Mapa obrigatorio de datas relativas:",
    `- hoje = ${context.today.datePtBr} (${context.today.weekday})`,
    `- amanha/amanh\xE3 = ${context.tomorrow.datePtBr} (${context.tomorrow.weekday})`,
    `- depois de amanha/depois de amanh\xE3 = ${context.dayAfterTomorrow.datePtBr} (${context.dayAfterTomorrow.weekday})`,
    "Calendario dos proximos 7 dias:",
    ...context.upcomingDays.map((day, index) => {
      const relation = index === 0 ? "hoje" : index === 1 ? "amanha/amanh\xE3" : index === 2 ? "depois de amanha/depois de amanh\xE3" : `em ${index} dias`;
      return `- ${day.datePtBr} (${day.weekday}) = ${relation}`;
    }),
    "Regras obrigatorias:",
    "- Use este mapa para interpretar hoje, amanha/amanh\xE3, depois de amanha/depois de amanh\xE3, mais tarde e dias da semana.",
    "- Nao use memoria interna do modelo para calcular data atual, dia da semana ou horario.",
    "- Se uma data absoluta do prompt ou historico nao for igual ao mapa de amanha, nao chame essa data de amanha.",
    "- Para agenda, disponibilidade, evento, lembrete ou confirmacao de horario, confira a data e o dia da semana por este bloco antes de responder.",
    "=== FIM DA DATA E HORA OFICIAL ==="
  ].join("\n");
}
function normalizeFold(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
function parseDateKey(dateKey) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateKey);
  if (!match) return Number.NaN;
  return Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 12, 0, 0);
}
function offsetDaysFromContext(context, dateKey) {
  const base = parseDateKey(context.dateKey);
  const target = parseDateKey(dateKey);
  if (!Number.isFinite(base) || !Number.isFinite(target)) return null;
  return Math.round((target - base) / (24 * 60 * 60 * 1e3));
}
function relationForOffset(offsetDays) {
  if (offsetDays === 0) return "hoje";
  if (offsetDays === 1) return "amanh\xE3";
  if (offsetDays === 2) return "depois de amanh\xE3";
  if (typeof offsetDays === "number" && offsetDays > 2) return `em ${offsetDays} dias`;
  if (offsetDays === -1) return "ontem";
  if (typeof offsetDays === "number" && offsetDays < -1) return `h\xE1 ${Math.abs(offsetDays)} dias`;
  return "data informada";
}
function buildDayFromDateParts(day, month, year) {
  if (!Number.isInteger(day) || !Number.isInteger(month) || !Number.isInteger(year)) return null;
  if (year < 2e3 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return null;
  const date = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() + 1 !== month || date.getUTCDate() !== day) {
    return null;
  }
  return {
    dateKey: `${String(year).padStart(4, "0")}-${pad2(month)}-${pad2(day)}`,
    datePtBr: `${pad2(day)}/${pad2(month)}/${String(year).padStart(4, "0")}`,
    weekday: WEEKDAY_LABELS[date.getUTCDay()]
  };
}
function uniqueMentions(mentions) {
  const seen = /* @__PURE__ */ new Set();
  const unique = [];
  for (const mention of mentions) {
    if (seen.has(mention.dateKey)) continue;
    seen.add(mention.dateKey);
    unique.push(mention);
  }
  return unique;
}
function extractBrazilTemporalDateMentions(text, now = /* @__PURE__ */ new Date()) {
  const context = getBrazilTemporalContext(now);
  const mentions = [];
  const pattern = /\b(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?\b/g;
  let match;
  while ((match = pattern.exec(String(text || ""))) !== null) {
    const day = Number(match[1]);
    const month = Number(match[2]);
    const yearRaw = match[3];
    const year = yearRaw ? Number(yearRaw.length === 2 ? `20${yearRaw}` : yearRaw) : Number(context.dateKey.slice(0, 4));
    const temporalDay = buildDayFromDateParts(day, month, year);
    if (!temporalDay) continue;
    const offsetDays = offsetDaysFromContext(context, temporalDay.dateKey);
    mentions.push({
      ...temporalDay,
      raw: match[0],
      offsetDays,
      relation: relationForOffset(offsetDays)
    });
  }
  return uniqueMentions(mentions);
}
function shouldUseBrazilTemporalToolContract(referenceText) {
  const raw = String(referenceText || "");
  if (/\b\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?\b/.test(raw)) return true;
  if (/\b\d{1,2}\s*h(?:\d{2})?\b/i.test(raw)) return true;
  const folded = normalizeFold(raw);
  return /\b(hoje|amanha|depois\s+de\s+amanha|ontem|agora|mais\s+tarde|data|horario|hora|agenda|agendar|agendamento|marcar|remarcar|evento|disponibilidade|disponivel|lembrete|compromisso|peneira|segunda|terca|quarta|quinta|sexta|sabado|domingo)\b/.test(folded);
}
function buildBrazilTemporalToolResult(params = {}) {
  const now = params.now || /* @__PURE__ */ new Date();
  const context = getBrazilTemporalContext(now);
  const dateMentions = extractBrazilTemporalDateMentions(params.referenceText || "", now).map((mention) => ({
    raw: mention.raw,
    dateKey: mention.dateKey,
    datePtBr: mention.datePtBr,
    weekday: mention.weekday,
    relation: mention.relation,
    offsetDays: mention.offsetDays,
    isToday: mention.dateKey === context.today.dateKey,
    isTomorrow: mention.dateKey === context.tomorrow.dateKey,
    isDayAfterTomorrow: mention.dateKey === context.dayAfterTomorrow.dateKey
  }));
  return {
    toolName: "resolveBrazilTemporalContext",
    source: "runtime",
    timeZone: context.timeZone,
    nowIso: context.nowIso,
    nowBrazil: {
      dateKey: context.dateKey,
      datePtBr: context.datePtBr,
      weekday: context.weekday,
      time: context.time
    },
    relativeDates: {
      today: context.today,
      tomorrow: context.tomorrow,
      dayAfterTomorrow: context.dayAfterTomorrow
    },
    upcomingDays: context.upcomingDays,
    dateMentions,
    constraints: [
      "Use America/Sao_Paulo as the only current time source.",
      "Never call an absolute date 'amanha' unless it equals relativeDates.tomorrow.dateKey.",
      "Never call an absolute date 'hoje' unless it equals relativeDates.today.dateKey.",
      "For scheduling, availability, event and reminder answers, resolve relative dates with this result before answering.",
      "Do not mention tool, API, SDK, prompt or internal runtime details to the customer."
    ]
  };
}
function buildBrazilTemporalToolContractBlock(params = {}) {
  const referenceText = String(params.referenceText || "");
  const result = buildBrazilTemporalToolResult({
    referenceText,
    now: params.now
  });
  const activeSignal = shouldUseBrazilTemporalToolContract(referenceText);
  return [
    "=== CONTRATO TEMPORAL ESTRUTURADO DO MOTOR ===",
    "Ferramenta deterministica: resolveBrazilTemporalContext.",
    activeSignal ? "Status: sinal temporal detectado; este resultado e obrigatorio para responder datas/horarios." : "Status: resultado preventivo disponivel para qualquer data/horario que apareca na resposta.",
    "Resultado runtime em JSON:",
    JSON.stringify(result, null, 2),
    "Contrato:",
    "- Use o JSON acima como fonte de verdade para hoje, amanha, depois de amanha, dia da semana e horario.",
    "- Se houver conflito entre prompt/historico e este JSON, prevalece este JSON para data/hora atual.",
    "- Nao exponha ao cliente que houve ferramenta, JSON, SDK, API, prompt ou regra interna.",
    "=== FIM DO CONTRATO TEMPORAL ==="
  ].join("\n");
}
function textClaimsTodayForEvent(text) {
  const folded = normalizeFold(text);
  return /\b(?:e|eh|sera|fica|acontece|vai ser)\s+\*?hoje\b/.test(folded) || /\bhoje\s*\(/.test(folded);
}
function textClaimsTomorrowForEvent(text) {
  const folded = normalizeFold(text);
  return /\b(?:e|eh|sera|fica|acontece|vai ser)\s+\*?amanha\b/.test(folded) || /\bamanha\s+mesmo\b/.test(folded);
}
function mentionConflictsWithRelativeText(mention, text) {
  const folded = normalizeFold(text);
  const hasToday = /\bhoje\b/.test(folded);
  const hasTomorrow = /\bamanha\b/.test(folded);
  const hasDayAfter = /\bdepois\s+de\s+amanha\b/.test(folded);
  if (hasToday && mention.offsetDays !== 0) return true;
  if (hasDayAfter && mention.offsetDays !== 2) return true;
  if (hasTomorrow && !hasDayAfter && mention.offsetDays !== 1) return true;
  return false;
}
function buildTemporalCorrectionText(datesToExplain, context) {
  const extraDates = uniqueMentions(datesToExplain).filter((mention) => mention.dateKey !== context.today.dateKey && mention.dateKey !== context.tomorrow.dateKey).map((mention) => `O dia ${mention.datePtBr} \xE9 ${mention.weekday}, ${mention.relation}.`);
  return [
    "Corrigindo a data:",
    `Hoje \xE9 ${context.today.datePtBr} (${context.today.weekday}).`,
    `Amanh\xE3 \xE9 ${context.tomorrow.datePtBr} (${context.tomorrow.weekday}).`,
    ...extraDates
  ].join("\n");
}
function weekdayStem(weekday) {
  return normalizeFold(weekday).replace(/\s*-\s*feira\b/g, "").trim();
}
function hasWrongWeekdayForRelativeDate(text, relationPattern, expectedWeekday) {
  const folded = normalizeFold(text);
  const expectedStem = weekdayStem(expectedWeekday);
  const weekdayStems = WEEKDAY_LABELS.map(weekdayStem);
  let match;
  relationPattern.lastIndex = 0;
  while ((match = relationPattern.exec(folded)) !== null) {
    const windowStart = Math.max(0, match.index - 40);
    const windowEnd = Math.min(folded.length, match.index + 140);
    const localWindow = folded.slice(windowStart, windowEnd);
    const mentionedWeekdays = weekdayStems.filter((stem) => new RegExp(`\\b${stem}\\b`).test(localWindow));
    if (mentionedWeekdays.some((stem) => stem !== expectedStem)) {
      return true;
    }
    if (match[0].length === 0) relationPattern.lastIndex += 1;
  }
  return false;
}
function hasRelativeWeekdayConflict(text, context) {
  return hasWrongWeekdayForRelativeDate(text, /\bhoje\b/g, context.today.weekday) || hasWrongWeekdayForRelativeDate(text, /\bamanha\b/g, context.tomorrow.weekday) || hasWrongWeekdayForRelativeDate(text, /\bdepois\s+de\s+amanha\b/g, context.dayAfterTomorrow.weekday);
}
var WEEKDAY_REPAIR_PATTERNS = [
  { stem: "domingo", pattern: "domingo(?:-feira)?" },
  { stem: "segunda", pattern: "segunda(?:-feira)?" },
  { stem: "terca", pattern: "ter(?:c|\\u00e7)a(?:-feira)?" },
  { stem: "quarta", pattern: "quarta(?:-feira)?" },
  { stem: "quinta", pattern: "quinta(?:-feira)?" },
  { stem: "sexta", pattern: "sexta(?:-feira)?" },
  { stem: "sabado", pattern: "s(?:a|\\u00e1)bado" }
];
var AMANHA_REPAIR_PATTERN = "amanh(?:a|\\u00e3)";
var DEPOIS_DE_AMANHA_REPAIR_PATTERN = `depois\\s+de\\s+${AMANHA_REPAIR_PATTERN}`;
var AMANHA_SEM_DEPOIS_REPAIR_PATTERN = `(?<!depois\\s+de\\s+)${AMANHA_REPAIR_PATTERN}`;
function relativeRepairToken(relationPattern) {
  return `\\b${relationPattern}(?=\\s|[,.;:!?]|$)`;
}
function repairWrongWeekdayForRelativeDate(text, relationPattern, expectedWeekday) {
  const expectedStem = weekdayStem(expectedWeekday);
  let repaired = text;
  const relationToken = relativeRepairToken(relationPattern);
  for (const weekday of WEEKDAY_REPAIR_PATTERNS) {
    if (weekday.stem === expectedStem) continue;
    const afterRelation = new RegExp(`(${relationToken}[^.!?\\n]{0,90}?)\\b${weekday.pattern}\\b`, "gi");
    repaired = repaired.replace(afterRelation, `$1${expectedWeekday}`);
    const beforeRelation = new RegExp(`\\b${weekday.pattern}\\b([^.!?\\n]{0,90}?${relationToken})`, "gi");
    repaired = repaired.replace(beforeRelation, `${expectedWeekday}$1`);
  }
  return repaired;
}
function buildDayFromDateText(rawDate, context) {
  const match = /\b(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?\b/.exec(String(rawDate || ""));
  if (!match) return null;
  const day = Number(match[1]);
  const month = Number(match[2]);
  const yearRaw = match[3];
  const year = yearRaw ? Number(yearRaw.length === 2 ? `20${yearRaw}` : yearRaw) : Number(context.dateKey.slice(0, 4));
  return buildDayFromDateParts(day, month, year);
}
function repairWrongDateForRelativeDate(text, relationPattern, expectedDay, context) {
  const datePattern = "(\\b\\d{1,2}[/-]\\d{1,2}(?:[/-]\\d{2,4})?\\b)";
  let repaired = text;
  const relationToken = relativeRepairToken(relationPattern);
  const afterRelation = new RegExp(`(${relationToken}[^.!?\\n]{0,120}?)${datePattern}`, "gi");
  repaired = repaired.replace(afterRelation, (full, prefix, rawDate) => {
    const mentionedDay = buildDayFromDateText(rawDate, context);
    if (!mentionedDay || mentionedDay.dateKey === expectedDay.dateKey) return full;
    return `${prefix}${expectedDay.datePtBr}`;
  });
  const beforeRelation = new RegExp(`${datePattern}([^.!?\\n]{0,120}?${relationToken})`, "gi");
  repaired = repaired.replace(beforeRelation, (full, rawDate, suffix) => {
    const mentionedDay = buildDayFromDateText(rawDate, context);
    if (!mentionedDay || mentionedDay.dateKey === expectedDay.dateKey) return full;
    return `${expectedDay.datePtBr}${suffix}`;
  });
  return repaired;
}
function repairRelativeWeekdayText(text, context) {
  let repaired = text;
  repaired = repairWrongWeekdayForRelativeDate(repaired, "hoje", context.today.weekday);
  repaired = repairWrongWeekdayForRelativeDate(repaired, DEPOIS_DE_AMANHA_REPAIR_PATTERN, context.dayAfterTomorrow.weekday);
  repaired = repairWrongWeekdayForRelativeDate(repaired, AMANHA_SEM_DEPOIS_REPAIR_PATTERN, context.tomorrow.weekday);
  return repaired;
}
function repairRelativeDateText(text, context) {
  let repaired = text;
  repaired = repairWrongDateForRelativeDate(repaired, "hoje", context.today, context);
  repaired = repairWrongDateForRelativeDate(repaired, DEPOIS_DE_AMANHA_REPAIR_PATTERN, context.dayAfterTomorrow, context);
  repaired = repairWrongDateForRelativeDate(repaired, AMANHA_SEM_DEPOIS_REPAIR_PATTERN, context.tomorrow, context);
  return repairRelativeWeekdayText(repaired, context);
}
function firstReferenceLine(referenceText) {
  return String(referenceText || "").split(/\n/)[0] || "";
}
function localWindowAroundRawText(text, raw, before = 120, after = 160) {
  const escapedRaw = String(raw || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const rawIndex = String(text || "").search(new RegExp(escapedRaw));
  if (rawIndex < 0) return String(text || "");
  return String(text || "").slice(
    Math.max(0, rawIndex - before),
    Math.min(String(text || "").length, rawIndex + after)
  );
}
function selectReferenceConflictsForRelativeClaim(mentions, referenceText, expectedOffsetDays) {
  const conflictingMentions = mentions.filter((mention) => mention.offsetDays !== expectedOffsetDays);
  if (conflictingMentions.length <= 1 && mentions.length === 1) {
    return conflictingMentions;
  }
  const fullReference = String(referenceText || "");
  return conflictingMentions.filter((mention) => {
    const localWindow = localWindowAroundRawText(fullReference, mention.raw);
    return mentionConflictsWithRelativeText(mention, localWindow);
  });
}
function hasAbsoluteDateText(text) {
  return /\b\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?\b/.test(String(text || ""));
}
function primaryReferenceRequestsTomorrow(primaryReference) {
  const folded = normalizeFold(primaryReference);
  return /\bamanha\b/.test(folded) && !/\bdepois\s+de\s+amanha\b/.test(folded);
}
function responseLooksLikeSchedulingOffer(text) {
  const folded = normalizeFold(text);
  return /\b(horario|periodo|manha|tarde|pre-agendamento|agendamento|marcar|consulta|atendimento|disponivel|prefere|consegue|vaga)\b/.test(folded);
}
function repairRelativeRelationFromPrimaryReference(responseText, primaryReference, context) {
  if (!primaryReferenceRequestsTomorrow(primaryReference)) return responseText;
  const foldedResponse = normalizeFold(responseText);
  if (!responseLooksLikeSchedulingOffer(responseText)) return responseText;
  if (!/\bhoje\b/.test(foldedResponse) || /\bamanha\b/.test(foldedResponse)) return responseText;
  return responseText.replace(/\bhoje\b(?:\s*\([^)]*\))?/gi, `amanh\xE3 (${context.tomorrow.weekday})`);
}
function enforceBrazilTemporalConsistency(params) {
  const responseText = String(params.responseText || "").trim();
  if (!responseText) return responseText;
  const now = params.now || /* @__PURE__ */ new Date();
  const context = getBrazilTemporalContext(now);
  const responseMentions = extractBrazilTemporalDateMentions(responseText, now);
  const referenceMentions = extractBrazilTemporalDateMentions(params.referenceText || "", now);
  const responseConflicts = [];
  const referenceConflicts = [];
  const primaryReference = firstReferenceLine(params.referenceText);
  const relationRepairedResponseText = repairRelativeRelationFromPrimaryReference(
    responseText,
    primaryReference,
    context
  );
  if (relationRepairedResponseText !== responseText) {
    return repairRelativeDateText(relationRepairedResponseText, context);
  }
  for (const mention of responseMentions) {
    const localWindow = localWindowAroundRawText(responseText, mention.raw);
    if (mentionConflictsWithRelativeText(mention, localWindow)) {
      responseConflicts.push(mention);
    }
  }
  if (textClaimsTodayForEvent(responseText)) {
    referenceConflicts.push(
      ...selectReferenceConflictsForRelativeClaim(referenceMentions, params.referenceText, 0)
    );
  }
  if (textClaimsTomorrowForEvent(responseText)) {
    referenceConflicts.push(
      ...selectReferenceConflictsForRelativeClaim(referenceMentions, params.referenceText, 1)
    );
  }
  const uniqueResponseConflicts = uniqueMentions(responseConflicts);
  const uniqueReferenceConflicts = uniqueMentions(referenceConflicts);
  const uniqueConflicts = uniqueMentions([...uniqueResponseConflicts, ...uniqueReferenceConflicts]);
  const relativeWeekdayConflict = hasRelativeWeekdayConflict(responseText, context);
  if (uniqueConflicts.length === 0 && !relativeWeekdayConflict) return responseText;
  const hasPrimaryReference = primaryReference.trim().length > 0;
  const canRepairRelativeDatesInPlace = !hasAbsoluteDateText(primaryReference) && uniqueReferenceConflicts.length === 0 && (relativeWeekdayConflict || hasPrimaryReference && uniqueResponseConflicts.length > 0);
  if (canRepairRelativeDatesInPlace) {
    const repaired = repairRelativeDateText(responseText, context);
    if (repaired !== responseText) return repaired;
  }
  return buildTemporalCorrectionText(uniqueConflicts, context);
}

// server/fkSemijoiasResponsePolicy.ts
var FK_SEMIJOIAS_GREETING = "Ola, futura revendedora Fk Semijoias, qual o seu nome?";
var FK_SEMIJOIAS_CATALOG_FALLBACK = "Essa informacao eu nao tenho aqui comigo, mas nosso setor de consignados pode te ajudar com isso!";
var FK_SEMIJOIAS_VIDEO_MEDIA_NAME = "VIDEO_SEMIJOIAS";
var FK_SEMIJOIAS_VIDEO_REPLY = "Vou te enviar um video com as pecas para voce conferir!";
var FK_SEMIJOIAS_FICHA_MEDIA_NAME = "FICHA_REVENDEDORA_FK";
var FK_SEMIJOIAS_FICHA_ALREADY_SENT_REPLY = "Pode preencher os dados da ficha por aqui. Se algum campo ficar faltando, eu te aviso.";
function normalizeFkSemijoiasText(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
function isFkSemijoiasPrompt(prompt) {
  const normalized = normalizeFkSemijoiasText(prompt);
  return normalized.includes("fk semijoias") && normalized.includes("franciele");
}
function isFkSemijoiasCatalogOrPriceRequest(message) {
  const normalized = normalizeFkSemijoiasText(message);
  return /\b(catalogo|catalogos|link|tabela|preco|precos|valor|valores)\b/.test(normalized);
}
function isFkSemijoiasSpecificFlowOrMediaRequest(message) {
  const normalized = normalizeFkSemijoiasText(message);
  return /\b(ficha|cadastro|cpf|video|videos|foto|fotos|peca|pecas|mostruario|comissao|endereco|instagram|score|spc|serasa)\b/.test(normalized);
}
function isFkSemijoiasProductOrVideoRequest(message) {
  const normalized = normalizeFkSemijoiasText(message);
  return /\b(video|videos|foto|fotos|peca|pecas|produto|produtos|brinco|brincos|anel|aneis|colar|colares|pulseira|pulseiras|corrente|correntes|mostruario|codigo|referencia|pagamento)\b/.test(normalized);
}
function hasFkSemijoiasVideoPromise(text) {
  const normalized = normalizeFkSemijoiasText(text);
  return /\b(vou|posso|consigo)\b.{0,40}\b(enviar|mandar)\b.{0,40}\bvideo\b/.test(normalized) || normalized.includes("video com as pecas");
}
function isFkSemijoiasVideoMediaAction(action) {
  const normalizedName = normalizeFkSemijoiasText(action?.media_name || action?.mediaName || action?.name || "");
  const normalizedType = normalizeFkSemijoiasText(action?.media_type || action?.mediaType || action?.type || "");
  return normalizedName === "video semijoias" || normalizedType === "video" || normalizedType === "send video";
}
function buildFkSemijoiasVideoAction() {
  return { type: "send_media", media_name: FK_SEMIJOIAS_VIDEO_MEDIA_NAME };
}
function buildFkSemijoiasFichaAction() {
  return { type: "send_media", media_name: FK_SEMIJOIAS_FICHA_MEDIA_NAME };
}
function ensureFkSemijoiasVideoAction(actions) {
  const withoutOpening = dropGreetingOpeningActions(actions);
  if (withoutOpening.some(isFkSemijoiasVideoMediaAction)) {
    return withoutOpening;
  }
  return [...withoutOpening, buildFkSemijoiasVideoAction()];
}
function ensureFkSemijoiasFichaAction(actions) {
  const withoutOpeningAndVideo = dropFkSemijoiasOpeningAndVideoActions(actions).filter((action) => !isFkSemijoiasFichaMediaAction(action));
  return [...withoutOpeningAndVideo, buildFkSemijoiasFichaAction()];
}
function isFkSemijoiasFichaMediaAction(action) {
  const normalizedName = normalizeFkSemijoiasText(action?.media_name || action?.mediaName || action?.name || "");
  const normalizedText = normalizeFkSemijoiasText(action?.text || action?.caption || "");
  return normalizedName.includes("ficha") || normalizedName.includes("revendedora") || hasFkSemijoiasFichaText(normalizedText);
}
function hasFkSemijoiasFichaText(value) {
  const normalized = normalizeFkSemijoiasText(value);
  if (!normalized) return false;
  if ((normalized.includes("posso te enviar") || normalized.includes("quer que eu te envie")) && !normalized.includes("cpf")) {
    return false;
  }
  return normalized.includes("ficha de cadastro") && normalized.includes("cpf") || normalized.includes("nome completo") && normalized.includes("cpf") || normalized.includes("revendedora fk") && normalized.includes("cpf") || normalized.includes("dados") && normalized.includes("cadastro") && normalized.includes("cpf");
}
function hasFkSemijoiasFichaInHistory(history) {
  return Array.isArray(history) && history.some(
    (entry) => entry?.role === "assistant" && hasFkSemijoiasFichaText(entry?.content)
  );
}
function hasFkSemijoiasFichaOfferInHistory(history) {
  return Array.isArray(history) && history.some((entry) => {
    if (entry?.role !== "assistant") return false;
    const normalized = normalizeFkSemijoiasText(entry?.content);
    return normalized.includes("posso te enviar") && normalized.includes("ficha") && normalized.includes("cadastro");
  });
}
function isFkSemijoiasShortAffirmative(message) {
  const normalized = normalizeFkSemijoiasText(message);
  if (!normalized) return false;
  const shortAffirmatives = /* @__PURE__ */ new Set([
    "sim",
    "ss",
    "s",
    "ok",
    "okay",
    "pode",
    "pode sim",
    "quero",
    "quero sim",
    "claro",
    "isso",
    "isso mesmo",
    "ta",
    "ta bom"
  ]);
  return shortAffirmatives.has(normalized);
}
function isFkSemijoiasExplicitFichaConfirmation(message) {
  const normalized = normalizeFkSemijoiasText(message);
  if (!normalized || !/\b(ficha|cadastro|formulario|formulario)\b/.test(normalized)) return false;
  return /\b(sim|quero|pode|pode enviar|envia|mande|manda|preencher|preencho|fazer)\b/.test(normalized);
}
function isFkSemijoiasFichaConfirmationRequest(params) {
  return isFkSemijoiasExplicitFichaConfirmation(params.message) || isFkSemijoiasShortAffirmative(params.message) && hasFkSemijoiasFichaOfferInHistory(params.history);
}
function isFkSemijoiasGenericInitialInterest(message) {
  const normalized = normalizeFkSemijoiasText(message);
  if (!normalized) return false;
  if (isFkSemijoiasCatalogOrPriceRequest(normalized) || isFkSemijoiasSpecificFlowOrMediaRequest(normalized)) {
    return false;
  }
  return /\btenho interesse\b/.test(normalized) || /\b(pegar|pega|quero|queria|gostaria|pretendo|posso)\b.{0,30}\b(vender|revender)\b/.test(normalized) || /\b(para|pra)\b.{0,10}\b(vender|revender)\b/.test(normalized) || /\bquero mais informacoes\b/.test(normalized) || /\bqueria mais informacoes\b/.test(normalized) || /\bgostaria de mais informacoes\b/.test(normalized) || /\bmais informacoes\b/.test(normalized) || /\bcomo funciona\b/.test(normalized) || /\bconverse conosco\b/.test(normalized);
}
function hasFkSemijoiasCatalogDigitalPromise(text) {
  const normalized = normalizeFkSemijoiasText(text);
  return normalized.includes("aqui vai o catalogo digital") || normalized.includes("enviei nosso catalogo completo") || normalized.includes("catalogo digital com todas as pecas") || normalized.includes("catalogo digital") && normalized.includes("tabela") || normalized.includes("catalogo") && normalized.includes("comiss") || normalized.includes("catalogo digital") && normalized.includes("pecas") && normalized.includes("valores") || normalized.includes("catalogo completo") && normalized.includes("tabela de precos") || normalized.includes("catalogo") && normalized.includes("tabela de precos");
}
function isGreetingOpeningAction(action) {
  return String(action?.opening_flow_source || "") === "greeting";
}
function getGreetingOpeningText(actions) {
  const textAction = actions.find(
    (action) => isGreetingOpeningAction(action) && String(action?.type || "") === "send_text" && String(action?.text || "").trim()
  );
  return String(textAction?.text || FK_SEMIJOIAS_GREETING).trim();
}
function dropGreetingOpeningActions(actions) {
  return actions.filter((action) => !isGreetingOpeningAction(action));
}
function dropFkSemijoiasOpeningAndVideoActions(actions) {
  return actions.filter((action) => !isGreetingOpeningAction(action) && !isFkSemijoiasVideoMediaAction(action));
}
function applyFkSemijoiasResponsePolicy(params) {
  let text = String(params.responseText || "").trim();
  let mediaActions = Array.isArray(params.mediaActions) ? params.mediaActions : [];
  const applied = [];
  if (!isFkSemijoiasPrompt(params.prompt)) {
    return { text, mediaActions, applied };
  }
  const firstAgentResponse = params.isFirstAgentResponse ?? !(Array.isArray(params.history) && params.history.some((entry) => entry?.role === "assistant"));
  const greetingText = getGreetingOpeningText(mediaActions);
  const hasGreetingAction = mediaActions.some(isGreetingOpeningAction);
  const hasVideoAction = mediaActions.some(isFkSemijoiasVideoMediaAction);
  const catalogOrPriceRequest = isFkSemijoiasCatalogOrPriceRequest(params.message);
  const productOrVideoRequest = isFkSemijoiasProductOrVideoRequest(params.message);
  const specificFlowOrMediaRequest = isFkSemijoiasSpecificFlowOrMediaRequest(params.message);
  const genericInitialInterest = firstAgentResponse && isFkSemijoiasGenericInitialInterest(params.message);
  const catalogDigitalPromise = hasFkSemijoiasCatalogDigitalPromise(text);
  const videoPromise = hasFkSemijoiasVideoPromise(text);
  const fichaAlreadySent = hasFkSemijoiasFichaInHistory(params.history);
  const fichaInCurrentTurn = hasFkSemijoiasFichaText(text) || mediaActions.some(isFkSemijoiasFichaMediaAction);
  const fichaConfirmationRequest = isFkSemijoiasFichaConfirmationRequest({
    message: params.message,
    history: params.history
  });
  if (fichaAlreadySent && (fichaInCurrentTurn || fichaConfirmationRequest || isFkSemijoiasShortAffirmative(params.message))) {
    text = FK_SEMIJOIAS_FICHA_ALREADY_SENT_REPLY;
    mediaActions = mediaActions.filter((action) => !isFkSemijoiasFichaMediaAction(action));
    applied.push("drop_duplicate_ficha_after_confirmation");
    return { text, mediaActions, applied };
  }
  if (!firstAgentResponse && fichaConfirmationRequest) {
    text = "";
    mediaActions = ensureFkSemijoiasFichaAction(mediaActions);
    applied.push("send_ficha_after_confirmation");
    return { text, mediaActions, applied };
  }
  if (firstAgentResponse && (catalogOrPriceRequest || productOrVideoRequest || specificFlowOrMediaRequest)) {
    if (normalizeFkSemijoiasText(text) !== normalizeFkSemijoiasText(greetingText) || hasGreetingAction || hasVideoAction || videoPromise) {
      applied.push(catalogOrPriceRequest ? "catalog_request_before_name_to_name_question" : "specific_request_before_name_to_name_question");
    }
    text = greetingText;
    if (mediaActions.length > 0) {
      applied.push("clear_media_before_name");
    }
    mediaActions = [];
    return { text, mediaActions, applied };
  }
  if (genericInitialInterest) {
    if (normalizeFkSemijoiasText(text) !== normalizeFkSemijoiasText(greetingText) || hasGreetingAction) {
      applied.push("generic_initial_interest_to_name_question");
    }
    text = greetingText;
    mediaActions = dropGreetingOpeningActions(mediaActions);
    return { text, mediaActions, applied };
  }
  if (catalogOrPriceRequest) {
    if (normalizeFkSemijoiasText(text) !== normalizeFkSemijoiasText(FK_SEMIJOIAS_CATALOG_FALLBACK)) {
      applied.push("catalog_request_fallback");
    }
    text = FK_SEMIJOIAS_CATALOG_FALLBACK;
    if (hasGreetingAction || hasVideoAction) {
      mediaActions = dropFkSemijoiasOpeningAndVideoActions(mediaActions);
      applied.push("drop_conflicting_media_after_catalog_request");
    }
    return { text, mediaActions, applied };
  }
  if (productOrVideoRequest || videoPromise || hasVideoAction) {
    if (productOrVideoRequest || !text || videoPromise) {
      text = FK_SEMIJOIAS_VIDEO_REPLY;
      applied.push("product_or_video_request_video");
    }
    const nextMediaActions = ensureFkSemijoiasVideoAction(mediaActions);
    if (hasGreetingAction || !hasVideoAction || nextMediaActions.length !== mediaActions.length) {
      applied.push("ensure_video_media_after_product_request");
    }
    mediaActions = nextMediaActions;
    return { text, mediaActions, applied };
  }
  if (catalogDigitalPromise) {
    text = firstAgentResponse ? greetingText : FK_SEMIJOIAS_CATALOG_FALLBACK;
    mediaActions = dropFkSemijoiasOpeningAndVideoActions(mediaActions);
    applied.push(firstAgentResponse ? "catalog_drift_to_name_question" : "catalog_drift_fallback");
    return { text, mediaActions, applied };
  }
  if (hasGreetingAction && normalizeFkSemijoiasText(text) === normalizeFkSemijoiasText(greetingText)) {
    mediaActions = dropGreetingOpeningActions(mediaActions);
    applied.push("drop_duplicate_opening_greeting");
  }
  return { text, mediaActions, applied };
}

// server/ticoLocacoesModule.ts
var TICO_LOCACOES_USER_ID = "58384f20-dc1b-416f-bc18-62ae9e812d85";
var TICO_TOYS = [
  {
    key: "cama_elastica_p",
    label: "Cama Elastica P",
    mediaName: "CAMA_ELASTICA_P",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224119123_815576ff.jpg",
    measure: "2,30m",
    price1: "R$150",
    price2: "R$230",
    price3: "R$320",
    keywords: ["cama elastica p", "cama elastica pequena", "cama pequena", "cama elastica"]
  },
  {
    key: "cama_elastica_m",
    label: "Cama Elastica M",
    mediaName: "CAMA_ELASTICA_M",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224140411_45eb757d.jpg",
    measure: "3,00m",
    price1: "R$160",
    price2: "R$240",
    price3: "R$330",
    keywords: ["cama elastica m", "cama elastica media", "cama media"]
  },
  {
    key: "cama_elastica_g",
    label: "Cama Elastica G",
    mediaName: "CAMA_ELASTICA_G",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224156034_2b296ad8.jpg",
    measure: "3,70m",
    price1: "R$170",
    price2: "R$250",
    price3: "R$350",
    keywords: ["cama elastica g", "cama elastica grande", "cama grande"]
  },
  {
    key: "piscina_casinha",
    label: "Piscina de Bolinhas Casinha",
    mediaName: "PISCINA_DE_BOLINHAS_CASINHA",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224197410_5840c66d.jpg",
    measure: "1,50x1,50m",
    price1: "R$150",
    price2: "R$230",
    price3: "R$320",
    keywords: ["piscina bolinha casinha", "piscina de bolinhas casinha", "piscina casinha", "bolinhas casinha"]
  },
  {
    key: "piscina_inflavel",
    label: "Piscina de Bolinhas Inflavel",
    mediaName: "PISCINA_DE_BOLINHAS_INFLAVEL",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224231020_af59ba7b.jpg",
    measure: "2,50x2,50m",
    price1: "R$180",
    price2: "R$270",
    price3: "R$370",
    keywords: ["piscina bolinha inflavel", "piscina de bolinhas inflavel", "piscina inflavel"]
  },
  {
    key: "castelinho",
    label: "Castelinho Inflavel",
    mediaName: "CASTELINHO_INFLAVEL",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224283607_9d968603.jpg",
    measure: "3,20x3,20m",
    price1: "R$220",
    price2: "R$330",
    price3: "R$450",
    keywords: ["castelinho", "castelo"]
  },
  {
    key: "bob_esponja",
    label: "Bob Esponja Inflavel",
    mediaName: "BOB_ESPONJA_INFLAVEL",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224323465_c03d9363.jpg",
    measure: "2,20x5,50x3,30m",
    price1: "R$300",
    price2: "R$450",
    price3: "R$620",
    keywords: ["bob esponja", "bob"]
  },
  {
    key: "toboga",
    label: "Toboga Inflavel",
    mediaName: "TOBOGA_INFLAVEL",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224363286_88c4e77a.jpg",
    measure: "3,00x5,00x4,20m",
    price1: "R$350",
    price2: "R$520",
    price3: "R$720",
    keywords: ["toboga", "tobogao", "toboga inflavel"]
  },
  {
    key: "guerra_cotonetes",
    label: "Guerra de Cotonetes",
    mediaName: "GUERRA_DE_COTONETES_INFLAVEL",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224389424_42553133.jpg",
    measure: "5,20x5,20x1,80m",
    price1: "R$390",
    price2: "R$600",
    price3: "R$830",
    keywords: ["guerra de cotonete", "guerra de cotonetes", "cotonete", "cotonetes"]
  },
  {
    key: "futebol_sabao",
    label: "Futebol de Sabao Inflavel",
    mediaName: "FUTEBOL_DE_SABAO_INFLAVEL",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224439580_68d62208.png",
    mimeType: "image/png",
    measure: "4,00x8,00x1,80m",
    price1: "R$700",
    price2: "R$1070",
    price3: "R$1490",
    keywords: ["futebol de sabao", "futebol sabao", "futebol"]
  },
  {
    key: "aero_hockey",
    label: "Aero Hockey",
    mediaName: "AERO_HOCKEY",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224537532_96400f0d.jpg",
    measure: "jogo de mesa",
    price1: "R$170",
    price2: "R$260",
    price3: "R$360",
    keywords: ["aero hockey", "hockey"]
  },
  {
    key: "pebolim",
    label: "Pebolim",
    mediaName: "PEBOLIM",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224516198_8c76539c.jpg",
    measure: "jogo de mesa",
    price1: "R$170",
    price2: "R$260",
    price3: "R$360",
    keywords: ["pebolim"]
  },
  {
    key: "ping_pong",
    label: "Ping Pong",
    mediaName: "PING_PONG",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224492574_131a4d2f.jpg",
    measure: "jogo de mesa",
    price1: "R$170",
    price2: "R$260",
    price3: "R$360",
    keywords: ["ping pong", "ping-pong"]
  },
  {
    key: "algodao_doce",
    label: "Maquina de Algodao Doce",
    mediaName: "MAQUINA_DE_ALGODAO_DOCE",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224593334_27d98bb1.jpg",
    measure: "servico para evento",
    price1: "R$170",
    price2: "R$250",
    price3: "R$320",
    keywords: ["algodao doce", "maquina de algodao"]
  },
  {
    key: "mesas_cadeiras",
    label: "Mesas e Cadeiras",
    mediaName: "MESAS_E_CADEIRAS",
    mediaUrl: "https://bnfpcuzjvycudccycqqt.supabase.co/storage/v1/object/public/whatsapp-media/system/1779224611763_509b04fa.jpg",
    measure: "conjunto",
    price1: "R$22",
    price2: "R$33",
    price3: "R$44",
    keywords: ["mesa", "mesas", "cadeira", "cadeiras"]
  }
];
var DEFAULT_OPTIONS = ["cama_elastica_p", "piscina_casinha", "castelinho"];
var OLDER_KIDS_OPTIONS = ["futebol_sabao", "guerra_cotonetes", "ping_pong"];
function isTicoLocacoesTenant(userId) {
  return String(userId || "").trim() === TICO_LOCACOES_USER_ID;
}
function normalizeText(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
function includesAny(text, terms) {
  return terms.some((term) => text.includes(term));
}
function hasTicoMediaOrPriceIntent(text) {
  return includesAny(text, [
    "foto",
    "fotos",
    "imagem",
    "imagens",
    "video",
    "videos",
    "catalogo",
    "opcoes",
    "opcao",
    "mostrar",
    "mostra",
    "ver",
    "valor",
    "preco",
    "orcamento",
    "alugar",
    "locar",
    "brinquedo",
    "brinquedos"
  ]);
}
function findToyByKey(key) {
  return TICO_TOYS.find((toy) => toy.key === key) || null;
}
function detectRequestedToys(normalizedMessage) {
  const selected = /* @__PURE__ */ new Map();
  for (const toy of TICO_TOYS) {
    if (toy.key === "cama_elastica_p" && includesAny(normalizedMessage, ["cama elastica grande", "cama elastica g", "cama elastica media", "cama elastica m", "cama media"])) {
      continue;
    }
    if (toy.key === "cama_elastica_m" && includesAny(normalizedMessage, ["cama elastica grande", "cama elastica g"])) {
      continue;
    }
    if (toy.key === "piscina_casinha" && normalizedMessage.includes("piscina") && normalizedMessage.includes("inflavel")) {
      continue;
    }
    if (toy.key === "piscina_inflavel" && normalizedMessage.includes("piscina") && normalizedMessage.includes("casinha")) {
      continue;
    }
    if (includesAny(normalizedMessage, toy.keywords.map(normalizeText))) {
      selected.set(toy.key, toy);
    }
  }
  if (normalizedMessage.includes("piscina") && !selected.has("piscina_casinha") && !selected.has("piscina_inflavel")) {
    for (const key of ["piscina_casinha", "piscina_inflavel"]) {
      const toy = findToyByKey(key);
      if (toy) selected.set(toy.key, toy);
    }
  }
  return [...selected.values()];
}
function detectBroadOptions(normalizedMessage) {
  const isBroadCatalog = includesAny(normalizedMessage, ["catalogo", "opcoes", "quais brinquedos", "brinquedos voces tem", "brinquedos disponiveis"]);
  if (!isBroadCatalog) return [];
  const keys = /\b(10|11|12|13|14|15)\s*anos\b/.test(normalizedMessage) || normalizedMessage.includes("maiores") ? OLDER_KIDS_OPTIONS : DEFAULT_OPTIONS;
  return keys.map(findToyByKey).filter((toy) => Boolean(toy));
}
function formatToyLine(toy) {
  const prices = [toy.price1 ? `1 dia ${toy.price1}` : "", toy.price2 ? `2 dias ${toy.price2}` : "", toy.price3 ? `3 dias ${toy.price3}` : ""].filter(Boolean).join(" | ");
  return `- ${toy.label}: ${toy.measure}${prices ? ` | ${prices}` : ""}.`;
}
function buildToyMediaAction(toy) {
  if (toy.mediaUrl) {
    return {
      type: "send_media_url",
      media_name: toy.mediaName,
      media_url: toy.mediaUrl,
      media_type: "image",
      mime_type: toy.mimeType || "image/jpeg"
    };
  }
  return {
    type: "send_media",
    media_name: toy.mediaName
  };
}
function buildTicoLocacoesDeterministicTurn(params) {
  if (!isTicoLocacoesTenant(params.userId)) return null;
  const normalizedMessage = normalizeText(params.message);
  if (!normalizedMessage) return null;
  let requestedToys = detectRequestedToys(normalizedMessage);
  const broadOptions = requestedToys.length > 0 ? [] : detectBroadOptions(normalizedMessage);
  const asksContextualMedia = requestedToys.length === 0 && broadOptions.length === 0 && includesAny(normalizedMessage, [
    "foto",
    "fotos",
    "imagem",
    "imagens",
    "manda",
    "mande",
    "mandar",
    "envia",
    "envie",
    "enviar",
    "mostra",
    "mostrar",
    "ver"
  ]);
  if (asksContextualMedia) {
    const normalizedContext = normalizeText(params.contextText);
    requestedToys = detectRequestedToys(normalizedContext).slice(0, 3);
  }
  const selected = (requestedToys.length > 0 ? requestedToys : broadOptions).slice(0, 3);
  if (selected.length === 0 || !hasTicoMediaOrPriceIntent(normalizedMessage)) {
    return null;
  }
  const intro = selected.length === 1 ? `Separei esta opcao para voce:` : `Separei ${selected.length} opcoes para voce:`;
  const text = [
    intro,
    ...selected.map(formatToyLine),
    "A disponibilidade e verificada apenas pelo nosso time apos analise dos dados, ta bom?",
    "Para fechar o orcamento, me passa a data do evento e o bairro/regiao?"
  ].join("\n");
  return {
    text,
    mediaActions: selected.map(buildToyMediaAction),
    mode: "tico_locacoes_media",
    matchedKeys: selected.map((toy) => toy.key)
  };
}

// server/schoolTriageGuard.ts
var SECTORS = {
  sabrina: {
    key: "sabrina",
    label: "Sabrina",
    link: "https://wa.me/5514998391204"
  },
  aline: {
    key: "aline",
    label: "Aline",
    link: "https://wa.me/551438412514"
  },
  maite: {
    key: "maite",
    label: "Mait\xEA",
    link: "https://wa.me/5514997583372"
  },
  sonia: {
    key: "sonia",
    label: "Sonia",
    link: "https://wa.me/5514996747816"
  },
  francieli: {
    key: "francieli",
    label: "Francieli",
    link: "https://wa.me/5514998620954"
  }
};
function normalizeSchoolText(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim();
}
function hasSchoolTriageMarker(prompt) {
  const normalized = normalizeSchoolText(prompt);
  return normalized.includes("agentezap escola triagem") || normalized.includes("colegio liceu arcanjos") && normalized.includes("lista de setores e links") && normalized.includes("alunos atendidos");
}
function extractMarkedBlock(prompt, key) {
  const pattern = new RegExp(
    `${key}\\s*:\\s*([\\s\\S]*?)(?=\\n\\s*[A-Z0-9_]+\\s*:|\\n\\s*\\[/AGENTEZAP_ESCOLA_TRIAGEM\\]|$)`,
    "i"
  );
  return pattern.exec(prompt)?.[1] || "";
}
function extractPdfStyleBlock(prompt, startPattern, endPatterns) {
  const startMatch = startPattern.exec(prompt);
  if (!startMatch || typeof startMatch.index !== "number") return "";
  const rest = prompt.slice(startMatch.index + startMatch[0].length);
  const endIndexes = endPatterns.map((pattern) => pattern.exec(rest)?.index ?? -1).filter((index) => index >= 0);
  const end = endIndexes.length ? Math.min(...endIndexes) : rest.length;
  return rest.slice(0, end);
}
function extractNamesFromBlock(block) {
  return block.replace(/--\s*\d+\s+of\s+\d+\s*--/gi, " ").split(/,|\n|;/).map((name) => name.trim().replace(/\s+/g, " ")).filter((name) => name.length >= 6 && /[A-Za-zÀ-ÿ]/.test(name)).filter((name) => !/^(cargo|nome|whatsapp|funcoes|lista|setor|alunos atendidos)/i.test(name));
}
function loadSchoolStudentLists(prompt) {
  const marked = {
    maite: extractNamesFromBlock(extractMarkedBlock(prompt, "SETOR_MAITE_ALUNOS")),
    sonia: extractNamesFromBlock(extractMarkedBlock(prompt, "SETOR_SONIA_ALUNOS")),
    francieli: extractNamesFromBlock(extractMarkedBlock(prompt, "SETOR_FRANCIELI_ALUNOS"))
  };
  if (marked.maite.length || marked.sonia.length || marked.francieli.length) {
    return marked;
  }
  const maite = extractPdfStyleBlock(
    prompt,
    /ALUNOS\s+ATENDIDOS\s+PELA\s+MAIT[ÊE]\s*:/i,
    [/Cargo:\s*Coordenadora/i, /ALUNOS\s+ATENDIDOS\s+PELA\s+DONA\s+SONIA/i, /ALUNOS\s+ATENDIDOS\s+PELA\s+SONIA/i]
  );
  const sonia = extractPdfStyleBlock(
    prompt,
    /ALUNOS\s+ATENDIDOS\s+PELA\s+(?:DONA\s+)?SONIA\s*:/i,
    [/Cargo:\s*Coordenadora/i, /ALUNOS\s+ATENDIDOS\s+PELA\s+FRANCIELI/i]
  );
  const francieli = extractPdfStyleBlock(
    prompt,
    /ALUNOS\s+ATENDIDOS\s+PELA\s+FRANCIELI\s*:/i,
    [/LISTA\s+DE\s+SETORES/i, /\[\/AGENTEZAP_ESCOLA_TRIAGEM\]/i]
  );
  return {
    maite: extractNamesFromBlock(maite),
    sonia: extractNamesFromBlock(sonia),
    francieli: extractNamesFromBlock(francieli)
  };
}
function findStudentSector(message, lists) {
  const normalizedMessage = normalizeSchoolText(message);
  for (const sector of ["maite", "sonia", "francieli"]) {
    for (const name of lists[sector]) {
      const normalizedName = normalizeSchoolText(name);
      if (normalizedName && normalizedMessage.includes(normalizedName)) {
        return { sector, name };
      }
    }
  }
  return null;
}
function classifyAdministrativeSubject(normalizedMessage) {
  if (/\b(matricula|matriculas|vaga|vagas|mensalidade|mensalidades|pagamento|pagar|boleto|pix|comprovante|dinheiro|financeiro|imposto|renda|nota fiscal|notas fiscais|cantina|excursao|uniforme|uniformes|eduxe|sloop|formatura|formaturas|evento|eventos|carteirinha|curriculo|curriculum|aniversariante|psicolog)\b/.test(normalizedMessage)) {
    return "sabrina";
  }
  if (/\b(historico|declaracao|ballet|xadrez|horario de aula|horario das aulas|impressao|imprimir|atividade impressa|prova impressa|medicamento|remedio|mochila|sair mais cedo|saida antecipada)\b/.test(normalizedMessage)) {
    return "aline";
  }
  if (/\b(olimpiada|olimpiadas)\b/.test(normalizedMessage)) {
    return "francieli";
  }
  return null;
}
function hasExternalSchoolContactSubject(normalizedMessage) {
  const hasExternalSignal = /\b(consultoria|consultor|consultora|fornecedor|fornecedora|parceria|empresa|grupo rabbit|sympla|evento online|proposta|apresentar|apresentacao|comercial|vendedor|vendedora|prestador|prestadora|treinamento|palestra|curso|servico educacional|servicos educacionais|escola crescer|horario disponivel|horarios disponiveis|atendimento comercial)\b/.test(normalizedMessage);
  if (!hasExternalSignal) return false;
  const hasGuardianOrStudentSignal = /\b(mae|pai|responsavel|filho|filha|aluno|aluna|estudante|serie|turma|matricula|mensalidade|boleto|pix|comprovante|declaracao|historico|falta|faltou|prova|remarcar|atestado)\b/.test(normalizedMessage);
  return !hasGuardianOrStudentSignal;
}
function hasPedagogicalSubject(normalizedMessage) {
  return /\b(atestado|falta|faltar|faltou|ausencia|ausente|viagem|viajar|tarefa|atividade|roupa|festa|prova|remarcar|relatorio|comportamental|educacional|pedagogico|professor|professora|coordenadora|coordenador)\b/.test(normalizedMessage);
}
function formatSchoolRoute(sectorKey, matchedStudent) {
  const sector = SECTORS[sectorKey];
  const subject = matchedStudent ? ` do(a) ${matchedStudent}` : "";
  return {
    handled: true,
    sector: sector.key,
    matchedStudent,
    reason: "school_triage_route",
    text: `Entendi. Para esse assunto${subject}, fale com ${sector.label}:
${sector.link}`
  };
}
function buildSchoolTriageResponseFromPrompt(params) {
  const prompt = String(params.prompt || "");
  const message = String(params.message || "").trim();
  if (!message || !hasSchoolTriageMarker(prompt)) return null;
  const normalizedMessage = normalizeSchoolText(message);
  const isOnlyGreeting = /^(oi|ola|olá|bom dia|boa tarde|boa noite|tudo bem|boa)$/.test(message.trim().toLowerCase());
  if (isOnlyGreeting) {
    return {
      handled: true,
      reason: "school_triage_missing_context",
      text: "Ol\xE1! Para te encaminhar certinho, me informe o nome completo do aluno(a) e o assunto, por favor."
    };
  }
  if (hasExternalSchoolContactSubject(normalizedMessage)) {
    return {
      handled: true,
      reason: "school_triage_external_contact",
      text: "Entendi. Esse e um contato externo/comercial. Para encaminhar corretamente, me confirme seu nome, empresa, assunto resumido e melhor telefone ou horario de retorno, por favor."
    };
  }
  const administrativeSector = classifyAdministrativeSubject(normalizedMessage);
  if (administrativeSector === "sabrina" || administrativeSector === "aline") {
    return formatSchoolRoute(administrativeSector);
  }
  const lists = loadSchoolStudentLists(prompt);
  const matchedStudent = findStudentSector(message, lists);
  if (administrativeSector === "francieli") {
    return formatSchoolRoute("francieli", matchedStudent?.name);
  }
  if (matchedStudent && hasPedagogicalSubject(normalizedMessage)) {
    return formatSchoolRoute(matchedStudent.sector, matchedStudent.name);
  }
  if (matchedStudent) {
    return {
      handled: true,
      sector: matchedStudent.sector,
      matchedStudent: matchedStudent.name,
      reason: "school_triage_missing_subject",
      text: `Encontrei o(a) aluno(a) ${matchedStudent.name}. Qual \xE9 o assunto para eu te encaminhar certinho?`
    };
  }
  if (hasPedagogicalSubject(normalizedMessage)) {
    return {
      handled: true,
      reason: "school_triage_missing_student",
      text: "Para te encaminhar \xE0 coordena\xE7\xE3o correta, me informe o nome completo do aluno(a) e a s\xE9rie/turma, por favor."
    };
  }
  return {
    handled: true,
    sector: "sabrina",
    reason: "school_triage_fallback",
    text: `Entendi. Para esse assunto, fale com Sabrina:
${SECTORS.sabrina.link}`
  };
}

// server/vicosaPizzaResponseGuard.ts
var VICOSA_PIZZA_USER_ID = "49cc61e1-412c-4c5a-a5a6-e64e548443dc";
var KNOWN_HALF_HALF_PAIRS = [
  {
    key: "calabresa_carne_do_sol_especial",
    name: "Calabresa + Carne do Sol Especial",
    match: [["calabresa"], ["carne do sol"]],
    smallPrice: "R$34,00",
    largePrice: "R$40,00"
  },
  {
    key: "calabresa_frango_catupiry",
    name: "Calabresa + Frango com Catupiry",
    match: [["calabresa"], ["frango"]],
    smallPrice: "R$26,00",
    largePrice: "R$33,00"
  }
];
function normalizeVicosaText(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
function isVicosaPizzaUser(userId) {
  return String(userId || "").trim() === VICOSA_PIZZA_USER_ID;
}
function hasAny(text, terms) {
  return terms.some((term) => text.includes(term));
}
function hasMenuHandoffMode(params) {
  if (params.menuHandoffOnly === true) return true;
  const promptText = normalizeVicosaText(params.prompt);
  return promptText.includes("calibracao_vicosa_menu_humano_2026_05_28") || promptText.includes("somente boas-vindas") && promptText.includes("cardapio") && promptText.includes("equipe humana");
}
function hasMenuWithoutHandoffMode(prompt) {
  return normalizeVicosaText(prompt).includes("calibracao_vicosa_cardapio_sem_handoff_2026_05_29");
}
function hasMenuHandoffIntent(text) {
  return hasAny(text, [
    "oi",
    "ola",
    "bom dia",
    "boa tarde",
    "boa noite",
    "cardapio",
    "menu",
    "opcoes",
    "preco",
    "precos",
    "valor",
    "taxa",
    "entrega",
    "prazo",
    "tempo",
    "demora",
    "delivery",
    "pedido",
    "pedir",
    "pizza",
    "calabresa",
    "hamburguer",
    "lanche",
    "endereco",
    "pagamento",
    "pix",
    "troco"
  ]);
}
function buildMenuHandoffReply(params) {
  if (params?.withoutHandoff) {
    return "Vou te enviar o cardapio oficial da Vicosa Pizza Burguer.";
  }
  return "Vou te enviar o cardapio oficial da Vicosa Pizza Burguer. A equipe da loja vai continuar o atendimento por aqui e confirmar pedido, valor final e taxa de entrega.";
}
function detectKnownHalfHalfPair(text) {
  return KNOWN_HALF_HALF_PAIRS.find(
    (pair) => pair.match.every((terms) => terms.some((term) => text.includes(term)))
  ) || null;
}
function wantsSmallPizza(text) {
  return /\b(p|pequena|peq)\b/.test(text);
}
function wantsLargePizza(text) {
  return /\b(g|grande)\b/.test(text);
}
function buildHalfHalfReply(messageText, isSummaryTurn, pair) {
  const small = wantsSmallPizza(messageText);
  const large = wantsLargePizza(messageText);
  const sizeText = small && !large ? "P/pequena" : "G/grande";
  const priceText = small && !large ? pair.smallPrice : pair.largePrice;
  if (isSummaryTurn) {
    return [
      `Resumo do pedido: 1 pizza ${sizeText} metade ${pair.name}.`,
      `O valor da pizza \xE9 ${priceText}, porque no meio a meio vale o sabor de maior valor.`,
      "Para fechar, envie a localiza\xE7\xE3o e confirme se quer borda.",
      "Depois disso, a equipe da loja confirma a taxa de entrega e envia o valor final pelo WhatsApp."
    ].join("\n");
  }
  if (small && !large) {
    return `A pizza P/pequena meio a meio ${pair.name} fica ${pair.smallPrice}, porque no meio a meio vale o sabor de maior valor. Quer confirmar a P mesmo?`;
  }
  if (large && !small) {
    return `A pizza G/grande meio a meio ${pair.name} fica ${pair.largePrice}, porque no meio a meio vale o sabor de maior valor. Quer confirmar a G mesmo?`;
  }
  return `A pizza meio a meio ${pair.name} segue o valor do sabor mais caro. Na G/grande fica ${pair.largePrice}. Na P/pequena fica ${pair.smallPrice}. Qual tamanho voc\xEA quer confirmar?`;
}
function buildNoMediumReply(messageText) {
  if (messageText.includes("calabresa")) {
    return "Na Vi\xE7osa Pizza Burguer n\xE3o trabalhamos com pizza m\xE9dia. Temos apenas P/pequena (4 fatias) e G/grande (8 fatias). A Calabresa custa R$25,00 na P e R$31,00 na G. Qual tamanho voc\xEA prefere?";
  }
  return "Na Vi\xE7osa Pizza Burguer n\xE3o trabalhamos com pizza m\xE9dia. Temos apenas P/pequena (4 fatias) e G/grande (8 fatias). Qual tamanho voc\xEA prefere?";
}
function buildDeliveryFeeReply() {
  return "A entrega fica em at\xE9 30 minutos depois da confirma\xE7\xE3o da loja. Para calcular a taxa e o valor final, envie endere\xE7o completo, ponto de refer\xEAncia e localiza\xE7\xE3o. A equipe da loja confirma tudo pelo WhatsApp.";
}
function buildArtifactFallbackReply() {
  return "Para fechar o pedido, me confirme o tamanho, os sabores, a forma de pagamento, o endere\xE7o completo, o ponto de refer\xEAncia e a localiza\xE7\xE3o. A equipe da loja confirma a taxa de entrega e o valor final pelo WhatsApp.";
}
function hasVicosaMenuMediaAction(mediaActions) {
  return mediaActions.some((action) => {
    const mediaName = normalizeVicosaText(action?.media_name || action?.mediaName || "");
    if (mediaName.includes("saudacao_info_extra") || mediaName.includes("cardapio_vicosa")) {
      return true;
    }
    return action?.type === "send_media_url" && normalizeVicosaText(action?.caption).includes("cardapio vicosa");
  });
}
function ensureVicosaPizzaMenuMediaAction(mediaActions, guardResult) {
  if (guardResult.shouldSendMenuMedia !== true) return mediaActions;
  if (hasVicosaMenuMediaAction(mediaActions)) return mediaActions;
  return [
    ...mediaActions,
    {
      type: "send_media",
      media_name: "CARDAPIO_VICOSA"
    }
  ];
}
function applyVicosaPizzaResponseGuard(params) {
  const originalText = String(params.text || "");
  if (!isVicosaPizzaUser(params.userId)) {
    return { text: originalText, applied: [] };
  }
  const messageText = normalizeVicosaText(params.message);
  const responseText = normalizeVicosaText(originalText);
  const combinedText = `${messageText}
${responseText}`;
  const applied = [];
  if (hasMenuHandoffMode(params)) {
    const withoutHandoff = hasMenuWithoutHandoffMode(params.prompt);
    const shouldReplace = hasMenuHandoffIntent(messageText) || hasAny(responseText, [
      "anotad",
      "confirme",
      "qual tamanho",
      "qual sabor",
      "endereco",
      "pagamento",
      "pix",
      "troco",
      "30 minutos",
      "taxa",
      "valor final"
    ]);
    if (shouldReplace) {
      applied.push("menu_handoff_only");
      return {
        text: buildMenuHandoffReply({ withoutHandoff }),
        applied,
        shouldSendMenuMedia: true
      };
    }
    return { text: originalText, applied };
  }
  const mentionsMediumPizza = messageText.includes("pizza") && hasAny(messageText, [" media", "media ", "medio", "m\xE9dia"]) || hasAny(responseText, ["pizza media", "pizza m\xE9dia", "media (g", "m\xE9dia (g", "temos pizza media", "temos pizza m\xE9dia"]);
  if (mentionsMediumPizza) {
    applied.push("no_medium_pizza");
    return { text: buildNoMediumReply(messageText), applied };
  }
  const halfHalfPair = detectKnownHalfHalfPair(combinedText);
  const mentionsHalfHalf = hasAny(combinedText, ["meio a meio", "meia", "metade", "1/2", "meio"]) && Boolean(halfHalfPair);
  const hasBadHalfHalfPrice = Boolean(halfHalfPair) && (hasAny(responseText, ["69,90", "69.90", "r$69", "soma", "somar", "somando"]) || /r\$\s*x{2}/i.test(originalText) || /r\$\s*y{2}/i.test(originalText));
  const hasOutputArtifact = /r\$\s*x{2}/i.test(originalText) || /r\$\s*y{2}/i.test(originalText) || hasAny(responseText, ["formatada de acordo", "suponha", "verifique o cardapio"]);
  const isSummaryTurn = hasAny(messageText, ["resumo", "resuma", "pedido", "rua", "pix", "endereco", "endere\xE7o"]);
  if (halfHalfPair && (mentionsHalfHalf || hasBadHalfHalfPrice)) {
    applied.push(`half_half_highest_price:${halfHalfPair.key}`);
    return { text: buildHalfHalfReply(messageText, isSummaryTurn, halfHalfPair), applied };
  }
  const asksDeliveryFeeOrTime = hasAny(messageText, ["taxa", "entrega", "prazo", "tempo", "demora", "delivery"]);
  const claimsFreeOrZeroFee = hasAny(responseText, ["taxa gratis", "taxa gr\xE1tis", "sem taxa", "r$0,00", "r$ 0,00"]);
  if (asksDeliveryFeeOrTime || claimsFreeOrZeroFee) {
    applied.push("delivery_fee_final_by_store");
    return { text: buildDeliveryFeeReply(), applied };
  }
  if (hasOutputArtifact) {
    applied.push("artifact_fallback");
    return { text: buildArtifactFallbackReply(), applied };
  }
  return { text: originalText, applied };
}

// server/rodrigoMetaFunnelService.ts
import { and, desc, eq, inArray, sql } from "drizzle-orm";

// server/rodrigoMetaFunnelHelpers.ts
var DEFAULT_QUALIFIED_LEAD_MIN_SCORE = 80;
function cleanText(value, maxLength = 512) {
  const text = String(value ?? "").trim();
  if (!text) return null;
  return text.length > maxLength ? text.slice(0, maxLength) : text;
}
function asRecord(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function isUsableRodrigoSubscriptionPhoneCandidateValue(value) {
  const text = String(value ?? "").trim();
  if (!text) return false;
  if (/^(sim|test|demo|mock|fake)[-_]/i.test(text)) return false;
  const digits = normalizePhoneToDigits(text);
  return digits.length >= 10;
}
function pushPhoneValue(target, value) {
  if (isUsableRodrigoSubscriptionPhoneCandidateValue(value)) {
    target.push(value);
  }
}
function collectMetadataPhoneValues(metadata) {
  const values = [];
  const keys = [
    "phone",
    "phoneNumber",
    "phone_number",
    "telefone",
    "celular",
    "mobile",
    "whatsapp",
    "whatsappNumber",
    "whatsapp_number",
    "customerPhone",
    "customer_phone",
    "checkoutPhone",
    "checkout_phone",
    "payerPhone",
    "payer_phone",
    "contactPhone",
    "contact_phone",
    "leadPhone",
    "lead_phone"
  ];
  for (const key of keys) {
    pushPhoneValue(values, metadata?.[key]);
  }
  return values;
}
function collectPaymentPhoneValues(rawResponse) {
  const values = [];
  const payerPhone = asRecord(asRecord(rawResponse?.payer).phone);
  const additionalPayerPhone = asRecord(asRecord(asRecord(rawResponse?.additional_info).payer).phone);
  for (const phone of [payerPhone, additionalPayerPhone]) {
    pushPhoneValue(values, phone.number);
    pushPhoneValue(values, phone.phoneNumber);
    pushPhoneValue(values, phone.phone_number);
    const areaCode = cleanText(phone.area_code || phone.areaCode, 8);
    const number = cleanText(phone.number || phone.phoneNumber || phone.phone_number, 32);
    if (areaCode && number) {
      pushPhoneValue(values, `${areaCode}${number}`);
    }
  }
  pushPhoneValue(values, rawResponse?.phone);
  pushPhoneValue(values, rawResponse?.phoneNumber);
  pushPhoneValue(values, rawResponse?.whatsapp);
  pushPhoneValue(values, rawResponse?.whatsappNumber);
  return values;
}
function buildRodrigoSubscriptionPhoneCandidates(input, extraValues = []) {
  const values = [
    input.phone,
    input.whatsappNumber,
    ...collectMetadataPhoneValues(asRecord(input.metadata)),
    ...collectPaymentPhoneValues(asRecord(input.paymentRawResponse)),
    ...extraValues
  ];
  const candidates = /* @__PURE__ */ new Set();
  for (const value of values) {
    if (!isUsableRodrigoSubscriptionPhoneCandidateValue(value)) continue;
    const digits = normalizePhoneToDigits(String(value || ""));
    if (digits) {
      candidates.add(digits);
      candidates.add(`+${digits}`);
    }
    for (const variant of buildBrazilWhatsAppPhoneVariants(String(value || ""))) {
      candidates.add(variant);
      candidates.add(`+${variant}`);
    }
  }
  return Array.from(candidates).filter(Boolean);
}
function normalizeRodrigoWhatsappAdsAttribution(input) {
  const source = asRecord(input);
  const attribution = {
    ctwaClid: cleanText(source.ctwaClid ?? source.ctwa_clid, 1024),
    sourceId: cleanText(source.sourceId ?? source.source_id, 128),
    sourceUrl: cleanText(source.sourceUrl ?? source.source_url, 1024),
    sourceType: cleanText(source.sourceType ?? source.source_type, 64),
    title: cleanText(source.title ?? source.headline, 256),
    body: cleanText(source.body, 512),
    mediaType: cleanText(source.mediaType ?? source.media_type, 64),
    thumbnailUrl: cleanText(source.thumbnailUrl ?? source.thumbnail_url, 1024),
    capturedAt: cleanText(source.capturedAt ?? source.captured_at, 64),
    messageId: cleanText(source.messageId ?? source.message_id, 128)
  };
  return attribution.ctwaClid || attribution.sourceId || attribution.sourceUrl || attribution.sourceType ? attribution : null;
}
function pickBestRodrigoWhatsappAdsAttribution(...candidates) {
  const normalized = candidates.map((candidate) => normalizeRodrigoWhatsappAdsAttribution(candidate)).filter(Boolean);
  if (!normalized.length) return null;
  return normalized.find((candidate) => Boolean(candidate.ctwaClid)) || normalized[0];
}
function buildRodrigoMetaFunnelEventKey(eventName, eventId) {
  return `${String(eventName || "").trim()}:${String(eventId || "").trim()}`;
}
function shouldSendRodrigoQualifiedLeadEvent(input) {
  const minScore = Math.max(
    1,
    Number(process.env.RODRIGO_META_QUALIFIED_LEAD_MIN_SCORE || DEFAULT_QUALIFIED_LEAD_MIN_SCORE)
  );
  const grade = String(input.potentialGrade || "").trim().toLowerCase();
  return Boolean(input.isPotential) && Number(input.potentialScore || 0) >= minScore && grade !== "descartar";
}

// server/rodrigoMetaFunnelService.ts
var RODRIGO_META_OWNER_EMAIL = "rodrigo4@gmail.com";
var RODRIGO_META_FUNNEL_VERSION = "rodrigo-meta-funnel-v1";
function cleanText2(value, maxLength = 512) {
  const text = String(value ?? "").trim();
  if (!text) return null;
  return text.length > maxLength ? text.slice(0, maxLength) : text;
}
function asRecord2(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function normalizeDigits(value) {
  return String(value || "").replace(/\D+/g, "");
}
function getFunnelEvents(rawAnalysis) {
  return asRecord2(rawAnalysis.metaCapiFunnelEvents);
}
function mergeFunnelEventRecord(rawAnalysis, eventKey, record) {
  return {
    ...rawAnalysis,
    metaCapiFunnelEvents: {
      ...getFunnelEvents(rawAnalysis),
      [eventKey]: record
    }
  };
}
function parseMoney(value) {
  const parsed = Number.parseFloat(String(value ?? "0").replace(",", "."));
  return Number.isFinite(parsed) ? parsed : 0;
}
function normalizeStatus(value) {
  return String(value || "").trim().toLowerCase();
}
function isPaidSubscriptionBackfillCandidate(row) {
  const status = normalizeStatus(row.status);
  const value = getSubscriptionBackfillValue(row);
  return value > 0 && (Boolean(row.paymentHistoryId) || status === "active" || status === "paid" || status === "confirmed");
}
function isCheckoutSubscriptionBackfillCandidate(row) {
  return !row.paymentHistoryId && normalizeStatus(row.status) === "pending_pix";
}
function getSubscriptionBackfillValue(row) {
  return parseMoney(row.paymentAmount) || parseMoney(row.couponPrice) || parseMoney(row.planValue);
}
function getSubscriptionBackfillPaymentId(row) {
  return cleanText2(row.mpPaymentId, 128) || cleanText2(row.paymentHistoryId, 128);
}
async function getRodrigoOwnerUserId() {
  const [owner] = await db.select({ id: users.id }).from(users).where(eq(users.email, RODRIGO_META_OWNER_EMAIL)).limit(1);
  return owner?.id || null;
}
async function loadSubscriptionLead(subscriptionId) {
  const [row] = await db.select({
    subscriptionId: subscriptions.id,
    userId: users.id,
    email: users.email,
    name: users.name,
    phone: users.phone,
    whatsappNumber: users.whatsappNumber,
    planName: plans.nome,
    planValue: plans.valor,
    metadata: subscriptions.metadata
  }).from(subscriptions).innerJoin(users, eq(users.id, subscriptions.userId)).leftJoin(plans, eq(plans.id, subscriptions.planId)).where(eq(subscriptions.id, subscriptionId)).limit(1);
  if (!row?.subscriptionId) return null;
  const [latestPayment] = await db.select({
    payerEmail: paymentHistory.payerEmail,
    rawResponse: paymentHistory.rawResponse
  }).from(paymentHistory).where(eq(paymentHistory.subscriptionId, subscriptionId)).orderBy(desc(paymentHistory.paymentDate), desc(paymentHistory.updatedAt), desc(paymentHistory.createdAt)).limit(1);
  return {
    ...row,
    metadata: asRecord2(row.metadata),
    paymentPayerEmail: latestPayment?.payerEmail || null,
    paymentRawResponse: asRecord2(latestPayment?.rawResponse)
  };
}
async function loadBuyerConnectionPhoneValues(userId) {
  const rows = await db.select({ phoneNumber: whatsappConnections.phoneNumber }).from(whatsappConnections).where(eq(whatsappConnections.userId, userId)).orderBy(desc(whatsappConnections.isConnected), desc(whatsappConnections.updatedAt)).limit(20);
  return rows.map((row) => row.phoneNumber || "").filter((value) => isUsableRodrigoSubscriptionPhoneCandidateValue(value));
}
function collectReferencedConversationIds(...records) {
  const ids = /* @__PURE__ */ new Set();
  const keys = [
    "conversationId",
    "conversation_id",
    "crmConversationId",
    "crm_conversation_id",
    "adminConversationId",
    "admin_conversation_id",
    "supportConversationId",
    "support_conversation_id",
    "receiptConversationId",
    "receipt_conversation_id"
  ];
  const visit = (record) => {
    if (!record || typeof record !== "object") return;
    for (const key of keys) {
      const value = cleanText2(record[key], 128);
      if (value) ids.add(value);
    }
    for (const value of Object.values(record)) {
      if (value && typeof value === "object" && !Array.isArray(value)) {
        visit(value);
      }
    }
  };
  for (const record of records) visit(record);
  return Array.from(ids);
}
async function loadReferencedConversationPhoneValues(lead) {
  const conversationIds = collectReferencedConversationIds(lead.metadata, lead.paymentRawResponse);
  if (!conversationIds.length) return [];
  const rows = await db.select({ contactNumber: conversations.contactNumber }).from(conversations).where(inArray(conversations.id, conversationIds)).limit(20);
  return rows.map((row) => row.contactNumber || "").filter((value) => isUsableRodrigoSubscriptionPhoneCandidateValue(value));
}
async function findRodrigoConversationBySubscription(lead) {
  const ownerUserId = await getRodrigoOwnerUserId();
  if (!ownerUserId) return null;
  const ownerConnections = await db.select({ id: whatsappConnections.id }).from(whatsappConnections).where(and(eq(whatsappConnections.userId, ownerUserId), eq(whatsappConnections.isConnected, true))).orderBy(desc(whatsappConnections.updatedAt));
  const connectionIds = ownerConnections.map((connection) => connection.id);
  if (!connectionIds.length) return null;
  const buyerConnectionPhoneValues = await loadBuyerConnectionPhoneValues(lead.userId);
  const referencedConversationPhoneValues = await loadReferencedConversationPhoneValues(lead);
  const phoneCandidates = buildRodrigoSubscriptionPhoneCandidates(lead, [
    ...buyerConnectionPhoneValues,
    ...referencedConversationPhoneValues
  ]);
  if (!phoneCandidates.length) return null;
  const exactRows = await db.select({
    id: conversations.id,
    connectionId: conversations.connectionId,
    contactNumber: conversations.contactNumber,
    contactName: conversations.contactName,
    remoteJid: conversations.remoteJid,
    jidSuffix: conversations.jidSuffix,
    rawAnalysis: conversationLeadIntelligence.rawAnalysis
  }).from(conversations).leftJoin(conversationLeadIntelligence, eq(conversationLeadIntelligence.conversationId, conversations.id)).where(and(inArray(conversations.connectionId, connectionIds), inArray(conversations.contactNumber, phoneCandidates))).orderBy(desc(conversations.lastMessageTime), desc(conversations.updatedAt)).limit(1);
  const row = exactRows[0] || null;
  if (row) {
    return { ...row, ownerUserId, rawAnalysis: asRecord2(row.rawAnalysis) };
  }
  const candidateDigits = new Set(phoneCandidates.map(normalizeDigits).filter(Boolean));
  const recentRows = await db.select({
    id: conversations.id,
    connectionId: conversations.connectionId,
    contactNumber: conversations.contactNumber,
    contactName: conversations.contactName,
    remoteJid: conversations.remoteJid,
    jidSuffix: conversations.jidSuffix,
    rawAnalysis: conversationLeadIntelligence.rawAnalysis
  }).from(conversations).leftJoin(conversationLeadIntelligence, eq(conversationLeadIntelligence.conversationId, conversations.id)).where(inArray(conversations.connectionId, connectionIds)).orderBy(desc(conversations.lastMessageTime), desc(conversations.updatedAt)).limit(2e3);
  const fallback = recentRows.find((candidate) => {
    const contactDigits = normalizeDigits(candidate.contactNumber);
    const jidDigits = normalizeDigits(candidate.remoteJid);
    return contactDigits && candidateDigits.has(contactDigits) || jidDigits && candidateDigits.has(jidDigits);
  });
  return fallback ? { ...fallback, ownerUserId, rawAnalysis: asRecord2(fallback.rawAnalysis) } : null;
}
async function findRodrigoConversationById(conversationId) {
  const [row] = await db.select({
    id: conversations.id,
    connectionId: conversations.connectionId,
    contactNumber: conversations.contactNumber,
    contactName: conversations.contactName,
    remoteJid: conversations.remoteJid,
    jidSuffix: conversations.jidSuffix,
    ownerUserId: users.id,
    ownerEmail: users.email,
    rawAnalysis: conversationLeadIntelligence.rawAnalysis
  }).from(conversations).innerJoin(whatsappConnections, eq(whatsappConnections.id, conversations.connectionId)).innerJoin(users, eq(users.id, whatsappConnections.userId)).leftJoin(conversationLeadIntelligence, eq(conversationLeadIntelligence.conversationId, conversations.id)).where(eq(conversations.id, conversationId)).limit(1);
  if (!row || row.ownerEmail !== RODRIGO_META_OWNER_EMAIL) return null;
  return { ...row, rawAnalysis: asRecord2(row.rawAnalysis) };
}
async function saveFunnelRecord(conversation, eventKey, record) {
  const nextRawAnalysis = mergeFunnelEventRecord(conversation.rawAnalysis, eventKey, record);
  await db.insert(conversationLeadIntelligence).values({
    conversationId: conversation.id,
    connectionId: conversation.connectionId,
    userId: conversation.ownerUserId,
    contactNumber: conversation.contactNumber,
    contactName: conversation.contactName || null,
    rawAnalysis: nextRawAnalysis,
    analysisVersion: RODRIGO_META_FUNNEL_VERSION
  }).onConflictDoUpdate({
    target: conversationLeadIntelligence.conversationId,
    set: {
      rawAnalysis: nextRawAnalysis,
      updatedAt: /* @__PURE__ */ new Date()
    }
  });
}
async function applyNativeLabelBestEffort(conversation, labelName, labelId, color) {
  const cleanName = String(labelName || "").trim();
  if (!cleanName) return null;
  try {
    const { applyNativeWhatsappChatLabel } = await import("./whatsapp-ORIGKV64.js");
    return await applyNativeWhatsappChatLabel({
      connectionId: conversation.connectionId,
      userId: conversation.ownerUserId,
      remoteJid: conversation.remoteJid,
      contactNumber: conversation.contactNumber,
      jidSuffix: conversation.jidSuffix,
      labelId,
      labelName: cleanName,
      color
    });
  } catch (error) {
    return {
      applied: false,
      skipped: "native_label_import_failed",
      error: error instanceof Error ? error.message : String(error)
    };
  }
}
async function sendAndRecordFunnelEvent(params) {
  const eventKey = buildRodrigoMetaFunnelEventKey(params.eventName, params.eventId);
  const previous = getFunnelEvents(params.conversation.rawAnalysis)[eventKey];
  const attribution = pickBestRodrigoWhatsappAdsAttribution(params.conversation.rawAnalysis.whatsappAdsAttribution);
  if (!hasMetaWhatsappClickIdAttribution(attribution)) {
    await saveFunnelRecord(params.conversation, eventKey, {
      status: "skipped",
      eventName: params.eventName,
      eventId: params.eventId,
      reason: "missing_ctwa_clid",
      recordedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return { recorded: false, skipped: "missing_ctwa_clid", eventName: params.eventName, eventId: params.eventId };
  }
  const label = await applyNativeLabelBestEffort(
    params.conversation,
    params.labelName,
    params.labelId || `agentezap_${params.eventName}`,
    params.labelColor ?? 0
  );
  if (previous?.status === "sent") {
    return { recorded: false, skipped: "already_sent", eventName: params.eventName, eventId: params.eventId, label };
  }
  try {
    const meta = await sendMetaWhatsappBusinessMessagingEvent({
      eventName: params.eventName,
      eventId: params.eventId,
      phone: params.phone || params.conversation.contactNumber,
      email: params.email || null,
      name: params.name || params.conversation.contactName,
      submittedAt: /* @__PURE__ */ new Date(),
      value: params.value ?? 0,
      currency: params.currency || "BRL",
      contentName: params.contentName || null,
      subscriptionId: cleanText2(params.customData?.subscription_id, 128),
      source: params.source,
      whatsappAdsAttribution: attribution,
      customData: {
        conversation_id: params.conversation.id,
        connection_id: params.conversation.connectionId,
        ...params.customData || {}
      }
    });
    await saveFunnelRecord(params.conversation, eventKey, {
      status: meta.sent ? "sent" : "skipped",
      eventName: params.eventName,
      eventId: params.eventId,
      metaEventId: meta.eventId,
      reason: "reason" in meta ? meta.reason : null,
      label,
      recordedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return { recorded: true, eventName: params.eventName, eventId: params.eventId, meta, label };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await saveFunnelRecord(params.conversation, eventKey, {
      status: "failed",
      eventName: params.eventName,
      eventId: params.eventId,
      error: message,
      label,
      recordedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return { recorded: false, skipped: "meta_capi_failed", eventName: params.eventName, eventId: params.eventId, label, error: message };
  }
}
async function recordLocalFunnelLabel(params) {
  const eventKey = buildRodrigoMetaFunnelEventKey(params.eventName, params.eventId);
  const previous = getFunnelEvents(params.conversation.rawAnalysis)[eventKey];
  const label = await applyNativeLabelBestEffort(
    params.conversation,
    params.labelName,
    params.labelId,
    params.labelColor
  );
  if (previous?.status === "sent") {
    return { recorded: false, skipped: "already_labeled", eventName: params.eventName, eventId: params.eventId, label };
  }
  const labelDetails = asRecord2(label);
  const labelApplied = labelDetails.applied === true;
  const labelSkippedReason = cleanText2(labelDetails.skipped, 128) || "native_label_not_applied";
  await saveFunnelRecord(params.conversation, eventKey, {
    status: labelApplied ? "sent" : "skipped",
    eventName: params.eventName,
    eventId: params.eventId,
    reason: labelApplied ? params.reason : `${params.reason}:${labelSkippedReason}`,
    label,
    recordedAt: (/* @__PURE__ */ new Date()).toISOString(),
    ...params.customData ? { customData: params.customData } : {}
  });
  if (!labelApplied) {
    return {
      recorded: false,
      skipped: labelSkippedReason,
      eventName: params.eventName,
      eventId: params.eventId,
      label
    };
  }
  return { recorded: true, eventName: params.eventName, eventId: params.eventId, label };
}
async function recordRodrigoWhatsappQualifiedLeadFromConversation(params) {
  if (!shouldSendRodrigoQualifiedLeadEvent(params)) {
    return { recorded: false, skipped: "not_qualified" };
  }
  const conversation = await findRodrigoConversationById(params.conversationId);
  if (!conversation) return { recorded: false, skipped: "conversation_not_found_or_not_rodrigo" };
  return sendAndRecordFunnelEvent({
    conversation,
    eventName: "LeadSubmitted",
    eventId: `conversation:${params.conversationId}:lead_submitted`,
    source: "rodrigo_whatsapp_qualified_lead",
    value: 0,
    contentName: "Lead qualificado WhatsApp",
    labelName: "Qualificado",
    labelId: "agentezap_qualificado",
    labelColor: 2,
    customData: {
      potential_score: params.potentialScore,
      potential_grade: params.potentialGrade || null,
      business_type: params.businessType || null
    }
  });
}
async function recordRodrigoWhatsappLowQualityLeadLabelFromConversation(params) {
  const grade = String(params.potentialGrade || "").trim().toLowerCase();
  const isLowQuality = !params.isPotential || Number(params.potentialScore || 0) < 45 || grade === "descartar";
  if (!isLowQuality) {
    return { recorded: false, skipped: "not_low_quality" };
  }
  const conversation = await findRodrigoConversationById(params.conversationId);
  if (!conversation) return { recorded: false, skipped: "conversation_not_found_or_not_rodrigo" };
  const attribution = pickBestRodrigoWhatsappAdsAttribution(conversation.rawAnalysis.whatsappAdsAttribution);
  if (!hasMetaWhatsappClickIdAttribution(attribution)) {
    return { recorded: false, skipped: "missing_ctwa_clid" };
  }
  return recordLocalFunnelLabel({
    conversation,
    eventName: "LocalLowQualityLeadLabel",
    eventId: `conversation:${params.conversationId}:low_quality`,
    reason: "local_label_only_not_meta_conversion",
    labelName: "Baixa qualidade",
    labelId: "agentezap_baixa_qualidade",
    labelColor: 14,
    customData: {
      potential_score: params.potentialScore,
      potential_grade: params.potentialGrade || null,
      business_type: params.businessType || null
    }
  });
}
async function recordSubscriptionFunnelEvent(params) {
  const lead = await loadSubscriptionLead(params.subscriptionId);
  if (!lead) return { recorded: false, skipped: "subscription_not_found" };
  const conversation = await findRodrigoConversationBySubscription(lead);
  if (!conversation) return { recorded: false, skipped: "rodrigo_conversation_not_found" };
  const value = params.value ?? parseMoney(lead.planValue);
  return sendAndRecordFunnelEvent({
    conversation,
    eventName: params.eventName,
    eventId: `subscription:${params.subscriptionId}:${params.eventIdSuffix}`,
    phone: lead.phone || lead.whatsappNumber,
    email: lead.email || lead.paymentPayerEmail,
    name: lead.name,
    value,
    currency: "BRL",
    contentName: lead.planName || "Assinatura AgenteZap",
    source: params.source,
    labelName: params.labelName,
    labelId: params.labelId,
    labelColor: params.labelColor,
    customData: {
      subscription_id: params.subscriptionId,
      plan_name: lead.planName || null,
      ...params.customData || {}
    }
  });
}
function recordRodrigoWhatsappInitiateCheckoutFromSubscription(params) {
  return recordSubscriptionFunnelEvent({
    subscriptionId: params.subscriptionId,
    eventName: "InitiateCheckout",
    eventIdSuffix: "initiate_checkout",
    value: params.value,
    source: "rodrigo_whatsapp_pix_checkout",
    labelName: "Pix enviado",
    labelId: "agentezap_pix_enviado",
    labelColor: 13,
    customData: {
      pix_provider: params.pixProvider || null,
      payment_id: params.paymentId || null
    }
  });
}
function recordRodrigoWhatsappPurchaseFromSubscription(params) {
  return recordSubscriptionFunnelEvent({
    subscriptionId: params.subscriptionId,
    eventName: "Purchase",
    eventIdSuffix: "paid",
    value: params.value,
    source: "rodrigo_whatsapp_paid_subscription",
    labelName: "Pago",
    labelId: "agentezap_pago",
    labelColor: 2,
    customData: {
      payment_id: params.paymentId || null
    }
  });
}
async function recordRodrigoWhatsappPendingPixLabelFromSubscription(params) {
  const lead = await loadSubscriptionLead(params.subscriptionId);
  if (!lead) return { recorded: false, skipped: "subscription_not_found" };
  const conversation = await findRodrigoConversationBySubscription(lead);
  if (!conversation) return { recorded: false, skipped: "rodrigo_conversation_not_found" };
  const step = Number(params.step || 1);
  return recordLocalFunnelLabel({
    conversation,
    eventName: "LocalPixPendingLabel",
    eventId: `subscription:${params.subscriptionId}:pix_pending_step_${Number.isFinite(step) ? step : 1}`,
    reason: "local_label_only_not_meta_conversion",
    labelName: "Pix pendente",
    labelId: "agentezap_pix_pendente",
    labelColor: 14,
    customData: {
      subscription_id: params.subscriptionId,
      plan_name: lead.planName || null,
      value: params.value ?? parseMoney(lead.planValue),
      recovery_step: Number.isFinite(step) ? step : 1,
      payment_id: params.paymentId || null
    }
  });
}
async function loadRecentSubscriptionBackfillRows(since, limit) {
  const rows = await db.select({
    subscriptionId: subscriptions.id,
    status: subscriptions.status,
    planValue: plans.valor,
    couponPrice: subscriptions.couponPrice,
    paymentHistoryId: paymentHistory.id,
    mpPaymentId: paymentHistory.mpPaymentId,
    paymentAmount: paymentHistory.amount
  }).from(subscriptions).innerJoin(users, eq(users.id, subscriptions.userId)).leftJoin(plans, eq(plans.id, subscriptions.planId)).leftJoin(
    paymentHistory,
    and(
      eq(paymentHistory.subscriptionId, subscriptions.id),
      inArray(paymentHistory.status, ["approved", "paid", "confirmed"])
    )
  ).where(sql`(
      ${subscriptions.createdAt} >= ${since}
      OR ${subscriptions.updatedAt} >= ${since}
      OR ${paymentHistory.paymentDate} >= ${since}
    )`).orderBy(desc(sql`COALESCE(${paymentHistory.paymentDate}, ${subscriptions.updatedAt}, ${subscriptions.createdAt})`)).limit(Math.max(limit * 3, limit));
  const unique = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (!row.subscriptionId || unique.has(row.subscriptionId)) continue;
    unique.set(row.subscriptionId, row);
    if (unique.size >= limit) break;
  }
  return Array.from(unique.values());
}
async function backfillRodrigoSubscriptionFunnelEvents(summary, since, limit, dryRun) {
  const rows = await loadRecentSubscriptionBackfillRows(since, limit);
  summary.subscriptionsInspected = rows.length;
  for (const row of rows) {
    const isPurchaseCandidate = isPaidSubscriptionBackfillCandidate(row);
    const isCheckoutCandidate = isCheckoutSubscriptionBackfillCandidate(row);
    if (!isPurchaseCandidate && !isCheckoutCandidate) {
      summary.subscriptionNeutralSkipped += 1;
      continue;
    }
    const lead = await loadSubscriptionLead(row.subscriptionId);
    if (!lead) {
      summary.subscriptionConversationNotFound += 1;
      continue;
    }
    const conversation = await findRodrigoConversationBySubscription(lead);
    if (!conversation) {
      summary.subscriptionConversationNotFound += 1;
      continue;
    }
    const attribution = pickBestRodrigoWhatsappAdsAttribution(conversation.rawAnalysis.whatsappAdsAttribution);
    if (!hasMetaWhatsappClickIdAttribution(attribution)) {
      summary.subscriptionMissingCtwaClid += 1;
      continue;
    }
    summary.subscriptionMatchesWithCtwa += 1;
    const value = getSubscriptionBackfillValue(row);
    if (isPurchaseCandidate) {
      summary.purchaseCandidates += 1;
      if (dryRun) continue;
      const result2 = await recordRodrigoWhatsappPurchaseFromSubscription({
        subscriptionId: row.subscriptionId,
        value,
        paymentId: getSubscriptionBackfillPaymentId(row)
      });
      if (result2.recorded && result2.meta && "sent" in result2.meta && result2.meta.sent) {
        summary.purchaseSent += 1;
      } else if (!result2.recorded && result2.skipped === "already_sent") {
        summary.purchaseAlreadyRecorded += 1;
      } else if (!result2.recorded && result2.error) {
        summary.failed += 1;
        summary.failures.push({
          conversationId: conversation.id,
          subscriptionId: row.subscriptionId,
          step: "purchase",
          reason: result2.error
        });
      } else {
        summary.purchaseSkipped += 1;
      }
      continue;
    }
    summary.checkoutCandidates += 1;
    if (dryRun) continue;
    const result = await recordRodrigoWhatsappInitiateCheckoutFromSubscription({
      subscriptionId: row.subscriptionId,
      value,
      pixProvider: "backfill_pending_pix",
      paymentId: getSubscriptionBackfillPaymentId(row)
    });
    if (result.recorded && result.meta && "sent" in result.meta && result.meta.sent) {
      summary.checkoutSent += 1;
    } else if (!result.recorded && result.skipped === "already_sent") {
      summary.checkoutAlreadyRecorded += 1;
    } else if (!result.recorded && result.error) {
      summary.failed += 1;
      summary.failures.push({
        conversationId: conversation.id,
        subscriptionId: row.subscriptionId,
        step: "checkout",
        reason: result.error
      });
    } else {
      summary.checkoutSkipped += 1;
    }
  }
}
function clampInteger(value, fallback, min, max) {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(min, Math.min(max, parsed));
}
function isLowQualityLead(input) {
  const grade = String(input.potentialGrade || "").trim().toLowerCase();
  return !input.isPotential || Number(input.potentialScore || 0) < 45 || grade === "descartar";
}
async function backfillRodrigoMetaFunnelFromRecentConversations(options) {
  const hours = clampInteger(options?.hours, 72, 1, 168);
  const limit = clampInteger(options?.limit, 200, 1, 500);
  const dryRun = options?.dryRun !== false;
  const since = new Date(Date.now() - hours * 60 * 60 * 1e3);
  const rows = await db.select({
    conversationId: conversationLeadIntelligence.conversationId,
    rawAnalysis: conversationLeadIntelligence.rawAnalysis,
    isPotential: conversationLeadIntelligence.isPotential,
    potentialScore: conversationLeadIntelligence.potentialScore,
    potentialGrade: conversationLeadIntelligence.potentialGrade,
    businessType: conversationLeadIntelligence.businessType,
    lastAnalyzedAt: conversationLeadIntelligence.lastAnalyzedAt,
    lastMessageTime: conversations.lastMessageTime
  }).from(conversationLeadIntelligence).innerJoin(conversations, eq(conversations.id, conversationLeadIntelligence.conversationId)).innerJoin(whatsappConnections, eq(whatsappConnections.id, conversations.connectionId)).innerJoin(users, eq(users.id, whatsappConnections.userId)).where(and(
    eq(users.email, RODRIGO_META_OWNER_EMAIL),
    sql`(
        ${conversationLeadIntelligence.createdAt} >= ${since}
        OR ${conversationLeadIntelligence.lastAnalyzedAt} >= ${since}
        OR ${conversations.lastMessageTime} >= ${since}
      )`
  )).orderBy(desc(conversationLeadIntelligence.lastAnalyzedAt), desc(conversations.lastMessageTime)).limit(limit);
  const summary = {
    success: true,
    ownerEmail: RODRIGO_META_OWNER_EMAIL,
    dryRun,
    hours,
    limit,
    inspected: rows.length,
    withCtwaClid: 0,
    qualifiedCandidates: 0,
    lowQualityCandidates: 0,
    neutralSkipped: 0,
    missingCtwaClid: 0,
    leadSent: 0,
    leadAlreadyRecorded: 0,
    leadSkipped: 0,
    lowQualityLabelApplied: 0,
    lowQualityAlreadyRecorded: 0,
    lowQualityLabelSkipped: 0,
    subscriptionsInspected: 0,
    subscriptionMatchesWithCtwa: 0,
    subscriptionMissingCtwaClid: 0,
    subscriptionConversationNotFound: 0,
    subscriptionNeutralSkipped: 0,
    checkoutCandidates: 0,
    checkoutSent: 0,
    checkoutAlreadyRecorded: 0,
    checkoutSkipped: 0,
    purchaseCandidates: 0,
    purchaseSent: 0,
    purchaseAlreadyRecorded: 0,
    purchaseSkipped: 0,
    failed: 0,
    failures: []
  };
  for (const row of rows) {
    const rawAnalysis = asRecord2(row.rawAnalysis);
    const attribution = pickBestRodrigoWhatsappAdsAttribution(rawAnalysis.whatsappAdsAttribution);
    const hasCtwaClid = hasMetaWhatsappClickIdAttribution(attribution);
    if (hasCtwaClid) {
      summary.withCtwaClid += 1;
    } else {
      summary.missingCtwaClid += 1;
      continue;
    }
    const candidate = {
      isPotential: row.isPotential,
      potentialScore: Number(row.potentialScore || 0),
      potentialGrade: row.potentialGrade,
      businessType: row.businessType
    };
    if (shouldSendRodrigoQualifiedLeadEvent(candidate)) {
      summary.qualifiedCandidates += 1;
      if (dryRun) continue;
      const result = await recordRodrigoWhatsappQualifiedLeadFromConversation({
        conversationId: row.conversationId,
        ...candidate
      });
      if (result.recorded && result.meta && "sent" in result.meta && result.meta.sent) {
        summary.leadSent += 1;
      } else if (!result.recorded && result.skipped === "already_sent") {
        summary.leadAlreadyRecorded += 1;
      } else if (!result.recorded && result.error) {
        summary.failed += 1;
        summary.failures.push({
          conversationId: row.conversationId,
          step: "lead",
          reason: result.error
        });
      } else {
        summary.leadSkipped += 1;
      }
      continue;
    }
    if (isLowQualityLead(candidate)) {
      summary.lowQualityCandidates += 1;
      if (dryRun) continue;
      const result = await recordRodrigoWhatsappLowQualityLeadLabelFromConversation({
        conversationId: row.conversationId,
        ...candidate
      });
      if (result.recorded) {
        summary.lowQualityLabelApplied += 1;
      } else if (result.skipped === "already_labeled") {
        summary.lowQualityAlreadyRecorded += 1;
      } else {
        summary.lowQualityLabelSkipped += 1;
        if (result.error) {
          summary.failed += 1;
          summary.failures.push({
            conversationId: row.conversationId,
            step: "low_quality_label",
            reason: result.error
          });
        }
      }
      continue;
    }
    summary.neutralSkipped += 1;
  }
  await backfillRodrigoSubscriptionFunnelEvents(summary, since, limit, dryRun);
  return summary;
}

export {
  getBrazilTemporalContext,
  buildBrazilTemporalPromptBlock,
  shouldUseBrazilTemporalToolContract,
  buildBrazilTemporalToolResult,
  buildBrazilTemporalToolContractBlock,
  enforceBrazilTemporalConsistency,
  applyFkSemijoiasResponsePolicy,
  buildTicoLocacoesDeterministicTurn,
  buildSchoolTriageResponseFromPrompt,
  ensureVicosaPizzaMenuMediaAction,
  applyVicosaPizzaResponseGuard,
  shouldSendRodrigoQualifiedLeadEvent,
  recordRodrigoWhatsappQualifiedLeadFromConversation,
  recordRodrigoWhatsappLowQualityLeadLabelFromConversation,
  recordRodrigoWhatsappInitiateCheckoutFromSubscription,
  recordRodrigoWhatsappPurchaseFromSubscription,
  recordRodrigoWhatsappPendingPixLabelFromSubscription,
  backfillRodrigoMetaFunnelFromRecentConversations
};
