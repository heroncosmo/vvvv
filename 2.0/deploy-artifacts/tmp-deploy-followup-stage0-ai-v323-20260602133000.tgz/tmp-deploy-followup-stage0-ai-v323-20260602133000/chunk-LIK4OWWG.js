import {
  __esm
} from "./chunk-KFQGP6VL.js";

// server/greetingTime.ts
function getBrazilTimeParts(now = /* @__PURE__ */ new Date()) {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: BRAZIL_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23"
  });
  const parts = formatter.formatToParts(now);
  const byType = new Map(parts.map((part) => [part.type, part.value]));
  return {
    year: Number(byType.get("year") || "0"),
    month: Number(byType.get("month") || "0"),
    day: Number(byType.get("day") || "0"),
    hour: Number(byType.get("hour") || "0"),
    minute: Number(byType.get("minute") || "0"),
    second: Number(byType.get("second") || "0")
  };
}
function getBrazilTimeDate(now = /* @__PURE__ */ new Date()) {
  const parts = getBrazilTimeParts(now);
  return new Date(
    parts.year,
    parts.month - 1,
    parts.day,
    parts.hour,
    parts.minute,
    parts.second,
    0
  );
}
function getBrazilTimeDateByUtcOffset(now = /* @__PURE__ */ new Date()) {
  const localOffsetMinutes = now.getTimezoneOffset();
  const offsetDeltaMinutes = localOffsetMinutes + BRAZIL_UTC_OFFSET_MINUTES;
  return new Date(now.getTime() + offsetDeltaMinutes * 60 * 1e3);
}
function getReliableBrazilGreetingHour(now = /* @__PURE__ */ new Date()) {
  const intlHour = getBrazilTimeDate(now).getHours();
  const fallbackHour = getBrazilTimeDateByUtcOffset(now).getHours();
  if (Math.abs(intlHour - fallbackHour) <= 1) {
    return intlHour;
  }
  return fallbackHour;
}
function getBrazilGreetingForHour(hour) {
  if (hour >= 5 && hour < 12) return "Bom dia";
  if (hour >= 12 && hour < 18) return "Boa tarde";
  return "Boa noite";
}
function buildBrazilGreetingPromptInstruction(now = /* @__PURE__ */ new Date()) {
  const brazilHour = getReliableBrazilGreetingHour(now);
  const currentGreeting = getBrazilGreetingForHour(brazilHour);
  return [
    "REGRA GLOBAL DE SAUDACAO PELO HORARIO DE BRASILIA:",
    `Horario atual oficial de Brasilia para esta resposta: ${String(brazilHour).padStart(2, "0")}:00.`,
    `Se voce escolher usar saudacao na primeira resposta util da conversa, a saudacao correta neste momento e: "${currentGreeting}".`,
    "Nunca copie automaticamente a saudacao escrita pelo cliente quando ela estiver errada para o horario atual.",
    'Exemplo: se forem 11:32 em Brasilia e o cliente escrever "boa tarde", responda com "Bom dia".',
    "Faixas oficiais de saudacao:",
    "- 05:00 ate 11:59 -> Bom dia",
    "- 12:00 ate 17:59 -> Boa tarde",
    "- 18:00 ate 04:59 -> Boa noite",
    "Depois da primeira resposta util, nao repita saudacao sem necessidade."
  ].join("\n");
}
function getBrazilOpeningGreetingForHour(hour) {
  if (hour >= 6 && hour < 12) return "Bom dia";
  if (hour >= 12 && hour < 18) return "Boa tarde";
  if (hour >= 18 && hour < 24) return "Boa noite";
  return "Ol\xE1, tudo bem?";
}
function replaceLiteralToken(source, token, replacement) {
  if (!source || !token) {
    return source;
  }
  return source.split(token).join(replacement);
}
function isWhitespaceCharacter(char) {
  return char === " " || char === "\n" || char === "\r" || char === "	";
}
function isGreetingBoundaryCharacter(char) {
  return isWhitespaceCharacter(char) || char === "!" || char === "," || char === "." || char === "?" || char === ";" || char === ":" || char === "(" || char === ")" || char === "-" || char === "\u2014";
}
function trimLeadingWhitespace(source) {
  let leadingWhitespaceLength = 0;
  while (leadingWhitespaceLength < source.length && isWhitespaceCharacter(source[leadingWhitespaceLength])) {
    leadingWhitespaceLength += 1;
  }
  return {
    leadingWhitespace: source.slice(0, leadingWhitespaceLength),
    trimmedSource: source.slice(leadingWhitespaceLength)
  };
}
function splitLeadingInlineMarkup(source) {
  let index = 0;
  while (index < source.length) {
    const char = source[index];
    if (char !== "*" && char !== "_") {
      break;
    }
    index += 1;
  }
  return {
    openingMarkup: source.slice(0, index),
    content: source.slice(index)
  };
}
function getTimedOpeningGreetingForHour(hour) {
  return getBrazilGreetingForHour(hour);
}
function startsWithGreeting(text, greeting) {
  const source = String(text || "");
  if (!source.trim()) {
    return false;
  }
  const { trimmedSource } = trimLeadingWhitespace(source);
  const { content } = splitLeadingInlineMarkup(trimmedSource);
  const loweredSource = content.toLocaleLowerCase("pt-BR");
  const loweredGreeting = greeting.toLocaleLowerCase("pt-BR");
  if (!loweredSource.startsWith(loweredGreeting)) {
    return false;
  }
  const boundaryCharacter = content[loweredGreeting.length];
  return boundaryCharacter === void 0 || isGreetingBoundaryCharacter(boundaryCharacter);
}
function replaceLeadingGreetingByHour(text, hour) {
  const source = String(text || "");
  if (!source.trim()) {
    return source;
  }
  const currentGreeting = getTimedOpeningGreetingForHour(hour);
  const { leadingWhitespace, trimmedSource } = trimLeadingWhitespace(source);
  const { openingMarkup, content } = splitLeadingInlineMarkup(trimmedSource);
  const loweredSource = content.toLocaleLowerCase("pt-BR");
  const candidateGreetings = ["Bom dia", "Boa tarde", "Boa noite", "Ol\xE1", "Ola", "Oi"];
  for (const greeting of candidateGreetings) {
    const loweredGreeting = greeting.toLocaleLowerCase("pt-BR");
    if (!loweredSource.startsWith(loweredGreeting)) {
      continue;
    }
    const boundaryCharacter = content[loweredGreeting.length];
    if (boundaryCharacter !== void 0 && !isGreetingBoundaryCharacter(boundaryCharacter)) {
      continue;
    }
    return `${leadingWhitespace}${openingMarkup}${currentGreeting}${content.slice(loweredGreeting.length)}`;
  }
  return source;
}
function normalizeConfiguredGreetingByHour(text, hour) {
  const source = String(text || "");
  if (!source.trim()) {
    return source;
  }
  const currentGreeting = getBrazilGreetingForHour(hour);
  const { leadingWhitespace, trimmedSource } = trimLeadingWhitespace(source);
  const loweredSource = trimmedSource.toLocaleLowerCase("pt-BR");
  for (const greeting of TIME_BASED_GREETINGS) {
    const loweredGreeting = greeting.toLocaleLowerCase("pt-BR");
    if (!loweredSource.startsWith(loweredGreeting)) {
      continue;
    }
    const boundaryCharacter = trimmedSource[loweredGreeting.length];
    if (boundaryCharacter !== void 0 && !isGreetingBoundaryCharacter(boundaryCharacter)) {
      continue;
    }
    return `${leadingWhitespace}${currentGreeting}${trimmedSource.slice(loweredGreeting.length)}`;
  }
  return source;
}
function normalizeConfiguredGreetingForBrazilTime(text, now = /* @__PURE__ */ new Date()) {
  const brazilHour = getReliableBrazilGreetingHour(now);
  const withDynamicOpeningGreeting = replaceLiteralToken(
    String(text || ""),
    OPENING_GREETING_PLACEHOLDER,
    getBrazilOpeningGreetingForHour(brazilHour)
  );
  return normalizeConfiguredGreetingByHour(withDynamicOpeningGreeting, brazilHour);
}
function ensureOpeningGreetingForBrazilTime(text, now = /* @__PURE__ */ new Date()) {
  const brazilHour = getReliableBrazilGreetingHour(now);
  const timedGreeting = `${getTimedOpeningGreetingForHour(brazilHour)}!`;
  const source = String(text || "");
  if (!source.trim()) {
    return timedGreeting;
  }
  const sourceWithDynamicGreeting = replaceLiteralToken(
    source,
    OPENING_GREETING_PLACEHOLDER,
    getTimedOpeningGreetingForHour(brazilHour)
  );
  const normalized = replaceLeadingGreetingByHour(sourceWithDynamicGreeting, brazilHour);
  if (startsWithGreeting(sourceWithDynamicGreeting, getTimedOpeningGreetingForHour(brazilHour))) {
    return sourceWithDynamicGreeting;
  }
  if (normalized !== sourceWithDynamicGreeting) {
    return normalized;
  }
  const { leadingWhitespace, trimmedSource } = trimLeadingWhitespace(source);
  return `${leadingWhitespace}${timedGreeting} ${trimmedSource}`.trimEnd();
}
var TIME_BASED_GREETINGS, OPENING_GREETING_PLACEHOLDER, BRAZIL_TIME_ZONE, BRAZIL_UTC_OFFSET_MINUTES;
var init_greetingTime = __esm({
  "server/greetingTime.ts"() {
    "use strict";
    TIME_BASED_GREETINGS = ["Bom dia", "Boa tarde", "Boa noite"];
    OPENING_GREETING_PLACEHOLDER = "{{saudacao_horario}}";
    BRAZIL_TIME_ZONE = "America/Sao_Paulo";
    BRAZIL_UTC_OFFSET_MINUTES = -3 * 60;
  }
});

export {
  getBrazilTimeParts,
  getBrazilTimeDate,
  buildBrazilGreetingPromptInstruction,
  normalizeConfiguredGreetingForBrazilTime,
  ensureOpeningGreetingForBrazilTime,
  init_greetingTime
};
