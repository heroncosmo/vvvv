#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:rprado-direct-gmail-local-send-v158c-20260518084720"
EXPECTED_BASE="agentezap-app:rprado-direct-gmail-local-send-v158-20260518083838"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-rprado-direct-gmail-local-send-v158c-20260518084720"
SESSIONS_DIR="/data/agentezap/sessions"

check_marker() {
  local label="$1"
  shift
  echo "[deploy] check=${label}"
  "$@"
}

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] WARN: current expected base is not healthy (${current_health}); continuing repair deploy over ${EXPECTED_BASE}" >&2
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi

if [ "$current_health" = "healthy" ]; then
  check_marker base_pwa_version docker exec agentezap-app sh -lc "grep -aR -m 1 'build-1779073548862' /app/dist/public/pwa-version.json >/dev/null"
  check_marker base_billing_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'button-settings-open-billing' /app/dist/public >/dev/null"
  check_marker base_mobile_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'mobile=editor' /app/dist/public >/dev/null"
  check_marker base_fk_policy docker exec agentezap-app sh -lc "grep -aR -m 1 'specific_request_before_name_to_name_question' /app/dist/api/http.js >/dev/null"
  check_marker base_fk_clear_media docker exec agentezap-app sh -lc "grep -aR -m 1 'clear_media_before_name' /app/dist/api/http.js >/dev/null"
  check_marker base_protocol_stub_guard docker exec agentezap-app sh -lc "grep -aR -m 1 'not_initial_meta_stub' /app/dist/api/http.js >/dev/null"
  check_marker base_protocol_skip docker exec agentezap-app sh -lc "grep -aR -m 1 'ignored_protocol_message' /app/dist/api/http.js >/dev/null"
else
  echo "[deploy] skipping live base marker checks because expected base container is not healthy"
fi

cd "$DEPLOY_DIR"
test -f dist/index.js
test -f dist/api/http.js
if [ -d dist/public ]; then
  echo "[deploy] ERROR: backend-only artifact must not include dist/public" >&2
  exit 1
fi

check_marker artifact_fk_video_guard grep -aR -m 1 'specific_request_before_name_to_name_question' dist/api/http.js
check_marker artifact_fk_clear_media grep -aR -m 1 'clear_media_before_name' dist/api/http.js
check_marker artifact_fk_drop_video grep -aR -m 1 'drop_conflicting_media_after_product_request' dist/api/http.js
check_marker artifact_protocol_stub_guard grep -aR -m 1 'not_initial_meta_stub' dist/api/http.js
check_marker artifact_protocol_skip grep -aR -m 1 'ignored_protocol_message' dist/api/http.js
check_marker artifact_unsupported_marker grep -aR -m 1 '\[mensagem nao suportada:' dist/api/http.js
check_marker artifact_monolith_local_send grep -aR -m 1 'monolith_local_instance_send_fallback_v158' dist/api/http.js

cat > Dockerfile <<EOF
FROM ${current_image}
COPY dist/ /app/dist/
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-rprado-direct-gmail-local-send-v158c-20260518084720"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path('.env.runtime')
desired = {
    'AGENTEZAP_APP_IMAGE': tag,
    'NODE_OPTIONS': '--max-old-space-size=4096',
    'WA_PENDING_TIMERS_START_DURING_RESTORE': 'false',
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split('=', 1)[0] if '=' in line else ''
    if key in desired:
        out.append(f'{key}={desired[key]}')
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f'{key}={value}')
path.write_text('\n'.join(out) + '\n')
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during app deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy after deploy" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi

check_marker deployed_pwa_version docker exec agentezap-app sh -lc "grep -aR -m 1 'build-1779073548862' /app/dist/public/pwa-version.json >/dev/null"
check_marker deployed_billing_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'button-settings-open-billing' /app/dist/public >/dev/null"
check_marker deployed_mobile_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'mobile=editor' /app/dist/public >/dev/null"
check_marker deployed_fk_video_guard docker exec agentezap-app sh -lc "grep -aR -m 1 'specific_request_before_name_to_name_question' /app/dist/api/http.js >/dev/null"
check_marker deployed_fk_clear_media docker exec agentezap-app sh -lc "grep -aR -m 1 'clear_media_before_name' /app/dist/api/http.js >/dev/null"
check_marker deployed_protocol_stub_guard docker exec agentezap-app sh -lc "grep -aR -m 1 'not_initial_meta_stub' /app/dist/api/http.js >/dev/null"
check_marker deployed_protocol_skip docker exec agentezap-app sh -lc "grep -aR -m 1 'ignored_protocol_message' /app/dist/api/http.js >/dev/null"
check_marker deployed_monolith_local_send docker exec agentezap-app sh -lc "grep -aR -m 1 'monolith_local_instance_send_fallback_v158' /app/dist/api/http.js >/dev/null"

docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"

echo "[deploy] done"
