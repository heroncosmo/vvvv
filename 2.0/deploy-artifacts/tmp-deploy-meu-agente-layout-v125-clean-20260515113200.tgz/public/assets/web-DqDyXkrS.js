import{W as n}from"./main-DAzAgMlz.js";import"./index-Bewp7wGj.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
