import{r as i}from"./main-DAzAgMlz.js";import"./index-Bewp7wGj.js";const r=i("PushNotifications",{});export{r as PushNotifications};
