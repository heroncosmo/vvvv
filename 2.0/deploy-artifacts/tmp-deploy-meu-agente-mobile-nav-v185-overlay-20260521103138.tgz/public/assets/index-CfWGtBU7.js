import{r as i}from"./main-BtmyCJgE.js";import"./index-d67MYvjU.js";const r=i("PushNotifications",{});export{r as PushNotifications};
