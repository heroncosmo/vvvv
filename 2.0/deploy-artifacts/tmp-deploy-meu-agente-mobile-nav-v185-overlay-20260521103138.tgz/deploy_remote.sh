#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:meu-agente-mobile-nav-v185-overlay-20260521103138"
EXPECTED_BASE="agentezap-app:cadastro-signup-background-v184-overlay-20260520162049"
EXPECTED_PUBLIC_VERSION="build-1779302930572"
NEW_PUBLIC_VERSION="build-1779370265418"
MAIN_JS="assets/main-BtmyCJgE.js"
MAIN_CSS="assets/main-B0TiMXXc.css"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-meu-agente-mobile-nav-v185-overlay-20260521103138"
SESSIONS_DIR="/data/agentezap/sessions"

check_marker() {
  local label="$1"
  shift
  echo "[deploy] check=${label}"
  "$@"
}

http_get() {
  docker exec agentezap-app node -e "fetch(process.argv[1]).then(async r=>{const t=await r.text(); console.log(t); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})" "$1"
}

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"
current_public_version="$(http_get 'http://127.0.0.1:5000/pwa-version.json' | grep -o "build-[0-9]*" | head -n 1 || true)"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] current_public_version=${current_public_version}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 1
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi
if [ "$current_public_version" != "$EXPECTED_PUBLIC_VERSION" ]; then
  echo "[deploy] ERROR: public build changed since validation (${current_public_version} != ${EXPECTED_PUBLIC_VERSION}). Rebase this deploy first." >&2
  exit 1
fi

check_marker base_theme_ai docker exec agentezap-app sh -lc "grep -aR -m 1 'Personalize com IA' /app/dist/public >/dev/null"
check_marker base_theme_simulator docker exec agentezap-app sh -lc "grep -aR -m 1 'Simulador WhatsApp' /app/dist/public >/dev/null"
check_marker base_mobile_entry docker exec agentezap-app sh -lc "grep -aR -m 1 'mobile=editor' /app/dist/public >/dev/null"
check_marker base_billing_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'button-settings-open-billing' /app/dist/public >/dev/null"

cd "$DEPLOY_DIR"
test -f dist/index.js
test -f dist/api/http.js
test -f public/index.html
test -f public/pwa-version.json
test -f "public/${MAIN_JS}"
test -f "public/${MAIN_CSS}"

check_marker artifact_signup_background grep -aR -m 1 'sendSignupWelcomeMessageInBackground' dist
check_marker artifact_theme_ai grep -aR -m 1 'Personalize com IA' public
check_marker artifact_theme_simulator grep -aR -m 1 'Simulador WhatsApp' public
check_marker artifact_mobile_entry grep -aR -m 1 'mobile=editor' public
check_marker artifact_onboarding grep -aR -m 1 'Crie seu Agente IA' public
check_marker artifact_billing_marker grep -aR -m 1 'button-settings-open-billing' public
check_marker artifact_mobile_editor_more grep -aR -m 1 'button-mobile-editor-more' public
check_marker artifact_mobile_editor_menu grep -aR -m 1 'menu-mobile-editor-sections' public
check_marker artifact_pwa_version grep -a "$NEW_PUBLIC_VERSION" public/pwa-version.json
check_marker artifact_boot_js grep -a "$MAIN_JS" public/assets/index-d67MYvjU.js
check_marker artifact_boot_css grep -a "$MAIN_CSS" public/assets/index-d67MYvjU.js

check_marker artifact_fk_catalog_before_name grep -aR -m 1 'catalog_request_before_name_to_name_question' dist
check_marker artifact_mauricio_mfc_module grep -aR -m 1 'mauricioMfcCatalogModule' dist
check_marker artifact_mauricio_mfc_price grep -aR -m 1 'resolveMauricioMfcCatalogUnitPrice' dist
check_marker artifact_adriana_greeting_guard grep -aR -m 1 'explicit_customer_greeting_period_guard_keep' dist
check_marker artifact_owner_signature_independent grep -aR -m 1 'owner_manual_signature_independent_from_ai_signature_v162' dist
check_marker artifact_tico_user grep -aR -m 1 'TICO_LOCACOES_USER_ID' dist
check_marker artifact_tico_mode grep -aR -m 1 'tico_locacoes_media' dist
check_marker artifact_jb_user grep -aR -m 1 'JB_ELETRICA_USER_ID' dist
check_marker artifact_jb_payment_guard grep -aR -m 1 'agendamento3_payment_confirmation_guard' dist
check_marker artifact_jb_intake_guard grep -aR -m 1 'agendamento3_strict_intake_guard' dist
check_marker artifact_jb_unknown_guard grep -aR -m 1 'agendamento3_strict_unknown_intent_guard' dist

cat > Dockerfile <<EOF
FROM ${current_image}
RUN find /app/dist -maxdepth 1 -type f -name '*.js' -delete && rm -rf /app/dist/api
COPY dist/ /app/dist/
COPY public/ /app/dist/public/
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
pre_switch_public_version="$(http_get 'http://127.0.0.1:5000/pwa-version.json' | grep -o "build-[0-9]*" | head -n 1 || true)"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi
if [ "$pre_switch_public_version" != "$EXPECTED_PUBLIC_VERSION" ]; then
  echo "[deploy] ERROR: public build changed while building (${pre_switch_public_version} != ${EXPECTED_PUBLIC_VERSION}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-meu-agente-mobile-nav-v185"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path(".env.runtime")
desired = {
    "AGENTEZAP_APP_IMAGE": tag,
    "NODE_OPTIONS": "--max-old-space-size=4096",
    "WA_PENDING_TIMERS_START_DURING_RESTORE": "false",
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in desired:
        out.append(f"{key}={desired[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"
running_public_version="$(http_get 'http://127.0.0.1:5000/pwa-version.json' | grep -o "build-[0-9]*" | head -n 1 || true)"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] running_public_version=${running_public_version}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during app deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy after deploy" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi
if [ "$running_public_version" != "$NEW_PUBLIC_VERSION" ]; then
  echo "[deploy] ERROR: public version did not update (${running_public_version} != ${NEW_PUBLIC_VERSION})" >&2
  exit 1
fi

check_marker deployed_signup_background docker exec agentezap-app sh -lc "grep -aR -m 1 'sendSignupWelcomeMessageInBackground' /app/dist >/dev/null"
check_marker deployed_theme_ai docker exec agentezap-app sh -lc "grep -aR -m 1 'Personalize com IA' /app/dist/public >/dev/null"
check_marker deployed_theme_simulator docker exec agentezap-app sh -lc "grep -aR -m 1 'Simulador WhatsApp' /app/dist/public >/dev/null"
check_marker deployed_mobile_entry docker exec agentezap-app sh -lc "grep -aR -m 1 'mobile=editor' /app/dist/public >/dev/null"
check_marker deployed_onboarding docker exec agentezap-app sh -lc "grep -aR -m 1 'Crie seu Agente IA' /app/dist/public >/dev/null"
check_marker deployed_billing_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'button-settings-open-billing' /app/dist/public >/dev/null"
check_marker deployed_mobile_editor_more docker exec agentezap-app sh -lc "grep -aR -m 1 'button-mobile-editor-more' /app/dist/public >/dev/null"
check_marker deployed_mobile_editor_menu docker exec agentezap-app sh -lc "grep -aR -m 1 'menu-mobile-editor-sections' /app/dist/public >/dev/null"
check_marker deployed_fk_catalog_before_name docker exec agentezap-app sh -lc "grep -aR -m 1 'catalog_request_before_name_to_name_question' /app/dist >/dev/null"
check_marker deployed_owner_signature_independent docker exec agentezap-app sh -lc "grep -aR -m 1 'owner_manual_signature_independent_from_ai_signature_v162' /app/dist >/dev/null"
check_marker deployed_jb_intake_guard docker exec agentezap-app sh -lc "grep -aR -m 1 'agendamento3_strict_intake_guard' /app/dist >/dev/null"

docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"

echo "[deploy] done"
