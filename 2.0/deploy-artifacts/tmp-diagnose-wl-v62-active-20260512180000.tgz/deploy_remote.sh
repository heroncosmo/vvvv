#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE="agentezap-app:meta-form-google-oauth-v62-20260512170913"
COMPOSE_DIR="/opt/agentezap-single/compose"
RUNTIME_ENV="${COMPOSE_DIR}/.env.runtime"

cd "${COMPOSE_DIR}"
test -f compose.yml
test -f "${RUNTIME_ENV}"

APP_CONTAINER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app || true)"
if [[ -z "${APP_CONTAINER}" ]]; then
  echo "app container not found" >&2
  exit 2
fi

ACTIVE_IMAGE="$(docker inspect -f '{{.Config.Image}}' "${APP_CONTAINER}" || true)"
echo "active_image=${ACTIVE_IMAGE}"
if [[ "${ACTIVE_IMAGE}" != "${EXPECTED_ACTIVE}" ]]; then
  echo "Abort diagnose: active image is not ${EXPECTED_ACTIVE}; got ${ACTIVE_IMAGE}" >&2
  exit 42
fi

docker exec "${APP_CONTAINER}" node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('healthz', r.status, await r.text()); if(!r.ok) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"
docker exec "${APP_CONTAINER}" node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{const text=await r.text(); console.log('api_health', r.status, text); if(!r.ok || !text.includes('monolith')) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"

echo "---- m2 correction anchors ----"
docker exec "${APP_CONTAINER}" sh -lc "grep -n 'function buildWebOnlyPromptM2AmountCorrection' /app/dist/api/http.js || true"
docker exec "${APP_CONTAINER}" sh -lc "grep -n 'fullContext' /app/dist/api/http.js | head -20 || true"
docker exec "${APP_CONTAINER}" sh -lc "grep -n 'extractWebOnlyAreaM2FromQuoteContext' /app/dist/api/http.js | head -20 || true"
docker exec "${APP_CONTAINER}" sh -lc "node - <<'NODE'
const fs = require('fs');
const src = fs.readFileSync('/app/dist/api/http.js', 'utf8');
function printBlock(label, needle, before = 300, after = 1600) {
  const index = src.indexOf(needle);
  console.log('==== ' + label + ' index=' + index + ' ====');
  if (index < 0) return;
  console.log(src.slice(Math.max(0, index - before), Math.min(src.length, index + after)));
}
printBlock('buildWebOnlyPromptM2AmountCorrection', 'function buildWebOnlyPromptM2AmountCorrection');
printBlock('hasWebOnlyStrongVideoPromise', 'function hasWebOnlyStrongVideoPromise');
printBlock('optimize call site', 'buildWebOnlyPromptM2AmountCorrection({');
NODE"

echo "diagnose_finished"
