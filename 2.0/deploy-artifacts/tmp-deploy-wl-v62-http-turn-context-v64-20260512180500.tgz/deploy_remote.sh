#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE="agentezap-app:meta-form-google-oauth-v62-20260512170913"
NEW_IMAGE="agentezap-app:wl-vidracaria-v62-http-turn-context-v64-20260512180500"
COMPOSE_DIR="/opt/agentezap-single/compose"
RUNTIME_ENV="${COMPOSE_DIR}/.env.runtime"
PATCH_CONTAINER="wl_v62_http_turn_context_patch_20260512180500"

cd "${COMPOSE_DIR}"
test -f compose.yml
test -f "${RUNTIME_ENV}"

rollback() {
  echo "rollback_to=${EXPECTED_ACTIVE}"
  if grep -q '^AGENTEZAP_APP_IMAGE=' "${RUNTIME_ENV}"; then
    sed -i "s|^AGENTEZAP_APP_IMAGE=.*|AGENTEZAP_APP_IMAGE=${EXPECTED_ACTIVE}|" "${RUNTIME_ENV}"
  else
    printf '\nAGENTEZAP_APP_IMAGE=%s\n' "${EXPECTED_ACTIVE}" >> "${RUNTIME_ENV}"
  fi
  docker compose --env-file "${RUNTIME_ENV}" -f compose.yml up -d --no-deps --wait app || true
  docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps app || true
}

APP_CONTAINER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app || true)"
if [[ -z "${APP_CONTAINER}" ]]; then
  echo "app container not found" >&2
  exit 2
fi

ACTIVE_IMAGE="$(docker inspect -f '{{.Config.Image}}' "${APP_CONTAINER}" || true)"
echo "active_image=${ACTIVE_IMAGE}"
if [[ "${ACTIVE_IMAGE}" != "${EXPECTED_ACTIVE}" ]]; then
  echo "Abort deploy: active image is not ${EXPECTED_ACTIVE}; got ${ACTIVE_IMAGE}" >&2
  exit 42
fi

docker exec "${APP_CONTAINER}" node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('healthz_before', r.status, await r.text()); if(!r.ok) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"
docker exec "${APP_CONTAINER}" node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{const text=await r.text(); console.log('api_health_before', r.status, text); if(!r.ok || !text.includes('monolith')) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"

BEFORE_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
BEFORE_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_before=${BEFORE_AUTH_DIRS}/${BEFORE_CREDS}"

docker rm -f "${PATCH_CONTAINER}" >/dev/null 2>&1 || true
docker create --name "${PATCH_CONTAINER}" --entrypoint sh "${EXPECTED_ACTIVE}" -c "sleep 600" >/dev/null
docker start "${PATCH_CONTAINER}" >/dev/null

cat > /tmp/patch_wl_http_turn_context.js <<'NODE'
const fs = require('fs');
const file = '/app/dist/api/http.js';
let src = fs.readFileSync(file, 'utf8');

function replaceOnce(label, oldText, newText) {
  if (!src.includes(oldText)) {
    throw new Error(`missing anchor: ${label}`);
  }
  src = src.replace(oldText, newText);
  console.log(`patched=${label}`);
}

const oldM2 = [
  '  const historyContext = Array.isArray(input.history) ? input.history.slice(-8).map((entry) => `${entry.role}: ${entry.content}`).join("\\n") : "";',
  '  const fullContext = [input.message, historyContext, originalText].filter(Boolean).join("\\n");',
  '  const areaM2 = extractWebOnlyAreaM2FromQuoteContext({',
  '    context: fullContext,',
  '    itemLabel: fullContext,',
  '    prompt: input.prompt',
  '  });'
].join('\n');

const newM2 = String.raw`  const currentMessageText = repairWebOnlyOutgoingText(input.message);
  const currentMessageHasMeasure = /\b\d{1,4}(?:[,.]\d{1,2})?\s*(?:x|por|\u00d7)\s*\d{1,4}(?:[,.]\d{1,2})?\b/i.test(currentMessageText) || /\b(?:largura|frente|v[a\u00e3]o|altura|alto|medida|medidas|tamanho)\b.{0,36}\b\d{2,4}(?:[,.]\d{1,2})?\b/i.test(currentMessageText) || /\b\d{2,4}(?:[,.]\d{1,2})?\b.{0,36}\b(?:largura|frente|v[a\u00e3]o|altura|alto|cent[i\u00ed]metros?|cm)\b/i.test(currentMessageText) || extractWebOnlyAreaM2FromQuoteContext({
    context: currentMessageText,
    itemLabel: currentMessageText,
    prompt: input.prompt
  }) !== null;
  if (!currentMessageHasMeasure) return null;
  const fullContext = [input.message, originalText].filter(Boolean).join("\n");
  const areaM2 = extractWebOnlyAreaM2FromQuoteContext({
    context: fullContext,
    itemLabel: fullContext,
    prompt: input.prompt
  });`;

const oldVideo = String.raw`  return /\b(vou|irei|enviei|enviando|segue|manda|mando|mandando|mostro|mostrar|encaminho|encaminhando)\b.{0,50}\b(video|videos|midia|midias|material|arquivo|arquivos)\b/.test(normalized) || /\b(video|videos|midia|midias|material|arquivo|arquivos)\b.{0,50}\b(envio|mando|mandei|encaminho|mostro|mostrar|segue)\b/.test(normalized) || /\b(ja|agora)\s+(te\s+)?(envio|mando|encaminho|mostro)\b.{0,50}\b(video|videos|midia|midias|material|arquivo|arquivos)\b/.test(normalized) || /\b(aqui\s+(esta|ta)|confere|olha)\s+(o\s+)?(video|material|arquivo)\b/.test(normalized) || /\b(te\s+)?(envio|mando|encaminho)\s+(o\s+)?(video|material|arquivo)\b/.test(normalized);`;

const newVideo = String.raw`  if (/\b(?:pode|consegue|conseguiria|tem\s+como)\b.{0,50}\b(?:enviar|mandar|encaminhar)\b.{0,80}\b(?:foto|fotos|imagem|imagens|video|videos|midia|midias|arquivo|arquivos)\b/.test(normalized) || /\b(?:me|nos)\s+(?:envia|envie|manda|mande|encaminha|encaminhe)\b.{0,80}\b(?:foto|fotos|imagem|imagens|video|videos|midia|midias|arquivo|arquivos)\b/.test(normalized) || /\b(?:foto|fotos|imagem|imagens|video|videos)\b.{0,60}\b(?:do|da|de|mostrando)\b.{0,60}\b(?:problema|vidro|box|produto|peca|pe[c\u00e7]a|local)\b/.test(normalized)) return false;
  return /\b(vou|irei|enviei|enviando|segue|mando|mandando|mostro|mostrar|encaminho|encaminhando)\b.{0,50}\b(video|videos|midia|midias|material|arquivo|arquivos)\b/.test(normalized) || /\b(video|videos|midia|midias|material|arquivo|arquivos)\b.{0,50}\b(envio|mando|mandei|encaminho|mostro|mostrar|segue)\b/.test(normalized) || /\b(ja|agora)\s+(te\s+)?(envio|mando|encaminho|mostro)\b.{0,50}\b(video|videos|midia|midias|material|arquivo|arquivos)\b/.test(normalized) || /\b(aqui\s+(esta|ta)|confere|olha)\s+(o\s+)?(video|material|arquivo)\b/.test(normalized) || /\b(te\s+)?(envio|mando|encaminho)\s+(o\s+)?(video|material|arquivo)\b/.test(normalized);`;

replaceOnce('m2-current-turn-context', oldM2, newM2);
replaceOnce('customer-media-upload-request-not-promise', oldVideo, newVideo);

fs.writeFileSync(file, src);
console.log('patch_complete=true');
NODE

docker cp /tmp/patch_wl_http_turn_context.js "${PATCH_CONTAINER}:/tmp/patch_wl_http_turn_context.js"
docker exec "${PATCH_CONTAINER}" node /tmp/patch_wl_http_turn_context.js
docker exec "${PATCH_CONTAINER}" node --check /app/dist/api/http.js
docker commit "${PATCH_CONTAINER}" "${NEW_IMAGE}" >/dev/null
docker rm -f "${PATCH_CONTAINER}" >/dev/null

if grep -q '^AGENTEZAP_APP_IMAGE=' "${RUNTIME_ENV}"; then
  sed -i "s|^AGENTEZAP_APP_IMAGE=.*|AGENTEZAP_APP_IMAGE=${NEW_IMAGE}|" "${RUNTIME_ENV}"
else
  printf '\nAGENTEZAP_APP_IMAGE=%s\n' "${NEW_IMAGE}" >> "${RUNTIME_ENV}"
fi

if ! docker compose --env-file "${RUNTIME_ENV}" -f compose.yml up -d --no-deps --wait app; then
  echo "deploy_failed_during_compose_wait" >&2
  rollback
  exit 1
fi

APP_CONTAINER_AFTER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app)"
if ! docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('healthz_after', r.status, await r.text()); if(!r.ok) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"; then
  rollback
  exit 1
fi
if ! docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{const text=await r.text(); console.log('api_health_after', r.status, text); if(!r.ok || !text.includes('monolith')) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"; then
  rollback
  exit 1
fi

AFTER_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
AFTER_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_after=${AFTER_AUTH_DIRS}/${AFTER_CREDS}"
echo "deploy_finished=${NEW_IMAGE}"
