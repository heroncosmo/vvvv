#!/usr/bin/env bash
set -euo pipefail

artifact=/tmp/tmp-deploy-pwa-version-sync-v293-20260529023500.tgz
workdir=/tmp/tmp-deploy-pwa-version-sync-v293-20260529023500
tag=agentezap-app:pwa-version-sync-v293-20260529023500
base=agentezap-app:protocol-message-no-promote-v292-20260529021500
expected_version=build-1780019181659

running_before="$(docker inspect agentezap-app --format '{{.Config.Image}}' 2>/dev/null || true)"
if [ "$running_before" != "$base" ]; then
  echo "ABORT_BASE_MISMATCH expected=$base running=$running_before" >&2
  exit 42
fi

ag_creds_before=$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l)
legacy_creds_before=$(find /data/whatsapp-sessions -name creds.json 2>/dev/null | wc -l)

rm -rf "$workdir"
mkdir -p "$workdir"
tar -xzf "$artifact" -C "$workdir"

{
  printf 'FROM %s\n' "$base"
  printf 'WORKDIR /app\n'
  printf 'COPY dist/public/pwa-version.json /app/dist/public/pwa-version.json\n'
  printf 'COPY dist/public/sw.js /app/dist/public/sw.js\n'
  printf 'COPY dist/public/site.webmanifest /app/dist/public/site.webmanifest\n'
  printf 'LABEL agentezap.patch="pwa-version-sync-v293"\n'
} > "$workdir/Dockerfile"

grep -aR -m 1 "$expected_version" "$workdir/dist/public/pwa-version.json" >/dev/null
grep -aR -m 1 "$expected_version" "$workdir/dist/public/sw.js" >/dev/null
grep -aR -m 1 "$expected_version" "$workdir/dist/public/site.webmanifest" >/dev/null

docker build -f "$workdir/Dockerfile" -t "$tag" "$workdir"

cd /opt/agentezap-single/compose
test -f compose.host-nginx.yml
./scripts/deploy-service.sh app "$tag"

printf 'LOCAL_HEALTH='
curl -fsS http://127.0.0.1:5000/healthz
echo
printf 'LOCAL_API_HEALTH='
curl -fsS http://127.0.0.1:5000/api/health
echo
printf 'PUBLIC_HEALTH='
curl -fsS https://agentezap.online/healthz
echo
printf 'PUBLIC_API_HEALTH='
curl -fsS https://agentezap.online/api/health
echo
printf 'PUBLIC_PWA_VERSION='
curl -fsS https://agentezap.online/pwa-version.json
echo
printf 'PUBLIC_SW_VERSION='
curl -fsS https://agentezap.online/sw.js | head -n 1
echo
printf 'MARKER='
docker exec agentezap-app sh -lc "grep -aR -m 1 'build-1780019181659' /app/dist/public/pwa-version.json >/dev/null && grep -aR -m 1 'build-1780019181659' /app/dist/public/sw.js >/dev/null && grep -aR -m 1 'build-1780019181659' /app/dist/public/assets/main-DvcVRf65.js >/dev/null && echo pwa-version-sync-ok"

ag_creds_after=$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l)
legacy_creds_after=$(find /data/whatsapp-sessions -name creds.json 2>/dev/null | wc -l)

echo "BASE_IMAGE=$base"
echo "NEW_IMAGE=$tag"
echo "RUNNING_BEFORE=$running_before"
echo "RUNNING_IMAGE=$(docker inspect agentezap-app --format '{{.Config.Image}}')"
echo "AGENTEZAP_CREDS_BEFORE=$ag_creds_before"
echo "AGENTEZAP_CREDS_AFTER=$ag_creds_after"
echo "LEGACY_CREDS_BEFORE=$legacy_creds_before"
echo "LEGACY_CREDS_AFTER=$legacy_creds_after"
echo "PORTS=$(docker port agentezap-app 2>/dev/null | tr '\n' ',')"