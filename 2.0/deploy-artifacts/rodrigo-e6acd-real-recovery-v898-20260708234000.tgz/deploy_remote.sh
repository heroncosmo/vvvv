#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE_IMAGE="agentezap-app:rodrigo-create-agent-email-extract-v898-20260708233000"

echo "[recovery] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[recovery] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[recovery] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

echo "[recovery] running guarded real recovery v898 for e6acd"
timeout --kill-after=20s 900s docker exec -i agentezap-app node --input-type=module <<'NODE' 2>&1 | sed -E \
  -e 's/contato@editoraplantasdobrasil\.com\.br/[redacted-lead-email]/g' \
  -e 's#https://agentezap\.online/test/[A-Za-z0-9._-]+#[redacted-test-url]#g' \
  -e 's/554288615476/[redacted-lead-phone]/g'
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import pg from "pg";

const conversationId = "e6acd123-10fc-4f44-82af-052949d5f13a";
const ownerEmail = "rodrigo4@gmail.com";
const expectedOwnerId = "cb9213c3-fde3-479e-a4aa-344171c59735";
const expectedLatestMessageId = "afad87d8-b7a0-4895-b4a2-90c4ebd2c945";
const expectedLatestText = "Por nada, Daniel. Te aviso por aqui quando estiver pronto para acessar e testar.";
const expectedInboundId = "38b35640-c938-4c50-9e00-242247adfe61";
const expectedInboundText = "ok, obrigado.";
const expectedLeadEmail = "contato@editoraplantasdobrasil.com.br";
const expectedLeadPhone = "554288615476";
const startedAt = new Date();

const distDir = "/app/dist";
const files = fs.readdirSync(distDir);
const storageFile = files.find((name) => /^storage-.*\.js$/.test(name));
const whatsappFile = files.find((name) => /^whatsapp-.*\.js$/.test(name));
if (!storageFile) throw new Error("storage bundle not found");
if (!whatsappFile) throw new Error("whatsapp bundle not found");

const { runWebOnlyAgentTestForUser } = await import(pathToFileURL(path.join(distDir, "api", "http.js")).href);
const { storage } = await import(pathToFileURL(path.join(distDir, storageFile)).href);
const { sendMessage } = await import(pathToFileURL(path.join(distDir, whatsappFile)).href);

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  max: 2,
  idleTimeoutMillis: 1000,
  connectionTimeoutMillis: 15000,
});

function normalizeText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function mapHistoryRow(row) {
  return {
    role: row.from_me ? "assistant" : "user",
    speaker: row.from_me ? "agent" : "customer",
    content: String(row.text || "").trim(),
  };
}

async function loadConversationState() {
  const result = await pool.query(
    `
      SELECT
        c.id,
        c.contact_name,
        c.contact_number,
        c.connection_id,
        c.last_message_text,
        c.last_message_time,
        c.last_message_from_me,
        c.followup_active,
        c.followup_stage,
        c.next_followup_at,
        wc.user_id,
        wc.is_connected,
        wc.ai_enabled,
        wc.provider_status,
        u.email AS owner_email
      FROM conversations c
      JOIN whatsapp_connections wc ON wc.id = c.connection_id
      JOIN users u ON u.id = wc.user_id
      WHERE c.id = $1
      LIMIT 1
    `,
    [conversationId],
  );
  return result.rows[0] || null;
}

async function loadMessagesAsc() {
  const result = await pool.query(
    `
      SELECT id, from_me, is_from_agent, text, timestamp, created_at
      FROM messages
      WHERE conversation_id = $1
      ORDER BY timestamp ASC NULLS FIRST, created_at ASC NULLS FIRST, id ASC
    `,
    [conversationId],
  );
  return result.rows;
}

async function assertFresh(label) {
  const state = await loadConversationState();
  if (!state) throw new Error(`${label}: conversation_not_found`);
  if (String(state.user_id) !== expectedOwnerId || String(state.owner_email).toLowerCase() !== ownerEmail) {
    throw new Error(`${label}: owner_mismatch`);
  }
  if (state.is_connected !== true || state.ai_enabled !== true || String(state.provider_status || "") !== "connected") {
    throw new Error(`${label}: connection_not_ready`);
  }
  if (String(state.contact_number || "") !== expectedLeadPhone) {
    throw new Error(`${label}: contact_phone_mismatch`);
  }

  const latest = await pool.query(
    `
      SELECT id, from_me, is_from_agent, text, timestamp, created_at
      FROM messages
      WHERE conversation_id = $1
      ORDER BY timestamp DESC NULLS LAST, created_at DESC NULLS LAST, id DESC
      LIMIT 1
    `,
    [conversationId],
  );
  const row = latest.rows[0];
  if (!row) throw new Error(`${label}: no_messages`);
  if (
    String(row.id) !== expectedLatestMessageId ||
    row.from_me !== true ||
    row.is_from_agent !== true ||
    normalizeText(row.text) !== normalizeText(expectedLatestText)
  ) {
    throw new Error(`${label}: freshness_changed latest=${row?.id || "none"}`);
  }
  return state;
}

async function assertNoNewInboundSinceStarted(label) {
  const result = await pool.query(
    `
      SELECT id, text, created_at
      FROM messages
      WHERE conversation_id = $1
        AND from_me = false
        AND created_at >= $2
      ORDER BY created_at DESC, id DESC
      LIMIT 1
    `,
    [conversationId, startedAt.toISOString()],
  );
  if (result.rows[0]) {
    throw new Error(`${label}: new_inbound_after_generation id=${result.rows[0].id}`);
  }
}

await assertFresh("before_generation");

const existing = await pool.query(
  `
    SELECT id, email, phone
    FROM users
    WHERE lower(email) = lower($1)
       OR regexp_replace(coalesce(phone, ''), '\\D', '', 'g') = $2
  `,
  [expectedLeadEmail, expectedLeadPhone],
);
const existingRows = existing.rows || [];
if (existingRows.length > 1) {
  throw new Error("multiple_existing_lead_users_before_recovery");
}
if (existingRows.length === 1) {
  const existingRow = existingRows[0];
  const existingEmail = String(existingRow.email || "").toLowerCase();
  const existingPhone = String(existingRow.phone || "").replace(/\D/g, "");
  const allowedExisting =
    existingEmail === expectedLeadEmail ||
    (existingEmail === `${expectedLeadPhone}@agentezap.online` && existingPhone === expectedLeadPhone);
  if (!allowedExisting) {
    throw new Error("unexpected_existing_lead_user_before_recovery");
  }
}

const messages = await loadMessagesAsc();
const inboundIndex = messages.findIndex((row) => String(row.id) === expectedInboundId);
if (inboundIndex < 0) throw new Error("expected_inbound_not_found");
const inbound = messages[inboundIndex];
if (normalizeText(inbound.text) !== normalizeText(expectedInboundText) || inbound.from_me === true) {
  throw new Error("expected_inbound_mismatch");
}
const history = messages
  .slice(0, inboundIndex)
  .filter((row) => String(row.text || "").trim())
  .map(mapHistoryRow);

const rodrigo = await storage.getUserByEmail(ownerEmail);
if (!rodrigo?.id || String(rodrigo.id) !== expectedOwnerId) {
  throw new Error("rodrigo_user_not_found_or_mismatch");
}

const result = await runWebOnlyAgentTestForUser(rodrigo.id, {
  message: expectedInboundText,
  history,
  contactName: "Daniel Saueressig",
  contactPhone: expectedLeadPhone,
  conversationId,
  testConversationKey: `recovery-v898-${conversationId}`,
  skipAccessCheck: true,
  agenticRuntimeEnabled: true,
  allowRodrigoCreateAgentContract: true,
  agendamento3Commit: true,
  flow2DeferStatePersistence: true,
  llmProviderTimeoutMs: 240000,
  publicTestRequestTimeoutMs: 300000,
});

const payload = result?.payload || {};
const parts = Array.isArray(payload.splitResponses)
  ? payload.splitResponses.map((item) => String(item || "").trim()).filter(Boolean)
  : [];
if (parts.length === 0 && String(payload.response || "").trim()) {
  parts.push(String(payload.response).trim());
}
const responseText = parts.join("\n\n");
const testUrlMatch = responseText.match(/https:\/\/agentezap\.online\/test\/[A-Za-z0-9._-]+/);
if (Number(result?.status || 500) >= 400 || parts.length === 0 || !testUrlMatch) {
  throw new Error(`codex_recovery_no_valid_link status=${result?.status || "unknown"} parts=${parts.length}`);
}

const created = await pool.query(
  `
    SELECT id, email, phone
    FROM users
    WHERE lower(email) = lower($1)
    LIMIT 1
  `,
  [expectedLeadEmail],
);
const createdUser = created.rows[0] || null;
if (!createdUser?.id) {
  throw new Error("created_user_with_expected_email_not_found");
}

const token = await pool.query(
  "SELECT token FROM admin_test_tokens WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1",
  [createdUser.id],
);
if (!token.rows[0]?.token) {
  throw new Error("created_user_missing_test_token");
}

await assertFresh("before_send");

const sendResults = [];
for (const part of parts) {
  await assertNoNewInboundSinceStarted(`before_send_part_${sendResults.length + 1}`);
  const sendResult = await sendMessage(rodrigo.id, conversationId, part, {
    isFromAgent: true,
    source: "agent",
    acceptQueued: true,
  });
  sendResults.push(sendResult);
  if (sendResult?.success === false) {
    throw new Error(`send_failed:${sendResult.reason || "unknown"}`);
  }
}
await assertNoNewInboundSinceStarted("after_send");

const verify = await pool.query(
  `
    SELECT
      count(*) FILTER (WHERE from_me = true AND is_from_agent = true AND text LIKE '%https://agentezap.online/test/%' AND created_at >= $2)::int AS link_messages,
      max(created_at) AS last_created_at
    FROM messages
    WHERE conversation_id = $1
  `,
  [conversationId, startedAt.toISOString()],
);
const linkMessages = Number(verify.rows[0]?.link_messages || 0);
if (linkMessages < 1) {
  throw new Error("sent_link_message_not_persisted");
}

const followup = await pool.query(
  `
    SELECT followup_active, followup_stage, next_followup_at, last_message_from_me, left(coalesce(last_message_text,''), 300) AS last_message_text
    FROM conversations
    WHERE id = $1
  `,
  [conversationId],
);

console.log(JSON.stringify({
  ok: true,
  status: Number(result?.status || 0),
  createdUser: Boolean(createdUser?.id),
  createdEmail: expectedLeadEmail,
  hasTestUrl: Boolean(testUrlMatch),
  parts: parts.length,
  sent: sendResults.length,
  linkMessages,
  sendStatuses: sendResults.map((item) => ({ success: item?.success !== false, queued: item?.queued === true, blocked: item?.blocked === true })),
  followup: followup.rows[0] || null,
  responsePreview: responseText.slice(0, 320),
}));

await pool.end().catch(() => {});
NODE

echo "[recovery] ok"
