#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE_IMAGE="agentezap-app:followup-model-policy-v890b-20260708153300"

echo "[inspect] active container"
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[inspect] unexpected active image: $ACTIVE_IMAGE" >&2
  exit 1
fi

echo "[inspect] port and health"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

echo "[inspect] env policy"
docker exec agentezap-app sh -lc '
  set -eu
  env | grep -E "^(AGENTEZAP_CODEX_CLI_(FOLLOWUP|TENANT|RODRIGO)_(MODEL|REASONING_EFFORT)|ENABLE_VPS_INTERNAL_CRONS|ENABLE_STATEFUL_INTERVAL_JOBS|STATEFUL_JOB_CRON_USER_FOLLOWUP_SCHEDULE)=" | sort
'

echo "[inspect] bundle markers"
docker exec -i agentezap-app node - <<'NODE'
const fs = require("node:fs");
const source = fs.readFileSync("/app/dist/api/http.js", "utf8");
const fullAppFile = fs.readdirSync("/app/dist").find((name) => /^full-app-.*\.js$/.test(name));
if (!fullAppFile) throw new Error("full-app bundle not found");
const fullApp = fs.readFileSync(`/app/dist/${fullAppFile}`, "utf8");
function sliceBetween(label, startNeedle, endNeedle) {
  const start = source.indexOf(startNeedle);
  const end = source.indexOf(endNeedle, start);
  if (start < 0 || end <= start) throw new Error(`${label} block not found`);
  return source.slice(start, end);
}
const modelBlock = sliceBetween("model selection", "function selectCodexModel", "function selectCodexReasoningEffort");
const reasoningBlock = sliceBetween("reasoning selection", "function selectCodexReasoningEffort", "function buildCodexEnv");
const checks = {
  followupModelPolicy: modelBlock.includes("AGENTEZAP_CODEX_CLI_FOLLOWUP_MODEL") && modelBlock.includes('"gpt-5.4-mini"'),
  followupBeforeRodrigoModel: modelBlock.indexOf("AGENTEZAP_CODEX_CLI_FOLLOWUP_MODEL") < modelBlock.indexOf("AGENTEZAP_CODEX_CLI_RODRIGO_MODEL"),
  followupReasoningPolicy: reasoningBlock.includes("AGENTEZAP_CODEX_CLI_FOLLOWUP_REASONING_EFFORT") && reasoningBlock.includes("AGENTEZAP_CODEX_CLI_TENANT_REASONING_EFFORT"),
  followupBeforeRodrigoReasoning: reasoningBlock.indexOf("AGENTEZAP_CODEX_CLI_FOLLOWUP_REASONING_EFFORT") < reasoningBlock.indexOf("AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT"),
  rodrigoNormalModel: modelBlock.includes("AGENTEZAP_CODEX_CLI_RODRIGO_MODEL") && modelBlock.includes('"gpt-5.5"'),
  rodrigoNormalReasoning: reasoningBlock.includes("AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT") && reasoningBlock.includes('"xhigh"'),
  tenantModel: modelBlock.includes("AGENTEZAP_CODEX_CLI_TENANT_MODEL") && modelBlock.includes('"gpt-5.4-mini"'),
  contextUsesActualModel: source.includes("model:${usedModel}"),
  noFixedRodrigoContextModel: !source.includes("model:gpt-5.5"),
  triggerParity: fullApp.includes('app.all("/api/followup/conversation/:id/trigger", delegateToVercelHttpHandler);'),
  noBroadFollowupDelegation: !fullApp.includes('app.all("/api/followup/*", delegateToVercelHttpHandler);'),
};
for (const [name, ok] of Object.entries(checks)) {
  if (!ok) throw new Error(`marker failed: ${name}`);
}
console.log(JSON.stringify(checks));
NODE

echo "[inspect] recent followup logs"
recent="$(docker logs --since 10m agentezap-app 2>&1 || true)"
echo "$recent" | grep -aE 'VPS CRON|vercel-followup-cron|USER-FOLLOW-UP|user-followup|agentic_followup' | tail -n 80 || true
if echo "$recent" | grep -aE 'statement timeout|sanitizeWebOnlyAgenticToolName|structured_output_invalid|ReferenceError|AbortError|MODULE_NOT_FOUND|SyntaxError|UnhandledPromiseRejection'; then
  echo "[inspect] recent error marker found" >&2
  exit 2
fi

echo "[inspect] READONLY_OK"
