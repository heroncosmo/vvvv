#!/usr/bin/env bash
set -euo pipefail

echo "ANDERSON_SUBSCRIPTION_LOOKUP2_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");
const url = process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL;
const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
const userId = "33d36098-0b80-4913-bd6a-02125a643934";
async function q(name, sql, params = []) {
  try {
    const result = await client.query(sql, params);
    console.log(`## ${name}`);
    console.log(JSON.stringify(result.rows, null, 2));
  } catch (error) {
    console.log(`## ${name}_ERROR`);
    console.log(error.message);
  }
}
(async () => {
  await client.connect();
  await q("subscriptions_target", `
    SELECT s.id, s.user_id, u.email, u.name, p.nome AS plan_name, p.valor AS plan_price,
           p.periodicidade, p.frequencia_dias, s.plan_id, s.status, s.coupon_price,
           s.data_inicio, s.data_fim, s.next_payment_date, s.pending_receipt,
           s.payer_email, s.payment_method, s.created_at, s.metadata
    FROM subscriptions s
    JOIN users u ON u.id = s.user_id
    JOIN plans p ON p.id = s.plan_id
    WHERE s.user_id = $1
    ORDER BY s.created_at DESC
  `, [userId]);
  await q("payment_history_target", `
    SELECT id, subscription_id, user_id, amount, status, status_detail, payment_type,
           payment_method, mp_payment_id, payer_email, created_at, raw_response
    FROM payment_history
    WHERE user_id = $1
    ORDER BY created_at DESC
    LIMIT 20
  `, [userId]);
  await q("receipts_target", `
    SELECT id, subscription_id, user_id, plan_id, amount, status, receipt_url,
           receipt_filename, receipt_mime_type, mp_payment_id, reviewed_by, reviewed_at,
           review_notes, created_at
    FROM payment_receipts
    WHERE user_id = $1
    ORDER BY created_at DESC
    LIMIT 20
  `, [userId]);
  await client.end();
})().catch(async (error) => {
  console.error("LOOKUP_ERROR", error);
  try { await client.end(); } catch {}
  process.exit(1);
});
NODE
echo "ANDERSON_SUBSCRIPTION_LOOKUP2_END"
