#!/usr/bin/env bash
set -euo pipefail

tag="agentezap-app:followup-config-importantinfo-v312-20260602014500"
expected_base="agentezap-app:owner-notification-exclusion-v310-slim-202606010315"
expected_public_version="build-1780288102510"
workdir="/tmp/tmp-deploy-followup-config-importantinfo-v312-20260602014500"
compose_dir="/opt/agentezap-single/compose"

cd "$compose_dir"
test -f compose.yml
test -f compose.host-nginx.yml
test -f scripts/deploy-service.sh

current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"
current_public_version="$(docker exec agentezap-app node -e "console.log(require('/app/dist/public/pwa-version.json').version)" 2>/dev/null || true)"

app_auth_before="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l)"
app_creds_before="$(find /data/agentezap/sessions -path '*/creds.json' 2>/dev/null | wc -l)"
legacy_auth_before="$(find /data/whatsapp-sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l)"
legacy_creds_before="$(find /data/whatsapp-sessions -path '*/creds.json' 2>/dev/null | wc -l)"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_restart=${current_restart}"
echo "[deploy] current_public_version=${current_public_version}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before app=${app_auth_before}/${app_creds_before} legacy=${legacy_auth_before}/${legacy_creds_before}"

if [ "$current_image" != "$expected_base" ]; then
  echo "[deploy] ERROR: base mismatch expected=${expected_base} current=${current_image}" >&2
  exit 42
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 43
fi
if [ "$current_public_version" != "$expected_public_version" ]; then
  echo "[deploy] ERROR: public version changed before deploy (${current_public_version} != ${expected_public_version})" >&2
  exit 44
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd" >&2
  exit 45
fi

cd "$workdir"
test -f dist/index.js
test -f dist/api/http.js
test -f Dockerfile

grep -aR -m 1 -- "Informacao importante" dist >/dev/null
grep -aR -m 1 -- "Nao foi possivel salvar a configuracao de follow-up" dist >/dev/null

docker build -f Dockerfile -t "$tag" .

cd "$compose_dir"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
pre_switch_public_version="$(docker exec agentezap-app node -e "console.log(require('/app/dist/public/pwa-version.json').version)" 2>/dev/null || true)"
if [ "$pre_switch_image" != "$current_image" ] || [ "$pre_switch_public_version" != "$expected_public_version" ]; then
  echo "[deploy] ERROR: app changed while building; not switching" >&2
  echo "[deploy] pre_switch_image=${pre_switch_image}" >&2
  echo "[deploy] pre_switch_public_version=${pre_switch_public_version}" >&2
  exit 46
fi

./scripts/deploy-service.sh app "$tag"

running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"
running_public_version="$(docker exec agentezap-app node -e "console.log(require('/app/dist/public/pwa-version.json').version)")"

app_auth_after="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l)"
app_creds_after="$(find /data/agentezap/sessions -path '*/creds.json' 2>/dev/null | wc -l)"
legacy_auth_after="$(find /data/whatsapp-sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l)"
legacy_creds_after="$(find /data/whatsapp-sessions -path '*/creds.json' 2>/dev/null | wc -l)"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_restart=${running_restart}"
echo "[deploy] running_public_version=${running_public_version}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after app=${app_auth_after}/${app_creds_after} legacy=${legacy_auth_after}/${legacy_creds_after}"

if [ "$running_image" != "$tag" ]; then
  echo "[deploy] ERROR: app did not switch to ${tag}" >&2
  exit 47
fi
if [ "$running_health" != "healthy" ]; then
  echo "[deploy] ERROR: deployed app is not healthy" >&2
  exit 48
fi
if [ "$running_public_version" != "$expected_public_version" ]; then
  echo "[deploy] ERROR: public version changed unexpectedly (${running_public_version} != ${expected_public_version})" >&2
  exit 49
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 50
fi
if [ "$app_auth_after" -lt "$app_auth_before" ] || [ "$app_creds_after" -lt "$app_creds_before" ] || [ "$legacy_auth_after" -lt "$legacy_auth_before" ] || [ "$legacy_creds_after" -lt "$legacy_creds_before" ]; then
  echo "[deploy] ERROR: session count dropped during deploy" >&2
  exit 51
fi

docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Informacao importante' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Nao foi possivel salvar a configuracao de follow-up' /app/dist >/dev/null"

printf 'LOCAL_HEALTH='
curl -fsS http://127.0.0.1:5000/healthz
echo
printf 'LOCAL_API_HEALTH='
curl -fsS http://127.0.0.1:5000/api/health
echo
printf 'PUBLIC_HEALTH='
curl -fsS https://agentezap.online/healthz
echo
printf 'PUBLIC_API_HEALTH='
curl -fsS https://agentezap.online/api/health
echo

echo "[deploy] done"
