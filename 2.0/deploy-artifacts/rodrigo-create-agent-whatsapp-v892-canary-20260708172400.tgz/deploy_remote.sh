#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE_IMAGE="agentezap-app:rodrigo-create-agent-whatsapp-v892-20260708171204"

echo "[canary] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[canary] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[canary] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

echo "[canary] running Rodrigo create-agent synthetic path"
docker exec -i agentezap-app node --input-type=module <<'NODE' 2>&1 | sed -E \
  -e 's/[0-9]{12,14}@agentezap\.online/[redacted-test-email]/g' \
  -e 's/token: [^,) ]+/token: [redacted]/g' \
  -e 's#https://agentezap\.online/test/[A-Za-z0-9._-]+#[redacted-test-url]#g' \
  -e 's/551188[0-9]{7}/[redacted-test-phone]/g'
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import pg from "pg";

const distDir = "/app/dist";
const suffix = String(Date.now()).slice(-7);
const phone = `551188${suffix}`;
const email = `${phone}@agentezap.online`;
const sessionId = `canary-rodrigo-create-agent-v892-${suffix}`;
const companyName = `Canary Rodrigo V892 ${suffix}`;
let createdUserId = null;
let cleanupStatus = "not_found";
let sessionRowsDeleted = 0;

const files = fs.readdirSync(distDir);
const storageFile = files.find((name) => /^storage-.*\.js$/.test(name));
if (!storageFile) throw new Error("storage bundle not found");

const { runWebOnlyAgentTestForUser } = await import(pathToFileURL(path.join(distDir, "api", "http.js")).href);
const { storage } = await import(pathToFileURL(path.join(distDir, storageFile)).href);
const rodrigo = await storage.getUserByEmail("rodrigo4@gmail.com");
if (!rodrigo?.id) throw new Error("rodrigo user not found");

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  max: 1,
  idleTimeoutMillis: 1000,
  connectionTimeoutMillis: 15000,
});

try {
  const result = await runWebOnlyAgentTestForUser(rodrigo.id, {
    message: `Quero testar o AgenteZap. Meu negocio chama ${companyName}, atuo com assistencia tecnica de celulares e quero que voces criem o agente de teste gratis por aqui no WhatsApp.`,
    history: [
      {
        role: "user",
        content: "Oi, queria testar o sistema para minha empresa.",
        speaker: "customer",
      },
      {
        role: "assistant",
        content: "Consigo criar o agente de teste por aqui. Me passa o nome da empresa e o tipo de atendimento.",
        speaker: "agent",
      },
    ],
    sessionId,
    conversationId: sessionId,
    testConversationKey: sessionId,
    contactName: "Canary Rodrigo",
    contactPhone: phone,
    skipAccessCheck: true,
    agenticRuntimeEnabled: true,
    allowRodrigoCreateAgentContract: true,
    llmProviderTimeoutMs: 180000,
    publicTestRequestTimeoutMs: 240000,
  });

  const createdUser = await storage.getUserByEmail(email);
  createdUserId = createdUser?.id || null;
  const payload = result?.payload || {};
  const responseText = String(
    payload.response ||
      (Array.isArray(payload.splitResponses) ? payload.splitResponses.join("\n\n") : "") ||
      "",
  );
  const status = Number(result?.status || 500);
  const hasTestUrl = /https:\/\/agentezap\.online\/test\/[A-Za-z0-9._-]+/.test(responseText);
  const ok = status === 200 && Boolean(createdUserId) && hasTestUrl && responseText.length > 20;

  console.log(JSON.stringify({
    ok,
    status,
    createdUser: Boolean(createdUserId),
    hasTestUrl,
    responseLength: responseText.length,
    mode: payload.mode || null,
    mediaActions: Array.isArray(payload.mediaActions) ? payload.mediaActions.length : 0,
  }));

  if (!ok) {
    throw new Error(`canary_failed status=${status} created=${Boolean(createdUserId)} hasTestUrl=${hasTestUrl} responseLength=${responseText.length}`);
  }
} finally {
  const user = createdUserId ? await storage.getUser(createdUserId) : await storage.getUserByEmail(email);
  if (user?.id) {
    await storage.deleteUser(user.id);
    const after = await storage.getUser(user.id);
    cleanupStatus = after ? "failed_still_exists" : "deleted";
  }
  const deleteResult = await pool.query(
    "delete from agent_test_session_messages where session_id = $1 or conversation_id = $1",
    [sessionId],
  ).catch((error) => {
    console.warn("[canary] session cleanup skipped:", error?.message || error);
    return { rowCount: 0 };
  });
  sessionRowsDeleted = Number(deleteResult?.rowCount || 0);
  await pool.end().catch(() => {});
  console.log(JSON.stringify({ cleanupStatus, sessionRowsDeleted }));
}
NODE

echo "[canary] ok"
