#!/usr/bin/env bash
set -euo pipefail

echo "[inspect] active image"
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app

echo "[inspect] followup cron async failed context"
docker logs --since 25m agentezap-app 2>&1 | awk '
  /vercel-followup-cron.*async failed/ { printing=1; count=0 }
  printing { print; count += 1 }
  printing && count >= 18 { printing=0 }
'

echo "[inspect] followup cron complete context"
docker logs --since 25m agentezap-app 2>&1 | awk '
  /vercel-followup-cron.*async complete/ { printing=1; count=0 }
  printing { print; count += 1 }
  printing && count >= 18 { printing=0 }
'

echo "[inspect] user-followup cron accepted lines"
docker logs --since 25m agentezap-app 2>&1 | grep -a -E 'vercel-followup-cron|VPS CRON.*user-followup|POST /api/cron/stateful-jobs/user-followup' | tail -n 80 || true

echo "[inspect] READ_ONLY_OK"
