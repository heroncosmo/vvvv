#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:login-pwa-cache-v126-20260515161006"
EXPECTED_BASE="agentezap-app:meu-agente-layout-v125-clean-20260515113200"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-login-pwa-cache-v126-20260515161006"
SESSIONS_DIR="/data/agentezap/sessions"

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_restart=${current_restart}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 1
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi

docker exec agentezap-app sh -lc "grep -aR -m 1 'agentezap:pwa-update-dismissed-version' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'send-audio' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'school_triage' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'direct_catalog_media' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'shouldAutoRunAgendamento3DirectInSimulator' /app/dist >/dev/null"

cd "$DEPLOY_DIR"
test -f dist/index.js
test -f dist/full-app-*.js
test -f dist/public/index.html
test -f dist/public/sw.js
test -f dist/public/pwa-version.json
test -d dist/public/assets
grep -aR -m 1 'Static asset not found' dist >/dev/null
grep -aR -m 1 'Resposta de versao do PWA nao e JSON' dist/public >/dev/null
grep -aR -m 1 'agentezap:pwa-update-dismissed-version' dist/public >/dev/null
grep -aR -m 1 'send-audio' dist >/dev/null
grep -aR -m 1 'Personalize com IA' dist/public >/dev/null
grep -aR -m 1 'Membros e Setores' dist/public >/dev/null
grep -aR -m 1 'button-nav-team-tools-mobile' dist/public >/dev/null
grep -aR -m 1 'Informa' dist/public >/dev/null
grep -aR -m 1 'button-mobile-sidebar-plan-card' dist/public >/dev/null
grep -aR -m 1 'button-nav-add-apps-mobile' dist/public >/dev/null
grep -aR -m 1 'Envio em Massa' dist/public >/dev/null
grep -aR -m 1 'Simulador WhatsApp' dist/public >/dev/null
grep -aR -m 1 'Selecionados para voc' dist/public >/dev/null
grep -aR -m 1 'Ver planos' dist/public >/dev/null
grep -aR -m 1 'school_triage' dist >/dev/null
grep -aR -m 1 'direct_catalog_media' dist >/dev/null
grep -aR -m 1 'shouldAutoRunAgendamento3DirectInSimulator' dist >/dev/null
if grep -aR -m 1 'IA Assistant' dist/public >/dev/null; then
  echo "[deploy] ERROR: IA Assistant still appears in deployable public bundle" >&2
  exit 1
fi
if grep -aR -m 1 'button-nav-media-library-sidebar' dist/public >/dev/null; then
  echo "[deploy] ERROR: media library sidebar button still appears in deployable public bundle" >&2
  exit 1
fi

python3 - <<'PY'
import json
import re
from pathlib import Path

index_html = Path("dist/public/index.html").read_text(encoding="utf-8")
pwa_json = json.loads(Path("dist/public/pwa-version.json").read_text(encoding="utf-8"))
sw = Path("dist/public/sw.js").read_text(encoding="utf-8")
meta_match = re.search(r'<meta name="agentezap-pwa-version"\s+content="([^"]+)"', index_html)
sw_match = re.search(r'PWA_VERSION\s*=\s*"([^"]+)"', sw)
meta_version = meta_match.group(1) if meta_match else ""
json_version = pwa_json.get("version", "")
sw_version = sw_match.group(1) if sw_match else ""
if not meta_version or meta_version != json_version or json_version != sw_version:
    raise SystemExit(f"PWA version mismatch: index={meta_version} json={json_version} sw={sw_version}")
if "then(() => self.skipWaiting())" in sw:
    raise SystemExit("Unexpected install-time skipWaiting in service worker")
print(f"[deploy] pwa_version={json_version}")
PY

cat > Dockerfile <<EOF
FROM ${current_image}
COPY dist/ /app/dist/
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-login-pwa-cache-v126-20260515161006"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path(".env.runtime")
desired = {
    "AGENTEZAP_APP_IMAGE": tag,
    "NODE_OPTIONS": "--max-old-space-size=4096",
    "WA_PENDING_TIMERS_START_DURING_RESTORE": "false",
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in desired:
        out.append(f"{key}={desired[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_restart=${running_restart}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during app-only deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi

docker exec agentezap-app sh -lc "grep -aR -m 1 'Static asset not found' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Resposta de versao do PWA nao e JSON' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'agentezap:pwa-update-dismissed-version' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'send-audio' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Personalize com IA' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Membros e Setores' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'button-nav-team-tools-mobile' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Informa' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'button-mobile-sidebar-plan-card' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'button-nav-add-apps-mobile' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Envio em Massa' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Simulador WhatsApp' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Selecionados para voc' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Ver planos' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "! grep -aR -m 1 'IA Assistant' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "! grep -aR -m 1 'button-nav-media-library-sidebar' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'school_triage' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'direct_catalog_media' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'shouldAutoRunAgendamento3DirectInSimulator' /app/dist >/dev/null"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/assets/main-BHAW0Xww.css').then(async r=>{const ct=r.headers.get('content-type')||''; const body=(await r.text()).slice(0,80); console.log('[deploy] stale_asset='+r.status+' '+ct+' '+body); if(r.status!==404 || ct.includes('text/html')) process.exit(1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/pwa-version.json?t=codex').then(async r=>{const ct=r.headers.get('content-type')||''; const body=await r.text(); console.log('[deploy] pwa_json='+r.status+' '+ct+' '+body.slice(0,120)); JSON.parse(body); if(!r.ok || !ct.includes('application/json')) process.exit(1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node <<'NODE'
const fs = require("fs");
const indexHtml = fs.readFileSync("/app/dist/public/index.html", "utf8");
const pwaJson = JSON.parse(fs.readFileSync("/app/dist/public/pwa-version.json", "utf8"));
const sw = fs.readFileSync("/app/dist/public/sw.js", "utf8");
const metaVersion = (indexHtml.match(/<meta name="agentezap-pwa-version"\s+content="([^"]+)"/) || [])[1];
const swVersion = (sw.match(/PWA_VERSION\s*=\s*"([^"]+)"/) || [])[1];
if (metaVersion !== pwaJson.version || pwaJson.version !== swVersion) {
  throw new Error(`runtime PWA version mismatch: index=${metaVersion} json=${pwaJson.version} sw=${swVersion}`);
}
if (sw.includes("then(() => self.skipWaiting())")) {
  throw new Error("Unexpected install-time skipWaiting in runtime service worker");
}
console.log(`[deploy] runtime_pwa_version=${pwaJson.version}`);
NODE

echo "[deploy] done"
