import{r as i}from"./main-LPcQxkBc.js";import"./index-kJ3jHkOV.js";const r=i("PushNotifications",{});export{r as PushNotifications};
