import{W as n}from"./main-LPcQxkBc.js";import"./index-kJ3jHkOV.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
