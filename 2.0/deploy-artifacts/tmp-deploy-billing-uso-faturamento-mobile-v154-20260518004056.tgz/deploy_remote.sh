#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:billing-uso-faturamento-mobile-v154-20260518004056"
EXPECTED_BASE="agentezap-app:manual-audio-ogg-v153-20260516113858"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-billing-uso-faturamento-mobile-v154-20260518004056"
SESSIONS_DIR="/data/agentezap/sessions"

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_restart=${current_restart}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this public-only deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 1
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi

cd "$DEPLOY_DIR"

check_file() {
  local file="$1"
  echo "[deploy] checking artifact file: ${file}"
  test -f "$file"
}

check_grep() {
  local pattern="$1"
  local file="$2"
  echo "[deploy] checking artifact grep: ${pattern} in ${file}"
  grep -aR -m 1 -- "$pattern" "$file" >/dev/null
}

check_file public/index.html
check_file public/sw.js
check_file public/site.webmanifest
check_file public/pwa-version.json
check_file public/assets/index-kJ3jHkOV.js
check_file public/assets/main-LPcQxkBc.js
check_file public/assets/main-Bij-lE8_.css

check_grep 'build-1779073548862' public/pwa-version.json
check_grep 'PWA_VERSION = "build-1779073548862"' public/sw.js
check_grep 'index-kJ3jHkOV.js' public/index.html
check_grep 'main-LPcQxkBc.js' public/assets/index-kJ3jHkOV.js
check_grep 'main-Bij-lE8_.css' public/assets/index-kJ3jHkOV.js
check_grep 'Ver faturamento' public/assets/main-LPcQxkBc.js
check_grep 'Pagar fatura' public/assets/main-LPcQxkBc.js
check_grep 'Pagar pr' public/assets/main-LPcQxkBc.js
check_grep 'button-settings-open-billing' public/assets/main-LPcQxkBc.js
check_grep 'mobile=editor' public/assets/main-LPcQxkBc.js
check_grep 'Selecionados para voc' public/assets/main-LPcQxkBc.js
check_grep 'Kanban' public/assets/main-LPcQxkBc.js
check_grep 'Simulador WhatsApp' public/assets/main-LPcQxkBc.js

cat > Dockerfile <<EOF
FROM ${current_image}
COPY public /app/dist/public
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-billing-uso-faturamento-mobile-v154-20260518004056"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path(".env.runtime")
desired = {
    "AGENTEZAP_APP_IMAGE": tag,
    "NODE_OPTIONS": "--max-old-space-size=4096",
    "WA_PENDING_TIMERS_START_DURING_RESTORE": "false",
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in desired:
        out.append(f"{key}={desired[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_restart=${running_restart}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during public-only deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi

docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'build-1779073548862' /app/dist/public/pwa-version.json >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'PWA_VERSION = \"build-1779073548862\"' /app/dist/public/sw.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'main-LPcQxkBc.js' /app/dist/public/assets/index-kJ3jHkOV.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'main-Bij-lE8_.css' /app/dist/public/assets/index-kJ3jHkOV.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Ver faturamento' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Pagar fatura' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Pagar pr' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'button-settings-open-billing' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'mobile=editor' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Selecionados para voc' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Kanban' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 -- 'Simulador WhatsApp' /app/dist/public/assets/main-LPcQxkBc.js >/dev/null"
docker exec agentezap-app node - <<'NODE'
async function assertResponse(path, expectedType, expectedText) {
  const response = await fetch(`http://127.0.0.1:5000${path}`, { cache: "no-store" });
  const text = await response.text();
  const type = response.headers.get("content-type") || "";
  console.log(`[deploy] ${path} status=${response.status} type=${type}`);
  if (!response.ok) throw new Error(`${path} returned ${response.status}`);
  if (!type.includes(expectedType)) throw new Error(`${path} returned wrong content-type ${type}`);
  if (expectedText && !text.includes(expectedText)) throw new Error(`${path} missing marker ${expectedText}`);
  if (text.trimStart().startsWith("<!DOCTYPE")) throw new Error(`${path} returned HTML shell instead of asset`);
}

await assertResponse("/assets/main-Bij-lE8_.css", "text/css", "az-");
await assertResponse("/assets/main-LPcQxkBc.js", "javascript", "Ver faturamento");
await assertResponse("/assets/index-kJ3jHkOV.js", "javascript", "main-LPcQxkBc.js");
await assertResponse("/pwa-version.json", "application/json", "build-1779073548862");
NODE
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"

echo "[deploy] done"
