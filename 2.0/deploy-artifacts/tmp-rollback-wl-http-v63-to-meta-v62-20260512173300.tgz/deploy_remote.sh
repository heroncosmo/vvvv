#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE="agentezap-app:wl-vidracaria-http-guard-v63-20260512173039"
ROLLBACK_IMAGE="agentezap-app:meta-form-google-oauth-v62-20260512170913"
COMPOSE_DIR="/opt/agentezap-single/compose"
RUNTIME_ENV="${COMPOSE_DIR}/.env.runtime"

cd "${COMPOSE_DIR}"
test -f compose.yml
test -f "${RUNTIME_ENV}"

APP_CONTAINER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app || true)"
ACTIVE_IMAGE=""
if [[ -n "${APP_CONTAINER}" ]]; then
  ACTIVE_IMAGE="$(docker inspect -f '{{.Config.Image}}' "${APP_CONTAINER}" || true)"
fi
echo "active_image=${ACTIVE_IMAGE}"
if [[ "${ACTIVE_IMAGE}" != "${EXPECTED_ACTIVE}" ]]; then
  echo "Abort rollback: active image is not ${EXPECTED_ACTIVE}; got ${ACTIVE_IMAGE}" >&2
  exit 42
fi

BEFORE_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
BEFORE_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_before=${BEFORE_AUTH_DIRS}/${BEFORE_CREDS}"

if grep -q '^AGENTEZAP_APP_IMAGE=' "${RUNTIME_ENV}"; then
  sed -i "s|^AGENTEZAP_APP_IMAGE=.*|AGENTEZAP_APP_IMAGE=${ROLLBACK_IMAGE}|" "${RUNTIME_ENV}"
else
  printf '\nAGENTEZAP_APP_IMAGE=%s\n' "${ROLLBACK_IMAGE}" >> "${RUNTIME_ENV}"
fi

docker compose --env-file "${RUNTIME_ENV}" -f compose.yml up -d --no-deps --wait app
docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps app

APP_CONTAINER_AFTER="$(docker compose --env-file "${RUNTIME_ENV}" -f compose.yml ps -q app)"
docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('healthz', r.status, await r.text()); if(!r.ok) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"
docker exec "${APP_CONTAINER_AFTER}" node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{const text=await r.text(); console.log('api_health', r.status, text); if(!r.ok || !text.includes('monolith')) process.exit(1)}).catch(e=>{console.error(e);process.exit(1)})"

AFTER_CREDS="$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d ' ')"
AFTER_AUTH_DIRS="$(find /data/agentezap/sessions -maxdepth 1 -type d -name 'auth_*' 2>/dev/null | wc -l | tr -d ' ')"
echo "sessions_after=${AFTER_AUTH_DIRS}/${AFTER_CREDS}"
echo "rollback_finished=${ROLLBACK_IMAGE}"
