#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE_IMAGE="agentezap-app:followup-model-policy-v890b-20260708153300"
COMPOSE_DIR="/opt/agentezap-single/compose"
RUNTIME_ENV="${COMPOSE_DIR}/.env.runtime"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

set_env_var() {
  local key="$1"
  local value="$2"
  if grep -qE "^${key}=" "$RUNTIME_ENV"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$RUNTIME_ENV"
  else
    printf "\n%s=%s\n" "$key" "$value" >> "$RUNTIME_ENV"
  fi
}

check_bundle_markers() {
  docker exec -i agentezap-app node - <<'NODE'
const fs = require("node:fs");
const source = fs.readFileSync("/app/dist/api/http.js", "utf8");
const fullAppFile = fs.readdirSync("/app/dist").find((name) => /^full-app-.*\.js$/.test(name));
if (!fullAppFile) throw new Error("full-app bundle not found");
const fullApp = fs.readFileSync(`/app/dist/${fullAppFile}`, "utf8");
function sliceBetween(label, startNeedle, endNeedle) {
  const start = source.indexOf(startNeedle);
  const end = source.indexOf(endNeedle, start);
  if (start < 0 || end <= start) throw new Error(`${label} block not found`);
  return source.slice(start, end);
}
const modelBlock = sliceBetween("model selection", "function selectCodexModel", "function selectCodexReasoningEffort");
const reasoningBlock = sliceBetween("reasoning selection", "function selectCodexReasoningEffort", "function buildCodexEnv");
const checks = {
  followupModelPolicy: modelBlock.includes("AGENTEZAP_CODEX_CLI_FOLLOWUP_MODEL") && modelBlock.includes('"gpt-5.4-mini"'),
  followupBeforeRodrigoModel: modelBlock.indexOf("AGENTEZAP_CODEX_CLI_FOLLOWUP_MODEL") < modelBlock.indexOf("AGENTEZAP_CODEX_CLI_RODRIGO_MODEL"),
  followupReasoningPolicy: reasoningBlock.includes("AGENTEZAP_CODEX_CLI_FOLLOWUP_REASONING_EFFORT") && reasoningBlock.includes("AGENTEZAP_CODEX_CLI_TENANT_REASONING_EFFORT"),
  followupBeforeRodrigoReasoning: reasoningBlock.indexOf("AGENTEZAP_CODEX_CLI_FOLLOWUP_REASONING_EFFORT") < reasoningBlock.indexOf("AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT"),
  rodrigoNormalModel: modelBlock.includes("AGENTEZAP_CODEX_CLI_RODRIGO_MODEL") && modelBlock.includes('"gpt-5.5"'),
  rodrigoNormalReasoning: reasoningBlock.includes("AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT") && reasoningBlock.includes('"xhigh"'),
  tenantModel: modelBlock.includes("AGENTEZAP_CODEX_CLI_TENANT_MODEL") && modelBlock.includes('"gpt-5.4-mini"'),
  contextUsesActualModel: source.includes("model:${usedModel}"),
  noFixedRodrigoContextModel: !source.includes("model:gpt-5.5"),
  triggerParity: fullApp.includes('app.all("/api/followup/conversation/:id/trigger", delegateToVercelHttpHandler);'),
  noBroadFollowupDelegation: !fullApp.includes('app.all("/api/followup/*", delegateToVercelHttpHandler);'),
};
for (const [name, ok] of Object.entries(checks)) {
  if (!ok) throw new Error(`marker failed: ${name}`);
}
console.log(JSON.stringify(checks));
NODE
}

echo "[env] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[env] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[env] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "$RUNTIME_ENV"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[env] creds before: ${before_creds}"

cd "$COMPOSE_DIR"
cp "$RUNTIME_ENV" ".env.runtime.before-followup-explicit-mini-v891-20260708154500"
set_env_var "AGENTEZAP_CODEX_CLI_FOLLOWUP_MODEL" "gpt-5.4-mini"
set_env_var "AGENTEZAP_CODEX_CLI_FOLLOWUP_REASONING_EFFORT" "medium"

echo "[env] sanitized runtime env policy"
grep -E '^(AGENTEZAP_CODEX_CLI_(FOLLOWUP|TENANT|RODRIGO)_(MODEL|REASONING_EFFORT)|ENABLE_VPS_INTERNAL_CRONS|ENABLE_STATEFUL_INTERVAL_JOBS|STATEFUL_JOB_CRON_USER_FOLLOWUP_SCHEDULE)=' "$RUNTIME_ENV" | sort

echo "[env] redeploying app-only with same image"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$ACTIVE_IMAGE"

echo "[env] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$EXPECTED_ACTIVE_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

echo "[env] container env policy"
docker exec agentezap-app sh -lc '
  set -eu
  test "${AGENTEZAP_CODEX_CLI_FOLLOWUP_MODEL:-}" = "gpt-5.4-mini"
  test "${AGENTEZAP_CODEX_CLI_FOLLOWUP_REASONING_EFFORT:-}" = "medium"
  test "${AGENTEZAP_CODEX_CLI_RODRIGO_MODEL:-}" = "gpt-5.5"
  test "${AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT:-}" = "xhigh"
  test "${AGENTEZAP_CODEX_CLI_TENANT_MODEL:-}" = "gpt-5.4-mini"
  env | grep -E "^(AGENTEZAP_CODEX_CLI_(FOLLOWUP|TENANT|RODRIGO)_(MODEL|REASONING_EFFORT)|ENABLE_VPS_INTERNAL_CRONS|ENABLE_STATEFUL_INTERVAL_JOBS|STATEFUL_JOB_CRON_USER_FOLLOWUP_SCHEDULE)=" | sort
'

check_bundle_markers

if docker logs --since 3m agentezap-app 2>&1 | grep -a -E 'statement timeout|sanitizeWebOnlyAgenticToolName|structured_output_invalid|ReferenceError|AbortError|MODULE_NOT_FOUND|SyntaxError|UnhandledPromiseRejection'; then
  echo "[env] recent error marker found" >&2
  exit 2
fi

after_creds="$(count_creds)"
echo "[env] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[env] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

echo "[env] EXPLICIT_FOLLOWUP_MINI_OK"
