#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="${NEW_IMAGE:-agentezap-app:plus-gate-ready-v873b-20260707144500}"
EXPECTED_ACTIVE_IMAGE="${EXPECTED_ACTIVE_IMAGE:-agentezap-app:plus-gate-ready-v873-20260707143000}"
TMP_CONTAINER="${TMP_CONTAINER:-agentezap-plus-gate-ready-v873b-tmp}"
COMPOSE_DIR="${COMPOSE_DIR:-/opt/agentezap-single/compose}"
DRY_RUN="${DRY_RUN:-0}"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

patch_public_bundle() {
  local container="$1"
  docker exec -i "$container" node <<'NODE'
const fs = require("fs");
const path = require("path");
const childProcess = require("child_process");

const assetsDir = "/app/dist/public/assets";
const jsFiles = fs.readdirSync(assetsDir)
  .filter((name) => /^main-[A-Za-z0-9_-]+\.js$/.test(name))
  .map((name) => path.join(assetsDir, name));

if (jsFiles.length < 1) {
  console.error("[deploy] no main bundle found");
  process.exit(50);
}

const oldGate = "h=!!o&&!m&&(c==null?void 0:c.shouldBlock)!==!0;u.useEffect(()=>{if(typeof window>";
const newGate = "h=!!o&&c!==void 0&&!m&&(c==null?void 0:c.shouldBlock)!==!0;u.useEffect(()=>{(h||!a.actionLabel&&!a.override)||n({actionLabel:null,override:null})},[a.actionLabel,a.override,h]);u.useEffect(()=>{if(typeof window>";
const gateReadyMarker = "h=!!o&&c!==void 0&&!m&&(c==null?void 0:c.shouldBlock)!==!0";
const staleDialogMarker = "u.useEffect(()=>{(h||!a.actionLabel&&!a.override)||n({actionLabel:null,override:null})},[a.actionLabel,a.override,h]);";

let replacementCount = 0;
const patched = [];

for (const file of jsFiles) {
  const original = fs.readFileSync(file, "utf8");
  const occurrences = original.split(oldGate).length - 1;
  if (occurrences > 0) {
    replacementCount += occurrences;
    const patchedText = original.split(oldGate).join(newGate);
    fs.writeFileSync(file, patchedText);
    patched.push(file);

    const tmpModule = `/tmp/${path.basename(file)}.mjs`;
    fs.writeFileSync(tmpModule, patchedText);
    childProcess.execFileSync("node", ["--check", tmpModule], { stdio: "inherit" });
    fs.unlinkSync(tmpModule);
  }
}

const allText = jsFiles.map((file) => fs.readFileSync(file, "utf8")).join("\n");
console.log(JSON.stringify({ patched, replacementCount }, null, 2));
if (replacementCount > 1) {
  console.error("[deploy] expected at most one action gate replacement");
  process.exit(51);
}

const checks = {
  gateWaitsForAccessStatus: allText.includes(gateReadyMarker),
  staleDialogCloses: allText.includes(staleDialogMarker),
  oldLoadingGateAbsent: !allText.includes(oldGate),
  pro300Preserved: allText.includes("introOfferPrice:300") && !allText.includes("introOfferPrice:349.99"),
  plusDialogStillPresent: allText.includes("Plano Plus") && allText.includes("Continuar no plano"),
};

console.log(JSON.stringify(checks, null, 2));
if (Object.values(checks).some((ok) => ok !== true)) {
  process.exit(52);
}
NODE
}

check_markers() {
  local container="$1"
  docker exec -i "$container" node <<'NODE'
const fs = require("fs");
const path = require("path");

const assetsDir = "/app/dist/public/assets";
const mainFiles = fs.readdirSync(assetsDir)
  .filter((name) => /^main-[A-Za-z0-9_-]+\.js$/.test(name))
  .map((name) => path.join(assetsDir, name));
const mainText = mainFiles.map((file) => fs.readFileSync(file, "utf8")).join("\n");
const httpText = fs.readFileSync("/app/dist/api/http.js", "utf8");

const checks = {
  gateWaitsForAccessStatus: mainText.includes("h=!!o&&c!==void 0&&!m&&(c==null?void 0:c.shouldBlock)!==!0"),
  staleDialogCloses: mainText.includes("u.useEffect(()=>{(h||!a.actionLabel&&!a.override)||n({actionLabel:null,override:null})},[a.actionLabel,a.override,h]);"),
  oldLoadingGateAbsent: !mainText.includes("h=!!o&&!m&&(c==null?void 0:c.shouldBlock)!==!0;u.useEffect(()=>{if(typeof window>"),
  plusDialogStillPresent: mainText.includes("Plano Plus") && mainText.includes("Continuar no plano"),
  pro300Preserved: mainText.includes("introOfferPrice:300") && !mainText.includes("introOfferPrice:349.99"),
  v872BridgePreserved: httpText.includes("bridgeDueLegacyPendingAIResponsesToVercelQueue") && httpText.includes("cancelled:bridged_to_vercel_agent_queue"),
  backendPro300Preserved: httpText.includes("CHECKOUT_PUBLIC_PRO_MONTHLY_PRICE = 300") && httpText.includes("normalizeCheckoutRenewalMonthlyPrice"),
};

console.log(JSON.stringify({
  mainFiles,
  checks,
}, null, 2));

if (Object.values(checks).some((ok) => ok !== true)) {
  process.exit(53);
}
NODE
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
    main_asset="$(ls /app/dist/public/assets/main-*.js | head -n 1)"
    test -n "$main_asset"
    cp "$main_asset" /tmp/agentezap-main-asset-check.mjs
    node --check /tmp/agentezap-main-asset-check.mjs
    rm -f /tmp/agentezap-main-asset-check.mjs
  '
}

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] patching public Plus action gate"
patch_public_bundle "$TMP_CONTAINER"
check_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "$DRY_RUN" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

public_main="$(curl -fsS http://127.0.0.1:5000/ | grep -o 'assets/main-[^"]*\.js' | head -n 1)"
if [ -z "$public_main" ]; then
  public_index="$(curl -fsS http://127.0.0.1:5000/ | grep -o '/assets/index-[^"]*\.js' | head -n 1 | sed 's#^/##')"
  test -n "$public_index"
  public_main="$(curl -fsS "http://127.0.0.1:5000/${public_index}" | grep -o 'assets/main-[^"]*\.js' | head -n 1)"
fi
test -n "$public_main"
curl -fsS "http://127.0.0.1:5000/${public_main}" | grep -F 'h=!!o&&c!==void 0&&!m&&(c==null?void 0:c.shouldBlock)!==!0' >/dev/null
curl -fsS "http://127.0.0.1:5000/${public_main}" | grep -F 'actionLabel:null,override:null})},[a.actionLabel,a.override,h]' >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|ReferenceError|Range out of order|UnhandledPromiseRejection|MODULE_NOT_FOUND'; then
  echo "[deploy] boot errors detected" >&2
  exit 62
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
