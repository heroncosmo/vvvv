import{r as i}from"./main-CrhmUOPX.js";import"./index-CYTtSLCe.js";const r=i("PushNotifications",{});export{r as PushNotifications};
