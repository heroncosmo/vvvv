import{W as n}from"./main-CrhmUOPX.js";import"./index-CYTtSLCe.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
