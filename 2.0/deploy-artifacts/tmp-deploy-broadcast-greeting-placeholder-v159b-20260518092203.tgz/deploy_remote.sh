#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:broadcast-greeting-placeholder-v159b-20260518092203"
EXPECTED_BASE="agentezap-app:rprado-direct-gmail-local-send-v158c-20260518084720"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-broadcast-greeting-placeholder-v159b-20260518092203"
SESSIONS_DIR="/data/agentezap/sessions"

check_marker() {
  local label="$1"
  shift
  echo "[deploy] check=${label}"
  "$@"
}

check_public_pwa() {
  python3 - "$1" <<'PY'
import json
import re
import sys
from pathlib import Path

public = Path(sys.argv[1])
index_html = (public / "index.html").read_text(encoding="utf-8")
pwa_json = json.loads((public / "pwa-version.json").read_text(encoding="utf-8"))
sw = (public / "sw.js").read_text(encoding="utf-8")
meta_match = re.search(r'<meta name="agentezap-pwa-version"\s+content="([^"]+)"', index_html)
sw_match = re.search(r'PWA_VERSION\s*=\s*"([^"]+)"', sw)
meta_version = meta_match.group(1) if meta_match else ""
json_version = pwa_json.get("version", "")
sw_version = sw_match.group(1) if sw_match else ""
if not meta_version or meta_version != json_version or json_version != sw_version:
    raise SystemExit(f"PWA version mismatch: index={meta_version} json={json_version} sw={sw_version}")
if "then(() => self.skipWaiting())" in sw:
    raise SystemExit("Unexpected install-time skipWaiting in service worker")
print(f"[deploy] pwa_version={json_version}")
PY
}

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 1
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi

check_marker base_pwa_runtime docker exec agentezap-app sh -lc "grep -aR -m 1 'agentezap:pwa-update-dismissed-version' /app/dist/public >/dev/null"
check_marker base_billing_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'button-settings-open-billing' /app/dist/public >/dev/null"
check_marker base_mobile_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'mobile=editor' /app/dist/public >/dev/null"
check_marker base_fk_policy docker exec agentezap-app sh -lc "grep -aR -m 1 'specific_request_before_name_to_name_question' /app/dist/api/http.js >/dev/null"
check_marker base_fk_clear_media docker exec agentezap-app sh -lc "grep -aR -m 1 'clear_media_before_name' /app/dist/api/http.js >/dev/null"
check_marker base_protocol_stub_guard docker exec agentezap-app sh -lc "grep -aR -m 1 'not_initial_meta_stub' /app/dist/api/http.js >/dev/null"
check_marker base_protocol_skip docker exec agentezap-app sh -lc "grep -aR -m 1 'ignored_protocol_message' /app/dist/api/http.js >/dev/null"
check_marker base_monolith_local_send docker exec agentezap-app sh -lc "grep -aR -m 1 'monolith_local_instance_send_fallback_v158' /app/dist/api/http.js >/dev/null"

cd "$DEPLOY_DIR"
test -f dist/index.js
test -f dist/api/http.js
test ! -d dist/public
test -f public/index.html
test -f public/sw.js
test -f public/pwa-version.json
test -f public/site.webmanifest
test -f public/assets/main-D_pg1u77.js
test -f public/assets/main-Bij-lE8_.css
test -f public/assets/index-Ddg_SIBh.js

check_public_pwa "public"
check_marker artifact_pwa_runtime grep -aR -m 1 'agentezap:pwa-update-dismissed-version' public
check_marker artifact_billing_marker grep -aR -m 1 'button-settings-open-billing' public
check_marker artifact_mobile_marker grep -aR -m 1 'mobile=editor' public
check_marker artifact_fk_video_guard grep -aR -m 1 'specific_request_before_name_to_name_question' dist/api/http.js
check_marker artifact_fk_clear_media grep -aR -m 1 'clear_media_before_name' dist/api/http.js
check_marker artifact_protocol_stub_guard grep -aR -m 1 'not_initial_meta_stub' dist/api/http.js
check_marker artifact_protocol_skip grep -aR -m 1 'ignored_protocol_message' dist/api/http.js
check_marker artifact_monolith_local_send grep -aR -m 1 'monolith_local_instance_send_fallback_v158' dist/api/http.js
check_marker artifact_broadcast_greeting_backend grep -aR -m 1 'GREETING_PLACEHOLDER_PATTERN' dist
check_marker artifact_broadcast_greeting_alias grep -aR -m 1 'cumprimento' dist
check_marker artifact_broadcast_greeting_ui grep -aR -m 1 '\[saudacao\]' public

cat > Dockerfile <<EOF
FROM ${current_image}
RUN find /app/dist -maxdepth 1 -type f -name '*.js' -delete && rm -rf /app/dist/api
COPY dist/ /app/dist/
RUN find /app/dist/public/assets -maxdepth 1 -type f \( -name 'main-*.js' -o -name 'main-*.css' -o -name 'index-*.js' -o -name 'web-*.js' \) -delete
COPY public/ /app/dist/public/
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-broadcast-greeting-placeholder-v159b-20260518092203"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path(".env.runtime")
desired = {
    "AGENTEZAP_APP_IMAGE": tag,
    "NODE_OPTIONS": "--max-old-space-size=4096",
    "WA_PENDING_TIMERS_START_DURING_RESTORE": "false",
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in desired:
        out.append(f"{key}={desired[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during app deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy after deploy" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi

docker exec agentezap-app node <<'NODE'
const fs = require("fs");
const indexHtml = fs.readFileSync("/app/dist/public/index.html", "utf8");
const pwaJson = JSON.parse(fs.readFileSync("/app/dist/public/pwa-version.json", "utf8"));
const sw = fs.readFileSync("/app/dist/public/sw.js", "utf8");
const metaVersion = (indexHtml.match(/<meta name="agentezap-pwa-version"\s+content="([^"]+)"/) || [])[1];
const swVersion = (sw.match(/PWA_VERSION\s*=\s*"([^"]+)"/) || [])[1];
if (!metaVersion || metaVersion !== pwaJson.version || pwaJson.version !== swVersion) {
  throw new Error(`runtime PWA version mismatch: index=${metaVersion} json=${pwaJson.version} sw=${swVersion}`);
}
if (sw.includes("then(() => self.skipWaiting())")) {
  throw new Error("Unexpected install-time skipWaiting in runtime service worker");
}
console.log(`[deploy] runtime_pwa_version=${pwaJson.version}`);
NODE
check_marker deployed_pwa_runtime docker exec agentezap-app sh -lc "grep -aR -m 1 'agentezap:pwa-update-dismissed-version' /app/dist/public >/dev/null"
check_marker deployed_billing_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'button-settings-open-billing' /app/dist/public >/dev/null"
check_marker deployed_mobile_marker docker exec agentezap-app sh -lc "grep -aR -m 1 'mobile=editor' /app/dist/public >/dev/null"
check_marker deployed_fk_video_guard docker exec agentezap-app sh -lc "grep -aR -m 1 'specific_request_before_name_to_name_question' /app/dist/api/http.js >/dev/null"
check_marker deployed_fk_clear_media docker exec agentezap-app sh -lc "grep -aR -m 1 'clear_media_before_name' /app/dist/api/http.js >/dev/null"
check_marker deployed_protocol_stub_guard docker exec agentezap-app sh -lc "grep -aR -m 1 'not_initial_meta_stub' /app/dist/api/http.js >/dev/null"
check_marker deployed_protocol_skip docker exec agentezap-app sh -lc "grep -aR -m 1 'ignored_protocol_message' /app/dist/api/http.js >/dev/null"
check_marker deployed_monolith_local_send docker exec agentezap-app sh -lc "grep -aR -m 1 'monolith_local_instance_send_fallback_v158' /app/dist/api/http.js >/dev/null"
check_marker deployed_broadcast_greeting_backend docker exec agentezap-app sh -lc "grep -aR -m 1 'GREETING_PLACEHOLDER_PATTERN' /app/dist >/dev/null"
check_marker deployed_broadcast_greeting_alias docker exec agentezap-app sh -lc "grep -aR -m 1 'cumprimento' /app/dist >/dev/null"
check_marker deployed_broadcast_greeting_ui docker exec agentezap-app sh -lc "grep -aR -m 1 '\[saudacao\]' /app/dist/public >/dev/null"

docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"

echo "[deploy] done"
