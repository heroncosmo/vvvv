import{r as i}from"./main-D_pg1u77.js";import"./index-Ddg_SIBh.js";const r=i("PushNotifications",{});export{r as PushNotifications};
