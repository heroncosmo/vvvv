import{W as n}from"./main-D_pg1u77.js";import"./index-Ddg_SIBh.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
