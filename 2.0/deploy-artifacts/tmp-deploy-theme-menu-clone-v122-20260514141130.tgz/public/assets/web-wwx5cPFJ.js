import{W as n}from"./main-3QnvcOUc.js";import"./index-CWT43Ysd.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
