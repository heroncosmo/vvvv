import{r as i}from"./main-3QnvcOUc.js";import"./index-CWT43Ysd.js";const r=i("PushNotifications",{});export{r as PushNotifications};
