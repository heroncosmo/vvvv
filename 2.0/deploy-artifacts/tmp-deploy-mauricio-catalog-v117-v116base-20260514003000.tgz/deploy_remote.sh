﻿#!/usr/bin/env bash
set -euo pipefail

TAG="agentezap-app:mauricio-catalog-v117-v116base-20260514003000"
EXPECTED_BASE="agentezap-app:frontend-theme-v116-20260514001336"
COMPOSE_DIR="/opt/agentezap-single/compose"
DEPLOY_DIR="/tmp/tmp-deploy-mauricio-catalog-v117-v116base-20260514003000"
SESSIONS_DIR="/data/agentezap/sessions"

cd "$COMPOSE_DIR"

before_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
before_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
current_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
current_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}' 2>/dev/null || true)"
current_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}' 2>/dev/null || true)"
current_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
current_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] current_image=${current_image}"
echo "[deploy] current_health=${current_health}"
echo "[deploy] current_restart=${current_restart}"
echo "[deploy] current_entrypoint=${current_entrypoint}"
echo "[deploy] current_cmd=${current_cmd}"
echo "[deploy] sessions_before=${before_auth}/${before_creds}"

if [ "$current_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed since validation (${current_image} != ${EXPECTED_BASE}). Rebase this deploy first." >&2
  exit 1
fi
if [ "$current_health" != "healthy" ]; then
  echo "[deploy] ERROR: app is not healthy before deploy" >&2
  exit 1
fi
if [ "$current_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$current_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: active app has unexpected entrypoint/cmd." >&2
  exit 1
fi

require_current_marker() {
  local marker="$1"
  local path="$2"
  echo "[deploy] checking active marker: ${marker} in ${path}"
  docker exec agentezap-app sh -lc "grep -aR -m 1 '$marker' '$path' >/dev/null"
}

require_current_marker 'az-search-input' '/app/dist/public'
require_current_marker 'az-chat-surface' '/app/dist/public'
require_current_marker 'shouldAutoRunAgendamento3DirectInSimulator' '/app/dist'
require_current_marker 'syncMode' '/app/dist'

cd "$DEPLOY_DIR"
test -f dist/index.js
test -f dist/api/http.js
test ! -d dist/public
grep -aR -m 1 'shouldAutoRunAgendamento3DirectInSimulator' dist >/dev/null
grep -aR -m 1 'agendamento3_next_available_slot' dist >/dev/null
grep -aR -m 1 'freebusy.query' dist >/dev/null
grep -aR -m 1 'sync_token' dist >/dev/null
grep -aR -m 1 'syncMode' dist >/dev/null
grep -aR -m 1 'concreteRequest' dist >/dev/null
grep -aR -m 1 'Agendamento 3.0 direct simulator fallback' dist >/dev/null
grep -aR -m 1 'buildKnownSubjectCatalogDirectReply' dist >/dev/null
grep -aR -m 1 'hasConcreteSimulatorFirstOpeningRequest' dist >/dev/null
grep -aR -m 1 'hasDeterministicCatalogImageDelivery' dist >/dev/null

cat > Dockerfile <<EOF
FROM ${current_image}
RUN mkdir -p /tmp/agentezap-public-keep \
  && cp -a /app/dist/public /tmp/agentezap-public-keep/public \
  && rm -rf /app/dist \
  && mkdir -p /app/dist \
  && cp -a /tmp/agentezap-public-keep/public /app/dist/public \
  && rm -rf /tmp/agentezap-public-keep
COPY dist /app/dist
EOF
docker build -t "$TAG" .

cd "$COMPOSE_DIR"
pre_switch_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
if [ "$pre_switch_image" != "$EXPECTED_BASE" ]; then
  echo "[deploy] ERROR: active image changed while building (${pre_switch_image} != ${EXPECTED_BASE}). Not switching app." >&2
  exit 1
fi

cp .env.runtime ".env.runtime.backup-mauricio-catalog-v117-v116base-20260514003000"
python3 - "$TAG" <<'PY'
from pathlib import Path
import sys

tag = sys.argv[1]
path = Path(".env.runtime")
desired = {
    "AGENTEZAP_APP_IMAGE": tag,
    "NODE_OPTIONS": "--max-old-space-size=4096",
    "WA_PENDING_TIMERS_START_DURING_RESTORE": "false",
}
lines = path.read_text().splitlines()
out = []
seen = set()
for line in lines:
    key = line.split("=", 1)[0] if "=" in line else ""
    if key in desired:
        out.append(f"{key}={desired[key]}")
        seen.add(key)
    else:
        out.append(line)
for key, value in desired.items():
    if key not in seen:
        out.append(f"{key}={value}")
path.write_text("\n".join(out) + "\n")
PY

docker compose --env-file .env.runtime -f compose.yml up -d --no-deps --wait app

after_auth="$(find "$SESSIONS_DIR" -maxdepth 1 -type d -name 'auth_*' | wc -l)"
after_creds="$(find "$SESSIONS_DIR" -path '*/creds.json' | wc -l)"
running_image="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
running_health="$(docker inspect agentezap-app --format '{{.State.Health.Status}}')"
running_restart="$(docker inspect agentezap-app --format '{{.RestartCount}}')"
running_entrypoint="$(docker inspect agentezap-app --format '{{json .Config.Entrypoint}}')"
running_cmd="$(docker inspect agentezap-app --format '{{json .Config.Cmd}}')"

echo "[deploy] running_image=${running_image}"
echo "[deploy] running_health=${running_health}"
echo "[deploy] running_restart=${running_restart}"
echo "[deploy] running_entrypoint=${running_entrypoint}"
echo "[deploy] running_cmd=${running_cmd}"
echo "[deploy] sessions_after=${after_auth}/${after_creds}"

if [ "$after_auth" -lt "$before_auth" ] || [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] ERROR: session count dropped during app-only deploy" >&2
  exit 1
fi
if [ "$running_image" != "$TAG" ]; then
  echo "[deploy] ERROR: app did not switch to expected image ${TAG}" >&2
  exit 1
fi
if [ "$running_entrypoint" != '["docker-entrypoint.sh"]' ] || [ "$running_cmd" != '["node","dist/index.js"]' ]; then
  echo "[deploy] ERROR: deployed app has unexpected entrypoint/cmd" >&2
  exit 1
fi

docker exec agentezap-app sh -lc "grep -aR -m 1 'az-search-input' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'az-chat-surface' /app/dist/public >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'shouldAutoRunAgendamento3DirectInSimulator' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'agendamento3_next_available_slot' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'freebusy.query' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'sync_token' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'syncMode' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'concreteRequest' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'Agendamento 3.0 direct simulator fallback' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'buildKnownSubjectCatalogDirectReply' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'hasConcreteSimulatorFirstOpeningRequest' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'hasDeterministicCatalogImageDelivery' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'enforcePromptCriticalRentalPaymentRule' /app/dist >/dev/null"
docker exec agentezap-app sh -lc "grep -aR -m 1 'resolveBrazilTemporalContext' /app/dist >/dev/null"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/healthz').then(async r=>{console.log('[deploy] container_healthz='+r.status+' '+(await r.text()).slice(0,120)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"
docker exec agentezap-app node -e "fetch('http://127.0.0.1:5000/api/health').then(async r=>{console.log('[deploy] container_api_health='+r.status+' '+(await r.text()).slice(0,300)); process.exit(r.ok?0:1)}).catch(e=>{console.error(e); process.exit(1)})"

echo "[deploy] done"
