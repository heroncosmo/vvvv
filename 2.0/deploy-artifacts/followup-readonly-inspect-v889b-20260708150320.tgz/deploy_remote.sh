#!/usr/bin/env bash
set -euo pipefail

EXPECTED_ACTIVE_IMAGE="agentezap-app:followup-structured-plan-v889b-20260708145740"

echo "[inspect] now=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
echo "[inspect] active_image=${ACTIVE_IMAGE}"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[inspect] unexpected active image; expected ${EXPECTED_ACTIVE_IMAGE}" >&2
  exit 1
fi

docker inspect --format '[inspect] state={{.State.Status}} health={{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} restart={{.RestartCount}} started={{.State.StartedAt}}' agentezap-app
echo "[inspect] port=$(docker port agentezap-app 5000/tcp)"
echo "[inspect] healthz=$(curl -fsS http://127.0.0.1:5000/healthz)"
echo "[inspect] api_health=$(curl -fsS http://127.0.0.1:5000/api/health)"

echo "[inspect] safe env markers"
docker exec agentezap-app sh -lc '
  env | sort | grep -E "^(ENABLE_VPS_INTERNAL_CRONS|ENABLE_VPS_CRON_SCHEDULER|ENABLE_STATEFUL_INTERVAL_JOBS|STATEFUL_JOB_CRON_USER_FOLLOWUP_SCHEDULE|STATEFUL_JOB_CRON_GROUPS|STATEFUL_JOBS_VERCEL_CRON_GROUPS|AGENTEZAP_CODEX_CLI_TENANT_MODEL|AGENTEZAP_CODEX_CLI_RODRIGO_MODEL|AGENTEZAP_CODEX_CLI_RODRIGO_REASONING_EFFORT|WEB_ONLY_FOLLOWUP_CRON_LIMIT|WEB_ONLY_FOLLOWUP_CRON_PER_USER_LIMIT|WEB_ONLY_FOLLOWUP_CRON_TIME_BUDGET_MS)=" || true
'

echo "[inspect] recent scheduler/followup logs"
docker logs --since 12m agentezap-app 2>&1 \
  | grep -a -E "VPS CRON|user-followup|vercel-followup-cron|followup agentic|followup rejected|followup agentic task failed|Codex CLI task failed|structured_output|statement timeout|sanitizeWebOnlyAgenticToolName|DEPLOY_OK" \
  | tail -n 240 || true

echo "[inspect] recent boot errors"
docker logs --since 12m agentezap-app 2>&1 \
  | grep -a -E "SyntaxError|Range out of order|ReferenceError|UnhandledPromiseRejection|MODULE_NOT_FOUND|AbortError|canceling statement due to statement timeout" \
  | tail -n 80 || true

echo "[inspect] READONLY_OK"
