#!/usr/bin/env bash
set -euo pipefail
cd /opt/agentezap-single/compose
printf 'DIAG_TIME='; date -Is
printf 'ACTIVE_IMAGE='; grep '^AGENTEZAP_APP_IMAGE=' .env.runtime | cut -d= -f2-
printf 'COMPOSE_FILES='; ls compose.yml compose.host-nginx.yml 2>/dev/null | tr '\n' ' '; echo
printf 'HEALTHZ='; curl -sf http://127.0.0.1:5000/healthz || true; echo
printf 'API_HEALTH='; curl -sf http://127.0.0.1:5000/api/health || true; echo
printf 'DOCKER_PS_APP='; docker ps --filter name=agentezap-app --format '{{.Names}} {{.Image}} {{.Status}}' || true
printf 'CREDS_COUNT='; find /data/whatsapp-sessions -maxdepth 2 -name creds.json 2>/dev/null | wc -l || true
echo '--- recent app logs simulator/filter ---'
docker logs --tail 500 agentezap-app 2>&1 | grep -Ei 'agent/test|test-agent|simulator|empty|Legacy simulator|secondary real runtime|WEB_ONLY|provider|mistral|timeout|abort|502|AI SDK|returned empty|callWebOnlyLlm|runWebOnlyAgentTestForUser' | tail -220 || true
echo '--- recent app logs tail ---'
docker logs --tail 120 agentezap-app 2>&1 || true
