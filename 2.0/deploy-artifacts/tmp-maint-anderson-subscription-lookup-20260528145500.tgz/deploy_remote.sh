#!/usr/bin/env bash
set -euo pipefail

echo "ANDERSON_SUBSCRIPTION_LOOKUP_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");

const url = process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL;
if (!url) throw new Error("DATABASE_URL missing");

const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
const conversationId = "7a7076cc-4206-437d-aebe-56a8c3374e33";
const userId = "33d36098-0b80-4913-bd6a-02125a643934";
const receiptIdent = "43C6F49DCF3544F395E664C47";

async function q(name, sql, params = []) {
  const result = await client.query(sql, params);
  console.log(`## ${name}`);
  console.log(JSON.stringify(result.rows, null, 2));
}

(async () => {
  await client.connect();
  await q("conversation", `
    SELECT c.id, wc.user_id AS owner_user_id, owner.email AS owner_email, c.contact_name, c.contact_number,
           c.connection_id, c.last_message_text, c.last_message_from_me, c.unread_count,
           c.needs_human_attention, c.followup_active
    FROM conversations c
    JOIN whatsapp_connections wc ON wc.id = c.connection_id
    LEFT JOIN users owner ON owner.id = wc.user_id
    WHERE c.id = $1
  `, [conversationId]);

  await q("messages_recent", `
    SELECT id, from_me, text, media_type, media_url, timestamp, created_at
    FROM messages
    WHERE conversation_id = $1
    ORDER BY timestamp DESC
    LIMIT 8
  `, [conversationId]);

  await q("user_target", `
    SELECT id, email, name, whatsapp_number, created_at
    FROM users
    WHERE id = $1
  `, [userId]);

  await q("subscriptions_target", `
    SELECT s.id, s.user_id, u.email, u.name, p.nome AS plan_name, p.valor AS plan_price,
           p.periodicidade, p.frequencia_dias, s.plan_id, s.status, s.coupon_price,
           s.data_inicio, s.data_fim, s.next_payment_date, s.pending_receipt,
           s.approved_receipt_at, s.payer_email, s.payment_method, s.created_at, s.metadata
    FROM subscriptions s
    JOIN users u ON u.id = s.user_id
    JOIN plans p ON p.id = s.plan_id
    WHERE s.user_id = $1
    ORDER BY s.created_at DESC
  `, [userId]);

  await q("payment_history_target", `
    SELECT id, subscription_id, user_id, amount, status, status_detail, payment_type,
           payment_method, mp_payment_id, payer_email, created_at, raw_response
    FROM payment_history
    WHERE user_id = $1 OR raw_response::text ILIKE '%' || $2 || '%'
    ORDER BY created_at DESC
    LIMIT 20
  `, [userId, receiptIdent]);

  await q("receipts_target", `
    SELECT id, subscription_id, user_id, plan_id, amount, status, receipt_url,
           receipt_filename, receipt_mime_type, mp_payment_id, reviewed_by, reviewed_at,
           review_notes, created_at
    FROM payment_receipts
    WHERE user_id = $1 OR review_notes ILIKE '%' || $2 || '%'
    ORDER BY created_at DESC
    LIMIT 20
  `, [userId, receiptIdent]);

  await client.end();
})().catch(async (error) => {
  console.error("LOOKUP_ERROR", error);
  try { await client.end(); } catch {}
  process.exit(1);
});
NODE
echo "ANDERSON_SUBSCRIPTION_LOOKUP_END"
