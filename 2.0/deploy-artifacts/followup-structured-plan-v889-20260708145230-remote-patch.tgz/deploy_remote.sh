#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="agentezap-app:followup-structured-plan-v889-20260708145230"
EXPECTED_ACTIVE_IMAGE="agentezap-app:followup-toolname-v888b-20260708143520"
TMP_CONTAINER="agentezap-followup-structured-plan-v889-tmp"
COMPOSE_DIR="/opt/agentezap-single/compose"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

patch_http_bundle() {
  local container="$1"
  test -s "${SCRIPT_DIR}/http.js"
  docker cp "${SCRIPT_DIR}/http.js" "${container}:/app/dist/api/http.js"
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
  '
}

check_markers() {
  local container="$1"
  docker exec -i "$container" node - <<'NODE'
const fs = require("node:fs");
const source = fs.readFileSync("/app/dist/api/http.js", "utf8");
const fullAppFile = fs.readdirSync("/app/dist").find((name) => /^full-app-.*\.js$/.test(name));
if (!fullAppFile) throw new Error("full-app bundle not found");
const fullApp = fs.readFileSync(`/app/dist/${fullAppFile}`, "utf8");
const genStart = source.indexOf("async function generateWebOnlyAgenticFollowupPlan");
const genEnd = source.indexOf("function resolveWebOnlyNextFollowupDate", genStart);
const normalizeStart = source.indexOf("function normalizeWebOnlyFollowupPlanJson");
const normalizeEnd = source.indexOf("function formatWebOnlyMessagesForStructuredPrompt", normalizeStart);
const recoveryStart = source.indexOf("async function recoverWebOnlyFollowupsWaitingForCompanyReply");
const recoveryEnd = source.indexOf("async function hasWebOnlyCustomerReplyInFollowupConversation", recoveryStart);
if (genStart < 0 || genEnd <= genStart) throw new Error("followup generator block not found");
if (normalizeStart < 0 || normalizeEnd <= normalizeStart) throw new Error("followup normalizer block not found");
if (recoveryStart < 0 || recoveryEnd <= recoveryStart) throw new Error("followup recovery block not found");
const gen = source.slice(genStart, genEnd);
const norm = source.slice(normalizeStart, normalizeEnd);
const rec = source.slice(recoveryStart, recoveryEnd);
const checks = {
  noObjectSchemaInFollowup: !gen.includes("objectSchema: webOnlyFollowupPlanSchema"),
  acceptsLiveCliPlan: gen.includes("liveCliPlan"),
  noRepairCall: !gen.includes("repairWebOnlyFollowupTimingIncoherentMessage"),
  sendMediaLegacyBlank: norm.includes('rawAction === "send_media"') && /message:\s*""/.test(norm) && !/parsed\?\.message|parsed\?\.text/.test(norm),
  helperDefined: source.includes("function sanitizeWebOnlyAgenticToolName"),
  antiTimeoutCandidate: rec.includes("WITH candidate_conversations AS"),
  antiTimeoutLateral: rec.includes("CROSS JOIN LATERAL"),
  antiTimeoutNoGlobalDistinct: !rec.includes("SELECT DISTINCT ON (m.conversation_id)"),
  triggerParity: fullApp.includes('app.all("/api/followup/conversation/:id/trigger", delegateToVercelHttpHandler);'),
  noBroadFollowupDelegation: !fullApp.includes('app.all("/api/followup/*", delegateToVercelHttpHandler);'),
  tenantModel: source.includes("AGENTEZAP_CODEX_CLI_TENANT_MODEL") && source.includes("gpt-5.4-mini"),
  rodrigoModel: source.includes("AGENTEZAP_CODEX_CLI_RODRIGO_MODEL") && source.includes("gpt-5.5"),
  asyncFollowup: source.includes("webOnlyUserFollowupCronInFlight") && source.includes("x-stateful-job-async"),
  pdfVision: source.includes("pdf_rendered_image_vision"),
};
for (const [name, ok] of Object.entries(checks)) {
  if (!ok) throw new Error(`marker failed: ${name}`);
}
console.log(JSON.stringify(checks));
NODE
  docker exec "$container" sh -lc 'command -v pdftoppm >/dev/null'
}

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] replacing /app/dist/api/http.js"
patch_http_bundle "$TMP_CONTAINER"
check_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|Range out of order|ReferenceError|UnhandledPromiseRejection|MODULE_NOT_FOUND|AbortError'; then
  echo "[deploy] boot errors detected" >&2
  exit 62
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
