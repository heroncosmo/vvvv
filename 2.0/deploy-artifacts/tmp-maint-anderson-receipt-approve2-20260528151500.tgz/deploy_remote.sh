#!/usr/bin/env bash
set -euo pipefail

echo "ANDERSON_RECEIPT_APPROVE_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");

const url = process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL;
if (!url) throw new Error("DATABASE_URL missing");

const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
const receiptId = "4a75a4e9-9fc4-487a-af5f-52fe81919c18";
const subscriptionId = "2e08234b-49da-45a1-b5db-4ceaa3ab1442";
const reviewer = "suporte_rodrigo_2026_05_28";
const note = "Comprovante conferido manualmente: Pix R$49,99, pago em 27/05/2026 16:10:47, pagador Anderson Rodrigues de Araujo Santos, favorecida Maria Fernandes de Bessa Macedo, identificacao 43C6F49DCF3544F395E664C47.";

(async () => {
  await client.connect();
  await client.query("BEGIN");

  const receipt = await client.query(
    "SELECT * FROM payment_receipts WHERE id = $1 FOR UPDATE",
    [receiptId],
  );
  if (receipt.rowCount !== 1) {
    throw new Error(`receipt_not_found:${receiptId}`);
  }
  if (receipt.rows[0].subscription_id !== subscriptionId) {
    throw new Error(`subscription_mismatch:${receipt.rows[0].subscription_id}`);
  }

  await client.query(`
    UPDATE payment_receipts
       SET status = 'approved',
           reviewed_at = now(),
           reviewed_by = $2,
           admin_notes = concat_ws(E'\n\n', nullif(admin_notes, ''), $3::text),
           updated_at = now()
     WHERE id = $1
  `, [receiptId, reviewer, note]);

  await client.query(`
    UPDATE subscriptions
       SET status = 'active',
           pending_receipt = false,
           payment_method = 'pix_manual',
           metadata = coalesce(metadata, '{}'::jsonb) || jsonb_build_object(
             'manualReceiptReviewedAt', now(),
             'manualReceiptReviewedBy', $2,
             'manualReceiptId', $1
           ),
           updated_at = now()
     WHERE id = $3
  `, [receiptId, reviewer, subscriptionId]);

  const after = await client.query(`
    SELECT s.id, s.status, s.pending_receipt, s.data_inicio, s.data_fim, s.next_payment_date,
           pr.id AS receipt_id, pr.status AS receipt_status, pr.reviewed_at, pr.reviewed_by
      FROM subscriptions s
      LEFT JOIN payment_receipts pr ON pr.subscription_id = s.id AND pr.id = $1
     WHERE s.id = $2
  `, [receiptId, subscriptionId]);

  await client.query("COMMIT");
  console.log("ANDERSON_RECEIPT_APPROVE_RESULT");
  console.log(JSON.stringify(after.rows, null, 2));
  await client.end();
})().catch(async (error) => {
  try { await client.query("ROLLBACK"); } catch {}
  try { await client.end(); } catch {}
  console.error("APPROVE_ERROR", error);
  process.exit(1);
});
NODE
echo "ANDERSON_RECEIPT_APPROVE_END"
