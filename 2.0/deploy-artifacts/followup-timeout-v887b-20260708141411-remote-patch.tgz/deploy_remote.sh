#!/usr/bin/env bash
set -euo pipefail

NEW_IMAGE="agentezap-app:followup-timeout-v887b-20260708141411"
EXPECTED_ACTIVE_IMAGE="agentezap-app:followup-codex-parity-v886b-20260708134904"
TMP_CONTAINER="agentezap-followup-timeout-v887b-tmp"
COMPOSE_DIR="/opt/agentezap-single/compose"

count_creds() {
  find /data/whatsapp-sessions /data/admin-whatsapp-sessions /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l | tr -d '[:space:]'
}

patch_http_bundle() {
  local container="$1"
  docker exec -i "$container" node - <<'NODE'
const fs = require("node:fs");
const file = "/app/dist/api/http.js";
let source = fs.readFileSync(file, "utf8");
const functionStart = source.indexOf("async function recoverWebOnlyFollowupsWaitingForCompanyReply");
const functionEnd = source.indexOf("async function hasWebOnlyCustomerReplyInFollowupConversation", functionStart);
if (functionStart < 0 || functionEnd <= functionStart) {
  throw new Error("follow-up company-reply recovery function block not found");
}

let block = source.slice(functionStart, functionEnd);
const queryStartNeedle = "  const result = await getPool().query(\n    `";
const queryEndNeedle = "\n    `,\n    [targetConversationId ? 1 : limit, perUserLimit, targetConversationId]\n  );";
const queryStart = block.indexOf(queryStartNeedle);
const queryEnd = block.indexOf(queryEndNeedle, queryStart);
if (queryStart < 0 || queryEnd <= queryStart) {
  throw new Error("follow-up recovery SQL query block not found");
}

const newQuery = `  const result = await getPool().query(
    \`
      WITH candidate_conversations AS (
        SELECT
          c.id,
          wc.user_id AS "userId",
          c.updated_at AS "conversationUpdatedAt"
        FROM conversations c
        INNER JOIN whatsapp_connections wc ON wc.id = c.connection_id
        INNER JOIN followup_configs fc ON fc.user_id = wc.user_id
        WHERE fc.is_enabled = true
          AND c.followup_active = true
          AND COALESCE(c.followup_stage, 0) = 0
          AND c.next_followup_at IS NULL
          AND (
            c.followup_disabled_reason ILIKE 'Cliente foi%'
            OR c.followup_disabled_reason ILIKE 'Cliente respondeu%'
          )
          AND COALESCE(c.jid_suffix, 's.whatsapp.net') <> 'g.us'
          AND COALESCE(c.remote_jid, '') NOT LIKE '%@g.us'
          AND ($3::text IS NULL OR c.id = $3)
      ),
      candidates AS (
        SELECT
          cc.id,
          cc."userId",
          latest_real.timestamp AS "latestMessageAt",
          ROW_NUMBER() OVER (
            PARTITION BY cc."userId"
            ORDER BY latest_real.timestamp DESC NULLS LAST, cc."conversationUpdatedAt" DESC
          ) AS user_rank
        FROM candidate_conversations cc
        CROSS JOIN LATERAL (
          SELECT
            m.from_me,
            m.status,
            m.timestamp,
            m.created_at
          FROM messages m
          WHERE m.conversation_id = cc.id
            AND (
              NULLIF(BTRIM(COALESCE(m.text, '')), '') IS NOT NULL
              OR NULLIF(BTRIM(COALESCE(m.media_caption, '')), '') IS NOT NULL
              OR m.media_type IS NOT NULL
              OR m.media_url IS NOT NULL
              OR m.media_url_original IS NOT NULL
            )
            AND COALESCE(m.text, '') NOT ILIKE '[Mensagem de protocolo]%'
          ORDER BY m.timestamp DESC NULLS LAST, m.created_at DESC NULLS LAST, m.id DESC
          LIMIT 1
        ) latest_real
        WHERE true
          AND latest_real.from_me = true
          AND COALESCE(latest_real.status, 'sent') NOT IN ('pending', 'pending_delivery', 'failed', 'sending', 'error')
      )
      SELECT id, "userId", "latestMessageAt"
      FROM candidates
      WHERE user_rank <= $2
      ORDER BY "latestMessageAt" DESC NULLS LAST, id ASC
      LIMIT $1
    \`,
    [targetConversationId ? 1 : limit, perUserLimit, targetConversationId]
  );`;

block = block.slice(0, queryStart) + newQuery + block.slice(queryEnd + queryEndNeedle.length);
source = source.slice(0, functionStart) + block + source.slice(functionEnd);
fs.writeFileSync(file, source);

const updated = fs.readFileSync(file, "utf8");
const nextStart = updated.indexOf("async function recoverWebOnlyFollowupsWaitingForCompanyReply");
const nextEnd = updated.indexOf("async function hasWebOnlyCustomerReplyInFollowupConversation", nextStart);
const nextBlock = updated.slice(nextStart, nextEnd);
if (!nextBlock.includes("WITH candidate_conversations AS")) throw new Error("missing candidate_conversations");
if (!nextBlock.includes("CROSS JOIN LATERAL")) throw new Error("missing lateral query");
if (nextBlock.includes("SELECT DISTINCT ON (m.conversation_id)")) throw new Error("global DISTINCT ON still present");
console.log(JSON.stringify({
  patched: true,
  hasCandidateConversations: true,
  hasLateral: true,
  hasDistinctOnGlobal: false,
}));
NODE
}

check_node_parse() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    node --check /app/dist/api/http.js
    node --check /app/dist/index.js
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    node --check "$full_app"
  '
}

check_markers() {
  local container="$1"
  docker exec "$container" sh -lc '
    set -eu
    full_app="$(ls /app/dist/full-app-*.js | head -n 1)"
    test -n "$full_app"
    grep -F "app.all(\"/api/followup/conversation/:id/trigger\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
    ! grep -F "app.all(\"/api/followup/*\", delegateToVercelHttpHandler);" "$full_app" >/dev/null
    grep -F "WITH candidate_conversations AS" /app/dist/api/http.js >/dev/null
    grep -F "CROSS JOIN LATERAL (" /app/dist/api/http.js >/dev/null
    grep -F "runWebOnlyUserFollowupJob({ conversationId })" /app/dist/api/http.js >/dev/null
    grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_TENANT_MODEL" /app/dist >/dev/null
    grep -R -a -F -l -- "gpt-5.4-mini" /app/dist >/dev/null
    grep -R -a -F -l -- "AGENTEZAP_CODEX_CLI_RODRIGO_MODEL" /app/dist >/dev/null
    grep -R -a -F -l -- "gpt-5.5" /app/dist >/dev/null
    grep -R -a -F -l -- "x-stateful-job-async" /app/dist >/dev/null
    grep -R -a -F -l -- "webOnlyUserFollowupCronInFlight" /app/dist >/dev/null
    grep -R -a -F -l -- "pdf_rendered_image_vision" /app/dist >/dev/null
    command -v pdftoppm >/dev/null
  '
}

echo "[deploy] checking active image"
ACTIVE_IMAGE="$(docker inspect --format '{{.Config.Image}}' agentezap-app)"
if [ "$ACTIVE_IMAGE" != "$EXPECTED_ACTIVE_IMAGE" ]; then
  echo "[deploy] unexpected active image: $ACTIVE_IMAGE" >&2
  echo "[deploy] expected: $EXPECTED_ACTIVE_IMAGE" >&2
  exit 1
fi

test -f "${COMPOSE_DIR}/compose.yml"
test -f "${COMPOSE_DIR}/compose.host-nginx.yml"
test -f "${COMPOSE_DIR}/.env.runtime"
test -x "${COMPOSE_DIR}/scripts/deploy-service.sh"

before_creds="$(count_creds)"
echo "[deploy] creds before: ${before_creds}"

docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true
cleanup() { docker rm -f "$TMP_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "[deploy] creating temporary container from active image"
docker create --name "$TMP_CONTAINER" "$ACTIVE_IMAGE" sh -lc 'sleep 3600' >/dev/null
docker start "$TMP_CONTAINER" >/dev/null

echo "[deploy] patching /app/dist/api/http.js"
patch_http_bundle "$TMP_CONTAINER"
check_markers "$TMP_CONTAINER"
check_node_parse "$TMP_CONTAINER"

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo "[deploy] DRY_RUN_OK ${NEW_IMAGE}"
  exit 0
fi

echo "[deploy] committing image ${NEW_IMAGE}"
docker commit \
  --change='ENTRYPOINT ["docker-entrypoint.sh"]' \
  --change='CMD ["node","dist/index.js"]' \
  "$TMP_CONTAINER" "$NEW_IMAGE" >/dev/null

echo "[deploy] deploying app-only"
cd "$COMPOSE_DIR"
"$COMPOSE_DIR/scripts/deploy-service.sh" app "$NEW_IMAGE"

echo "[deploy] validating service"
sleep 25
docker inspect --format '{{.Config.Image}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}} {{.RestartCount}}' agentezap-app
test "$(docker inspect --format '{{.Config.Image}}' agentezap-app)" = "$NEW_IMAGE"
test "$(docker port agentezap-app 5000/tcp)" = "127.0.0.1:5000"
curl -fsS http://127.0.0.1:5000/healthz
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"mode":"monolith"' >/dev/null
curl -fsS http://127.0.0.1:5000/api/health | grep -F '"runtimeProfile":"full"' >/dev/null

if docker logs --since 2m agentezap-app 2>&1 | grep -a -E 'SyntaxError|Range out of order|ReferenceError|UnhandledPromiseRejection|MODULE_NOT_FOUND|AbortError'; then
  echo "[deploy] boot errors detected" >&2
  exit 62
fi

after_creds="$(count_creds)"
echo "[deploy] creds after: ${after_creds}"
if [ "$after_creds" -lt "$before_creds" ]; then
  echo "[deploy] creds count decreased: before=${before_creds} after=${after_creds}" >&2
  exit 3
fi

check_markers agentezap-app
check_node_parse agentezap-app
echo "[deploy] DEPLOY_OK ${NEW_IMAGE}"
