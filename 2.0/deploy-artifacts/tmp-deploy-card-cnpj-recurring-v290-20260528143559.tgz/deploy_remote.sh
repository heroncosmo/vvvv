#!/usr/bin/env bash
set -euo pipefail

artifact=/tmp/tmp-deploy-card-cnpj-recurring-v290-20260528143559.tgz
workdir=/tmp/tmp-deploy-card-cnpj-recurring-v290-20260528143559
tag=agentezap-app:card-cnpj-recurring-v290-20260528143559
base=agentezap-app:adriana-temporal-reference-v289-20260528131500

running_before="$(docker inspect agentezap-app --format '{{.Config.Image}}' 2>/dev/null || true)"
if [ "$running_before" != "$base" ]; then
  echo "ABORT_BASE_MISMATCH expected=$base running=$running_before" >&2
  exit 42
fi

ag_creds_before=$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l)
legacy_creds_before=$(find /data/whatsapp-sessions -name creds.json 2>/dev/null | wc -l)

rm -rf "$workdir"
mkdir -p "$workdir"
tar -xzf "$artifact" -C "$workdir"

{
  printf 'FROM %s\n' "$base"
  printf 'WORKDIR /app\n'
  printf "RUN find /app/dist -maxdepth 1 -type f -name '*.js' -delete && rm -rf /app/dist/api\n"
  printf 'COPY dist/*.js /app/dist/\n'
  printf 'COPY dist/api /app/dist/api\n'
  printf 'COPY dist/public/index.html /app/dist/public/index.html\n'
  printf 'COPY dist/public/assets/index-BaI0E2Sf.js /app/dist/public/assets/index-BaI0E2Sf.js\n'
  printf 'COPY dist/public/assets/main-COkgBkaB.js /app/dist/public/assets/main-COkgBkaB.js\n'
  printf 'COPY dist/public/assets/main-DvL3yQNR.css /app/dist/public/assets/main-DvL3yQNR.css\n'
  printf 'LABEL agentezap.patch="card-cnpj-recurring-v290"\n'
} > "$workdir/Dockerfile"

grep -aR -m 1 'normalizedIdentificationType' "$workdir/dist" >/dev/null
grep -aR -m 1 'Documento do Titular' "$workdir/dist/public" >/dev/null

docker build -f "$workdir/Dockerfile" -t "$tag" "$workdir"

cd /opt/agentezap-single/compose
test -f compose.host-nginx.yml
./scripts/deploy-service.sh app "$tag"

printf 'LOCAL_HEALTH='
curl -fsS http://127.0.0.1:5000/healthz
echo
printf 'LOCAL_API_HEALTH='
curl -fsS http://127.0.0.1:5000/api/health
echo
printf 'PUBLIC_HEALTH='
curl -fsS https://agentezap.online/healthz
echo
printf 'PUBLIC_API_HEALTH='
curl -fsS https://agentezap.online/api/health
echo
printf 'MARKER='
docker exec agentezap-app sh -lc "grep -aR -m 1 'normalizedIdentificationType' /app/dist >/dev/null && grep -aR -m 1 'Documento do Titular' /app/dist/public >/dev/null && echo card-cnpj-recurring-ok"

ag_creds_after=$(find /data/agentezap/sessions -name creds.json 2>/dev/null | wc -l)
legacy_creds_after=$(find /data/whatsapp-sessions -name creds.json 2>/dev/null | wc -l)

echo "BASE_IMAGE=$base"
echo "NEW_IMAGE=$tag"
echo "RUNNING_BEFORE=$running_before"
echo "RUNNING_IMAGE=$(docker inspect agentezap-app --format '{{.Config.Image}}')"
echo "AGENTEZAP_CREDS_BEFORE=$ag_creds_before"
echo "AGENTEZAP_CREDS_AFTER=$ag_creds_after"
echo "LEGACY_CREDS_BEFORE=$legacy_creds_before"
echo "LEGACY_CREDS_AFTER=$legacy_creds_after"
echo "PORTS=$(docker port agentezap-app 2>/dev/null | tr '\n' ',')"
