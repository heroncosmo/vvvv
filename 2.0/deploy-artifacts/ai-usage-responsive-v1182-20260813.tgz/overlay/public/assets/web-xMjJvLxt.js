import{W as n}from"./main-Bg-IeRU2.js";import"./index-D2YEbbRt.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
