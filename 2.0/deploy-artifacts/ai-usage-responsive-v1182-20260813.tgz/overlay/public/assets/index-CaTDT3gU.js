import{r as i}from"./main-Bg-IeRU2.js";import"./index-D2YEbbRt.js";const r=i("PushNotifications",{});export{r as PushNotifications};
