#!/usr/bin/env bash
set -Eeuo pipefail

STACK_DIR="/opt/agentezap-single/compose"
EXPECTED_IMAGE="agentezap-app:ai-usage-bootstrap-canonical-v1181-20260812"
EXPECTED_IMAGE_ID="sha256:9b707db279a482d5fe06fdd3872d13cbcea6b97f80ed3cc721d158818d667b24"
TARGET_IMAGE="agentezap-app:ai-usage-responsive-v1182-20260813"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/overlay"
BACKUP_ENV="${STACK_DIR}/.env.runtime.ai-usage-responsive-v1182-backup"
DOCKERFILE="/tmp/Dockerfile.ai-usage-responsive-v1182"
MANIFEST="/tmp/ai-usage-responsive-v1182.sha256"
ENV_CHANGED=0

count_creds() {
  find "$1" -type f -name creds.json 2>/dev/null | wc -l
}

wait_for_healthy() {
  for _ in $(seq 1 120); do
    local state health
    state="$(docker inspect agentezap-app --format '{{.State.Status}}' 2>/dev/null || true)"
    health="$(docker inspect agentezap-app --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}' 2>/dev/null || true)"
    if [[ "$state" == "running" && "$health" == "healthy" ]]; then
      return 0
    fi
    sleep 2
  done
  return 1
}

cleanup() {
  rm -f "$DOCKERFILE" "$MANIFEST"
}

rollback() {
  local exit_code=$?
  set +e
  if [[ "$ENV_CHANGED" == "1" && -f "$BACKUP_ENV" ]]; then
    cp "$BACKUP_ENV" "${STACK_DIR}/.env.runtime"
    cd "$STACK_DIR"
    docker compose --env-file .env.runtime -f compose.yml -f compose.host-nginx.yml up -d --no-deps --wait app
    wait_for_healthy
  fi
  cleanup
  exit "$exit_code"
}
trap rollback ERR

[[ -d "$BUILD_DIR/public" ]]
[[ -f "$BUILD_DIR/public/index.html" ]]
[[ -f "$BUILD_DIR/public/assets/index-D2YEbbRt.js" ]]
[[ -f "$BUILD_DIR/public/assets/main-Bg-IeRU2.js" ]]
[[ -f "$BUILD_DIR/public/assets/main-BWjEocBS.css" ]]
[[ "$(docker inspect agentezap-app --format '{{.Config.Image}}')" == "$EXPECTED_IMAGE" ]]
[[ "$(docker inspect agentezap-app --format '{{.Image}}')" == "$EXPECTED_IMAGE_ID" ]]
[[ "$(docker inspect agentezap-app --format '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')" == "running/healthy/0/false" ]]
! pgrep -af 'docker (build|compose)|deploy-service|fast-deploy|deploy_safe_release' | grep -v "$$" | grep -v "pgrep -af" >/dev/null

BEFORE_CREDS_HOST="$(count_creds /data/whatsapp-sessions)"
BEFORE_CREDS_MOUNT="$(count_creds /data/agentezap/sessions)"
BEFORE_CMD="$(docker image inspect "$EXPECTED_IMAGE" --format '{{json .Config.Cmd}}')"
BEFORE_ENTRYPOINT="$(docker image inspect "$EXPECTED_IMAGE" --format '{{json .Config.Entrypoint}}')"
BEFORE_WORKER="$(docker inspect agentezap-audio-worker --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
BEFORE_PROXY="$(docker inspect agentezap-agnes-codex-proxy --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
(
  cd "$BUILD_DIR"
  find . -type f -print0 | sort -z | xargs -0 sha256sum > "$MANIFEST"
)
SOURCE_OVERLAY_HASH="$(sha256sum "$MANIFEST" | cut -d " " -f1)"

docker image inspect "$TARGET_IMAGE" >/dev/null 2>&1 && {
  echo "target image already exists" >&2
  exit 1
}

cat > "$DOCKERFILE" <<EOF
FROM ${EXPECTED_IMAGE}
COPY public /app/dist/public
EOF
docker build --pull=false --no-cache -t "$TARGET_IMAGE" -f "$DOCKERFILE" "$BUILD_DIR"

[[ "$(docker image inspect "$TARGET_IMAGE" --format '{{json .Config.Cmd}}')" == "$BEFORE_CMD" ]]
[[ "$(docker image inspect "$TARGET_IMAGE" --format '{{json .Config.Entrypoint}}')" == "$BEFORE_ENTRYPOINT" ]]
docker run --rm -i --network none --entrypoint sh "$TARGET_IMAGE" -ec 'cd /app/dist; sha256sum -c >/dev/null' < "$MANIFEST"
docker run --rm --network none --entrypoint sh "$TARGET_IMAGE" -ec '
  node --check /app/dist/index.js >/dev/null
  node --check /app/dist/api/http.js >/dev/null
  grep -R -q "/api/usage/conversations" /app/dist
  grep -q "index-D2YEbbRt.js" /app/dist/public/index.html
  grep -q "main-Bg-IeRU2.js" /app/dist/public/assets/index-D2YEbbRt.js
  grep -q "main-BWjEocBS.css" /app/dist/public/assets/index-D2YEbbRt.js
  grep -q "Detalhes de consumo por conversa" /app/dist/public/assets/main-Bg-IeRU2.js
  grep -q "Tokens processados" /app/dist/public/assets/main-Bg-IeRU2.js
  grep -q "xl:grid-cols-5" /app/dist/public/assets/main-Bg-IeRU2.js
  grep -q "IA Pro" /app/dist/public/assets/main-Bg-IeRU2.js
  grep -q "ilimitad(?:o|a|os|as)" /app/dist/public/assets/main-Bg-IeRU2.js
  ! grep -q "min-w-\\[820px\\]" /app/dist/public/assets/main-Bg-IeRU2.js
'

cd "$STACK_DIR"
cp .env.runtime "$BACKUP_ENV"
ENV_CHANGED=1
sed -i "s#^AGENTEZAP_APP_IMAGE=.*#AGENTEZAP_APP_IMAGE=${TARGET_IMAGE}#" .env.runtime
grep -qxF "AGENTEZAP_APP_IMAGE=${TARGET_IMAGE}" .env.runtime
docker compose --env-file .env.runtime -f compose.yml -f compose.host-nginx.yml config >/dev/null
docker compose --env-file .env.runtime -f compose.yml -f compose.host-nginx.yml up -d --no-deps --wait app
wait_for_healthy

POST_IMAGE="$(docker inspect agentezap-app --format '{{.Config.Image}}')"
POST_IMAGE_ID="$(docker inspect agentezap-app --format '{{.Image}}')"
POST_STATE="$(docker inspect agentezap-app --format '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
POST_PORTS="$(docker inspect agentezap-app --format '{{json .HostConfig.PortBindings}}')"
POST_CREDS_HOST="$(count_creds /data/whatsapp-sessions)"
POST_CREDS_MOUNT="$(count_creds /data/agentezap/sessions)"
POST_WORKER="$(docker inspect agentezap-audio-worker --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
POST_PROXY="$(docker inspect agentezap-agnes-codex-proxy --format '{{.Config.Image}}/{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}nohealth{{end}}/{{.RestartCount}}/{{.State.OOMKilled}}')"
LOCAL_HEALTH="$(curl -fsS http://127.0.0.1:5000/healthz)"
PUBLIC_HEALTH="$(curl -fsS https://agentezap.online/healthz)"
API_HEALTH="$(curl -fsS http://127.0.0.1:5000/api/health)"

[[ "$POST_IMAGE" == "$TARGET_IMAGE" ]]
[[ "$POST_STATE" == "running/healthy/0/false" ]]
grep -q '127.0.0.1' <<<"$POST_PORTS"
[[ "$BEFORE_CREDS_HOST" == "$POST_CREDS_HOST" ]]
[[ "$BEFORE_CREDS_MOUNT" == "$POST_CREDS_MOUNT" ]]
[[ "$BEFORE_WORKER" == "$POST_WORKER" ]]
[[ "$BEFORE_PROXY" == "$POST_PROXY" ]]
docker exec -i agentezap-app sh -ec 'cd /app/dist; sha256sum -c >/dev/null' < "$MANIFEST"
[[ "$LOCAL_HEALTH" == "ok" && "$PUBLIC_HEALTH" == "ok" ]]
grep -q '"mode":"monolith"' <<<"$API_HEALTH"
grep -q '"runtimeProfile":"full"' <<<"$API_HEALTH"

ENV_CHANGED=0
rm -f "$BACKUP_ENV"
cleanup
trap - ERR

echo "pre_image=$EXPECTED_IMAGE"
echo "post_image=$POST_IMAGE"
echo "post_image_id=$POST_IMAGE_ID"
echo "post_state=$POST_STATE"
echo "ports=$POST_PORTS"
echo "creds_host=$POST_CREDS_HOST creds_mount=$POST_CREDS_MOUNT"
echo "worker=$POST_WORKER"
echo "proxy=$POST_PROXY"
echo "overlay_hash=$SOURCE_OVERLAY_HASH"
echo "health=$LOCAL_HEALTH/$PUBLIC_HEALTH"
echo "api_health=$API_HEALTH"
