#!/usr/bin/env bash
set -euo pipefail

echo "CONV18_LOOKUP2_START"
docker exec -i agentezap-app node - <<'NODE'
const pg = require("pg");
const url = process.env.DATABASE_URL_DIRECT || process.env.DATABASE_URL;
const client = new pg.Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
const conversationId = "5e5a71cb-e7f8-420e-8d12-205183fbe544";

async function q(name, sql, params = []) {
  try {
    const result = await client.query(sql, params);
    console.log(`## ${name}`);
    console.log(JSON.stringify(result.rows, null, 2));
  } catch (error) {
    console.log(`## ${name}_ERROR`);
    console.log(error.message);
  }
}

(async () => {
  await client.connect();
  await q("conversation", `
    SELECT c.id, wc.user_id AS owner_user_id, owner.email AS owner_email, c.contact_name, c.contact_number,
           c.connection_id, c.last_message_text, c.last_message_from_me, c.unread_count,
           c.needs_human_attention, c.followup_active, c.created_at, c.updated_at,
           wc.phone_number AS owner_connection_phone, wc.status AS owner_connection_status,
           wc.is_active AS owner_connection_active
    FROM conversations c
    JOIN whatsapp_connections wc ON wc.id = c.connection_id
    LEFT JOIN users owner ON owner.id = wc.user_id
    WHERE c.id = $1
  `, [conversationId]);
  await q("messages", `
    SELECT id, from_me, text, media_type, media_url, timestamp, created_at
    FROM messages
    WHERE conversation_id = $1
    ORDER BY timestamp ASC
  `, [conversationId]);
  await q("connections_same_number", `
    SELECT wc.id, wc.user_id, u.email, u.name AS user_name, wc.phone_number, wc.status, wc.is_active,
           wc.created_at, wc.updated_at, wc.last_seen_at
    FROM whatsapp_connections wc
    LEFT JOIN users u ON u.id = wc.user_id
    WHERE regexp_replace(coalesce(wc.phone_number, ''), '\\D', '', 'g') IN (
      SELECT regexp_replace(coalesce(c.contact_number, ''), '\\D', '', 'g')
      FROM conversations c WHERE c.id = $1
    )
    ORDER BY wc.updated_at DESC NULLS LAST
    LIMIT 20
  `, [conversationId]);
  await q("users_matching_phone_or_name", `
    SELECT id, email, name, phone, created_at, updated_at
    FROM users
    WHERE regexp_replace(coalesce(phone, ''), '\\D', '', 'g') IN (
      SELECT regexp_replace(coalesce(c.contact_number, ''), '\\D', '', 'g')
      FROM conversations c WHERE c.id = $1
    )
       OR lower(coalesce(name, '')) LIKE '%seguratech%'
       OR lower(coalesce(email, '')) LIKE '%seguratech%'
    ORDER BY updated_at DESC NULLS LAST
    LIMIT 20
  `, [conversationId]);
  await q("recent_conversations_same_contact", `
    SELECT c.id, u.email AS owner_email, c.contact_name, c.contact_number, c.last_message_text,
           c.last_message_from_me, c.updated_at
    FROM conversations c
    JOIN whatsapp_connections wc ON wc.id = c.connection_id
    LEFT JOIN users u ON u.id = wc.user_id
    WHERE regexp_replace(coalesce(c.contact_number, ''), '\\D', '', 'g') IN (
      SELECT regexp_replace(coalesce(contact_number, ''), '\\D', '', 'g')
      FROM conversations WHERE id = $1
    )
    ORDER BY c.updated_at DESC
    LIMIT 20
  `, [conversationId]);
  await client.end();
})().catch(async (error) => {
  console.error("CONV18_LOOKUP2_FATAL", error);
  try { await client.end(); } catch {}
  process.exit(1);
});
NODE
echo "CONV18_LOOKUP2_END"
