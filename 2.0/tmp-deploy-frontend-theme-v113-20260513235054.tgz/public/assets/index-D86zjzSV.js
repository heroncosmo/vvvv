import{r as i}from"./main-C64hjbZ2.js";import"./index-C8OQYYna.js";const r=i("PushNotifications",{});export{r as PushNotifications};
