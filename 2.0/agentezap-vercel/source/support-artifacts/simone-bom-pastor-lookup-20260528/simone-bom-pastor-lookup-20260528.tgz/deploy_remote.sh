#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

async function q(client, text, params = []) {
  const result = await client.query(text, params);
  return result.rows;
}

(async () => {
  const client = await pool.connect();
  try {
    const targetPhone = "5519996766301";
    const targetPhoneLocal = "19996766301";
    const targetTerms = ["%simone%", "%bom pastor%", "%souza viana%", "%19996766301%", "%5519996766301%"];

    const users = await q(
      client,
      `
        SELECT id, email, name, phone, whatsapp_number, assigned_plan_id, business_type, created_at, updated_at
          FROM users
         WHERE lower(coalesce(email,'')) LIKE ANY($1)
            OR lower(coalesce(name,'')) LIKE ANY($1)
            OR regexp_replace(coalesce(phone,''), '\\D', '', 'g') IN ($2, $3)
            OR regexp_replace(coalesce(whatsapp_number,''), '\\D', '', 'g') IN ($2, $3)
         ORDER BY updated_at DESC NULLS LAST, created_at DESC NULLS LAST
         LIMIT 40
      `,
      [targetTerms, targetPhone, targetPhoneLocal],
    );

    const userIds = users.map((u) => u.id);
    const subscriptionsByUser = userIds.length
      ? await q(
          client,
          `
            SELECT s.id, s.user_id, u.email, u.name, s.status, s.pending_receipt, s.coupon_price,
                   s.payment_method, s.payer_email, s.data_inicio, s.data_fim, s.next_payment_date,
                   s.created_at, s.updated_at, p.nome AS plan_name, p.preco AS plan_price
              FROM subscriptions s
              LEFT JOIN users u ON u.id = s.user_id
              LEFT JOIN plans p ON p.id = s.plan_id
             WHERE s.user_id = ANY($1)
             ORDER BY s.created_at DESC
          `,
          [userIds],
        )
      : [];

    const recent99Subscriptions = await q(
      client,
      `
        SELECT s.id, s.user_id, u.email, u.name, u.phone, u.whatsapp_number,
               s.status, s.pending_receipt, s.coupon_price, s.payment_method,
               s.payer_email, s.data_inicio, s.data_fim, s.next_payment_date,
               s.created_at, s.updated_at, p.nome AS plan_name, p.preco AS plan_price
          FROM subscriptions s
          LEFT JOIN users u ON u.id = s.user_id
          LEFT JOIN plans p ON p.id = s.plan_id
         WHERE s.created_at >= timestamp '2026-05-26 00:00:00'
           AND (
             s.coupon_price::numeric BETWEEN 99 AND 100
             OR p.preco::numeric BETWEEN 99 AND 100
             OR lower(coalesce(p.nome,'')) LIKE '%configurada%'
           )
         ORDER BY s.created_at DESC
         LIMIT 80
      `,
    );

    const receipts = await q(
      client,
      `
        SELECT pr.id, pr.user_id, u.email, u.name, u.phone, u.whatsapp_number,
               pr.subscription_id, pr.plan_id, pr.amount, pr.status,
               pr.reviewed_at, pr.review_notes, pr.created_at, pr.updated_at,
               s.status AS subscription_status, s.pending_receipt, s.coupon_price,
               p.nome AS plan_name, p.preco AS plan_price
          FROM payment_receipts pr
          LEFT JOIN users u ON u.id = pr.user_id
          LEFT JOIN subscriptions s ON s.id = pr.subscription_id
          LEFT JOIN plans p ON p.id = coalesce(pr.plan_id, s.plan_id)
         WHERE pr.created_at >= timestamp '2026-05-26 00:00:00'
           AND (
             pr.amount::numeric BETWEEN 99 AND 100
             OR lower(coalesce(u.name,'')) LIKE ANY($1)
             OR lower(coalesce(u.email,'')) LIKE ANY($1)
             OR regexp_replace(coalesce(u.phone,''), '\\D', '', 'g') IN ($2, $3)
             OR regexp_replace(coalesce(u.whatsapp_number,''), '\\D', '', 'g') IN ($2, $3)
           )
         ORDER BY pr.created_at DESC
         LIMIT 100
      `,
      [targetTerms, targetPhone, targetPhoneLocal],
    );

    const conversationTags = await q(
      client,
      `
        SELECT c.id AS conversation_id, t.name, t.color, ct.created_at
          FROM conversations c
          LEFT JOIN conversation_tags ct ON ct.conversation_id = c.id
          LEFT JOIN tags t ON t.id = ct.tag_id
         WHERE c.id = '0b98d398-3162-4e98-9200-33c7dfd5623e'
         ORDER BY ct.created_at DESC
      `,
    ).catch((error) => [{ error: error.message }]);

    console.log(JSON.stringify({
      ok: true,
      target: { phone: targetPhone, name: "Simone / Bom Pastor" },
      users,
      subscriptionsByUser,
      recent99Subscriptions,
      receipts,
      conversationTags,
    }, null, 2));
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
