#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const userId = "48a35b8d-9155-4393-ad5d-c5020a9c1dc2";
const targetSubscriptionId = "9e21f387-12b7-49b1-bc83-b0312516b654";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

(async () => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const target = await client.query(
      `UPDATE subscriptions
          SET coupon_price = 49.99,
              status = 'expired',
              pending_receipt = false,
              updated_at = now()
        WHERE id = $1
          AND user_id = $2
        RETURNING id, user_id, status, coupon_price, data_inicio, data_fim, next_payment_date`,
      [targetSubscriptionId, userId],
    );

    const cancelled = await client.query(
      `UPDATE subscriptions
          SET status = 'cancelled',
              updated_at = now()
        WHERE user_id = $1
          AND id <> $2
          AND status IN ('pending', 'pending_pix')
        RETURNING id, status, created_at`,
      [userId, targetSubscriptionId],
    );

    await client.query("COMMIT");

    const subscriptions = await client.query(
      `SELECT s.id, s.status, s.coupon_price, s.data_inicio, s.data_fim,
              s.next_payment_date, s.pending_receipt, s.created_at, s.updated_at,
              p.nome AS plan_name
         FROM subscriptions s
         LEFT JOIN plans p ON p.id = s.plan_id
        WHERE s.user_id = $1
        ORDER BY s.created_at DESC`,
      [userId],
    );

    console.log(JSON.stringify({
      ok: true,
      target: target.rows[0] || null,
      cancelled: cancelled.rows,
      subscriptions: subscriptions.rows,
    }, null, 2));
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
