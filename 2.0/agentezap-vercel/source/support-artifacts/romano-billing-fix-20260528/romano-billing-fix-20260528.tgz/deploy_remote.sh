#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const userId = "d8cc1698-b846-437a-9b64-eaa3381ba455";
const targetSubscriptionId = "78a00324-6e14-421d-bfae-7997c6093b67";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

(async () => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const target = await client.query(
      `UPDATE subscriptions
          SET coupon_price = 99.99,
              status = 'expired',
              pending_receipt = false,
              updated_at = now()
        WHERE id = $1
          AND user_id = $2
        RETURNING id, user_id, status, coupon_price, data_inicio, data_fim, next_payment_date`,
      [targetSubscriptionId, userId],
    );

    const cancelled = await client.query(
      `UPDATE subscriptions
          SET status = 'cancelled',
              updated_at = now()
        WHERE user_id = $1
          AND id <> $2
          AND status IN ('pending', 'pending_pix')
        RETURNING id, status, created_at`,
      [userId, targetSubscriptionId],
    );

    await client.query("COMMIT");

    console.log(JSON.stringify({
      ok: true,
      target: target.rows[0] || null,
      cancelled: cancelled.rows,
    }, null, 2));
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
