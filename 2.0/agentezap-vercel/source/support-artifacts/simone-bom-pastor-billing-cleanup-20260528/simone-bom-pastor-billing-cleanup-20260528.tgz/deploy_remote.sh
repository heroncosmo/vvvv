#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

(async () => {
  const userId = "24d420bc-da8c-466b-8a6d-041143ef2af1";
  const subscriptionId = "f4672c86-2460-4e67-9341-28f848dbdc92";
  const receiptId = "3b129d96-8bb2-480e-bc6a-a6248165b0ea";
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const receipt = await client.query(
      `
        UPDATE payment_receipts
           SET status = 'approved',
               reviewed_at = COALESCE(reviewed_at, NOW()),
               admin_notes = trim(coalesce(admin_notes, '') || CASE WHEN coalesce(admin_notes, '') = '' THEN '' ELSE E'\n' END || $4),
               updated_at = NOW()
         WHERE id = $1
           AND user_id = $2
           AND subscription_id = $3
         RETURNING id, user_id, subscription_id, amount, status, reviewed_at
      `,
      [receiptId, userId, subscriptionId, "Comprovante de R$99,99 conferido na conversa de suporte em 27/05/2026."],
    );

    const activeSubscription = await client.query(
      `
        UPDATE subscriptions
           SET status = 'active',
               pending_receipt = false,
               data_inicio = COALESCE(data_inicio, timestamp '2026-05-27 13:03:09.994'),
               data_fim = COALESCE(data_fim, timestamp '2026-06-26 13:03:09.994'),
               next_payment_date = COALESCE(next_payment_date, timestamp '2026-06-26 13:03:09.994'),
               updated_at = NOW()
         WHERE id = $1
           AND user_id = $2
         RETURNING id, user_id, status, pending_receipt, coupon_price, data_inicio, data_fim, next_payment_date
      `,
      [subscriptionId, userId],
    );

    const cancelledDuplicates = await client.query(
      `
        UPDATE subscriptions
           SET status = 'cancelled',
               updated_at = NOW(),
               metadata = COALESCE(metadata, '{}'::jsonb) || jsonb_build_object(
                 'cancelled_reason', 'duplicate_pending_pix_after_manual_receipt_approved',
                 'active_subscription_id', $1,
                 'cleanup_at', NOW()
               )
         WHERE user_id = $2
           AND id <> $1
           AND status IN ('pending', 'pending_pix')
         RETURNING id, status, coupon_price, created_at
      `,
      [subscriptionId, userId],
    );

    await client.query("COMMIT");
    console.log(JSON.stringify({
      ok: true,
      receipt: receipt.rows,
      activeSubscription: activeSubscription.rows,
      cancelledDuplicates: cancelledDuplicates.rows,
    }, null, 2));
  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
})();
NODE
