#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const conversationId = "52ca1e0c-946e-4253-a1ce-9862bf0ff2f6";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

(async () => {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `UPDATE conversations
          SET needs_human_attention = false,
              attention_reason = null,
              attention_confidence = null,
              attention_qualified_at = null,
              unread_count = 0,
              updated_at = now()
        WHERE id = $1
        RETURNING id, last_message_from_me, unread_count, needs_human_attention, followup_active, updated_at`,
      [conversationId],
    );
    console.log(JSON.stringify({ ok: true, conversation: result.rows[0] || null }, null, 2));
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
