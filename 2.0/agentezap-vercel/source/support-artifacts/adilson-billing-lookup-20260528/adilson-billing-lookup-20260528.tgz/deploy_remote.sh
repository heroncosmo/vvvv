#!/usr/bin/env bash
set -euo pipefail

app_container="$(docker ps --format '{{.Names}}' | grep -E 'agentezap.*app|app' | head -n 1)"
if [ -z "$app_container" ]; then
  echo "app container not found" >&2
  docker ps --format '{{.Names}}'
  exit 1
fi

docker exec -i "$app_container" node <<'NODE'
const { Pool } = require("pg");

const conversationId = "52ca1e0c-946e-4253-a1ce-9862bf0ff2f6";
const phone = "5519981645236";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || process.env.DATABASE_URL_DIRECT,
  ssl: { rejectUnauthorized: false },
  max: 1,
});

(async () => {
  const client = await pool.connect();
  try {
    const conversation = await client.query(
      `SELECT c.id, c.connection_id, c.contact_number, c.remote_jid, c.contact_name,
              c.last_message_text, c.last_message_time, c.last_message_from_me,
              c.unread_count, c.needs_human_attention, c.followup_active,
              wc.user_id AS owner_user_id, wc.phone_number AS owner_connection_phone,
              u.email AS owner_email, u.name AS owner_name
         FROM conversations c
         LEFT JOIN whatsapp_connections wc ON wc.id = c.connection_id
         LEFT JOIN users u ON u.id = wc.user_id
        WHERE c.id = $1`,
      [conversationId],
    );

    const users = await client.query(
      `SELECT u.id, u.email, u.name, u.phone, u.whatsapp_number, u.created_at,
              p.nome AS active_plan_name,
              s.id AS active_subscription_id,
              s.status AS active_subscription_status,
              s.coupon_price AS active_coupon_price,
              s.data_inicio AS active_data_inicio,
              s.data_fim AS active_data_fim,
              s.next_payment_date AS active_next_payment_date,
              s.pending_receipt AS active_pending_receipt
         FROM users u
         LEFT JOIN LATERAL (
           SELECT s.*
             FROM subscriptions s
            WHERE s.user_id = u.id
            ORDER BY
              CASE WHEN s.status = 'active' THEN 0 WHEN s.status IN ('pending_pix','pending') THEN 1 ELSE 2 END,
              COALESCE(s.updated_at, s.created_at) DESC,
              s.id DESC
            LIMIT 1
         ) s ON true
         LEFT JOIN plans p ON p.id = s.plan_id
        WHERE regexp_replace(coalesce(u.phone, ''), '\\D', '', 'g') LIKE $1
           OR regexp_replace(coalesce(u.whatsapp_number, ''), '\\D', '', 'g') LIKE $1
           OR lower(coalesce(u.name, '')) LIKE '%adilson%'
           OR lower(coalesce(u.email, '')) LIKE '%adilson%'
        ORDER BY u.created_at DESC
        LIMIT 20`,
      [`%${phone.slice(-8)}`],
    );

    const userIds = users.rows.map((row) => row.id);
    let subscriptions = { rows: [] };
    let payments = { rows: [] };
    let receipts = { rows: [] };
    if (userIds.length > 0) {
      subscriptions = await client.query(
        `SELECT s.id, s.user_id, u.email, u.name, p.nome AS plan_name,
                s.status, s.coupon_price, s.created_at, s.updated_at,
                s.data_inicio, s.data_fim, s.next_payment_date, s.pending_receipt,
                s.payment_method, s.metadata
           FROM subscriptions s
           LEFT JOIN users u ON u.id = s.user_id
           LEFT JOIN plans p ON p.id = s.plan_id
          WHERE s.user_id = ANY($1::text[])
          ORDER BY s.created_at DESC`,
        [userIds],
      );
      payments = await client.query(
        `SELECT ph.id, ph.user_id, ph.subscription_id, ph.amount, ph.status,
                ph.payment_method, ph.mp_payment_id, ph.created_at, ph.updated_at, ph.metadata
           FROM payment_history ph
          WHERE ph.user_id = ANY($1::text[])
             OR ph.subscription_id IN (SELECT id FROM subscriptions WHERE user_id = ANY($1::text[]))
          ORDER BY ph.created_at DESC
          LIMIT 30`,
        [userIds],
      );
      receipts = await client.query(
        `SELECT pr.id, pr.user_id, pr.subscription_id, pr.amount, pr.status,
                pr.created_at, pr.updated_at, pr.approved_at, pr.payer_name,
                pr.payer_document, pr.payment_date, pr.notes
           FROM payment_receipts pr
          WHERE pr.user_id = ANY($1::text[])
             OR pr.subscription_id IN (SELECT id FROM subscriptions WHERE user_id = ANY($1::text[]))
          ORDER BY pr.created_at DESC
          LIMIT 30`,
        [userIds],
      );
    }

    console.log(JSON.stringify({
      ok: true,
      conversation: conversation.rows[0] || null,
      users: users.rows,
      subscriptions: subscriptions.rows,
      payments: payments.rows,
      receipts: receipts.rows,
    }, null, 2));
  } finally {
    client.release();
    await pool.end();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
NODE
